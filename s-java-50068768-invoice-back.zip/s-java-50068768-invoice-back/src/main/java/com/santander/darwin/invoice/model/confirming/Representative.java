package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Representative.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Representative {
	// Datos de Representative
	private Object representatives;
	private Object confirmingOperation;
	private CustomerRepresentative customer;
}