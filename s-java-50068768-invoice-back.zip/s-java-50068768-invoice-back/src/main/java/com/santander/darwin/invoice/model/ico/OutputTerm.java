package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * The Class OperationsPanel.
 */

@Setter
@Getter
@NoArgsConstructor
public class OutputTerm {
	
	/** The list operations panel. */
	private List<LoanSubsidyList> loanSubsidyList;
	/**
	 * The Class OperationsPanel.
	 */
}
