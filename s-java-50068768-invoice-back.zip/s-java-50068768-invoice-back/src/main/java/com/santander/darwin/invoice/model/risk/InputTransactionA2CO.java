package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * InputTransactionA2CO.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputTransactionA2CO {

	private BigDecimal aaa;
	private BigDecimal ccentro;
	private BigDecimal cempresa;
	private BigDecimal cnumeric;
	private String codmonbe;
	private String codmonsw;
	private String coestref;
	private String condstd;
	private String csubtipr;
	private Date fechvtoc;
	private String idcent;
	private String idcentc;
	private String idcontcc;
	private String idcontnu;
	private String idcontr;
	private String idcontrc;
	private String idempr;
	private String idemprc;
	private String idprod;
	private String idprod2;
	private String idsubgr;
	private String idsubgrc;
	private BigDecimal impabonc;
	private BigDecimal impamrt;
	private BigDecimal plazodoc;
	private BigDecimal pnplazo;
	private String tipforma;

}
