package com.santander.darwin.invoice.model.model200;

import com.santander.darwin.invoice.model.CommonInformation;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * PersonalData.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class PersonalData {

	// Variables

	// Email
	@NotNull
	@Email
	private String email;
	// Movil
	@NotNull
	private CommonInformation mobilePhone;

	//Mails
	private List<Email200> moreEmails;

}
