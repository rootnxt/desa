package com.santander.darwin.invoice.model.orientados;

/**
 * OrientadoInput.java
 *
 * @author igndom
 *
 */
public class OrientadoInput {

	private String acodcamp;
	private String canalpre;
	private String cfamilia;
	private String codpers;
	private String fechaConsulta;
	private String idempr;
	private String tipopers;

	/**
	 * @return the acodcamp
	 */
	public String getAcodcamp() {
		return acodcamp;
	}

	/**
	 * @param acodcamp the acodcamp to set
	 */
	public void setAcodcamp(String acodcamp) {
		this.acodcamp = acodcamp;
	}

	/**
	 * @return the canalpre
	 */
	public String getCanalpre() {
		return canalpre;
	}

	/**
	 * @param canalpre the canalpre to set
	 */
	public void setCanalpre(String canalpre) {
		this.canalpre = canalpre;
	}

	/**
	 * @return the cfamilia
	 */
	public String getCfamilia() {
		return cfamilia;
	}

	/**
	 * @param cfamilia the cfamilia to set
	 */
	public void setCfamilia(String cfamilia) {
		this.cfamilia = cfamilia;
	}

	/**
	 * @return the codpers
	 */
	public String getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(String codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the fechaConsulta
	 */
	public String getFechaConsulta() {
		return fechaConsulta;
	}

	/**
	 * @param fechaConsulta the fechaConsulta to set
	 */
	public void setFechaConsulta(String fechaConsulta) {
		this.fechaConsulta = fechaConsulta;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}

}
