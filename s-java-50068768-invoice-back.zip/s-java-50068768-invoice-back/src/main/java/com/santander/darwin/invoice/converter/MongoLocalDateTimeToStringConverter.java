package com.santander.darwin.invoice.converter;

import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import org.springframework.core.convert.converter.Converter;

import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * MongoLocalDateTimeToStringConverter
 * 
 * @author igndom
 *
 */
public class MongoLocalDateTimeToStringConverter implements Converter<MongoLocalDateTime, String> {

	@Override
	public String convert(MongoLocalDateTime source) {
		// Convertidor custom de mongo a string
		return MongoLocalDateTime.DATE_FORMATTER.format(ZonedDateTime.of(source.toLocalDateTime(), ZoneId.of("GMT")));
	}
}
