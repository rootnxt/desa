/**
 * 
 */
package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.santander.darwin.invoice.model.pmp.InputNextPmp;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * InvoiceInit
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class InvoiceInit {

	/** The operationId. */
	private String operationId;

	/** The app. */
	private String app;

	/** The device. */
	private String device;

	/** The code. */
	private String code;

	/** The langStandard. */
	private String langStandard;

	/** The limitsone. */
	private boolean limitsone;

	/** The limitsPage. */
	private boolean limitsPage;
	
	// Pymes

	/** The family. */
	private String family;

	/** The name. */
	private String name;

	/** The name. */
	private String internalName;

	/** The finance. */
	private BigDecimal finance;

	/** The amountMax. */
	@JsonIgnore
	private BigDecimal amountMax;

	/** The amountMin. */
	@JsonIgnore
	private BigDecimal amountMin;
	
	// Lo utilizamos para controlar si es pymes

	/** The limitsLimits. */
	@JsonIgnore
	private boolean limitsLimits;

	/** The oriented. */
	@JsonIgnore
	private boolean oriented;

	/** The precon. */
	@JsonIgnore
	private boolean precon;

	/** The p2. */
	@JsonIgnore
	private boolean p2;

	/** The currency. */
	@JsonIgnore
	private String currency;

	/** The products. */
	@JsonIgnore
	private List<String> products;
	
	// Plazo

	/** The months. */
	private int months;

	/** The inputNextPmp. */
	private InputNextPmp inputNextPmp;

	/** The policyNumber. */
	private String policyNumber;

	/** The group. */
	private String group;
	
	// Se añaden los dos campos nuevos de entrada
	/** The personType. */
	private String personType;
	
	/** The personCode. */
	private String personCode;

	// Número de empleado
	private String employed;
	
	// PMP MVP2
	/** the codseg. */
	private String codseg;
	
	/** the dessegas. */
	private String dessegas;
	
	// END PMP MVP2
}
