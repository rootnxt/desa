package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputSat002055.java
 *
 * @author igndom
 *
 */
public class InputSat002055 {

	private List<String> a1tipcir;
	private List<BigDecimal> codpers;
	private List<String> idcent;
	private List<String> idempr;
	private List<String> tipopers;
	private List<String> cdfinalo;
	private List<String> indfactu;
	private List<String> anroempe;

	/**
	 * @return the a1tipcir
	 */
	public List<String> getA1tipcir() {
		return a1tipcir;
	}

	/**
	 * @param a1tipcir the a1tipcir to set
	 */
	public void setA1tipcir(List<String> a1tipcir) {
		this.a1tipcir = a1tipcir;
	}

	/**
	 * @return the codpers
	 */
	public List<BigDecimal> getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(List<BigDecimal> codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the idcent
	 */
	public List<String> getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(List<String> idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public List<String> getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(List<String> idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the tipopers
	 */
	public List<String> getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(List<String> tipopers) {
		this.tipopers = tipopers;
	}

	/**
	 * @return the cdfinalo
	 */
	public List<String> getCdfinalo() {
		return cdfinalo;
	}

	/**
	 * @param cdfinalo the cdfinalo to set
	 */
	public void setCdfinalo(List<String> cdfinalo) {
		this.cdfinalo = cdfinalo;
	}

	/**
	 * @return the indfactu
	 */
	public List<String> getIndfactu() {
		return indfactu;
	}

	/**
	 * @param indfactu the indfactu to set
	 */
	public void setIndfactu(List<String> indfactu) {
		this.indfactu = indfactu;
	}

	/**
	 * @return the anroempe
	 */
	public List<String> getAnroempe() {
		return anroempe;
	}

	/**
	 * @param anroempe the anroempe to set
	 */
	public void setAnroempe(List<String> anroempe) {
		this.anroempe = anroempe;
	}

}
