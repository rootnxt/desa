package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * AccountRefinancing.java
 *
 * @author igndom
 *
 */
public class AccountRefinancing extends CommonRefinancing {

	private String irregularEntryDate;
	private Balances balances;

	/**
	 * @return the irregularEntryDate
	 */
	public String getIrregularEntryDate() {
		return irregularEntryDate;
	}

	/**
	 * @param irregularEntryDate the irregularEntryDate to set
	 */
	public void setIrregularEntryDate(String irregularEntryDate) {
		this.irregularEntryDate = irregularEntryDate;
	}

	/**
	 * @return the balances
	 */
	public Balances getBalances() {
		return balances;
	}

	/**
	 * @param balances the balances to set
	 */
	public void setBalances(Balances balances) {
		this.balances = balances;
	}

}
