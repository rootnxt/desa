package com.santander.darwin.invoice.model;

/**
 * Entrada el codigo de persona
 * 
 * @author josdon
 *
 */
public class ClientLocationInput {
	private String coddocfi;
	private String tipdocfi;
	private String tiplocal;
	
	
	
	
	/**
	 * Constructor
	 */
	public ClientLocationInput() {
		super();
	}


	/**
	 * Constructor de la clase
	 * 
	 * @param tipdocfi tipo de documento
	 * @param coddocfi codigo de documento
	 * @param tiplocal tipo
	 */
	public ClientLocationInput(String tipdocfi, String coddocfi, String tiplocal) {
		super();
		this.coddocfi = coddocfi;
		this.tipdocfi = tipdocfi;
		this.tiplocal = tiplocal;
	}

	/**
	 * @return the coddocfi
	 */
	public String getCoddocfi() {
		return coddocfi;
	}


	/**
	 * @param coddocfi the coddocfi to set
	 */
	public void setCoddocfi(String coddocfi) {
		this.coddocfi = coddocfi;
	}


	/**
	 * @return the tipdocfi
	 */
	public String getTipdocfi() {
		return tipdocfi;
	}


	/**
	 * @param tipdocfi the tipdocfi to set
	 */
	public void setTipdocfi(String tipdocfi) {
		this.tipdocfi = tipdocfi;
	}


	/**
	 * @return the tiplocal
	 */
	public String getTiplocal() {
		return tiplocal;
	}


	/**
	 * @param tiplocal the tiplocal to set
	 */
	public void setTiplocal(String tiplocal) {
		this.tiplocal = tiplocal;
	}
	
	
}
