package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SencolMotorResponseDTO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the sencol motor response DTO
 */
@Builder

/**
 * Instantiates a new sencol motor response DTO.
 */
@NoArgsConstructor

/**
 * Instantiates a new sencol motor response DTO.
 *
 * @param proposalResponse the proposal response
 * @param isValid the is valid
 * @param errorCode the error code
 * @param errorMessage the error message
 */
@AllArgsConstructor
public class SencolMotorResponseDTO {

    /** The proposal response. */
    private SencolMotorProposalResponse proposalResponse;
    
    /** The is valid. */
    private Boolean isValid;
    
    /** The error code. */
    private String errorCode;
    
    /** The error message. */
    private String errorMessage;
}
