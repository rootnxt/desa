package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * The RepDetails model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor
public class RepDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The contract. */
	private Contract contract;

    /** The order. */
    private BigDecimal order;

    /**
     * Gets the RepDetails object.
     *
     * @param repDetails the repDetails.
     *
     * @return RepDetails returns the RepDetails Object.
     */
    public RepDetails (RepDetails repDetails) {
        this.contract = repDetails.contract;
        this.order = repDetails.order;
    }

}
