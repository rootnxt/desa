//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.24 a las 09:57:53 PM EDT 
//


package es.santander.darwin.financiaciondigital.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para sourcesVO complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="sourcesVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sourceType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sourceState" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="criticalityOfIntervener" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="newAccreditedIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="numberOfSourcePetitions" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="responseCodeOfExternalSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="responseDescriptionOfExternalSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="admissionDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="modificationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="modificationUser" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sourcesVO", propOrder = {
    "sourceType",
    "sourceState",
    "criticalityOfIntervener",
    "newAccreditedIndicator",
    "numberOfSourcePetitions",
    "responseCodeOfExternalSource",
    "responseDescriptionOfExternalSource",
    "admissionDate",
    "modificationDate",
    "modificationUser"
})
public class SourcesVO {

    @XmlElement(required = true)
    protected String sourceType;
    @XmlElement(required = true)
    protected String sourceState;
    @XmlElement(required = true)
    protected String criticalityOfIntervener;
    @XmlElement(required = true)
    protected String newAccreditedIndicator;
    protected int numberOfSourcePetitions;
    @XmlElement(required = true)
    protected String responseCodeOfExternalSource;
    @XmlElement(required = true)
    protected String responseDescriptionOfExternalSource;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar admissionDate;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar modificationDate;
    @XmlElement(required = true)
    protected String modificationUser;

    /**
     * Obtiene el valor de la propiedad sourceType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceType() {
        return sourceType;
    }

    /**
     * Define el valor de la propiedad sourceType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceType(String value) {
        this.sourceType = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceState() {
        return sourceState;
    }

    /**
     * Define el valor de la propiedad sourceState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceState(String value) {
        this.sourceState = value;
    }

    /**
     * Obtiene el valor de la propiedad criticalityOfIntervener.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCriticalityOfIntervener() {
        return criticalityOfIntervener;
    }

    /**
     * Define el valor de la propiedad criticalityOfIntervener.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCriticalityOfIntervener(String value) {
        this.criticalityOfIntervener = value;
    }

    /**
     * Obtiene el valor de la propiedad newAccreditedIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewAccreditedIndicator() {
        return newAccreditedIndicator;
    }

    /**
     * Define el valor de la propiedad newAccreditedIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewAccreditedIndicator(String value) {
        this.newAccreditedIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad numberOfSourcePetitions.
     * 
     */
    public int getNumberOfSourcePetitions() {
        return numberOfSourcePetitions;
    }

    /**
     * Define el valor de la propiedad numberOfSourcePetitions.
     * 
     */
    public void setNumberOfSourcePetitions(int value) {
        this.numberOfSourcePetitions = value;
    }

    /**
     * Obtiene el valor de la propiedad responseCodeOfExternalSource.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseCodeOfExternalSource() {
        return responseCodeOfExternalSource;
    }

    /**
     * Define el valor de la propiedad responseCodeOfExternalSource.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseCodeOfExternalSource(String value) {
        this.responseCodeOfExternalSource = value;
    }

    /**
     * Obtiene el valor de la propiedad responseDescriptionOfExternalSource.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseDescriptionOfExternalSource() {
        return responseDescriptionOfExternalSource;
    }

    /**
     * Define el valor de la propiedad responseDescriptionOfExternalSource.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseDescriptionOfExternalSource(String value) {
        this.responseDescriptionOfExternalSource = value;
    }

    /**
     * Obtiene el valor de la propiedad admissionDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAdmissionDate() {
        return admissionDate;
    }

    /**
     * Define el valor de la propiedad admissionDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAdmissionDate(XMLGregorianCalendar value) {
        this.admissionDate = value;
    }

    /**
     * Obtiene el valor de la propiedad modificationDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModificationDate() {
        return modificationDate;
    }

    /**
     * Define el valor de la propiedad modificationDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModificationDate(XMLGregorianCalendar value) {
        this.modificationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad modificationUser.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModificationUser() {
        return modificationUser;
    }

    /**
     * Define el valor de la propiedad modificationUser.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModificationUser(String value) {
        this.modificationUser = value;
    }

}
