package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Loan.java
 *
 * @author igndom
 *
 */
public class Loan extends CommonRefinancing {

	private String dueDate;
	private Conditions conditions;
	private BalancesLoan balances;

	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return the conditions
	 */
	public Conditions getConditions() {
		return conditions;
	}

	/**
	 * @param conditions the conditions to set
	 */
	public void setConditions(Conditions conditions) {
		this.conditions = conditions;
	}

	/**
	 * @return the balances
	 */
	public BalancesLoan getBalances() {
		return balances;
	}

	/**
	 * @param balances the balances to set
	 */
	public void setBalances(BalancesLoan balances) {
		this.balances = balances;
	}

}
