package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the person code.
 *
 * @return the person code
 */
@Getter

/**
 * Sets the person code.
 *
 * @param personCode the new person code
 */
@Setter

/**
 * Instantiates a new limit input.
 */
@NoArgsConstructor
public class LimitInput {

    /** The person type. */
    private String personType;
    
    /** The person code. */
    private Integer personCode;

}
