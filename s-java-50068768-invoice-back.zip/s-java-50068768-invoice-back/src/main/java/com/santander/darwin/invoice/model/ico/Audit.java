package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Audit.
 */

/**
 * Sets the last update date.
 *
 * @param lastUpdateDate the new last update date
 */
@Setter

/**
 * Gets the last update date.
 *
 * @return the last update date
 */
@Getter

/**
 * Instantiates a new audit.
 */
@NoArgsConstructor
public class Audit {

	/** The last update user. */
	private String lastUpdateUser;
	
	/** The last update date. */
	private String lastUpdateDate;
}
