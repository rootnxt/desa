package com.santander.darwin.invoice.model.fioc;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Sets the codigo persona.
 *
 * @param codigoPersona the new codigo persona
 */
@Setter

/**
 * Gets the codigo persona.
 *
 * @return the codigo persona
 */
@Getter

/**
 * Instantiates a new person fioc.
 */
@NoArgsConstructor
public class PersonFioc{

	/** The tipo persona. */
	private String tipoPersona;
	
	/** The codigo persona. */
	private String codigoPersona;

}