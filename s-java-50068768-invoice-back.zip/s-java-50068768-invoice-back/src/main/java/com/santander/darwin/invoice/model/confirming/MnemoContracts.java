package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.Setter;

/**
 * MnemoContracts.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class MnemoContracts {

	// Codigos Mnemos y contrato
	private MnemoContract national;
	private MnemoContract international;
}
