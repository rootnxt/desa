package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * CommonType.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CommonType {

	/**The type */
	private String type;
	
	/**The description */
	private String description;
	
	/**The refer*/
	private String refer;
	private String codRefer;

	/**
	 * Constructor
	 *
	 */
	public CommonType() {
		super();
	}

	/**
	 * Constructor
	 *
	 * @param description String
	 */
	public CommonType(String description) {
		super();
		this.description = description;
	}

	/**
	 * Constructor
	 *
	 * @param type        String
	 * @param description String
	 */
	public CommonType(String type, String description) {
		super();
		this.type = type;
		this.description = description;
	}
	/**
	 * Constructor
	 *
	 * @param type        String
	 * @param description String
	 * @param refer       String
	 */
	public CommonType(String type, String description, String refer) {
		super();
		this.type = type;
		this.description = description;
		this.refer = refer;
	}
	/**
	 * Constructor
	 *
	 * @param type        String
	 * @param description String
	 * @param refer       String
	 * @param codRefer    String
	 */
	public CommonType(String type, String description, String refer, String codRefer) {
		super();
		this.type = type;
		this.description = description;
		this.refer = refer;
		this.codRefer = codRefer;
	}

}
