package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

import javax.xml.transform.dom.DOMResult;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.SoapFaultDetailElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.w3c.dom.Node;

import es.santander.darwin.common.ws.bean.ResourcesBean;
import es.santander.darwin.financiaciondigital.cwpola.ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLA;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLAResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAClient;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAService;
import es.santander.darwin.interceptor.service.EndPointSelectorService;
import es.santander.darwin.security.authentication.converter.TokenConverter;

/**
 * The Class DatosUsuarioLAServiceImplTest.
 */
public class DatosUsuarioLAServiceImplTest {

    /** The datos usuario LA client. */
    @Mock
    private DatosUsuarioLAClient datosUsuarioLAClient;

    /** The token converter. */
    @Mock
    private TokenConverter tokenConverter;

    /** The end point selector service. */
    @Mock
    private EndPointSelectorService endPointSelectorService;

    /** The datos usuario LA service. */
    @InjectMocks
    private DatosUsuarioLAService datosUsuarioLAService = new DatosUsuarioLAServiceImpl();

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }


    /**
     * Gets the user name test OK.
     *
     * @return the user name test OK
     * @throws Exception the exception
     */
    @Test
    public void getUserNameTestOK() throws Exception {

        DatosUsuarioLAResponse soapResponse = new DatosUsuarioLAResponse();
        ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType type =
                new ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType();
        type.setNombreUsuario("Vistor");
        soapResponse.setMethodResult(type);
        
        ReflectionTestUtils.setField(datosUsuarioLAService, "endpoint", "uwu");

        Authentication authentication = Mockito.mock(Authentication.class);
        // Mockito.whens() for your authorization object
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        doReturn("endpoint").when(endPointSelectorService).getEndPoint(any(ResourcesBean.class));
        doReturn("corporateToken").when(tokenConverter).getCorpToken();
        doReturn(soapResponse).when(datosUsuarioLAClient).executeSoapRequest(any(String.class),
                any(DatosUsuarioLA.class));

        String result = datosUsuarioLAService.getUserName("0049");
        assertNotNull(result);

    }


    /**
     * Gets the user name NOK.
     *
     * @return the user name NOK
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getUserNameNOK() throws Exception {

        DatosUsuarioLAResponse soapResponse = new DatosUsuarioLAResponse();
        ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType type =
                new ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType();
        type.setNombreUsuario("Vistor");
        soapResponse.setMethodResult(type);
        
        ReflectionTestUtils.setField(datosUsuarioLAService, "endpoint", "uwu");

        Authentication authentication = Mockito.mock(Authentication.class);
        // Mockito.whens() for your authorization object
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        doReturn("endpoint").when(endPointSelectorService).getEndPoint(any(ResourcesBean.class));
        doReturn("corporateToken").when(tokenConverter).getCorpToken();
        doThrow(EmptyStackException.class).when(datosUsuarioLAClient).executeSoapRequest(any(String.class),
                any(DatosUsuarioLA.class));

        String result = datosUsuarioLAService.getUserName("0049");
        assertNotNull(result);

    }


    /**
     * Gets the user name test NOK 2.
     *
     * @return the user name test NOK 2
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getUserNameTestNOK2() throws Exception {

        DatosUsuarioLAResponse soapResponse = new DatosUsuarioLAResponse();
        ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType type =
                new ComBanestoAlCwpolaCwpdatosusuarioLaFCbDatosUsuarioLASType();
        type.setNombreUsuario("Vistor");
        soapResponse.setMethodResult(type);
        
        ReflectionTestUtils.setField(datosUsuarioLAService, "endpoint", "uwu");

        Authentication authentication = Mockito.mock(Authentication.class);
        // Mockito.whens() for your authorization object
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        SoapFault soapFault = Mockito.mock(SoapFault.class);
        List<SoapFaultDetailElement> detailEntriesList = new ArrayList<>();
        detailEntriesList.add(Mockito.mock(SoapFaultDetailElement.class));
        detailEntriesList.add(Mockito.mock(SoapFaultDetailElement.class));
        DOMResult domResult = Mockito.mock(DOMResult.class);
        Mockito.when(detailEntriesList.get(0).getResult()).thenReturn(domResult);
        Mockito.when(detailEntriesList.get(1).getResult()).thenReturn(domResult);
        Node node = Mockito.mock(Node.class);
        Mockito.when(node.getTextContent()).thenReturn("");
        Mockito.when(domResult.getNode()).thenReturn(node);
        Mockito.when(soapFault.getFaultStringOrReason()).thenReturn("BE_0289");
        SoapFaultDetail detail = Mockito.mock(SoapFaultDetail.class);
        Mockito.when(soapFault.getFaultDetail()).thenReturn(detail);
        Mockito.when(detail.getDetailEntries()).thenReturn(detailEntriesList.iterator());
        SoapBody soapBody = Mockito.mock(SoapBody.class);
        Mockito.when(soapBody.getFault()).thenReturn(soapFault);

        SoapMessage soapMsg = Mockito.mock(SoapMessage.class);
        Mockito.when(soapMsg.getSoapBody()).thenReturn(soapBody);

        doReturn("endpoint").when(endPointSelectorService).getEndPoint(any(ResourcesBean.class));
        doReturn("corporateToken").when(tokenConverter).getCorpToken();
        doThrow(new SoapFaultClientException(soapMsg)).when(datosUsuarioLAClient).executeSoapRequest(any(String.class),
                any(DatosUsuarioLA.class));

        String result = datosUsuarioLAService.getUserName("0049");
        assertNotNull(result);

    }
}
