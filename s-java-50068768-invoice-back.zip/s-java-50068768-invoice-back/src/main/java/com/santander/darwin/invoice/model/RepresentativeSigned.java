package com.santander.darwin.invoice.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * RepresentativeSigned.java
 *
 * @author igndom
 *
 */
public class RepresentativeSigned {

	@NotNull(message = "DOCUMENTNUMBERNULL")
	@NotEmpty(message = "DOCUMENTNUMBEREMPTY")
	private String documentNumber;
	@NotNull(message = "NOMUSUARNULL")
	@NotEmpty(message = "NOMUSUAREMPTY")
	private String nomusuar;

	/**
	 * @return the documentNumber
	 */
	public String getDocumentNumber() {
		return documentNumber;
	}

	/**
	 * @param documentNumber the documentNumber to set
	 */
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	/**
	 * @return the nomusuar
	 */
	public String getNomusuar() {
		return nomusuar;
	}

	/**
	 * @param nomusuar the nomusuar to set
	 */
	public void setNomusuar(String nomusuar) {
		this.nomusuar = nomusuar;
	}

}
