package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * The OutputPersonData model class.
 *
 */
@Setter
@Getter
@NoArgsConstructor
public class OutputPersonData {
	/** customer contract list */
	List<CustomerContract> customerContractList;
	
	/** codperr. */
    int codperr;
    
    /** indice. */
    int indice;
    
    /** ordinter. */
    int ordinter;
    
    /** tipoperr. */
    String tipoperr;
}
