package com.santander.darwin.invoice.model.arm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * InfoOutputData
 * 
 * @author igndom
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "info_output_data", })
public class InfoOutputData {

	private String status;
	@JsonProperty("info_output_data")
	private String info;
	private String idOrigination;
	private String referenceImport;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the info
	 */
	public String getInfo() {
		return info;
	}

	/**
	 * @param info the info to set
	 */
	public void setInfo(String info) {
		this.info = info;
	}

	/**
	 * @return the idOrigination
	 */
	public String getIdOrigination() {
		return idOrigination;
	}

	/**
	 * @param idOrigination the idOrigination to set
	 */
	public void setIdOrigination(String idOrigination) {
		this.idOrigination = idOrigination;
	}

	/**
	 * @return the referenceImport
	 */
	public String getReferenceImport() {
		return referenceImport;
	}

	/**
	 * @param referenceImport the referenceImport to set
	 */
	public void setReferenceImport(String referenceImport) {
		this.referenceImport = referenceImport;
	}

}
