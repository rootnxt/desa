package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 
 * Salida de la consulta de atributos de catálogo de productos
 * 
 * @author x574726
 * 
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CatalogAttributesAndValuesOutput {

	/**
	 * 
	 * catalogAttributesAndValuesOut - List
	 * 
	 * Lista de valores de atributo de salida
	 * 
	 */
    private List<CatalogAttributeOutput> catalogAttributesAndValuesOut;
    
}
