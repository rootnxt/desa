package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Optional;

/**
 * Cards.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Card extends CommonRefinancing {

	//Atributos bloque 1
	private String pan;
	private BigDecimal limit;
	private BigDecimal drawnBalance;
	//Atributos bloque 2
	private Interest interest;
	private BigDecimal totalUnpaidAmount;
	//Atributos bloque 3
	private BigDecimal debtCapital;
	private BigDecimal debtInterestRate;
	private BigDecimal debtdFee;
	//Atributos bloque 4
	private String description;
	private String completeDescription;
	private boolean error;
	//Atributos bloque 5
	private BigDecimal nonSettledDebt;
	private BigDecimal settledDebt;
	private BigDecimal refinancedDebt;
	private BigDecimal debtCapitalAmount;
	//Atributos bloque 6
	private BigDecimal latePaymentInterest;
	private BigDecimal comissionAmount;
	private BigDecimal ordinaryDefaultInterest;
	private String contractType;
	private Date irregularEntryDate;

	/**
	 * getIrregularEntryDate
	 * @return Date
	 */
	public Date getIrregularEntryDate() {
		// Forma de obtener la fecha segura sonar
		return Optional.ofNullable(irregularEntryDate).map(Date::getTime).map(Date::new).orElse(null);
	}

	/** setIrregularEntryDate
	 * @param irregularEntryDate
	 */
	public void setIrregularEntryDate(Date irregularEntryDate) {
		// Forma de cambiar la fecha segura sonar
		this.irregularEntryDate = Optional.ofNullable(irregularEntryDate).map(Date::getTime).map(Date::new)
				.orElse(null);
	}

}
