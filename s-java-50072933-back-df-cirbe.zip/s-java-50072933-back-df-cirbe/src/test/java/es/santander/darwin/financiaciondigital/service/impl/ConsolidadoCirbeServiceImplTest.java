package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsolidadoDto;
import es.santander.darwin.financiaciondigital.domain.ConsolidadoResponse;
import es.santander.darwin.financiaciondigital.domain.ConsultaConsolidadoCirbeResponseVO;
import es.santander.darwin.financiaciondigital.domain.ListaRequest;
import es.santander.darwin.financiaciondigital.domain.ListaResumenRequest;
import es.santander.darwin.financiaciondigital.domain.ListaResumenResponse;
import es.santander.darwin.financiaciondigital.domain.Persona;
import es.santander.darwin.financiaciondigital.domain.SummaryCirbe;
import es.santander.darwin.financiaciondigital.domain.SummaryCirbeCods;
import es.santander.darwin.financiaciondigital.domain.SummaryImports;
import es.santander.darwin.financiaciondigital.service.ConsolidadoCirbeService;
import es.santander.darwin.financiaciondigital.service.RestConsolidadoService;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

/**
 * The Class ConsolidadoCirbeServiceImplTest.
 */
public class ConsolidadoCirbeServiceImplTest {

    /** The rest consolidado service. */
    @Mock
    private RestConsolidadoService restConsolidadoService;

    /** The Consolidado cirbe service. */
    @InjectMocks
    private ConsolidadoCirbeService ConsolidadoCirbeService = new ConsolidadoCirbeServiceImpl();

    /** The cirbe cods list. */
    @Spy
    private SummaryCirbeCods cirbeCodsList;
    
    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Call consolidado cirbe OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK() throws Exception {

        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "1");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "existeConsolidadoMismaFechaCirite", "1");
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 1.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK1() throws Exception {

        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "5");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "existeConsolidadoMismaFechaCirite", "1");
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }

    /**
     * Call consolidado cirbe OK 2.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK2() throws Exception {

        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "2");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "existeConsolidadoDistintaFechaCirite", "2");
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 3.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK3() throws Exception {

        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "3");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "noExisteConsolidado", "3");
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 4.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK4() throws Exception {
             
        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "4");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "microActivado", "4");
        
        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("100");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        request.setListaResumen(listaResumen);
        
        List<SummaryCirbe> cirbeCodsList2 = new ArrayList<>();
        SummaryCirbe summaryCirbe = new SummaryCirbe();
        summaryCirbe.setCode("A0001");
        summaryCirbe.setDescription("");
        cirbeCodsList2.add(summaryCirbe);
        cirbeCodsList.setCirbeCodsList(cirbeCodsList2);
        
        doReturn(consolidadoResponse).when(restConsolidadoService).callConsolidado(any(ListaResumenRequest.class));
        
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 5.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK5() throws Exception {
             
        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "4");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "microActivado", "4");
        
        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        request.setListaResumen(listaResumen);
        
        List<SummaryCirbe> cirbeCodsList2 = new ArrayList<>();
        SummaryCirbe summaryCirbe = new SummaryCirbe();
        summaryCirbe.setCode("A0001");
        summaryCirbe.setDescription("");
        cirbeCodsList2.add(summaryCirbe);
        cirbeCodsList.setCirbeCodsList(cirbeCodsList2);
        
        doReturn(consolidadoResponse).when(restConsolidadoService).callConsolidado(any(ListaResumenRequest.class));
        
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNotNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 6.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK6() throws Exception {
             
        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "4");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "microActivado", "4");
        
        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("101");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        request.setListaResumen(listaResumen);
        
        List<SummaryCirbe> cirbeCodsList2 = new ArrayList<>();
        SummaryCirbe summaryCirbe = new SummaryCirbe();
        summaryCirbe.setCode("A0001");
        summaryCirbe.setDescription("");
        cirbeCodsList2.add(summaryCirbe);
        cirbeCodsList.setCirbeCodsList(cirbeCodsList2);
        
        doReturn(consolidadoResponse).when(restConsolidadoService).callConsolidado(any(ListaResumenRequest.class));
        
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 7.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK7() throws Exception {
             
        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "4");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "microActivado", "4");
        
        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("102");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        request.setListaResumen(listaResumen);
        
        List<SummaryCirbe> cirbeCodsList2 = new ArrayList<>();
        SummaryCirbe summaryCirbe = new SummaryCirbe();
        summaryCirbe.setCode("A0001");
        summaryCirbe.setDescription("");
        cirbeCodsList2.add(summaryCirbe);
        cirbeCodsList.setCirbeCodsList(cirbeCodsList2);
        
        doReturn(consolidadoResponse).when(restConsolidadoService).callConsolidado(any(ListaResumenRequest.class));
        
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNull(result);
    }
    
    /**
     * Call consolidado cirbe OK 8.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoCirbeOK8() throws Exception {
             
        BasicPersonDataResponseVO sasnaDto = new BasicPersonDataResponseVO();
        sasnaDto.setCodPaisN("ES");
        sasnaDto.setDocumentCod("A1223333");

        ReflectionTestUtils.setField(ConsolidadoCirbeService, "mock", "4");
        ReflectionTestUtils.setField(ConsolidadoCirbeService, "microActivado", "4");
        
        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("A0001");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        request.setListaResumen(listaResumen);
        
        List<SummaryCirbe> cirbeCodsList2 = new ArrayList<>();
        SummaryCirbe summaryCirbe = new SummaryCirbe();
        summaryCirbe.setCode("A0001");
        summaryCirbe.setDescription("");
        cirbeCodsList2.add(summaryCirbe);
        cirbeCodsList.setCirbeCodsList(cirbeCodsList2);
        
        doReturn(consolidadoResponse).when(restConsolidadoService).callConsolidado(any(ListaResumenRequest.class));
        
        ConsultaConsolidadoCirbeResponseVO result = ConsolidadoCirbeService.callConsolidadoCirbe(sasnaDto);
        assertNull(result);
    }
}
