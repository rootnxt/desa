package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLA;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLAResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAClient;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

public class DatosUsuarioLAClientTest {

    @Mock
    private WebServiceTemplate webServiceTemplate;

    @InjectMocks
    private DatosUsuarioLAClient datosUsuarioLAClient;

    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeSoapRequestTestOK() throws Exception {

        DatosUsuarioLAResponse response = TestDataUtil.fillDummyObject(new DatosUsuarioLAResponse());
        DatosUsuarioLA request = new DatosUsuarioLA();

        doReturn(response).when(webServiceTemplate).marshalSendAndReceive(any(String.class),
                any(DatosUsuarioLA.class), any(SoapActionCallback.class));

        ReflectionTestUtils.setField(datosUsuarioLAClient, "soapAction", "uwu");

        DatosUsuarioLAResponse result = datosUsuarioLAClient.executeSoapRequest("endpoint", request);
        assertNotNull(result);

    }

    @Test(expected = DigitalConsumptionServiceException.class)
    public void handleErrorTestOK() throws Exception {

        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException(HttpStatus.REQUEST_TIMEOUT,
                ErrorMessagesConstants.ERROR_TIMEOUT_WEBSERVICETEMPLATE, ExceptionsErrorConstants.ERROR_CODE_TEMPORAL,
                ErrorMessagesConstants.ERROR_WEBSERVICE_TEMPLATE,
                new Throwable(ErrorMessagesConstants.TIMEOUT_EXCEPTION));
        e.getCause();

        datosUsuarioLAClient.handleError();

    }

}
