package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the data.
 *
 * @return the data
 */
@Getter

/**
 * Sets the data.
 *
 * @param data the new data
 */
@Setter

/**
 * Instantiates a new resume limit.
 */
@NoArgsConstructor
public class ResumeLimit {

    /** The data. */
    private ResumeDataLimit data;

}
