package com.santander.darwin.invoice.model.common;

import com.santander.darwin.invoice.model.ProductGen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * ProductCommon.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProductCommon extends ProductGen {

	// Variables tipologia
	private String typology;
	// subtypology
	private String subtypology;
	// subtypologyDig
	private String subtypologyDig;
	// Variables producto
	private String campaign;
	
	// Campañas de avalistas
	private String campaignGuarantors;
	private String family;
	
	 //Cuota única
    private boolean onlyFee;
    
    private List<CommonCsv> modelsCsv;
    
    //tags
    private String tags;
    private String segmento;
    
    // importe minimo slider
    private BigDecimal min; 
    private BigDecimal percentManager;
    
    //Limite para derivar a Oficina
    private BigDecimal limit;
    
    // Hoja solicitud para p1
    private boolean allowCirbePE1; 
    // Hoja solicitud para p2
    private boolean allowCirbePE2; 
    
    //flag traspaso a oficinas p1
    private boolean allowOfficePE1;
    
    // flag traspaso a oficinas p2
    private boolean allowOfficePE2;
    
    //flag contratacion usuarios PE1
    private boolean allowPE1;
    
    //flag contratacion usuarios PE2
    private boolean allowPE2;
    
    //PSD2
    private boolean psd2;
    private String prelationOrder;
    
	/** The durationSign. */
    private String durationSign;

}
