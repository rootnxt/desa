package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * RefinancerContract.java
 *
 * @author igndom
 *
 */
public class RefinancerContract {

	private String refinancerContractCompany;
	private String refinancerContractCenter;
	private String refinancerContractProduct;
	private String refinancerContractContract;
	

	/**
	 * @return the refinancerContractCompany
	 */
	public String getRefinancerContractCompany() {
		return refinancerContractCompany;
	}

	/**
	 * @param refinancerContractCompany the refinancerContractCompany to set
	 */
	public void setRefinancerContractCompany(String refinancerContractCompany) {
		this.refinancerContractCompany = refinancerContractCompany;
	}

	/**
	 * @return the refinancerContractCenter
	 */
	public String getRefinancerContractCenter() {
		return refinancerContractCenter;
	}

	/**
	 * @param refinancerContractCenter the refinancerContractCenter to set
	 */
	public void setRefinancerContractCenter(String refinancerContractCenter) {
		this.refinancerContractCenter = refinancerContractCenter;
	}

	/**
	 * @return the refinancerContractProduct
	 */
	public String getRefinancerContractProduct() {
		return refinancerContractProduct;
	}

	/**
	 * @param refinancerContractProduct the refinancerContractProduct to set
	 */
	public void setRefinancerContractProduct(String refinancerContractProduct) {
		this.refinancerContractProduct = refinancerContractProduct;
	}

	/**
	 * @return the refinancerContractContract
	 */
	public String getRefinancerContractContract() {
		return refinancerContractContract;
	}

	/**
	 * @param refinancerContractContract the refinancerContractContract to set
	 */
	public void setRefinancerContractContract(String refinancerContractContract) {
		this.refinancerContractContract = refinancerContractContract;
	}

	
}
