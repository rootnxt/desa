package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * FormalizedRequest.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class FormalizedRequest {

	// Variable de operationId
	// Para swagger
	@Schema(example = "7512000002013207", description = "Id of operation")
	@NotNull(message = "IVSIGNID")
	@NotEmpty(message = "IVSIGNIDEMPTY")
	@Size(message = "IVSIGNIDSIZE", min = 15, max = 32)
	private String operationId;

	// Variable representative
	@Schema(example = "", description = "List of representatives")
	private List<Person> representatives;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}
