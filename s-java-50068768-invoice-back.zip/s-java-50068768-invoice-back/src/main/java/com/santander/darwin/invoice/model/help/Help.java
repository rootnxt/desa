package com.santander.darwin.invoice.model.help;

/**
 * Help.java
 *
 * @author igndom
 *
 */
public class Help {

	private boolean show;
	private Doubts doubts;
	private Manager manager;

	/**
	 * @return the show
	 */
	public boolean isShow() {
		return show;
	}

	/**
	 * @param show the show to set
	 */
	public void setShow(boolean show) {
		this.show = show;
	}

	/**
	 * @return the doubts
	 */
	public Doubts getDoubts() {
		return doubts;
	}

	/**
	 * @param doubts the doubts to set
	 */
	public void setDoubts(Doubts doubts) {
		this.doubts = doubts;
	}

	/**
	 * @return the manager
	 */
	public Manager getManager() {
		return manager;
	}

	/**
	 * @param manager the manager to set
	 */
	public void setManager(Manager manager) {
		this.manager = manager;
	}

}
