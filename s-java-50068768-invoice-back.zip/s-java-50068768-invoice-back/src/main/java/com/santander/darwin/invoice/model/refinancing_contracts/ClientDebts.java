package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * ClientDebts.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ClientDebts extends Client {

	// Variables
	private List<Contract> contratos;

}
