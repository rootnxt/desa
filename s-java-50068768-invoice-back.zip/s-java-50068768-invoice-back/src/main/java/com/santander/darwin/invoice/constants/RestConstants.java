/**
 * 
 */
package com.santander.darwin.invoice.constants;

/**
 * RestConstants.
 *
 * @author josdon
 */
public class RestConstants {

	/** The Constant REST_PREFIX. */
	// Prefijos rest para las deprecadas
	public static final String REST_PREFIX = "/rest";
	
	/** The Constant REST_INVOICE_VALIDATION_OLD. */
	// PrevalidationController
	public static final String REST_INVOICE_VALIDATION_OLD = REST_PREFIX + "/validate";
	
	/** The Constant REST_INVOICE_VALIDATION. */
	public static final String REST_INVOICE_VALIDATION = "/v1/pre-validations";

	 /** The Constant REST_CREDIT_LIMIT_OLD. */
 	// InvoiceController
    public static final String REST_CREDIT_LIMIT_OLD = REST_PREFIX + "/limit/getCreditLimit";
    
    /** The Constant REST_CREDIT_LIMIT. */
    public static final String REST_CREDIT_LIMIT = "/v1/limit-clients";
    
    /** The Constant REST_INVOICE_INIT. */
    public static final String REST_INVOICE_INIT = "/v1/invoices/init";
    
    /** The Constant REST_INVOICE_INIT_OLD. */
    public static final String REST_INVOICE_INIT_OLD = "/rest/invoices/init";
    
    /** The Constant REST_INVOICE_ABANDON. */
    public static final String REST_INVOICE_ABANDON = "/v1/invoices/abandon/{operationId}/{stateFront}";
    
    /** The Constant REST_INVOICE_SIMULATION_NEW. */
    public static final String REST_INVOICE_SIMULATION_NEW = "/v1/invoices/simulation/new/{operationId}";
    
    /** The Constant REST_INVOICE_REGENERATE_TOKEN. */
    public static final String REST_INVOICE_REGENERATE_TOKEN = "/v1/invoices/regenerate-token/{operationId}";
    
    /** The Constant REST_INVOICE_DISPLAY_PDF_OLD. */
    public static final String REST_INVOICE_DISPLAY_PDF_OLD = REST_PREFIX + "/invoices/displayPdf/{gnId}/{gnTipoDoc}";
    
    /** The Constant REST_INVOICE_DISPLAY_PDF. */
    public static final String REST_INVOICE_DISPLAY_PDF = "/v1/mailbox/documents";
    
    /** The Constant REST_INVOICE_FORMALIZE_PROPOSAL_OLD. */
    public static final String REST_INVOICE_FORMALIZE_PROPOSAL_OLD = REST_PREFIX + "/invoices/proposal/formalize";
    
    /** The Constant REST_INVOICE_FORMALIZE_PROPOSAL. */
    public static final String REST_INVOICE_FORMALIZE_PROPOSAL = "/v1/mailbox/proposals";
    
    /** The Constant REST_INVOICE_SIGNED_PROPOSAL_OLD. */
    public static final String REST_INVOICE_SIGNED_PROPOSAL_OLD = REST_PREFIX + "/invoices/proposal/signed";

	/** The Constants REST_EXT_SIGN **/
	public static final String REST_EXT_SIGN="/v1/signers/{applicationId}/{amount}/{currency}/{persons}/{faculties}";

	/** The Constant REST_INVOICE_SIGNED_PROPOSAL. */
    public static final String REST_INVOICE_SIGNED_PROPOSAL = "/v1/mailbox/signature-documents";

	/** The Constant REST_HEADER_SERVICE. */
	public static final String REST_HEADER_SERVICE = "/v1/header-service";

	/** The Constant REST_LIST_SOLICITUDE. */
	public static final String REST_LIST_SOLICITUDE = "/v1/list-solicitude/{operationId}/{stateFront}/{app}";
	
	/** The Constant REST_NEW_SOLICITUDE. */
	public static final String REST_NEW_SOLICITUDE = "/v1/list-solicitude/new-solicitude/{operationId}";

	/** The Constant REST_CANCEL_EXP. */
	public static final String REST_CANCEL_EXP = "/v1/list-solicitude/cancelExp/{operationId}";

	/** The Constant REST_SIMULATION_FIND. */
	public static final String REST_SIMULATION_FIND = "/v1/simulation/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_NEXT. */
	public static final String REST_SIMULATION_NEXT = "/v1/simulation/next/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_NEXT_MOTOR. */
	public static final String REST_SIMULATION_NEXT_MOTOR = "/v1/simulation/next-motor/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_NEXT_GUARANTOR. */
	public static final String REST_SIMULATION_NEXT_GUARANTOR = "/v1/simulation/next-guarantor/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_BACK. */
	public static final String REST_SIMULATION_BACK = "/v1/simulation/back/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_RECAL. */
	public static final String REST_SIMULATION_RECAL = "/v1/simulation/recal/{operationId}/{stateFront}";
	
	/** The Constant REST_SIMULATION_FINALITYS. */
	public static final String REST_SIMULATION_FINALITYS = "/v1/simulation/finalitys/{operationId}";
	
	/** The Constant REST_SIMULATION_FINALITY_PRODUCTS. */
	public static final String REST_SIMULATION_FINALITY_PRODUCTS = "/v1/simulation/finality/products/{operationId}/{code}";
	
	/** The Constant REST_SIMULATION_PRODUCT_DETAIL. */
	public static final String REST_SIMULATION_PRODUCT_DETAIL = "/v1/simulation/detail/{operationId}";
	
	/** The Constant REST_SIMULATION_PROGRESS. */
	public static final String REST_SIMULATION_PROGRESS = "/v1/simulation/progress/{operationId}";
	
	/** The Constant REST_GUARANTORS_FIND. */
	//GuarantorController
	public static final String REST_GUARANTORS_FIND = "/v1/guarantors/{operationId}/{stateFront}";
	
	/** The Constant REST_GUARANTORS_NEXT. */
	public static final String REST_GUARANTORS_NEXT = "/v1/guarantors/next/{operationId}/{stateFront}";
	
	/** The Constant REST_GUARANTORS_NEXT_MOTOR. */
	public static final String REST_GUARANTORS_NEXT_MOTOR = "/v1/guarantors/next-motor/{operationId}/{stateFront}";
	
	/** The Constant REST_GUARANTORS_BACK. */
	public static final String REST_GUARANTORS_BACK = "/v1/guarantors/back/{operationId}/{stateFront}";
	
	/** The Constant REST_GUARANTORS_DETAILFFNN. */
	public static final String REST_GUARANTORS_DETAILFFNN = 
			"/v1/guarantors/ffnn/{operationId}/{stateFront}/{personType}/{personCode}";

	 /** The Constant REST_TASK_RECAST. */
 	// Job
    public static final String REST_TASK_RECAST = "/v1/job/risk-recasts";
    
    /** The Constant REST_TASK_TRANSFER. */
    public static final String REST_TASK_TRANSFER = "/v1/job/risk-transfer";
    
    /** The Constant REST_TASK_CSV. */
    public static final String REST_TASK_CSV = "/v1/job/report-contracts";
    
    /** The Constant REST_TASK_REPORT. */
    public static final String REST_TASK_REPORT = "/v1/job/report-kpis";

	/** The Constant REST_MODEL200_FIND. */
	// Model200Controller
	public static final String REST_MODEL200_FIND = "/v1/model200/{operationId}/{stateFront}";
	
	/** The Constant REST_MODEL200_NEXT. */
	public static final String REST_MODEL200_NEXT = "/v1/model200/next/{operationId}/{stateFront}";
	
	/** The Constant REST_MODEL200_BACK. */
	public static final String REST_MODEL200_BACK = "/v1/model200/back/{operationId}/{stateFront}";
	
	/** The Constant REST_MODEL200_SEND. */
	public static final String REST_MODEL200_SEND = "/v1/model200/sends/{operationId}/{stateFront}";

    /** The Constant REST_MODELAEAT_FIND. */
    // ModelAEATController
    public static final String REST_MODEL_ADDITIONAL_FIND = "/v1/additional-csv/{operationId}/{stateFront}";

    /** The Constant REST_MODELAEAT_NEXT. */
    public static final String REST_MODEL_ADDITIONAL_NEXT = "/v1/additional-csv/next/{operationId}/{stateFront}";

    /** The Constant REST_MODELAEAT_BACK. */
    public static final String REST_MODEL_ADDITIONAL_BACK = "/v1/additional-csv/back/{operationId}/{stateFront}";

	/** The Constant REST_NOTIFY_AEAT_200_OLD. */
	// Notificación modelo 200
    public static final String REST_NOTIFY_AEAT_200_OLD = REST_PREFIX
                    + "/exposed-service-aeat/{personType}/{personNumber}";
    
    /** The Constant REST_NOTIFY_AEAT_200. */
    public static final String REST_NOTIFY_AEAT_200 = "/v1/aeat-taxes/model-200";

    /** The Constant REST_NOTIFY_WITHOUT_ACTIVITY_OLD. */
    // Notificación de 24 horas sin retomar la solicitud
    public static final String REST_NOTIFY_WITHOUT_ACTIVITY_OLD = REST_PREFIX + "/notify/resumeSolicitude";
    
    /** The Constant REST_NOTIFY_WITHOUT_ACTIVITY. */
    public static final String REST_NOTIFY_WITHOUT_ACTIVITY = "/v1/solicitude-reminder";

    /** The Constant REST_CIRBE_SEND. */
    // CirbeController
    public static final String REST_CIRBE_SEND = "/v1/cirbe/sends/{operationId}/{stateFront}";
    
    /** The Constant REST_CIRBE_SASNA. */
    public static final String REST_CIRBE_SASNA = 
    		"/v1/cirbe/sendSasna/{operationId}/{stateFront}/{personType}/{personCode}";


    /** The Constant REST_NOTIFY_CIRBE_OLD. */
    // Notificación cirbe
    public static final String REST_NOTIFY_CIRBE_OLD = REST_PREFIX + "/exposed-service-cirbe";
    
    /** The Constant REST_NOTIFY_CIRBE. */
    public static final String REST_NOTIFY_CIRBE = "/v1/cirbe/risks";

	/** The Constant REST_HIRING_FIND. */
	// HiringController
	public static final String REST_HIRING_FIND = "/v1/hiring/{operationId}/{stateFront}";
	
	/** The Constant REST_CONSULTATION_FIND. */
	// ConsultationController 
	public static final String REST_CONSULTATION_FIND = "/v1/consultation/{operationId}/{stateFront}";
	
	/** The Constant REST_HIRING_NEXT. */
	public static final String REST_HIRING_NEXT = "/v1/hiring/next/{operationId}/{stateFront}";
	
	/** The Constant REST_HIRING_NEXT_SIGN_LATER. */
	public static final String REST_HIRING_NEXT_SIGN_LATER = "/v1/hiring/next-sign-later/{operationId}/{stateFront}";
	
	/** The Constant REST_HIRING_BACK. */
	public static final String REST_HIRING_BACK = "/v1/hiring/back/{operationId}/{stateFront}";
	
	/** The Constant REST_HIRING_PREFORMALIZE. */
	public static final String REST_HIRING_PREFORMALIZE = "/v1/hiring/preformalize/{operationId}/{stateFront}";
	
	/** The Constant REST_HIRING_CHANGE_ACCOUNT. */
	public static final String REST_HIRING_CHANGE_ACCOUNT = "/v1/hiring/change-account/{operationId}/{stateFront}";

	/** The Constant REST_HIRING_UPDATE_PREFORM_DATES. */
	public static final String REST_HIRING_UPDATE_PREFORM_DATES = "/v1/hiring/update-preform-dates/{operationId}";
	
	/** The Constant REST_HIRING_DOWNLOAD_DOCUMENT. */
	public static final String REST_HIRING_DOWNLOAD_DOCUMENT = "/v1/hiring/download/{operationId}";
	
	/** The Constant REST_HIRING_CANCEL_PREFORMALIZE. */
	public static final String REST_HIRING_CANCEL_PREFORMALIZE = "/v1/hiring/cancel-preformalize/{operationId}";

	/** The Constant REST_HIRING_CANCEL_FORMALIZE. */
	public static final String REST_HIRING_CANCEL_FORMALIZE = "/v1/hiring/cancel-formalize/{operationId}";

	/** The Constant REST_SIGN_FIND. */
	// SignController
	public static final String REST_SIGN_FIND = "/v1/sign/{operationId}/{stateFront}";
	
	/** The Constant REST_SIGN_NEXT. */
	public static final String REST_SIGN_NEXT = "/v1/sign/next/{operationId}/{stateFront}";
	
	/** The Constant REST_SIGN_BACK. */
	public static final String REST_SIGN_BACK = "/v1/sign/back/{operationId}/{stateFront}";

	/** The Constant REST_SIGNER_FIND. */
	// SignerController
	public static final String REST_SIGNER_FIND = "/v1/signers/{operationId}/{stateFront}";
	
	/** The Constant REST_SIGNER_NEXT. */
	public static final String REST_SIGNER_NEXT = "/v1/signers/next/{operationId}/{stateFront}";
	
	/** The Constant REST_SIGNER_BACK. */
	public static final String REST_SIGNER_BACK = "/v1/signers/back/{operationId}/{stateFront}";

	/** The Constant REST_PROXIE_FIND. */
	// ProxieController
	public static final String REST_PROXIE_FIND = "/v1/proxie/{operationId}/{stateFront}";
	
	/** The Constant REST_PROXIE_NEXT. */
	public static final String REST_PROXIE_NEXT = "/v1/proxie/next/{operationId}/{stateFront}";

	/** The Constant REST_SIMULATION_NEXT_MOTOR. */
	public static final String REST_PROXIE_NEXT_MOTOR = "/v1/proxie/next-motor/{operationId}/{stateFront}";
	
	/** The Constant REST_PROXIE_BACK. */
	public static final String REST_PROXIE_BACK = "/v1/proxie/back/{operationId}/{stateFront}";

	/** The Constant REST_PROXIE_PRINT_ASSET_APP. */
	public static final String REST_PROXIE_PRINT_ASSET_APP = "/v1/proxie/document/asset-application/{operationId}/{personId}/{personName}/{intervForm}";

	/** The Constant REST_END_FIND. */
	// EndController
	public static final String REST_END_FIND = "/v1/end/{operationId}/{stateFront}";
	
	public static final String REST_SUMMARY_FIND = "/v1/summary/{operationId}/{stateFront}";
	
	/** The Constant REST_END_FIND_FORMALIZED. */
	public static final String REST_END_FIND_FORMALIZED = "/v1/end/formalized/{operationId}/{stateFront}";

	/** The Constant REST_AGGREGATOR_FIND. */
	// AgregationController
	public static final String REST_AGGREGATOR_FIND = "/v1/aggregator/{operationId}/{stateFront}";
	
	/** The Constant REST_AGGREGATOR_NEXT. */
	public static final String REST_AGGREGATOR_NEXT = "/v1/aggregator/next/{operationId}/{stateFront}";
	
	/** The Constant REST_AGGREGATOR_BACK. */
	public static final String REST_AGGREGATOR_BACK = "/v1/aggregator/back/{operationId}/{stateFront}";
	
	/** The Constant REST_AGGREGATOR_END. */
	public static final String REST_AGGREGATOR_END = "/v1/aggregator/end/{operationId}/{stateFront}/{end}";
	
 	/** The Constant REST_NOTIFY_MOTOR_KPIS. */
	 // Notificación aggregation motor kpis
    public static final String REST_NOTIFY_MOTOR_KPIS = "/v1/motor-kpis";

    /** The Constant REST_LIMIT_FIND. */
    public static final String REST_LIMIT_FIND = "/v1/limits/{appId}";

    /** The Constant REST_LIMIT_NEXT. */
    public static final String REST_LIMIT_NEXT = "/v1/limits/next";
    
    /** The Constant REST_HIRING_FORM_FIND. */
	public static final String REST_HIRING_FORM_FIND = "/v1/hiring-form/{appId}";
	
	/** The Constant REST_HIRING_FORM_NEXT. */
	public static final String REST_HIRING_FORM_NEXT = "/v1/hiring-form/next/{appId}/{result}";
	
	/** The Constant REST_HIRING_FORM_BACK. */
	public static final String REST_HIRING_FORM_BACK = "/v1/hiring-form/back/{appId}";
	
    public static final String REST_LIMIT_END_FIND = "/v1/end/limits/{appId}/{operationId}";
  
    /** The Constant REST_LIMIT_END_FIND_OPERATIONID. */
    public static final String REST_LIMIT_END_FIND_OPERATIONID = "/v1/end/limits/{appId}/{operationId}";
    
    /** The Constant REST_KPIS_FIND. */
	public static final String REST_KPIS_FIND = "/v1/kpis/{operationId}/{stateFront}";
	public static final String REST_KPIS_FINDS = "/v1/kpis/{proposal}";
	public static final String REST_KPIS_FIND_INFO = "/v1/info-kpis/{proposal}";
	public static final String REST_KPIS_NEXT = "/v1/kpis/next/{operationId}/{stateFront}";
	public static final String REST_KPIS_BACK = "/v1/kpis/back/{operationId}/{stateFront}";
	
    /** The Constant REST_PMP_FIND_FACTORING_RESOURCES. */
    public static final String REST_PMP_FIND_FACTORING_RESOURCES = "/v1/pmp/{policyNumber}/{groups}";
    public static final String REST_PMP_FIND_FACTORING_RESOURCES_NEW = "/v1/pmp/{operationId}/{policyNumber}/{groups}";

	/** The Constant REST_PMP_INTERVENERS. */
	public static final String REST_PMP_INTERVENERS = "/v1/pmp/interveners/{policyNumber}";

	/** The Constant REST_PMP_FIND. */
	public static final String REST_PMP_FIND = "/v1/pmp/centers/{policyNumber}";

	/** The Constant REST_PMP_NEXT. */
    public static final String REST_PMP_NEXT = "/v1/pmp/next";
    
    /** The Constant REST_PMP_NEXT_NEW. */
    public static final String REST_PMP_NEXT_NEW = "/v1/pmp/nextNew";
    
    /** The Constant REST_PMP_FIND_GENERIC. */
    public static final String REST_PMP_FIND_GENERIC = "/v1/pmp/generic/{appId}";

	/** The Constant REST_GRADDO_SEND. */
	public static final String REST_GRADDO_SEND = "/v1/graddo/send/{operationId}/{tipoDocumento}";
	
	/** The Constant REST_SIMULATION_PRINT_ASSET_APP */
	public static final String REST_SIMULATION_PRINT_ASSET_APP = "/v1/simulation/document/asset-application/{operationId}";
	
	/** The Constant REST_SIMULATION_COMMISSIONS */
	public static final String REST_SIMULATION_COMMISSIONS = "/v1/simulation/commissions/{operationId}";
	
	/** The Constant REST_DOCUMENTS_LIST_SERVICE */
	public static final String REST_DOCUMENTS_LIST_SERVICE = "/v1/invoices/documents/{operationId}";
	
	/** The Constant REST_DOWNLOAD_DOCUMENT_CONTENT */
	public static final String REST_DOWNLOAD_DOCUMENT_CONTENT = "/v1/invoices/document/content/{docType}/{gnId}";
	
	// Errores swagger
	public static final String BAD_REQUEST_DESCRIPTION = "Bad Request";

    public static final String UNAUTHORIZED_DESCRIPTION = "Unauthorized";

    public static final String NOT_FOUND_DESCRIPTION = "Not Found";

    public static final String INTERNAL_SERVER_DESCRIPTION = "Internal Server Error";

	/** The Constant REST_WACOM_FIND. */
	// WacomController
	public static final String REST_SIGN_DIGI_FIND = "/v1/digi/{operationId}/{stateFront}";
	
	/** The Constant REST_WACOM_NEXT. */
	public static final String REST_SIGN_DIGI_NEXT = "/v1/digi/next/{operationId}/{stateFront}";
	
	/** The Constant REST_WACOM_BACK. */
	public static final String REST_SIGN_DIGI_BACK = "/v1/digi/back/{operationId}/{stateFront}";

	/** The REST_PROPOSAL_STATE_GET */
	public static final String REST_PROPOSAL_STATE="/v1/proposal/{idProposal}";
	
	/** The REST_PROPOSAL_SAVE_ANEXOSOSTENIBILIDAD */
	public static final String REST_PROPOSAL_SAVE_ANEXOSOSTENIBILIDAD="/v1/proposal/anexosostenibilidad";
	
	/** The REST_EXT_PROPOSAL_INIT */
	public static final String REST_EXT_PROPOSAL_INIT = "/v1/ext-proposal/init";

	/** The REST_EXT_PROPOSAL_CREATE */
	public static final String REST_EXT_PROPOSAL_CREATE = "/v1/external-proposal/create";

	/** The REST_PROPOSAL_STATE_GET */
	public static final String REST_PROPOSAL_INDPROCE="/v1/proposal/indproce/{idProposal}/{indProce}";

	/** The URL_PILOT */
	public static final String URL_PILOT = "/v1/smart-pricing/pilot";
	
	/** The Constant URL_UPDATE_PROPOSAL. */
	public static final String URL_UPDATE_PROPOSAL = "v1/external-proposal/update-proposal";
	
	/** The Constant API_ICO_TERM. */
	public static final String API_ICO_TERM = "/v1/ico/term/{loan_subsidy_id}";

	/**
	 * Instantiates a new rest constants.
	 */
	private RestConstants() {
		throw new IllegalStateException("Utility class");
	}

}