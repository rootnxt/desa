package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.soap.OutputNoClients;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * BastanteoSigner.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class BastanteoSigner {
	
	//Atributos de la clase
	private String id;
	private boolean selected;
	
	// obligatorySigners
	private Integer obligatorySigners;
	
	// signers
	private List<OutputNoClients> signers;
}
