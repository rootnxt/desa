package com.santander.darwin.invoice.model.refinancing_contracts;

import com.santander.darwin.invoice.model.common.ContractCommon;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Contract.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Contract extends ContractCommon {

	// Datos bloque 1
	private String id;
	private String subprod;
	private String indRefis;
	// Datos bloque 2
	private String agrupProd;
	private String indInmpag;
	private String indGarHipot;
	private String indOtrGaran;
	// Datos bloque 3
	private String indComprPago;
	private String indCmbDisp;
	private String indCmbHabltado;
	private String intentosCmb;
	// Datos bloque 4
	private String indCmnHabilitado;
	private String indPagoPend;
	private String fecIrregular;
	private String callCenter;
	// Datos bloque 5
	private String flagAplCliente;
	private String idApl;
	private String indBorCampa;
	private String tipoPersAva1;
	private String codPersAva1;
	// Datos bloque 6
	private String tipoDocu1;
	private String docuAval1;
	private String tipoPersAva2;
	private String codPersAva2;
	private String tipoDocu2;
	// Datos bloque 7
	private String docuAval2;
	private String tipoPersAva3;
	private String codPersAva3;
	// Datos bloque 8
	private String tipoDocu3;
	private String docuAval3;
	private String tipoPersAva4;
	// Datos bloque 9
	private String codPersAva4;
	private String tipoDocu4;
	private String docuAval4;
	// Datos bloque 10
	private String tipoPersAva5;
	private String codPersAva5;
	private String tipoDocu5;
	private String docuAval5;
	// Datos bloque 11
	private String fechaAlta;
	private String indRefinan;
	private String idCentRefis;

}
