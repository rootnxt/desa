package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

/**
 * Model for confidential values
 * 
 * @author icozar
 *
 */
@Getter
@Setter
public class CommonLang {

	// Id for object
	private String lang;
	// Name of the object
	private String name;
    /** The channel. */
    private String channel;
	
	/**
	 * Constructor
	 */
	public CommonLang() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param lang String
	 * @param name String
	 */
	public CommonLang(String lang, String name) {
		this.lang = lang;
		this.name = name;
	}

	/**
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * @param lang the lang to set
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
