package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * BankAccounts
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class BankAccounts {
	//Embedded 
	@JsonProperty("_embedded")
	private Embedded embedded;
	
	//Embedded 
	@JsonProperty("_links")
	private Links links;
}
