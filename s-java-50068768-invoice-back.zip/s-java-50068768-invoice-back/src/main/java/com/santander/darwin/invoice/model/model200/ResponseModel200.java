package com.santander.darwin.invoice.model.model200;

/**
 * ResponseModel200.java
 *
 * @author igndom
 *
 */
public class ResponseModel200 {

	private String idReferencia;

	/**
	 * @return the idReferencia
	 */
	public String getIdReferencia() {
		return idReferencia;
	}

	/**
	 * @param idReferencia the idReferencia to set
	 */
	public void setIdReferencia(String idReferencia) {
		this.idReferencia = idReferencia;
	}

}
