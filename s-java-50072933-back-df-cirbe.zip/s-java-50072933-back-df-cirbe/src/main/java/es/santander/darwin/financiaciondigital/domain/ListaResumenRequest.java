package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the lista resumen request
 */
@Builder

/**
 * Instantiates a new lista resumen request.
 */
@NoArgsConstructor

/**
 * Instantiates a new lista resumen request.
 *
 * @param listaResumen the lista resumen
 */
@AllArgsConstructor
public class ListaResumenRequest {
    
    /** The lista request. */
    private List<ListaRequest> listaResumen;
    
}
