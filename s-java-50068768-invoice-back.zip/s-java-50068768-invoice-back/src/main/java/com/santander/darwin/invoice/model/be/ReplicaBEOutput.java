    package com.santander.darwin.invoice.model.be;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class ReplicaBEOutput.
 */

/**
 * Gets the replicated service code.
 *
 * @return the replicated service code
 */
@Getter

/**
 * Sets the replicated service code.
 *
 * @param replicatedServiceCode
 *            the new replicated service code
 */
@Setter
public class ReplicaBEOutput {

    /** The groups register service. */
    private boolean groupsRegisterService;

    /** The replicated service code. */
    private String replicatedServiceCode;

}