package com.santander.darwin.invoice.model.risk;

import java.util.List;

/**
 * InputTransactionA1GG.java
 *
 * @author igndom
 *
 */
public class InputTransactionA1GG extends GenericTransactionA1G {

	private List<String> cfmt1;

	/**
	 * @return the cfmt1
	 */
	public List<String> getCfmt1() {
		return cfmt1;
	}

	/**
	 * @param cfmt1 the cfmt1 to set
	 */
	public void setCfmt1(List<String> cfmt1) {
		this.cfmt1 = cfmt1;
	}

}
