package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the summary imports
 */
@Builder

/**
 * Instantiates a new summary imports.
 */
@NoArgsConstructor

/**
 * Instantiates a new summary imports.
 *
 * @param riesgoTotalLim the riesgo total lim
 * @param riesgoTotalDisp the riesgo total disp
 * @param credComConRecurLim the cred com con recur lim
 * @param credComConRecurDisp the cred com con recur disp
 * @param credComSinRecurLim the cred com sin recur lim
 * @param credComSinRecurDisp the cred com sin recur disp
 * @param credFinanMenosAnioLim the cred finan menos anio lim
 * @param credFinanMenosAnioDisp the cred finan menos anio disp
 * @param credFinanMasAnioLim the cred finan mas anio lim
 * @param credFinanMasAnioDisp the cred finan mas anio disp
 * @param arrendamientoFinanDisp the arrendamiento finan disp
 * @param avalesDisp the avales disp
 * @param credDocIrrevocabDisp the cred doc irrevocab disp
 * @param otrosRiesgosDisp the otros riesgos disp
 */
@AllArgsConstructor
public class SummaryImports {
    
    /** The riesgo total lim. */
    private BigDecimal riesgoTotalLim;
    
    /** The riesgo total disp. */
    private BigDecimal riesgoTotalDisp;
    
    /** The cred com con recur lim. */
    private BigDecimal credComConRecurLim;
    
    /** The cred com con recur disp. */
    private BigDecimal credComConRecurDisp;
    
    /** The cred com sin recur lim. */
    private BigDecimal credComSinRecurLim;
    
    /** The cred com sin recur disp. */
    private BigDecimal credComSinRecurDisp;
    
    /** The cred finan menos anio lim. */
    private BigDecimal credFinanMenosAnioLim;
    
    /** The cred finan menos anio disp. */
    private BigDecimal credFinanMenosAnioDisp;
    
    /** The cred finan mas anio lim. */
    private BigDecimal credFinanMasAnioLim;
    
    /** The cred finan mas anio disp. */
    private BigDecimal credFinanMasAnioDisp;
    
    /** The arrendamiento finan disp. */
    private BigDecimal arrendamientoFinanDisp;
    
    /** The avales disp. */
    private BigDecimal avalesDisp;
    
    /** The cred doc irrevocab disp. */
    private BigDecimal credDocIrrevocabDisp;
    
    /** The otros riesgos disp. */
    private BigDecimal otrosRiesgosDisp;


}
