package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BasicPersonDataRequestVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the basic person data request VO
 */
@Builder

/**
 * Instantiates a new basic person data request VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new basic person data request VO.
 *
 * @param codpers the codpers
 * @param tipopers the tipopers
 * @param idempr the idempr
 */
@AllArgsConstructor
public class BasicPersonDataRequestVO {

	/** The codpers. */
	private BigDecimal codpers;

	/** The tipopers. */
	private String tipopers;

	/** The idempr. */
	private String idempr;

}