package com.santander.darwin.invoice;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cache.annotation.EnableCaching;

/**
 * App
 * 
 * @author igndom
 *
 */
@SpringBootApplication(exclude = HibernateJpaAutoConfiguration.class)
@EnableCaching
public class App {
	/**
	 * main
	 * 
	 * @param args String[]
	 */
	public static void main(String[] args) {
		new SpringApplicationBuilder(App.class).run(args);
	}

}
