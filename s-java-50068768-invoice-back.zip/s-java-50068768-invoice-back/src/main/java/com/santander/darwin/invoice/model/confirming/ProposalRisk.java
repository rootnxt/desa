package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProposalRisk.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProposalRisk {
	// Datos de ProposalRisk
	private ProposalId proposalId;

	//
	// p rivat e Pr opos alId pro posal IdPmp
	private AmountPrix amount;
	// Datos de ProposalRisk
	private String typeProposalCode;
	private String typeProposalDescription;
	private int loanPeriod;
	// Datos de ProposalRisk
	private String maturityDate;
	private int deferralOfPayment;
	private String originCode;
	private String originDescription;
	// Datos de location
	private String locationCode;
	private String locationDescription;
	private String applicationStateCode;
	private String applicationStateDescription;
	// Datos de ProposalRisk
	private String loanPurposeCode;
	private String loanPurposeDescription;
	private String channelCode;
	private String channelDescription;
	// Datos de ProductCatalog
	private ProductCatalog productCatalog;
	private Audit audit;
	// Datos de PMP
	private String pmpsignatureDate;
	private String pmpsignatureFlag;
}