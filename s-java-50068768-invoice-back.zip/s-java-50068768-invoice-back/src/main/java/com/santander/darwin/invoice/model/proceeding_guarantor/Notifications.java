package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * Notifications.java
 *
 * @author igndom
 *
 */
public class Notifications {

	private String channel;
	private String endPoint;
	private String notifyForSign;
	private String notifyCompletedExp;

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the endPoint
	 */
	public String getEndPoint() {
		return endPoint;
	}

	/**
	 * @param endPoint the endPoint to set
	 */
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	/**
	 * @return the notifyForSign
	 */
	public String getNotifyForSign() {
		return notifyForSign;
	}

	/**
	 * @param notifyForSign the notifyForSign to set
	 */
	public void setNotifyForSign(String notifyForSign) {
		this.notifyForSign = notifyForSign;
	}

	/**
	 * @return the notifyCompletedExp
	 */
	public String getNotifyCompletedExp() {
		return notifyCompletedExp;
	}

	/**
	 * @param notifyCompletedExp the notifyCompletedExp to set
	 */
	public void setNotifyCompletedExp(String notifyCompletedExp) {
		this.notifyCompletedExp = notifyCompletedExp;
	}

}
