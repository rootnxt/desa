package com.santander.darwin.invoice.model.limit;

import com.santander.darwin.invoice.model.simulation.Term;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Checks if is selected.
 *
 * @return true, if is selected
 */
@Getter

/**
 * Sets the selected.
 *
 * @param selected
 *            the new selected
 */
@Setter

/**
 * Instantiates a new grouped type finance products.
 */
@NoArgsConstructor
public class GroupedTypeFinanceProducts {

    /** The id. */
    private String id;

    /** The name. */
    private String name;

    /** The name. */
    private String internalName;

    /** The selected. */
    private boolean selected;
    
    /** The selected. */
    private String family;
    
    /** The financing. */
    private Financing financing;
    
    /** The months */
    private Term months;
    
    
    /** The digital */
    private boolean digitalProduct;
    private BigDecimal digitalLimit;

}
