package com.santander.darwin.invoice.model.model200;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

/**
 * NotificationModel200.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class NotificationModel200Old {

	// Codigo csv agencia tributaria
	// Para swagger
	@Schema(example = "RYH5S6KPGPE8LU98", description = "Security verification code")
	@NotNull(message = "CSVNULL")
	@NotEmpty(message = "CSVEMPTY")
	@Size(message = "CSVSIZE", min = 16, max = 16)
	private String csv;
	// Nombre empresa
	// Para swagger
	@Schema(example = "47909521S", description = "Name of company")
	private String companyName;
	// Cnae y periodo
	// Para swagger
	@Schema(example = "6630", description = "National Classification of Economic Activities of company")
	private String cnae;
	// Para swagger
	@Schema(example = "2", description = "Period of company")
	private String period;
	@Schema(example = "", description = "List of manager")
	private List<Manager200> manager;
	@Schema(example = "", description = "List of stockholders")
	private List<Stockholders> stockholders;
	// Otros datos
	// Para swagger
	@Schema(example = "5000", description = "Result of operation")
	private BigDecimal operationResults;
	// Para swagger
	@Schema(example = "2000", description = "Profit and loss")
	private BigDecimal profitLoss;
	// Dato base
	// Para swagger
	@Schema(example = "3000", description = "Base of tax")
	private BigDecimal taxBase;
	// Para swagger
	@Schema(example = "4000", description = "Full content of fee")
	private BigDecimal fullFee;
	// Datos de retorno
	// Para swagger
	@Schema(example = "00", description = "Global code of return")
	private BigDecimal globalReturn;
	// Datos de agencia tributaria
	// Para swagger
	@Schema(example = "01", description = "State of model 200")
	@NotNull(message = "STATEAEATNULL")
	@NotEmpty(message = "STATEAEATEMPTY")
	@Size(message = "STATEAEATSIZE", min = 2, max = 2)
	private String stateAEAT;
	// Para swagger
	@Schema(example = "OK", description = "Description of state of model 200")
	private String descStateAEAT;
}
