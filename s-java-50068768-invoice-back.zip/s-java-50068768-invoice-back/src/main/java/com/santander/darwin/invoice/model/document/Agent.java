/**
 * 
 */
package com.santander.darwin.invoice.model.document;

/**
 * Agent
 * 
 * @author josdon
 *
 */
public class Agent {

	private String document;
	private String name;

	/**
	 * @return the document
	 */
	public String getDocument() {
		return document;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(String document) {
		this.document = document;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
