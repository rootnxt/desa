package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OrganizationName.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class OrganizationName {
	// Datos de OrganizationName
	private String legalName;
}