package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

/**
 * Links
 * 
 * @author igndom
 *
 */
public class Links {
	// Self
	private Self self;
	// Next
	private Next next;

	/**
	 * @return the self
	 */
	public Self getSelf() {
		return self;
	}

	/**
	 * @param self the self to set
	 */
	public void setSelf(Self self) {
		this.self = self;
	}
	
	/**
	 * @return the next
	 */
	public Next getNext() {
		return next;
	}

	/**
	 * @param next the next to set
	 */
	public void setNext(Next next) {
		this.next = next;
	}
	
}
