package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * OutputSat002312.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class OutputSat002312 {

	private List<String> a1tipppr;
	private List<String> codprod;
	private List<String> codsprod;
	private List<String> cotfina;
	private List<String> cotpropu;
	private List<String> codcesta;
	private List<String> nomtip;
	private List<String> descr023;
	private List<String> nomtipo;
	private List<BigDecimal> plazopro;
	private List<String> operacio;
	private List<BigDecimal> implimit;
	private List<String> nomcesta;
	private List<BigDecimal> limpprop;
	private List<String> codmonsw;
	private List<String> destarab;
	private List<String> timestam;
	private List<BigDecimal> impant15;
	private List<String> indac;
	private List<Date> fecvenci;
	private List<String> fechaape;
	private List<BigDecimal> tasa;
	private List<String> descresp;
	private List<String> dlocaliz;
	private List<String> nomseg;
	private List<String> usumodd;
	private List<String> a1codseg;
	private List<String> usualt;
	private List<String> indacc1;

}
