package com.santander.darwin.invoice.model.lanzadera;

import com.santander.darwin.invoice.model.Product;
import org.springframework.data.annotation.Id;

/**
 * InvoiceDataLanzadera.java
 *
 * @author igndom
 *
 */
public class InvoiceDataLanzadera extends InputLanzadera {

	@Id
	private String id;
	private String sign;
	private String contract;
	private String desc;
	private String company;
	private Product product;
	private String campaing;
	private String family;

	/**
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * @param sign the sign to set
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}

	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the campaing
	 */
	public String getCampaing() {
		return campaing;
	}

	/**
	 * @param campaing the campaing to set
	 */
	public void setCampaing(String campaing) {
		this.campaing = campaing;
	}

	/**
	 * @return the family
	 */
	public String getFamily() {
		return family;
	}

	/**
	 * @param family the family to set
	 */
	public void setFamily(String family) {
		this.family = family;
	}

}
