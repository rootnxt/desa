/**
 * 
 */
package com.santander.darwin.invoice.model.document;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * DocumentGeneratorInput
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class DocumentGeneratorInput {

	/** The agent */
	private List<Agent> agent;
	
	/** The guarantor List (listado de avalistas) */
	private List<GuarantorDoc> guarantor;

	/** The proposal */
	private Proposal proposal;

	/** The signatureIndicator */
	private String signatureIndicator;

	/** The typeSign  */
	private String typeSign;
	
	/** The numeroPMP */
	private String numeroPMP;
	
	/** The fechaPMP */
	private String fechaPMP;
	
	/** The indicadorPMP */
	private String indicadorPMP;

}
