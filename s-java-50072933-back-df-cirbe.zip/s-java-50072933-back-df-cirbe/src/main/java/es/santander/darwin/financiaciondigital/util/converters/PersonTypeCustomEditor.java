package es.santander.darwin.financiaciondigital.util.converters;

import static es.santander.darwin.financiaciondigital.constant.ErrorConstants.MESSAGE_INVALID_PERSON_TYPE;

import java.beans.PropertyEditorSupport;

import org.apache.commons.lang.StringUtils;

import es.santander.darwin.financiaciondigital.constant.PersonType;

/**
 * The Class PersonTypeCustomEditor. Para el uso correcto de este converter debe declararse con @InitBinder en el
 * controlador que lo necesite.
 *
 * @author everis
 */
public class PersonTypeCustomEditor extends PropertyEditorSupport {

    /*
     * (non-Javadoc)
     * 
     * @see java.beans.PropertyEditorSupport#setAsText(java.lang.String)
     */
    @Override
    public void setAsText(String text) {
        PersonType personTypeValue = null;
        if (StringUtils.isNotBlank(text)) {
            String personValue = text.trim();
            for (PersonType personType : PersonType.values()) {
                if (personType.getValue().equalsIgnoreCase(personValue)) {
                    personTypeValue = personType;
                    break;
                }
            }
        }
        if (personTypeValue == null) {
            throw new IllegalArgumentException(MESSAGE_INVALID_PERSON_TYPE);
        }
        this.setValue(personTypeValue);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.beans.PropertyEditorSupport#getAsText()
     */
    @Override
    public String getAsText() {
        PersonType personType = (PersonType) super.getValue();
        if (personType != null) {
            return personType.getValue();
        } else {
            return StringUtils.EMPTY;
        }
    }

}
