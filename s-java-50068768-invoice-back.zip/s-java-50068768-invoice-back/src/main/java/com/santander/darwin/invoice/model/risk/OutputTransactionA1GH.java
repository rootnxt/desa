package com.santander.darwin.invoice.model.risk;

import java.util.List;

/**
 * OutputTransactionA1GH.java
 *
 * @author igndom
 *
 */
public class OutputTransactionA1GH {

	private List<String> cdestref;
	private List<String> empresal;
	private String empresar;
	private String estanref;
	private String mensaje6;
	private String producs;
	private String retorno;
	private String subpro;
	private List<String> subprodu;
	private List<String> tiprod;

	/**
	 * @return the cdestref
	 */
	public List<String> getCdestref() {
		return cdestref;
	}

	/**
	 * @param cdestref the cdestref to set
	 */
	public void setCdestref(List<String> cdestref) {
		this.cdestref = cdestref;
	}

	/**
	 * @return the empresal
	 */
	public List<String> getEmpresal() {
		return empresal;
	}

	/**
	 * @param empresal the empresal to set
	 */
	public void setEmpresal(List<String> empresal) {
		this.empresal = empresal;
	}

	/**
	 * @return the empresar
	 */
	public String getEmpresar() {
		return empresar;
	}

	/**
	 * @param empresar the empresar to set
	 */
	public void setEmpresar(String empresar) {
		this.empresar = empresar;
	}

	/**
	 * @return the estanref
	 */
	public String getEstanref() {
		return estanref;
	}

	/**
	 * @param estanref the estanref to set
	 */
	public void setEstanref(String estanref) {
		this.estanref = estanref;
	}

	/**
	 * @return the mensaje6
	 */
	public String getMensaje6() {
		return mensaje6;
	}

	/**
	 * @param mensaje6 the mensaje6 to set
	 */
	public void setMensaje6(String mensaje6) {
		this.mensaje6 = mensaje6;
	}

	/**
	 * @return the producs
	 */
	public String getProducs() {
		return producs;
	}

	/**
	 * @param producs the producs to set
	 */
	public void setProducs(String producs) {
		this.producs = producs;
	}

	/**
	 * @return the retorno
	 */
	public String getRetorno() {
		return retorno;
	}

	/**
	 * @param retorno the retorno to set
	 */
	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}

	/**
	 * @return the subpro
	 */
	public String getSubpro() {
		return subpro;
	}

	/**
	 * @param subpro the subpro to set
	 */
	public void setSubpro(String subpro) {
		this.subpro = subpro;
	}

	/**
	 * @return the subprodu
	 */
	public List<String> getSubprodu() {
		return subprodu;
	}

	/**
	 * @param subprodu the subprodu to set
	 */
	public void setSubprodu(List<String> subprodu) {
		this.subprodu = subprodu;
	}

	/**
	 * @return the tiprod
	 */
	public List<String> getTiprod() {
		return tiprod;
	}

	/**
	 * @param tiprod the tiprod to set
	 */
	public void setTiprod(List<String> tiprod) {
		this.tiprod = tiprod;
	}

}
