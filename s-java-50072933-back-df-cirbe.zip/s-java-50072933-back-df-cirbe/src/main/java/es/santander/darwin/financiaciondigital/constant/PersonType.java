package es.santander.darwin.financiaciondigital.constant;

/**
 * The Enum PersonType.
 *
 * @author everis
 */
public enum PersonType {

    /** The physical. */
    PHYSICAL("F"),
    
    /** The legal. */
    JURIDICAL("J");
    
    /** The value. */
    private String value;
    
    /**
     * Instantiates a new person type.
     *
     * @param value the value
     */
    PersonType(String value){
        this.value = value;
    }
    
    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return this.value;
    }
}
