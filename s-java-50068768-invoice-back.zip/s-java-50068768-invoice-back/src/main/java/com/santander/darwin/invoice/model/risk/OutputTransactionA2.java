package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * OutputTransactionA2.java
 *
 * @author igndom
 *
 */
public class OutputTransactionA2 {
	
	private List<String> codtasre;
	private BigDecimal comapmax;
	private BigDecimal comapmin;
	private BigDecimal cplazome;
	private List<String> descrab;
	private List<BigDecimal> desdeper;
	private List<BigDecimal> difrencl;
	private List<String> estdtr1;
	private List<String> estdtr2;
	private List<BigDecimal> hastaper;
	private BigDecimal imptcuo;
	private List<BigDecimal> tasacom;
	private BigDecimal tramo;

	/**
	 * @return the codtasre
	 */
	public List<String> getCodtasre() {
		return codtasre;
	}

	/**
	 * @param codtasre the codtasre to set
	 */
	public void setCodtasre(List<String> codtasre) {
		this.codtasre = codtasre;
	}

	/**
	 * @return the comapmax
	 */
	public BigDecimal getComapmax() {
		return comapmax;
	}

	/**
	 * @param comapmax the comapmax to set
	 */
	public void setComapmax(BigDecimal comapmax) {
		this.comapmax = comapmax;
	}

	/**
	 * @return the comapmin
	 */
	public BigDecimal getComapmin() {
		return comapmin;
	}

	/**
	 * @param comapmin the comapmin to set
	 */
	public void setComapmin(BigDecimal comapmin) {
		this.comapmin = comapmin;
	}

	/**
	 * @return the cplazome
	 */
	public BigDecimal getCplazome() {
		return cplazome;
	}

	/**
	 * @param cplazome the cplazome to set
	 */
	public void setCplazome(BigDecimal cplazome) {
		this.cplazome = cplazome;
	}

	/**
	 * @return the descrab
	 */
	public List<String> getDescrab() {
		return descrab;
	}

	/**
	 * @param descrab the descrab to set
	 */
	public void setDescrab(List<String> descrab) {
		this.descrab = descrab;
	}

	/**
	 * @return the desdeper
	 */
	public List<BigDecimal> getDesdeper() {
		return desdeper;
	}

	/**
	 * @param desdeper the desdeper to set
	 */
	public void setDesdeper(List<BigDecimal> desdeper) {
		this.desdeper = desdeper;
	}

	/**
	 * @return the difrencl
	 */
	public List<BigDecimal> getDifrencl() {
		return difrencl;
	}

	/**
	 * @param difrencl the difrencl to set
	 */
	public void setDifrencl(List<BigDecimal> difrencl) {
		this.difrencl = difrencl;
	}

	/**
	 * @return the estdtr1
	 */
	public List<String> getEstdtr1() {
		return estdtr1;
	}

	/**
	 * @param estdtr1 the estdtr1 to set
	 */
	public void setEstdtr1(List<String> estdtr1) {
		this.estdtr1 = estdtr1;
	}

	/**
	 * @return the estdtr2
	 */
	public List<String> getEstdtr2() {
		return estdtr2;
	}

	/**
	 * @param estdtr2 the estdtr2 to set
	 */
	public void setEstdtr2(List<String> estdtr2) {
		this.estdtr2 = estdtr2;
	}

	/**
	 * @return the hastaper
	 */
	public List<BigDecimal> getHastaper() {
		return hastaper;
	}

	/**
	 * @param hastaper the hastaper to set
	 */
	public void setHastaper(List<BigDecimal> hastaper) {
		this.hastaper = hastaper;
	}

	/**
	 * @return the imptcuo
	 */
	public BigDecimal getImptcuo() {
		return imptcuo;
	}

	/**
	 * @param imptcuo the imptcuo to set
	 */
	public void setImptcuo(BigDecimal imptcuo) {
		this.imptcuo = imptcuo;
	}

	/**
	 * @return the tasacom
	 */
	public List<BigDecimal> getTasacom() {
		return tasacom;
	}

	/**
	 * @param tasacom the tasacom to set
	 */
	public void setTasacom(List<BigDecimal> tasacom) {
		this.tasacom = tasacom;
	}

	/**
	 * @return the tramo
	 */
	public BigDecimal getTramo() {
		return tramo;
	}

	/**
	 * @param tramo the tramo to set
	 */
	public void setTramo(BigDecimal tramo) {
		this.tramo = tramo;
	}
	
}
