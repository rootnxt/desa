package com.santander.darwin.invoice.constants;

/**
 * StateProposal.java
 *
 * @author igndom
 *
 */
public enum StateProposal {

	// Sin propuesta
	PROPOSAL_WITHOUT_PROPOSAL("00"),

	// Solicitada
	PROPOSAL_REQUESTED("01"),

	// Aprobada
	PROPOSAL_APPROVED("02"),

	// Preformalizada
	PROPOSAL_PREFORMALIZED("15"),

	// Formalizada Parcialmente
	PROPOSAL_PARTIALLY_FORMALIZED("04"),

	// Formalizada
	PROPOSAL_FORMALIZED("05"),

	// Denegada
	PROPOSAL_DENIED("03"),

	// Baja
	PROPOSAL_DOWN("06"),

	// Vencida por vencimiento
	PROPOSAL_EXPIRED_BY_EXPIRATION("10"),

	// No formalizada
	PROPOSAL_NON_FORMALIZED("11"),

	// No resuelta
	PROPOSAL_UNRESOLVED("12");

	private String code;

	/**
	 * Instantiate a new state front.
	 *
	 * @param code the code
	 */
	StateProposal(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Get state from code.
	 *
	 * @param code the code
	 * @return StateFront
	 */
	public static StateProposal getStateFromCode(String code) {
		for (StateProposal stateFrontType : StateProposal.values()) {
			if (stateFrontType.getCode().equals(code)) {
				return stateFrontType;
			}
		}
		return null;
	}
}
