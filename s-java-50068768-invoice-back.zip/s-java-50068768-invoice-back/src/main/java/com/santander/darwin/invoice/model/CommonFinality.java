package com.santander.darwin.invoice.model;

/**
 * Model for confidential CommonFinality values
 * 
 * @author josdon
 *
 */
public class CommonFinality extends CommonInformation {

	// Id for object
	private int order;
	// Name of the object
	private boolean highlight;
	// The channel
	private String canal;
	
	/**
	 * Constructor 
	 */
	public CommonFinality() {
		super();
	}
	
	/**
	 * Constructor
	 * 
	 * @param id String
	 * @param name String
	 */
	public CommonFinality(String id, String name) {
		super(id, name);
	}
	/**
	 * @return the order
	 */
	public int getOrder() {
		return order;
	}
	/**
	 * @param order the order to set
	 */
	public void setOrder(int order) {
		this.order = order;
	}
	/**
	 * @return the highlight
	 */
	public boolean isHighlight() {
		return highlight;
	}
	/**
	 * @param highlight the highlight to set
	 */
	public void setHighlight(boolean highlight) {
		this.highlight = highlight;
	}

	/**
	 * @return the canal
	 */
	public String getCanal() {
		return canal;
	}

	/**
	 * @param canal the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}

	

}
