package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InvoiceExtends.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceExtends extends Invoice {
	//Datos de InvoiceExtends
	private boolean selected;
	private BigDecimal finance;
	//Datos de InvoiceExtends
	private BigDecimal preFinance;
	
}
