package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * The Group Class.
 */
@Getter
@Setter
public class GroupClass implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The group. */
    private String group;

    /** The groupId. */
    private String groupId;
    
    /** The maximumContractingTerms. */
    private MaximumContractingTerms maximumContractingTerms;

    /** The balances. */
    private BalancesAdn balances;

    /** The contracts. */
    private List<Contract> contracts;

}
