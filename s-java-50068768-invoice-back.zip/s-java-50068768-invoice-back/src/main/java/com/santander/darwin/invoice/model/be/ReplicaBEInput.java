package com.santander.darwin.invoice.model.be;

/**
 * The Class ReplicaBEInput.
 */
public class ReplicaBEInput {

    /** The contract. */
    private ContractBE contract;

    /** The user alias. */
    private String userAlias;

    /** The register service code. */
    private String registerServiceCode;

    /** The services. */
    private String[] services;

    /**
     * Gets the contract.
     *
     * @return the contract
     */
    public ContractBE getContract() {
        return contract;
    }

    /**
     * Sets the contract.
     *
     * @param contract
     *            the new contract
     */
    public void setContract(ContractBE contract) {
        this.contract = contract;
    }

    /**
     * Gets the user alias.
     *
     * @return the user alias
     */
    public String getUserAlias() {
        return userAlias;
    }

    /**
     * Sets the user alias.
     *
     * @param userAlias
     *            the new user alias
     */
    public void setUserAlias(String userAlias) {
        this.userAlias = userAlias;
    }

    /**
     * Gets the register service code.
     *
     * @return the register service code
     */
    public String getRegisterServiceCode() {
        return registerServiceCode;
    }

    /**
     * Sets the register service code.
     *
     * @param registerServiceCode
     *            the new register service code
     */
    public void setRegisterServiceCode(String registerServiceCode) {
        this.registerServiceCode = registerServiceCode;
    }

    /**
     * Gets the services.
     *
     * @return the services
     */
    public String[] getServices() {
        return services.clone();
    }

    /**
     * Sets the services.
     *
     * @param services
     *            the new services
     */
    public void setServices(String[] services) {
        this.services = services.clone();
    }
}