package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Entrada de la consulta de atributos de catálogo de productos
 * 
 */
@Getter
@Setter
public class CatalogAttributesAndValuesInput {

	/**
	 * catalogAttributesAndValuesIn - List
	 */
	private List<CatalogAttributeInput> catalogAttributesAndValuesIn;

	/**
	 * fecini
	 */
	private String fecini;
	
}
