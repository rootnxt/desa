package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * DataRulesDTO.java
 *
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataRulesDTO {
	
	// expedientCode  
	private Integer expedientCode;
	// ruleCode
	private String ruleCode;
	// faculty
	private String faculty;
	//facultyDescription
	private String facultyDescription;
	// amount
	private String amount;
	// initialAmount
	private String initialAmount;
	// finalAmount
	private String finalAmount;
	// currency
	private String currency;
	// requiredGroup
	private Integer requiredGroup;
	// requiredSignatureNumber
	private Integer requiredSignatureNumber;
	// requiredRepresentativeList
	List<GroupsRepresentativesMembersDTO> requiredRepresentativeList;
	// optionalGroup
	private float optionalGroup;
	// optionalSignatureNumber
	private float optionalSignatureNumber;
	// optionalRepresentativeList
	List<GroupsRepresentativesMembersDTO> optionalRepresentativeList;

}
