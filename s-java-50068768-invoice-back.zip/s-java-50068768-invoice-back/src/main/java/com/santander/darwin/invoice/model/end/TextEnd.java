package com.santander.darwin.invoice.model.end;

import lombok.Getter;
import lombok.Setter;

/**
 * End.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class TextEnd {

	// Pantalla de traspaso a oficina
	private DataText office;
	
	// Pantalla Activacion
	private DataText proposalSubmitted;
	
	// Pantalla de Activacion de servicios
	private DataText serviceActivation;
	
	// Pantalla de solicitud cancelada
	private DataText cancelProposal;

}
