package com.santander.darwin.invoice.model.model200;

import java.math.BigDecimal;

/**
 * FinancialStatement.java
 *
 * @author igndom
 *
 */
public class FinancialStatement {

	private BigDecimal operatingResult;
	private BigDecimal profitAndLoss;
	private BigDecimal taxBase;
	private BigDecimal fullFee;

	/**
	 * @return the operatingResult
	 */
	public BigDecimal getOperatingResult() {
		return operatingResult;
	}

	/**
	 * @param operatingResult the operatingResult to set
	 */
	public void setOperatingResult(BigDecimal operatingResult) {
		this.operatingResult = operatingResult;
	}

	/**
	 * @return the profitAndLoss
	 */
	public BigDecimal getProfitAndLoss() {
		return profitAndLoss;
	}

	/**
	 * @param profitAndLoss the profitAndLoss to set
	 */
	public void setProfitAndLoss(BigDecimal profitAndLoss) {
		this.profitAndLoss = profitAndLoss;
	}

	/**
	 * @return the taxBase
	 */
	public BigDecimal getTaxBase() {
		return taxBase;
	}

	/**
	 * @param taxBase the taxBase to set
	 */
	public void setTaxBase(BigDecimal taxBase) {
		this.taxBase = taxBase;
	}

	/**
	 * @return the fullFee
	 */
	public BigDecimal getFullFee() {
		return fullFee;
	}

	/**
	 * @param fullFee the fullFee to set
	 */
	public void setFullFee(BigDecimal fullFee) {
		this.fullFee = fullFee;
	}

}
