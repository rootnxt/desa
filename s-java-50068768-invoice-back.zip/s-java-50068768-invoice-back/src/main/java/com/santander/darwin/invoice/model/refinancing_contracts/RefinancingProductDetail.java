package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProductoDetail.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class RefinancingProductDetail {

	//Atributos de la clase
	private String description;
	private Object value;
	private String type;

}
