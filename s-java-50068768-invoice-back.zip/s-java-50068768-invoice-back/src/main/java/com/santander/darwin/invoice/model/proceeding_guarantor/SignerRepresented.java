/**
 * 
 */
package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * SignerRepresented
 * 
 * @author josdon
 *
 */
public class SignerRepresented {
	
	// J - 12345456
	private String personNumber;
	private String fullName;


	/**
	 * @return the personNumber
	 */
	public String getPersonNumber() {
		return personNumber;
	}

	/**
	 * @param personNumber the personNumber to set
	 */
	public void setPersonNumber(String personNumber) {
		this.personNumber = personNumber;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
