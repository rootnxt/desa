package es.santander.darwin.financiaciondigital.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsolidadoResponse;
import es.santander.darwin.financiaciondigital.domain.ConsultaConsolidadoCirbeResponseVO;
import es.santander.darwin.financiaciondigital.domain.ListaRequest;
import es.santander.darwin.financiaciondigital.domain.ListaResumenRequest;
import es.santander.darwin.financiaciondigital.domain.Persona;
import es.santander.darwin.financiaciondigital.domain.SummaryCirbe;
import es.santander.darwin.financiaciondigital.domain.SummaryCirbeCods;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.service.ConsolidadoCirbeService;
import es.santander.darwin.financiaciondigital.service.RestConsolidadoService;
import lombok.extern.slf4j.Slf4j;

/** The Constant log. */

/** The Constant log. */

/** The Constant log. */
@Slf4j
@Service
public class ConsolidadoCirbeServiceImpl implements ConsolidadoCirbeService {

    /** The rest consolidado service. */
    @Autowired
    private RestConsolidadoService restConsolidadoService;

    /** The summary cirbe cods list. */
    @Autowired
    private SummaryCirbeCods cirbeCodsList;

    /** The soap action. */
    @Value("${cirbe.consolidado.valores.existeConsolidadoMismaFechaCirite}")
    private String existeConsolidadoMismaFechaCirite;

    /** The soap action. */
    @Value("${cirbe.consolidado.valores.existeConsolidadoDistintaFechaCirite}")
    private String existeConsolidadoDistintaFechaCirite;

    /** The soap action. */
    @Value("${cirbe.consolidado.valores.noExisteConsolidado}")
    private String noExisteConsolidado;

    /** The soap action. */
    @Value("${cirbe.consolidado.valores.microActivado}")
    private String microActivado;

    /** The soap action. */
    @Value("${cirbe.consolidado.mock}")
    private String mock;

    @Override
    public ConsultaConsolidadoCirbeResponseVO callConsolidadoCirbe(BasicPersonDataResponseVO basicPersonDataRes)
            throws DigitalConsumptionServiceException {
        ConsultaConsolidadoCirbeResponseVO consolidadoCirbe = new ConsultaConsolidadoCirbeResponseVO();

        ListaResumenRequest listaResumenRequest = new ListaResumenRequest();
        List<ListaRequest> listaRequest = new ArrayList<>();
        ListaRequest request = new ListaRequest();
        Persona persona = new Persona();
        request.setCodigoIdentificacionPers(basicPersonDataRes.getCodPaisR() + basicPersonDataRes.getDocumentCod());
        request.setFechaDesde(Constants.VALUE_BLANK);
        request.setFechaHasta(Constants.VALUE_BLANK);
        request.setGrupo(Constants.VALUE_BLANK);
        persona.setCodigoDePersona(Constants.VALUE_BLANK);
        persona.setTipoDePersona(Constants.VALUE_BLANK);
        request.setPersona(persona);
        listaRequest.add(request);
        listaResumenRequest.setListaResumen(listaRequest);

        // TODO implementar
        if (mock.equals(existeConsolidadoMismaFechaCirite)) {
            log.info("existeConsolidadoMismaFechaCirite");
            consolidadoCirbe.setFechaSistema("201701");
            consolidadoCirbe.setFechaCliente("201801");
            return consolidadoCirbe;
        } else if (mock.equals(existeConsolidadoDistintaFechaCirite)) {
            log.info("existeConsolidadoDistintaFechaCirite");
            consolidadoCirbe.setFechaSistema("201801");
            consolidadoCirbe.setFechaCliente("201701");
            return consolidadoCirbe;
        } else if (mock.equals(noExisteConsolidado)) {
            log.info("noExisteConsolidado");
            consolidadoCirbe.setNuevoAcreditado(true);
            return consolidadoCirbe;
        } else if (mock.equals(microActivado)) {
            log.info("microActivado");
            ConsolidadoResponse methodResult = restConsolidadoService.callConsolidado(listaResumenRequest);
            log.info(methodResult.getMethodResult().get(0).getCodError());

            if (methodResult.getMethodResult().get(0).getCodError().equals(Constants.VALUE_BLANK)) {
                consolidadoCirbe.setFechaSistema(methodResult.getMethodResult().get(0).getUltimaFecha());
                consolidadoCirbe.setFechaCliente(methodResult.getMethodResult().get(0).getListaResumen()
                        .get(0).getFecha());
                consolidadoCirbe.setNuevoAcreditado(false);
            }

            if (methodResult.getMethodResult().get(0).getCodError().equals(Constants.VALUE_100) ||
                    validationSummaryCirbe(methodResult.getMethodResult().get(0).getCodError())) {

                consolidadoCirbe.setNuevoAcreditado(true);
            }

            if (methodResult.getMethodResult().get(0).getCodError().equals(Constants.VALUE_101)
                    || methodResult.getMethodResult().get(0).getCodError().equals(Constants.VALUE_102)
                    || validationSummaryCirbe(methodResult.getMethodResult().get(0).getCodError())) {

                return null;
            }

            return consolidadoCirbe;
        }

        return consolidadoCirbe;
    }

    /**
     * Validation summary cirbe.
     *
     * @param code the code
     * @return true, if successful
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    public boolean validationSummaryCirbe(String code) throws DigitalConsumptionServiceException {

        List<SummaryCirbe> summaryCirbeInfoList = cirbeCodsList.getCirbeCodsList();
        for (int i = 0; i < summaryCirbeInfoList.size(); i++) {
            if (code.equals(summaryCirbeInfoList.get(i).getCode())) {
                return true;
            }
        }
        return false;
    }

}
