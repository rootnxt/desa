package es.santander.darwin.financiaciondigital.domain;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the proposal requests sencol motor DTO
 */
@Builder

/**
 * Instantiates a new proposal requests sencol motor DTO.
 *
 * @param company          the company
 * @param center           the center
 * @param year             the year
 * @param proposalNumber   the proposal number
 * @param modificationUser the modification user
 */
@AllArgsConstructor

/**
 * Instantiates a new proposal requests sencol motor DTO.
 */
@NoArgsConstructor
public class ProposalRequestsSencolMotorDTO {

	/** The company. */
	@Size(min = 4, max = 4)
	@NotNull
	/** The company. */
	private String company;

	/** The center. */
	@Size(min = 4, max = 4)
	@NotNull
	/** The center. */
	private String center;

	/** The year. */
	@Digits(integer = 4, fraction = 0)
	@NotNull
	/** The year. */
	private Integer year;

	/** The proposal number. */
	@Digits(integer = 5, fraction = 0)
	@NotNull
	/** The proposal number. */
	private Integer proposalNumber;

	/** The modification user. */
	@NotNull
	private String modificationUser;

	/** The sub application. */
	private String subApplication;

}
