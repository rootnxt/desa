package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PersonVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the person VO
 */
@Builder

/**
 * Instantiates a new person VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new person VO.
 *
 * @param intervencion the intervencion
 * @param sourceTypeList the source type list
 */
@AllArgsConstructor
public class PersonVO {

    /** The intervencion. */
    private String intervencion;
    
    /** The source type list. */
    private List<SourceTypeVO> sourceTypeList;
}
