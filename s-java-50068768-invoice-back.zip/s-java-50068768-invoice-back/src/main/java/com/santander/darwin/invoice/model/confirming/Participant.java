package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Participant.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Participant {
	// Datos de Participant
	private String relationshipTypeCode;
	private String relationshipTypeDescription;
	private String percenResponsability;
	private List<Representative> representatives;
	private ConfirmingOperation confirmingOperation;
	// Datos de Customer
	private Customer customer;
}
