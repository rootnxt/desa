package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * PersonName.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class PersonName {
	// Datos de PersonName
	private String givenName;
	private String lastName;
	private String secondLastName;
}