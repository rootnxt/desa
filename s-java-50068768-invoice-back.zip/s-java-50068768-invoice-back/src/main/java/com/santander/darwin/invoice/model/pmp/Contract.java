package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The Contract Class.
 */
@Getter
@Setter
public class Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The contractId. */
    private BigDecimal contractId;

    /** The proposalId. */
    private BigDecimal proposalId;

}
