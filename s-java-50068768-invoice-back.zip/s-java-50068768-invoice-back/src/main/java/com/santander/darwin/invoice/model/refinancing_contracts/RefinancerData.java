package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

/**
 * RefinancerData.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class RefinancerData {

	// Atributos de la clase
	private Double proposalAmount;
	private Double openingComission;
	private Double interestRate;
	private Integer term;
	private String associatedAccount;
}
