package es.santander.darwin.financiaciondigital.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.soap.exceptions.DetailSoapFaultDefinitionExceptionResolver;
import es.santander.darwin.financiaciondigital.soap.exceptions.ServiceFaultException;

// TODO: Auto-generated Javadoc
/**
 * The Class WsConfig.
 */
@ComponentScan({ "es.santander.darwin.financiaciondigital.*" })
@EnableWs
@Configuration
public class WsConfig extends WsConfigurerAdapter {

    /** The locationuri. */
    @Value("${constantsoap.locationuri}")
    private String locationuri;

    /** The servlet. */
    @Value("${constantsoap.servlet}")
    private String servlet;

    /**
     * Message dispatcher servlet.
     *
     * @param context the context
     * @return the servlet registration bean
     */
    @Bean
    public ServletRegistrationBean<MessageDispatcherServlet> messageDispatcherServlet(ApplicationContext context) {
        MessageDispatcherServlet messageDispatcherServlet = new MessageDispatcherServlet();
        messageDispatcherServlet.setApplicationContext(context);
        messageDispatcherServlet.setTransformWsdlLocations(true);
        return new ServletRegistrationBean<MessageDispatcherServlet>(messageDispatcherServlet, servlet);
    }

    /**
     * Default wsdl 11 definition.
     *
     * @param personRequestSchema the person request schema
     * @return the default wsdl 11 definition
     */
    @Bean(name = "personRequests")
    public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchema personRequestSchema) {
        DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
        wsdl11Definition.setPortTypeName("PersonRequestsPort");
        wsdl11Definition.setLocationUri(locationuri);
        wsdl11Definition.setTargetNamespace(Constants.NAME_SPACE);
        wsdl11Definition.setSchema(personRequestSchema);
        return wsdl11Definition;
    }
    

    /**
     * Person proposal request wsdl 11 definition.
     *
     * @param personAndProposalRequestSchema the person and proposal request schema
     * @return the default wsdl 11 definition
     */
    @Bean(name = "personProposalRequests")
    public DefaultWsdl11Definition personProposalRequestWsdl11Definition(XsdSchema personAndProposalRequestSchema) {
        DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
        wsdl11Definition.setPortTypeName("PersonProposalRequestsPort");
        wsdl11Definition.setLocationUri("/soap");
        wsdl11Definition.setTargetNamespace(Constants.NAME_SPACE);
        wsdl11Definition.setSchema(personAndProposalRequestSchema);
        return wsdl11Definition;
    }

    /**
     * Metodo que se encarga de asignar de obtener el transformador.
     * 
     * @return XsdSchema
     */
    @Bean
    public XsdSchema personRequestSchema() {
        Resource resource = new ClassPathResource("/xsd/personRequests.xsd", getClass());
        return new SimpleXsdSchema(resource);
    }

    /**
     * Metodo que se encarga de asignar de obtener el transformador.
     * 
     * @return XsdSchema
     */
    @Bean
    public XsdSchema personAndProposalRequestSchema() {
        Resource resource = new ClassPathResource("/xsd/personAndProposalRequest.xsd", getClass()); 
        return new SimpleXsdSchema(resource);
    }

    /**
     * Exception resolver.
     *
     * @return the soap fault mapping exception resolver
     */
    @Bean
    public SoapFaultMappingExceptionResolver exceptionResolver() {
        SoapFaultMappingExceptionResolver exceptionResolver = new DetailSoapFaultDefinitionExceptionResolver();

        SoapFaultDefinition faultDefinition = new SoapFaultDefinition();
        faultDefinition.setFaultCode(SoapFaultDefinition.SERVER);
        exceptionResolver.setDefaultFault(faultDefinition);

        Properties errorMappings = new Properties();
        errorMappings.setProperty(Exception.class.getName(), SoapFaultDefinition.SERVER.toString());
        errorMappings.setProperty(ServiceFaultException.class.getName(), SoapFaultDefinition.SERVER.toString());
        exceptionResolver.setExceptionMappings(errorMappings);
        exceptionResolver.setOrder(1);
        return exceptionResolver;
    }
}
