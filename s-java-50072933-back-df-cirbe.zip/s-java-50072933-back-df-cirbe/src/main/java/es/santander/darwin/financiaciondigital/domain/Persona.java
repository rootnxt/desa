package es.santander.darwin.financiaciondigital.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Persona.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the persona
 */
@Builder

/**
 * Instantiates a new persona.
 */
@NoArgsConstructor

/**
 * Instantiates a new persona.
 *
 * @param tipoDePersona the tipo de persona
 * @param codigoDePersona the codigo de persona
 */
@AllArgsConstructor
public class Persona {
    
    /** The tipo de persona. */
    @JsonProperty("tipo_de_persona")
    private String tipoDePersona;
    
    /** The codigo de persona. */
    @JsonProperty("codigo_de_persona")
    private String codigoDePersona;

}
