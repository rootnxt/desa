package com.santander.darwin.invoice.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/**
 * CustomDataSourceTemplate
 * 
 * @author ciber
 *
 */
@Slf4j
public class CustomDataSourceTemplate extends JdbcTemplate {

	protected String serviceKey;

	@Value("${spring.datasource.url}")
	private String nombrePool;
	@Value("${spring.datasource.username}")
	private String usuario;
	@Value("${spring.datasource.password}")
	private String pass;
	@Value("${spring.datasource.driverClassName}")
	private String driver;

	/**
	 * Constructor
	 * 
	 * @param dataSourceKey String
	 */
	public CustomDataSourceTemplate(String dataSourceKey) {
		this.serviceKey = dataSourceKey;
	}

	/**
	 * Despues de la carga de properties
	 */
	@Override
	public void afterPropertiesSet() {
		this.setDataSourceFromKey();
		super.afterPropertiesSet();
	}

	/**
	 * setDataSourceFromKey
	 */
	public void setDataSourceFromKey() {
		DataSource dataSource = configBBDD();
		this.setDataSource(dataSource);
	}

	/**
	 * configBBDD
	 * 
	 * @return DriverManagerDataSource
	 */
	protected DriverManagerDataSource configBBDD() {
		if (nombrePool == null || usuario == null || pass == null || driver == null) {
			log.error("RESP_BBDD_DATABASE_CONNECTION", "Uno de los valores en bbdd.{0} es nulo o vacio",
					this.serviceKey);
			return null;
		} else {
			DataSourceParamsBean paramsBean = new DataSourceParamsBean(nombrePool, driver, usuario, pass);
			return configureDataSource(paramsBean);
		}
	}

	/**
	 * Returns db datasource from the configuration bean
	 * 
	 * @param paramsBean
	 * @return
	 */
	protected DriverManagerDataSource configureDataSource(DataSourceParamsBean paramsBean) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(paramsBean.getDriver());
		dataSource.setUrl(paramsBean.getDbPoolName());
		dataSource.setUsername(paramsBean.getUser());
		dataSource.setPassword(paramsBean.getPass());
		return dataSource;
	}

	/**
	 * @return the nombrePool
	 */
	public String getNombrePool() {
		return nombrePool;
	}

	/**
	 * @param nombrePool the nombrePool to set
	 */
	public void setNombrePool(String nombrePool) {
		this.nombrePool = nombrePool;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}

	/**
	 * @return the driver
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

}
