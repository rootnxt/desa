package es.santander.darwin.financiaciondigital.service.impl;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.domain.OrchestratorMotorResponse;
import es.santander.darwin.financiaciondigital.domain.PersonDtoRequest;
import es.santander.darwin.financiaciondigital.domain.ProposalDto;
import es.santander.darwin.financiaciondigital.domain.RecoveryEndpointRequest;
import es.santander.darwin.financiaciondigital.domain.RecoveryPhoneAndMailResponse;
import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.domain.SendNotifDto;
import es.santander.darwin.financiaciondigital.domain.TitularesEndpointRequest;
import es.santander.darwin.financiaciondigital.dto.PropuestaRgoDto;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntityPK;
import es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest;
import es.santander.darwin.financiaciondigital.lib.model.ProposalPersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.ProposedInformation;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAService;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import es.santander.darwin.financiaciondigital.soap.repositories.PropuestaRgoJpaRepository;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class CirbeAsyncService.
 */

/** The Constant log. */

/** The Constant log. */
@Slf4j
@Component
public class CirbeAsyncHelper {

    /** The rest consumer cirbe service. */
    @Autowired
    private RestConsumerCirbeService restConsumerCirbeService;

    /** The propuesta rgo jpa repository. */
    @Autowired
    private PropuestaRgoJpaRepository propuestaRgoJpaRepository;

    /** The cirbe sasna service impl. */
    @Autowired
    private CirbeSasnaServiceImpl cirbeSasnaServiceImpl;

    /** The rest consumer service. */
    @Autowired
    private RestConsumerService restConsumerService;

    /** The datos usuario LA. */
    @Autowired
    private DatosUsuarioLAService datosUsuarioLA;

    /** The contrat. */
    @Value("${cirbe.sencol.noti.contrat}")
    private String contrat;

    /** The Sms AC. */
    @Value("${cirbe.sencol.noti.smsAC}")
    private String smsAC;

    /** The sms DL. */
    @Value("${cirbe.sencol.noti.smsDL}")
    private String smsDL;

    /** The mail AC. */
    @Value("${cirbe.sencol.noti.mailAC}")
    private String mailAC;

    /** The mail DL. */
    @Value("${cirbe.sencol.noti.mailDL}")
    private String mailDL;

    /** The Not nece. */
    @Value("${cirbe.sencol.criticality.NoNecesario}")
    private String NotNece;

    /** The Not impre. */
    @Value("${cirbe.sencol.criticality.NoImprecindible}")
    private String NotImpre;

    /** The Impre. */
    @Value("${cirbe.sencol.criticality.Imprecindible}")
    private String Impre;

    /**
     * Call sasna.
     *
     * @param companyId the company id
     * @param personType the person type
     * @param personCode the person code
     * @param petitionUser the petition user
     * @return the future
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Async
    public Future<SasnaResponse> callSasna(String companyId, String personType, BigDecimal personCode,
            String petitionUser) throws DigitalConsumptionServiceException {
        SasnaResponse send = cirbeSasnaServiceImpl.callSasna(companyId, personType, personCode, petitionUser);
        return new AsyncResult<SasnaResponse>(send);
    }

    /**
     * Gets the send notif async.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param sendNotifDto the send notif dto
     * @return the send notif async
     * @throws DigitalConsumptionInternalException the digital consumption internal exception
     */
    @Async
    public Future<Void> getSendNotifAsync(String personType, Integer personCode, SendNotifDto sendNotifDto)
            throws DigitalConsumptionInternalException {
        log.info("Inicio Metodo asincrono getSendNotifAsync " + Thread.currentThread().getName() + ":"
                + Thread.currentThread().getId());
        CompletableFuture<Void> future = new CompletableFuture<Void>();
        try {
            restConsumerCirbeService.senNotiSmsOrEmail(personType, personCode, sendNotifDto);
            log.info("Fin Metodo asincrono senNotiSmsOrEmail " + Thread.currentThread().getName() + ":"
                    + Thread.currentThread().getId());
        } catch (Exception e) {
            log.info("ERROR AL LLAMAR A NOTIFICACIONES");
        }
        future.complete(null);
        return future;
    }

    /**
     * Call orchestrator async.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param callType the call type
     * @param proposalDto the proposal dto
     * @return the future
     * @throws DigitalConsumptionInternalException the digital consumption internal exception
     */
    @Async
    public Future<OrchestratorMotorResponse> callOrchestratorAsync(String personType, Integer personCode,
            String callType, ProposalDto proposalDto) throws DigitalConsumptionInternalException {
        OrchestratorMotorResponse send = restConsumerCirbeService.orchestratorMotor(personType, personCode, callType,
                proposalDto);
        return new AsyncResult<OrchestratorMotorResponse>(send);
    }

    /**
     * Call mod resolutions.
     *
     * @param proposalPersonResponseList the proposal person response list
     * @return the future
     * @throws DigitalConsumptionInternalException the digital consumption internal exception
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    @Async
    public Future<SencolResponse> callModResolutions(List<ProposalPersonRequests> proposalPersonResponseList,
    		PersonDtoRequest person)
            throws DigitalConsumptionInternalException, DigitalConsumptionServiceException, InterruptedException,
            ExecutionException {
        SencolResponse send = proposalPersonResponseLists(proposalPersonResponseList, person);
        return new AsyncResult<SencolResponse>(send);
    }

    /**
     * Call propuesta rgo dto.
     *
     * @param idEmpr the id empr
     * @param idCent the id cent
     * @param year the year
     * @param numPropo the num propo
     * @return the future
     * @throws DigitalConsumptionInternalException the digital consumption internal exception
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Async
    public Future<PropuestaRgoDto> callPropuestaRgoDto(String idEmpr, String idCent, String year, BigDecimal numPropo)
            throws DigitalConsumptionInternalException, DigitalConsumptionServiceException {
        PropuestaRgoDto send = getDataProposalRGO(idEmpr, idCent, year, numPropo);
        return new AsyncResult<PropuestaRgoDto>(send);
    }

    /**
     * Proposal person response lists.
     *
     * @param proposalPersonResponseList the proposal person response list
     * @return the sencol response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    private SencolResponse proposalPersonResponseLists(List<ProposalPersonRequests> proposalPersonResponseList, PersonDtoRequest person)
            throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {
        SencolResponse response = new SencolResponse();
        ProposedInformation proposedInformation = null;
        List<ProposalPersonRequests> proposalPersonList = null;
        ProposalDto proposalDto = null;
	String retornoMotor="";
        try {
            for (int i = 0; i < proposalPersonResponseList.size(); i++) {
                proposalPersonList = restConsumerService.getProposalRequestsUpdate(
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getPersonType(),
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getPersonCode(),
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getCompanyId(),
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getCenterId(),
                        String.valueOf(
                                proposalPersonResponseList.get(i).getRequestPersonIdentifier().getProposalYear()),
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getProposalNumber(),
                        proposalPersonResponseList.get(i).getRequestPersonIdentifier().getSourceType());
                for (int j = 0; j < proposalPersonList.size(); j++) {
                    Future<OrchestratorMotorResponse> orchestratorMotor = null;
                    Future<PropuestaRgoDto> propuestaRgoDto = null;
                    proposalDto = new ProposalDto();
                    proposalDto.setCenterId(proposalPersonList.get(j).getRequestPersonIdentifier().getCenterId());
                    proposalDto.setCompanyId(proposalPersonList.get(j).getRequestPersonIdentifier().getCompanyId());
                    proposalDto.setProposalNumber(
                            proposalPersonList.get(j).getRequestPersonIdentifier().getProposalNumber());
                    proposalDto.setProposalYear(String
                            .valueOf(proposalPersonList.get(j).getRequestPersonIdentifier().getProposalYear()));

                    try {
                        propuestaRgoDto = callPropuestaRgoDto(proposalDto.getCompanyId(), proposalDto.getCenterId(),
                                proposalDto.getProposalYear(), new BigDecimal(proposalDto.getProposalNumber()));

                        propuestaRgoDto.get();
                        log.info("$$$$$$ Call PROPOSAL STATE: LLAMADA CORRECTA, PNA_CODESTAD="
                                + propuestaRgoDto.get().getCotestad() + ", PNA_INDPROCE="
                                + propuestaRgoDto.get().getIndproce());
                    } catch (Exception e) {
                        log.info("$$$$$$ Call PROPOSAL STATE: LLAMADA FALLIDA");
                        throw new DigitalConsumptionServiceException(e,
                                ExceptionsErrorConstants.ERROR_DETAIL_SENCOL_PROPOSAL_STATE);
                    }

                    if (propuestaRgoDto.get().getCotestad().equals(Constants.CODESTAD)) {
                        try {
                            orchestratorMotor = callOrchestratorAsync(
                                    proposalPersonList.get(j).getRequestPersonIdentifier().getPersonType(),
                                    proposalPersonList.get(j).getRequestPersonIdentifier().getPersonCode(),
                                    Constants.CALL_TYPE, proposalDto);

                            orchestratorMotor.get();
                            log.info("$$$$$$ Call Motor: LLAMADA CORRECTA");
                            restConsumerService.getPersonRequestsUpdate(
                                    proposalPersonList.get(j).getRequestPersonIdentifier().getCompanyId(),
                                    proposalPersonList.get(j).getRequestPersonIdentifier().getCenterId(),
                                    String.valueOf(proposalPersonList.get(j).getRequestPersonIdentifier()
                                            .getProposalYear()),
                                    proposalPersonList.get(j).getRequestPersonIdentifier().getProposalNumber());
                        } catch (Exception e) {
                            log.info("$$$$$$ Call Motor: LLAMADA FALLIDA");
                            throw new DigitalConsumptionServiceException(e,
                                    ExceptionsErrorConstants.ERROR_DETAIL_SENCOL_MOTOR);
                        }

                    } else {
                        restConsumerService.getProposalPersonRequestsUpdate(proposalDto.getCompanyId(),
                                proposalDto.getCenterId(), proposalDto.getProposalYear(),
                                proposalDto.getProposalNumber());
                    }
                    if (null != orchestratorMotor) {
                        try {
                            proposedInformation = restConsumerService.sencolUpdate(proposalDto.getCompanyId(),
                                    proposalDto.getCenterId(), proposalDto.getProposalYear(),
                                    proposalDto.getProposalNumber(), orchestratorMotor.get().getReportMotor());
			    retornoMotor = orchestratorMotor.get().getReportMotor();
                            log.info(
                                    "$$$$$$ Actualizacion de Datos ProposedInformation (Fase&&Estado): Actualizacion con Exito");
                            if (propuestaRgoDto.get().getIndproce().equals(Constants.PROCESS_INDICATOR)) {
                                notiEmailAndPhone(proposedInformation);
                            }
                        } catch (Exception e) {
                            log.info(
                                    "$$$$$$ Actualizacion de Datos ProposedInformation (Fase&&Estado): Actualizacion fallida");
                            throw new DigitalConsumptionServiceException(e,
                                    ExceptionsErrorConstants.ERROR_DETAIL_SENCOL_MOTOR);
                        }
                    }
                }

                ProposalPersonRequests recoveredProposal = proposalPersonResponseList.get(i);
                
                String validEndpoint = restConsumerService.getValidEndpoint(Constants.APP_NAME, recoveredProposal.getSubApplication());
                
                if (StringUtils.isNotBlank(validEndpoint)) {
                    log.info("$$$$$$ Async endpoint url: " + validEndpoint);

                    RecoveryEndpointRequest recoveryRequest = new RecoveryEndpointRequest();
                    recoveryRequest.setBdeCode(person.getBdeCode());
                    recoveryRequest.setBdeDescription(person.getBdeDescription());
                    recoveryRequest.setDecision(retornoMotor);
                    recoveryRequest.setReturnValue(response.getCode());
                    recoveryRequest.setPersonType(person.getPersonType());
                    recoveryRequest.setPersonCode(person.getPersonCode().intValue());
                    recoveryRequest.setCompanyId(recoveredProposal.getRequestPersonIdentifier().getCompanyId());
                    recoveryRequest.setCenterId(recoveredProposal.getRequestPersonIdentifier().getCenterId());
                    recoveryRequest.setProposalYear(recoveredProposal.getRequestPersonIdentifier().getProposalYear());
                    recoveryRequest.setProposalNumber(recoveredProposal.getRequestPersonIdentifier().getProposalNumber());
                    
                    List<TitularesEndpointRequest> titulares = proposalPersonResponseList.stream().map( ppr -> TitularesEndpointRequest.builder()
                            .personCode(person.getPersonCode())
                            .personType(person.getPersonType())
                            .sourceType(recoveredProposal.getRequestPersonIdentifier().getSourceType())
                            .sourceState(recoveredProposal.getSourceState())
                            .criticalityData(recoveredProposal.getCriticalityData())
                            .processIndicator(recoveredProposal.getProcessIndicator())
                        .build()).collect(Collectors.toList());
                    
                    recoveryRequest.setTitulares(titulares);

                    log.info("$$$$$$ Executing Async endpoint request body: " + recoveryRequest.toString());
                    
                    Future<Void> recoveryEndpoint = recoveryEndpointAsync(validEndpoint, recoveryRequest);
                    recoveryEndpoint.get();
                    log.info("$$$$$$ Call Async endpoint: LLAMADA FINALIZADA AL ENDPOINT EXTERNO");
                }
            }
            return response;
        } catch (Exception e) {
            throw e;
        }
    }
    
	/**
	 * Recovery endpoint async.
	 *
	 * @param endpoint
	 *            the endpoint
	 * @param recoveryRequest
	 *            the recovery request
	 * @return the future
	 * @throws DigitalConsumptionInternalException
	 *             the digital consumption internal exception
	 */
	@Async
	public Future<Void> recoveryEndpointAsync(String endpoint, RecoveryEndpointRequest recoveryRequest)
			throws DigitalConsumptionInternalException {
		CompletableFuture<Void> future = new CompletableFuture<Void>();
		try {
			restConsumerCirbeService.recoveryEndpoint(endpoint, recoveryRequest);
			log.info("Fin Metodo asincrono recoveryEndpointAsync " + Thread.currentThread().getName() + ":"
					+ Thread.currentThread().getId());
		} catch (Exception e) {
			log.info("ERROR AL CONSUMIR EL SERVICIO", e);
		}
		future.complete(null);
		return future;
	}

    /**
     * Noti email and phone.
     *
     * @param proposedInformation the proposed information
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void notiEmailAndPhone(ProposedInformation proposedInformation)
            throws InterruptedException, ExecutionException, DigitalConsumptionServiceException {
        ProposalRequest proposalRequest = new ProposalRequest();
        proposalRequest.setCenterId(proposedInformation.getProcessIdentifier().getProposalCode().getCenter());
        proposalRequest.setCompanyId(proposedInformation.getProcessIdentifier().getProposalCode().getCompany());
        proposalRequest
                .setProposalNumber(proposedInformation.getProcessIdentifier().getProposalCode().getProposalNumber());
        proposalRequest.setProposalYear(proposedInformation.getProcessIdentifier().getProposalCode().getYear());

        RecoveryPhoneAndMailResponse personal = restConsumerCirbeService.recoveryPhoneMail(
                proposedInformation.getProcessIdentifier().getPerson().getPersonType(),
                proposedInformation.getProcessIdentifier().getPerson().getPersonCode(), proposalRequest);

        if (null != personal) {
            String userName = null;
            userName = datosUsuarioLA.getUserName(proposalRequest.getCompanyId());
            log.info("user Name: " + userName);
            SendNotifDto sendNotifDto = new SendNotifDto();
            String sms = "", mail = "", subject = "";
            sendNotifDto.setCompanyId(proposedInformation.getProcessIdentifier().getProposalCode().getCompany());

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.FORMAT_DATE);
            String formatDate = proposedInformation.getProposalData().getUpdateProposalTimestamp()
                    .format(formatter);
            if (proposedInformation.getProposalData().getProposalState().equals(Constants.PROPOSAL_STATE_02)) {
                sms = MessageFormat.format(smsAC,
                        proposedInformation.getProcessIdentifier().getProduct().getProductDescription());
                mail = MessageFormat.format(mailAC, userName, formatDate, contrat);
                subject = Constants.SUBJECT_REQUEST_OF
                        + proposedInformation.getProcessIdentifier().getProduct().getProductDescription();
            }
            if (proposedInformation.getProposalData().getProposalState().equals(Constants.PROPOSAL_STATE_06)) {
                sms = MessageFormat.format(smsDL,
                        proposedInformation.getProcessIdentifier().getProduct().getProductDescription());
                mail = MessageFormat.format(mailDL, userName, formatDate,
                        proposedInformation.getProcessIdentifier().getProduct().getProductDescription());
                subject = Constants.SUBJECT_REQUEST_OF
                        + proposedInformation.getProcessIdentifier().getProduct().getProductDescription();
            }

            if (!StringUtils.isBlank(personal.getPhoneNumber())) {
                log.info("telefono: " + personal.getPhoneNumber());
                sendNotifDto.setPhoneNumber(personal.getPhoneNumber());
                sendNotifDto.setInternationalPrefix(personal.getInternationalPrefix());
                sendNotifDto.setIndNotif(Constants.IDENT_NOTI_0);
                sendNotifDto.setMessage(sms);
                Future<?> sendNotif = getSendNotifAsync(
                        proposedInformation.getProcessIdentifier().getPerson().getPersonType(),
                        proposedInformation.getProcessIdentifier().getPerson().getPersonCode(), sendNotifDto);
                log.info("$$$$$$ Send Notification SMS: Se ha enviado la Notificacion correctamente");
            }

            if (!StringUtils.isBlank(personal.getEmail())) {
                log.info("email: " + personal.getEmail());
                sendNotifDto.setEmail(personal.getEmail());
                sendNotifDto.setIndNotif(Constants.IDENT_NOTI_1);
                sendNotifDto.setSubject(subject);
                sendNotifDto.setMessage(mail);
                Future<?> sendNotif = getSendNotifAsync(
                        proposedInformation.getProcessIdentifier().getPerson().getPersonType(),
                        proposedInformation.getProcessIdentifier().getPerson().getPersonCode(), sendNotifDto);
                log.info("$$$$$$ Send Notification Mail: Se ha enviado la Notificacion correctamente");
            }

        }
    }

    /**
     * Gets the data proposal RGO.
     *
     * @param idEmpr the id empr
     * @param idCent the id cent
     * @param year the year
     * @param numPropo the num propo
     * @return the data proposal RGO
     */
    private PropuestaRgoDto getDataProposalRGO(String idEmpr, String idCent, String year, BigDecimal numPropo) {
        PropuestaRgoDto pptaDto = new PropuestaRgoDto();
        PropuestaRgoEntityPK pk = PropuestaRgoEntityPK.builder().anoprop(year).idcent(idCent).idempr(idEmpr)
                .numprop(numPropo).build();
        Optional<PropuestaRgoEntity> proposalRgo = propuestaRgoJpaRepository.findById(pk);
        if (proposalRgo.isPresent()) {
            pptaDto = PropuestaRgoDto.builder().cotestad(proposalRgo.get().getCotestad())
                    .indproce(proposalRgo.get().getIndproce()).build();
        }
        return pptaDto;
    }
}
