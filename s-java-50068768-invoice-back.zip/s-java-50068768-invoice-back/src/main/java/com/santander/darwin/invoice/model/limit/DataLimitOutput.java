package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the products.
 *
 * @return the products
 */
@Getter

/**
 * Sets the products.
 *
 * @param products the new products
 */
@Setter

/**
 * Instantiates a new data limit output.
 */
@NoArgsConstructor
public class DataLimitOutput {

    /** The type finance. */
    private TypeFinance typeFinance;
    
    /** The products. */
    private List<TypeFinanceProducts> products;

}
