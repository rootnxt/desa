package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * 
 * The printPoliciesInput class.
 *
 */
@Getter
@Setter
public class PrintPoliciesInput {
    
	/** The proposal. */
    private Proposal proposal;
    
    /** The language. */ 
    private LanguageBean language;
    
    /** The docName. */
    private String docName;
    
    /** The indSignature.  */
    private String indSignature;
    
    /** The list signers. */
    private List<Signer> listSigners;
    
    /** The typDocument. */
    private String typDocument;
    
    /** The print page. */
    private String printPage;
    
    /** The tae. */
    private Double tae;
    
    /** The intervNotarial. */
    private String intervNotarial;
    
}
