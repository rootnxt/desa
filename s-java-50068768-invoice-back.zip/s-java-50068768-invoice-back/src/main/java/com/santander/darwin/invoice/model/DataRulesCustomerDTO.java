package com.santander.darwin.invoice.model;

import lombok.Data;

import java.util.List;

/**
 * Proposal Response.
 *
 * @author NttData
 */

/**
 * Instantiates a new data rules customer DTO.
 */
@Data
public class DataRulesCustomerDTO {
	
	/** The customer id. */
	private String customerId;
	
	/** The embedded. */
	private List<DataRulesDTO> embedded;

}
