package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Conditions.java
 *
 * @author igndom
 *
 */
public class Conditions {

	private Capital nextInstallmentAmount;
	private String nextInstallmentDate;
	private String interestRate;

	/**
	 * @return the nextInstallmentAmount
	 */
	public Capital getNextInstallmentAmount() {
		return nextInstallmentAmount;
	}

	/**
	 * @param nextInstallmentAmount the nextInstallmentAmount to set
	 */
	public void setNextInstallmentAmount(Capital nextInstallmentAmount) {
		this.nextInstallmentAmount = nextInstallmentAmount;
	}

	/**
	 * @return the nextInstallmentDate
	 */
	public String getNextInstallmentDate() {
		return nextInstallmentDate;
	}

	/**
	 * @param nextInstallmentDate the nextInstallmentDate to set
	 */
	public void setNextInstallmentDate(String nextInstallmentDate) {
		this.nextInstallmentDate = nextInstallmentDate;
	}

	/**
	 * @return the interestRate
	 */
	public String getInterestRate() {
		return interestRate;
	}

	/**
	 * @param interestRate the interestRate to set
	 */
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}

}
