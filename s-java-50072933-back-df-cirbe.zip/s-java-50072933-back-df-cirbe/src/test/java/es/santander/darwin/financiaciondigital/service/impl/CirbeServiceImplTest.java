package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import es.santander.darwin.financiaciondigital.constant.ErrorConstants;
import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.domain.ConsultPersonProcessResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsultPersonResponseVO;
import es.santander.darwin.financiaciondigital.domain.PersonDtoRequest;
import es.santander.darwin.financiaciondigital.domain.PersonVO;
import es.santander.darwin.financiaciondigital.domain.PetitionsTreatmentProcessResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolDto;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolMotorDTO;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.domain.SourceTypeVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.jpa.model.PersoPropuestaEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PersoPropuestaEntityPK;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntityPK;
import es.santander.darwin.financiaciondigital.lib.model.PersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.ProposalPersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.bean.PersonRequestIdentifier;
import es.santander.darwin.financiaciondigital.lib.model.bean.ProposalRequestsSencol;
import es.santander.darwin.financiaciondigital.lib.model.bean.RequestPersonIdentifier;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.CiriteService;
import es.santander.darwin.financiaciondigital.service.ConsolidadoCirbeService;
import es.santander.darwin.financiaciondigital.service.DFLibConnectorService;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import es.santander.darwin.financiaciondigital.soap.DataPerson;
import es.santander.darwin.financiaciondigital.soap.GetPersonRequest;
import es.santander.darwin.financiaciondigital.soap.GetPersonResponse;
import es.santander.darwin.financiaciondigital.soap.PersonListVO;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalResponse;
import es.santander.darwin.financiaciondigital.soap.repositories.PersonProposalJpaRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.PersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.ProposalPersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.PropuestaRgoJpaRepository;

/**
 * The Class CirbeServiceImplTest.
 */
public class CirbeServiceImplTest {

    /** The cirbe service. */
    @Spy
    @InjectMocks
    private CirbeServiceImpl cirbeService = new CirbeServiceImpl();

    /** The cirbe async helper. */
    @Mock
    private CirbeAsyncHelper cirbeAsyncHelper = new CirbeAsyncHelper();

    /** The lib connector svc. */
    @Mock
    private DFLibConnectorService libConnectorSvc;

    /** The consolidado cirbe service. */
    @Mock
    private ConsolidadoCirbeService consolidadoCirbeService;

    /** The rest consumer service. */
    @Mock
    private RestConsumerService restConsumerService;

    @Mock
    private RestConsumerCirbeService restConsumerCirbeService;

    /** The person requests repository. */
    @Mock
    private PersonRequestsRepository personRequestsRepository;

    @Mock
    private PersonProposalJpaRepository persoPropRepository;

    /** The person request. */
    @Mock
    private List<PersonRequests> personRequest;

    /** The person. */
    @Mock
    private DataPerson person;

    /** The cirite service. */
    @Mock
    private CiriteService ciriteService;

    /** The propuesta rgo jpa repository. */
    @Mock
    private PropuestaRgoJpaRepository propuestaRgoJpaRepository;

    /** The proposal person requests repository. */
    @Mock
    private ProposalPersonRequestsRepository proposalPersonRequestsRepository;

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
        personRequest = new ArrayList<>();
        person = new DataPerson();
    }

    /**
     * Gets the person request test OK 1.
     *
     * @return the person request test OK 1
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    @Test
    public void getPersonRequestTestOK1() throws DigitalConsumptionServiceException, DatatypeConfigurationException {
        GetPersonRequest proposalRequests = new GetPersonRequest();

        proposalRequests.setCompanyID("0049");
        proposalRequests.setPersonType("J");
        proposalRequests.setPersonCode(new BigDecimal(320));
        PersonRequests personRequests = new PersonRequests();
        personRequests.setAdmissionDate(new Date());
        personRequests.setModificationDate(new Date());
        personRequests.setPetitionsNumber(1);
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setSourceType("CIRBE");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        personRequest.add(personRequests);

        doReturn(personRequest).when(personRequestsRepository).findPersonRequestForPetitions2(
                any(String.class), any(String.class), any(Integer.class));
        GetPersonResponse response = new GetPersonResponse();
        PersonListVO personVO = new PersonListVO();
        personVO.getDataPersonLists().add(person);
        response.getDataPersonLists().add(personVO);
        response = cirbeService.getPersonRequest(proposalRequests);
        assertNotNull(response);
    }

    /**
     * Gets the person request test OK 2.
     *
     * @return the person request test OK 2
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Test
    public void getPersonRequestTestOK2() throws DigitalConsumptionServiceException {
        GetPersonRequest proposalRequests = new GetPersonRequest();

        proposalRequests.setCompanyID("0049");
        proposalRequests.setPersonType("J");
        proposalRequests.setPersonCode(new BigDecimal(320));
        PersonRequests personRequests = new PersonRequests();
        personRequests.setAdmissionDate(new Date());
        personRequests.setModificationDate(new Date());
        personRequests.setPetitionsNumber(1);
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setSourceType("CIRBE");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        personRequest.add(personRequests);

        doReturn(personRequest).when(personRequestsRepository).findPersonRequestForPetitions2(
                any(String.class), any(String.class), any(Integer.class));

        GetPersonResponse response = cirbeService.getPersonRequest(proposalRequests);
        assertNotNull(response);
    }

    /**
     * Gets the person request test NOK 1.
     *
     * @return the person request test NOK 1
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getPersonRequestTestNOK1() throws DigitalConsumptionServiceException {
        GetPersonRequest proposalRequests = new GetPersonRequest();
        proposalRequests.setCompanyID("0049");
        proposalRequests.setPersonType("J");
        proposalRequests.setPersonCode(new BigDecimal(320));
        doReturn(personRequest).when(personRequestsRepository).findPersonRequestForPetitions2(
                any(String.class), any(String.class), any(Integer.class));
        cirbeService.getPersonRequest(proposalRequests);
    }

    /**
     * Gets the person request test NOK 3.
     *
     * @return the person request test NOK 3
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getPersonRequestTestNOK3() throws DigitalConsumptionServiceException {
        GetPersonRequest proposalRequests = new GetPersonRequest();
        proposalRequests.setCompanyID("");
        proposalRequests.setPersonType("");
        proposalRequests.setPersonCode(null);
        cirbeService.getPersonRequest(proposalRequests);
    }

    /**
     * Gets the person request test NOK 4.
     *
     * @return the person request test NOK 4
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getPersonRequestTestNOK4() throws DigitalConsumptionServiceException {
        GetPersonRequest proposalRequests = new GetPersonRequest();
        proposalRequests.setCompanyID("00049");
        proposalRequests.setPersonType("Jj");
        proposalRequests.setPersonCode(new BigDecimal(320));
        cirbeService.getPersonRequest(proposalRequests);
    }

    /**
     * Gets the petitions of person and proposals response test OK 1.
     *
     * @return the petitions of person and proposals response test OK 1
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    @Test
    public void getPetitionsOfPersonAndProposalsResponseTestOK1()
            throws DigitalConsumptionServiceException, DatatypeConfigurationException {
        PropuestaRgoEntityPK propuestaRgoEntityPkMock =
                new PropuestaRgoEntityPK("0029", "0282", "2019", new BigDecimal(322));
        PropuestaRgoEntity propRgoEntMock = new PropuestaRgoEntity();
        propRgoEntMock.setId(propuestaRgoEntityPkMock);
        propRgoEntMock.setA1tippcc("tippcc");
        propRgoEntMock.setA1tippci("tippci");
        propRgoEntMock.setA1tippld("tippId");
        propRgoEntMock.setCotestad("11");
        propRgoEntMock.setIndproce("12");
        Optional<PropuestaRgoEntity> proposalRgoMock = Optional.of(propRgoEntMock);
        RequestPersonIdentifier requestPersonIdentifier =
                new RequestPersonIdentifier("0049", "0282", 2019, 322, "J", 45, "CIRBE");
        ProposalPersonRequests proposalPersonRequestMock = new ProposalPersonRequests("11", requestPersonIdentifier,
                "11", "1", "S", "T1", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod", null);
        List<ProposalPersonRequests> proposalPersonRequestsMock = new ArrayList<>();
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        PersonRequestIdentifier personReqIdentifierMock = new PersonRequestIdentifier("0049", "J", 45, "CIRBE");
        PersonRequests personRequestMock = new PersonRequests("123", personReqIdentifierMock, "S", "1", 111, "0046",
                "descCode", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod");
        List<PersonRequests> personRequestsListMock = new ArrayList<>();
        personRequestsListMock.add(personRequestMock);
        personRequestsListMock.add(personRequestMock);

        doReturn(proposalRgoMock).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));
        doReturn(proposalPersonRequestsMock).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsForPetitions(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class));
        doReturn(personRequestsListMock).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class),
                any(String.class));

        PetitionsOfPersonAndProposalResponse response = new PetitionsOfPersonAndProposalResponse();
        PetitionsOfPersonAndProposalRequest request = new PetitionsOfPersonAndProposalRequest();
        request.setCenter("0282");
        request.setCompany("0049");
        request.setProposalNumber("322");
        request.setYear("2019");
        response = cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
        assertNotNull(response);
    }

    @Test
    public void getPetitionsOfPersonAndProposalsResponseTestOK2()
            throws DigitalConsumptionServiceException, DatatypeConfigurationException {
        PropuestaRgoEntityPK propuestaRgoEntityPkMock =
                new PropuestaRgoEntityPK("0029", "0282", "2019", new BigDecimal(322));
        PropuestaRgoEntity propRgoEntMock = new PropuestaRgoEntity();
        propRgoEntMock.setId(propuestaRgoEntityPkMock);
        propRgoEntMock.setA1tippcc("tippcc");
        propRgoEntMock.setA1tippci("tippci");
        propRgoEntMock.setA1tippld("tippId");
        propRgoEntMock.setCotestad("11");
        propRgoEntMock.setIndproce("12");
        PersonRequestIdentifier personReqIdentifierMock = new PersonRequestIdentifier("0049", "J", 45, "CIRBE");
        PersonRequests personRequestMock = new PersonRequests("123", personReqIdentifierMock, "S", "1", 111, "0046",
                "descCode", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod");
        List<PersonRequests> personRequestsListMock = new ArrayList<>();
        personRequestsListMock.add(personRequestMock);
        personRequestsListMock.add(personRequestMock);

        List<PersoPropuestaEntity> listaTitulares = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaTitulares = new PersoPropuestaEntity();
        persoPropuestaTitulares.setFormint("uwu");
        PersoPropuestaEntityPK idT = new PersoPropuestaEntityPK();
        idT.setCenterId("0282");
        idT.setCompanyId("0049");
        idT.setIntervType("01");
        idT.setOrdintc(123);
        idT.setPersonCode(new BigDecimal("200"));
        idT.setPersonType("J");
        idT.setProposalNumber(new BigDecimal("1234"));
        idT.setProposalYear("2019");
        persoPropuestaTitulares.setId(idT);
        persoPropuestaTitulares.setImporAct(new BigDecimal("1234"));
        persoPropuestaTitulares.setIndProju("uwu");
        persoPropuestaTitulares.setIndrai("uwu");
        persoPropuestaTitulares.setModifierUser("uwu");
        persoPropuestaTitulares.setModifyDate(LocalDate.now());
        persoPropuestaTitulares.setPorParti(new BigDecimal("1234"));
        persoPropuestaTitulares.setRegMatri("uwu");
        listaTitulares.add(persoPropuestaTitulares);

        List<PersoPropuestaEntity> listaAvalistas = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaAvalistas = new PersoPropuestaEntity();
        PersoPropuestaEntityPK idA = new PersoPropuestaEntityPK();
        idA.setCenterId("0282");
        idA.setCompanyId("0049");
        idA.setIntervType("01");
        idA.setOrdintc(123);
        idA.setPersonCode(new BigDecimal("200"));
        idA.setPersonType("J");
        idA.setProposalNumber(new BigDecimal("1234"));
        idA.setProposalYear("2019");
        persoPropuestaAvalistas.setId(idA);
        listaAvalistas.add(persoPropuestaAvalistas);
        doReturn(listaTitulares).when(persoPropRepository).getListaTitulares(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(listaAvalistas).when(persoPropRepository).getListaAvalistas(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(personRequest).when(personRequestsRepository).findPersonRequestForPetitions2(
                any(String.class), any(String.class), any(Integer.class));

        PetitionsOfPersonAndProposalResponse response = new PetitionsOfPersonAndProposalResponse();
        PetitionsOfPersonAndProposalRequest request = new PetitionsOfPersonAndProposalRequest();
        request.setCenter("0282");
        request.setCompany("0049");
        request.setProposalNumber("322");
        request.setYear("2019");
        response = cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
        assertNotNull(response);
    }

    /**
     * Gets the petitions of person and proposals response test NOK 1.
     *
     * @return the petitions of person and proposals response test NOK 1
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    @Test(expected = DatatypeConfigurationException.class)
    public void getPetitionsOfPersonAndProposalsResponseTestNOK1()
            throws DigitalConsumptionServiceException, DatatypeConfigurationException {

        PropuestaRgoEntityPK propuestaRgoEntityPkMock =
                new PropuestaRgoEntityPK("0029", "0282", "2019", new BigDecimal(322));
        PropuestaRgoEntity propRgoEntMock = new PropuestaRgoEntity();
        propRgoEntMock.setId(propuestaRgoEntityPkMock);
        propRgoEntMock.setA1tippcc("tippcc");
        propRgoEntMock.setA1tippci("tippci");
        propRgoEntMock.setA1tippld("tippId");
        propRgoEntMock.setCotestad("11");
        propRgoEntMock.setIndproce("12");
        Optional<PropuestaRgoEntity> proposalRgoMock = Optional.of(propRgoEntMock);
        RequestPersonIdentifier requestPersonIdentifier =
                new RequestPersonIdentifier("0049", "0282", 2019, 322, "J", 45, "CIRBE");
        ProposalPersonRequests proposalPersonRequestMock = new ProposalPersonRequests("11", requestPersonIdentifier,
                "11", "1", "S", "T1", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod", null);
        List<ProposalPersonRequests> proposalPersonRequestsMock = new ArrayList<>();
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        PersonRequestIdentifier personReqIdentifierMock = new PersonRequestIdentifier("0049", "J", 45, "CIRBE");
        PersonRequests personRequestMock = new PersonRequests("123", personReqIdentifierMock, "S", "1", 111, "0046",
                "descCode", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod");
        List<PersonRequests> personRequestsListMock = new ArrayList<>();
        personRequestsListMock.add(personRequestMock);

        doReturn(proposalRgoMock).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));
        doReturn(proposalPersonRequestsMock).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsForPetitions(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class));
        doReturn(personRequestsListMock).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class),
                any(String.class));
        doThrow(new DatatypeConfigurationException()).when(cirbeService).getXmlGregorianChange(any(Date.class));

        PetitionsOfPersonAndProposalRequest request = new PetitionsOfPersonAndProposalRequest();
        request.setCenter("0282");
        request.setCompany("0049");
        request.setProposalNumber("322");
        request.setYear("2019");
        cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
    }

    @Test(expected = DigitalConsumptionServiceException.class)
    public void getPetitionsOfPersonAndProposalsResponseTestNOK2()
            throws DigitalConsumptionServiceException, DatatypeConfigurationException {
        PropuestaRgoEntityPK propuestaRgoEntityPkMock =
                new PropuestaRgoEntityPK("0029", "0282", "2019", new BigDecimal(322));
        PropuestaRgoEntity propRgoEntMock = new PropuestaRgoEntity();
        propRgoEntMock.setId(propuestaRgoEntityPkMock);
        propRgoEntMock.setA1tippcc("tippcc");
        propRgoEntMock.setA1tippci("tippci");
        propRgoEntMock.setA1tippld("tippId");
        propRgoEntMock.setCotestad("11");
        propRgoEntMock.setIndproce("12");
        Optional<PropuestaRgoEntity> proposalRgoMock = Optional.of(propRgoEntMock);
        RequestPersonIdentifier requestPersonIdentifier =
                new RequestPersonIdentifier("0049", "0282", 2019, 322, "J", 45, "CIRBE");
        ProposalPersonRequests proposalPersonRequestMock = new ProposalPersonRequests("11", requestPersonIdentifier,
                "11", "1", "S", "T1", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod", null);
        List<ProposalPersonRequests> proposalPersonRequestsMock = new ArrayList<>();
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        PersonRequestIdentifier personReqIdentifierMock = new PersonRequestIdentifier("0049", "J", 45, "CIRBE");
        PersonRequests personRequestMock = new PersonRequests("123", personReqIdentifierMock, "S", "1", 111, "0046",
                "descCode", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod");
        List<PersonRequests> personRequestsListMock = new ArrayList<>();
        personRequestsListMock.add(personRequestMock);
        personRequestsListMock.add(personRequestMock);
        doReturn(personRequestsListMock).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class),
                any(String.class));
        doReturn(proposalRgoMock).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));
        doReturn(proposalPersonRequestsMock).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsForPetitions(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class));
        doReturn(personRequestsListMock).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class),
                any(String.class));

        PetitionsOfPersonAndProposalResponse response = new PetitionsOfPersonAndProposalResponse();
        PetitionsOfPersonAndProposalRequest request = new PetitionsOfPersonAndProposalRequest();
        request.setCenter(null);
        request.setCompany(null);
        request.setProposalNumber(null);
        request.setYear(null);
        response = cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
        assertNotNull(response);
    }

    @Test(expected = DigitalConsumptionServiceException.class)
    public void getPetitionsOfPersonAndProposalsResponseTestNOK3()
            throws DigitalConsumptionServiceException, DatatypeConfigurationException {
        PropuestaRgoEntityPK propuestaRgoEntityPkMock =
                new PropuestaRgoEntityPK("0029", "0282", "2019", new BigDecimal(322));
        PropuestaRgoEntity propRgoEntMock = new PropuestaRgoEntity();
        propRgoEntMock.setId(propuestaRgoEntityPkMock);
        propRgoEntMock.setA1tippcc("tippcc");
        propRgoEntMock.setA1tippci("tippci");
        propRgoEntMock.setA1tippld("tippId");
        propRgoEntMock.setCotestad("11");
        propRgoEntMock.setIndproce("12");
        Optional<PropuestaRgoEntity> proposalRgoMock = Optional.of(propRgoEntMock);
        RequestPersonIdentifier requestPersonIdentifier =
                new RequestPersonIdentifier("0049", "0282", 2019, 322, "J", 45, "CIRBE");
        ProposalPersonRequests proposalPersonRequestMock = new ProposalPersonRequests("11", requestPersonIdentifier,
                "11", "1", "S", "T1", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod", null);
        List<ProposalPersonRequests> proposalPersonRequestsMock = new ArrayList<>();
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        proposalPersonRequestsMock.add(proposalPersonRequestMock);
        PersonRequestIdentifier personReqIdentifierMock = new PersonRequestIdentifier("0049", "J", 45, "CIRBE");
        PersonRequests personRequestMock = new PersonRequests("123", personReqIdentifierMock, "S", "1", 111, "0046",
                "descCode", new Date(System.currentTimeMillis() + 360000),
                new Date(System.currentTimeMillis() + 720000), "userMod");
        List<PersonRequests> personRequestsListMock = new ArrayList<>();
        personRequestsListMock.add(personRequestMock);
        personRequestsListMock.add(personRequestMock);

        doReturn(proposalRgoMock).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));
        doReturn(proposalPersonRequestsMock).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsForPetitions(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class));
        doReturn(personRequestsListMock).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class),
                any(String.class));

        PetitionsOfPersonAndProposalResponse response = new PetitionsOfPersonAndProposalResponse();
        PetitionsOfPersonAndProposalRequest request = new PetitionsOfPersonAndProposalRequest();
        request.setCenter("");
        request.setCompany("");
        request.setProposalNumber("");
        request.setYear("");
        response = cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
        assertNotNull(response);
    }

    @Test
    public void callSencolNOK_Async() throws Exception {

        Future<SencolResponse> response = null;

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doReturn(response).when(cirbeAsyncHelper).callSasna(any(String.class), any(String.class), any(BigDecimal.class),
                any(String.class));

        cirbeService.callSencol(body);

    }

    @Test
    public void callSencolNOK_Person() throws Exception {

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("00499");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("1234567890"));
        personDto.setPersonType("JJ");
        personList.add(personDto);
        body.setPersonList(personList);

        SencolResponse result = cirbeService.callSencol(body);
        assertNotNull(result);

    }

    @Test
    public void callSencolNOK2_Person() throws Exception {

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("004");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("1234567890"));
        personDto.setPersonType("");
        personList.add(personDto);
        body.setPersonList(personList);

        SencolResponse result = cirbeService.callSencol(body);
        assertNotNull(result);

    }

    @Test
    public void callSencolNull_Person() throws Exception {

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(null);
        personDto.setPersonType("");
        personList.add(personDto);
        body.setPersonList(personList);

        SencolResponse result = cirbeService.callSencol(body);
        assertNotNull(result);

    }

    @Test
    public void callSencolNull2_Person() throws Exception {

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId(null);
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(null);
        personDto.setPersonType(null);
        personList.add(personDto);
        body.setPersonList(personList);

        SencolResponse result = cirbeService.callSencol(body);
        assertNotNull(result);

    }

    @Test
    public void callSencolOK_Async2() throws Exception {

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);
        Future<SencolResponse> callModSencol = null;

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doReturn(personRequests).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));
        doReturn(proposalPersonResponseList).when(restConsumerService).sencolProposalPersonRequests(any(String.class),
                any(Integer.class), any(String.class));
        doReturn(callModSencol).when(cirbeAsyncHelper).callModResolutions(proposalPersonResponseList, null);

        cirbeService.callSencol(body);

    }

    @Test
    public void callSencolNOK2_Async()
            throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException("uwu", "200", t);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("B0001");
        personDto.setBdeDescription("bde");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doThrow(e).when(cirbeAsyncHelper).callSasna(any(String.class), any(String.class), any(BigDecimal.class),
                any(String.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_10));

    }

    @Test
    public void callSencolNOK3() throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException("uwu", "200", t,
                ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PERSON_REQUESTS);

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doReturn(personRequests).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));
        doThrow(e).when(restConsumerService).sencolProposalPersonRequests(any(String.class),
                any(Integer.class), any(String.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_20));

    }

    @Test
    public void callSencolNOK4() throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException("uwu", "200", t,
                ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS);

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doThrow(e).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_30));

    }

    @Test
    public void callSencolNOK5() throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException("uwu", "200", t,
                ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PROPOSAL_STATE);

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doThrow(e).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_40));

    }

    @Test
    public void callSencolNOK6() throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e = new DigitalConsumptionServiceException("uwu", "200", t,
                ErrorMessagesConstants.ERROR_DETAIL_SENCOL_MOTOR);

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doThrow(e).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_50));

    }

    @Test
    public void callSencolNOK7() throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        Throwable t = new Throwable();
        DigitalConsumptionServiceException e =
                new DigitalConsumptionServiceException("uwu", "200", t, ErrorMessagesConstants.ERROR_CODE_NO_ACCOUNT);

        PersonRequests personRequests = new PersonRequests();
        PersonRequestIdentifier personRequestIdentifier = new PersonRequestIdentifier();
        personRequestIdentifier.setCompanyId("0049");
        personRequestIdentifier.setPersonCode(1234);
        personRequestIdentifier.setPersonType("J");
        personRequestIdentifier.setSourceType("uwu");
        personRequests.setPersonRequestIdentifier(personRequestIdentifier);
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequests = new ProposalPersonRequests();
        proposalPersonResponseList.add(proposalPersonRequests);

        ProposalRequestsSencolDto body = new ProposalRequestsSencolDto();
        body.setCompanyId("0049");
        body.setUserRequest("uwu");
        List<PersonDtoRequest> personList = new ArrayList<>();
        PersonDtoRequest personDto = new PersonDtoRequest();
        personDto.setBdeCode("12345");
        personDto.setBdeDescription("uwu");
        personDto.setPersonCode(new BigDecimal("200"));
        personDto.setPersonType("J");
        personList.add(personDto);
        body.setPersonList(personList);

        doThrow(e).when(restConsumerService).sencolPersonRequests(any(ProposalRequestsSencol.class));

        SencolResponse response = cirbeService.callSencol(body);
        assertTrue(response.getCode().equalsIgnoreCase(ErrorConstants.ERROR_CODE_SENCOL_100));

    }

    @Test
    public void callTreatmentProcessTestNull() throws Exception {

        ProposalRequestsSencolMotorDTO proposalRequest = new ProposalRequestsSencolMotorDTO();
        proposalRequest.setCenter("0282");
        proposalRequest.setCompany("0049");
        proposalRequest.setModificationUser("uwu");
        proposalRequest.setProposalNumber(1234);
        proposalRequest.setYear(2019);

        ConsultPersonResponseVO consultPersonResponse = null;
        Map<String, String> bodyParamMap = new HashMap<String, String>();
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        doReturn(consultPersonResponse).when(restConsumerCirbeService).consultPerson(bodyParamMap);

        PetitionsTreatmentProcessResponse response = cirbeService.callTreatmentProcess(proposalRequest);
        assertTrue(response.getResponseMessage().equalsIgnoreCase(ErrorConstants.ERROR_PERSONA_ASOCIADA));

    }

    @Test
    public void callTreatmentProcessTestOKT() throws Exception {

        ProposalRequestsSencolMotorDTO proposalRequest = new ProposalRequestsSencolMotorDTO();
        proposalRequest.setCenter("0282");
        proposalRequest.setCompany("0049");
        proposalRequest.setModificationUser("uwu");
        proposalRequest.setProposalNumber(1234);
        proposalRequest.setYear(2019);

        ConsultPersonProcessResponseVO consultPersonResponse = new ConsultPersonProcessResponseVO();
        List<PersonVO> personList = new ArrayList<>();
        PersonVO personVO = new PersonVO();
        personVO.setIntervencion("T11");
        List<SourceTypeVO> sourceTypeList = new ArrayList<>();
        SourceTypeVO sourceTypeVO = new SourceTypeVO();
        sourceTypeVO.setCriticidad("uwu");
        sourceTypeVO.setSourceType("CIRBE");
        sourceTypeList.add(sourceTypeVO);
        personVO.setSourceTypeList(sourceTypeList);
        personList.add(personVO);
        consultPersonResponse.setPersons(personList);

        List<PersoPropuestaEntity> listaTitulares = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaTitulares = new PersoPropuestaEntity();
        persoPropuestaTitulares.setFormint("uwu");
        PersoPropuestaEntityPK idT = new PersoPropuestaEntityPK();
        idT.setCenterId("0282");
        idT.setCompanyId("0049");
        idT.setIntervType("uwu");
        idT.setOrdintc(123);
        idT.setPersonCode(new BigDecimal("200"));
        idT.setPersonType("J");
        idT.setProposalNumber(new BigDecimal("1234"));
        idT.setProposalYear("2019");
        persoPropuestaTitulares.setId(idT);
        persoPropuestaTitulares.setImporAct(new BigDecimal("1234"));
        persoPropuestaTitulares.setIndProju("uwu");
        persoPropuestaTitulares.setIndrai("uwu");
        persoPropuestaTitulares.setModifierUser("uwu");
        persoPropuestaTitulares.setModifyDate(LocalDate.now());
        persoPropuestaTitulares.setPorParti(new BigDecimal("1234"));
        persoPropuestaTitulares.setRegMatri("uwu");
        listaTitulares.add(persoPropuestaTitulares);

        List<PersoPropuestaEntity> listaAvalistas = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaAvalistas = new PersoPropuestaEntity();
        PersoPropuestaEntityPK idA = new PersoPropuestaEntityPK();
        idA.setCenterId("0282");
        idA.setCompanyId("0049");
        idA.setIntervType("uwu");
        idA.setOrdintc(123);
        idA.setPersonCode(new BigDecimal("200"));
        idA.setPersonType("J");
        idA.setProposalNumber(new BigDecimal("1234"));
        idA.setProposalYear("2019");
        persoPropuestaAvalistas.setId(idA);
        listaAvalistas.add(persoPropuestaAvalistas);

        List<ProposalPersonRequests> peticionesExistentes = new ArrayList<>();
        Map<String, String> bodyParamMap = new HashMap<String, String>();
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        doReturn(consultPersonResponse).when(restConsumerCirbeService).consultPerson(bodyParamMap);

        doReturn(listaTitulares).when(persoPropRepository).getListaTitulares(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(listaAvalistas).when(persoPropRepository).getListaAvalistas(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(peticionesExistentes).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsByRequestIdentifier(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class), any(String.class), any(Integer.class), any(String.class));

        PetitionsTreatmentProcessResponse result = cirbeService.callTreatmentProcess(proposalRequest);
        assertNotNull(result);
    }

    @Test
    public void callTreatmentProcessTestOKA() throws Exception {

        ProposalRequestsSencolMotorDTO proposalRequest = new ProposalRequestsSencolMotorDTO();
        proposalRequest.setCenter("0282");
        proposalRequest.setCompany("0049");
        proposalRequest.setModificationUser("uwu");
        proposalRequest.setProposalNumber(1234);
        proposalRequest.setYear(2019);

        ConsultPersonProcessResponseVO consultPersonResponse = new ConsultPersonProcessResponseVO();
        List<PersonVO> personList = new ArrayList<>();
        PersonVO personVO = new PersonVO();
        personVO.setIntervencion("A11");
        List<SourceTypeVO> sourceTypeList = new ArrayList<>();
        SourceTypeVO sourceTypeVO = new SourceTypeVO();
        sourceTypeVO.setCriticidad("uwu");
        sourceTypeVO.setSourceType("CIRBE");
        sourceTypeList.add(sourceTypeVO);
        personVO.setSourceTypeList(sourceTypeList);
        personList.add(personVO);
        consultPersonResponse.setPersons(personList);

        List<PersoPropuestaEntity> listaTitulares = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaTitulares = new PersoPropuestaEntity();
        persoPropuestaTitulares.setFormint("uwu");
        PersoPropuestaEntityPK idT = new PersoPropuestaEntityPK();
        idT.setCenterId("0282");
        idT.setCompanyId("0049");
        idT.setIntervType("uwu");
        idT.setOrdintc(123);
        idT.setPersonCode(new BigDecimal("200"));
        idT.setPersonType("J");
        idT.setProposalNumber(new BigDecimal("1234"));
        idT.setProposalYear("2019");
        persoPropuestaTitulares.setId(idT);
        persoPropuestaTitulares.setImporAct(new BigDecimal("1234"));
        persoPropuestaTitulares.setIndProju("uwu");
        persoPropuestaTitulares.setIndrai("uwu");
        persoPropuestaTitulares.setModifierUser("uwu");
        persoPropuestaTitulares.setModifyDate(LocalDate.now());
        persoPropuestaTitulares.setPorParti(new BigDecimal("1234"));
        persoPropuestaTitulares.setRegMatri("uwu");
        listaTitulares.add(persoPropuestaTitulares);

        List<PersoPropuestaEntity> listaAvalistas = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaAvalistas = new PersoPropuestaEntity();
        PersoPropuestaEntityPK idA = new PersoPropuestaEntityPK();
        idA.setCenterId("0282");
        idA.setCompanyId("0049");
        idA.setIntervType("uwu");
        idA.setOrdintc(123);
        idA.setPersonCode(new BigDecimal("200"));
        idA.setPersonType("J");
        idA.setProposalNumber(new BigDecimal("1234"));
        idA.setProposalYear("2019");
        persoPropuestaAvalistas.setId(idA);
        listaAvalistas.add(persoPropuestaAvalistas);

        List<ProposalPersonRequests> peticionesExistentes = new ArrayList<>();

        List<PersonRequests> personRequestList = new ArrayList<>();
        PersonRequests personRequest = new PersonRequests();
        personRequest.setPetitionsNumber(1);
        personRequestList.add(personRequest);

        ReflectionTestUtils.setField(cirbeService, "sourceType", "uwu");

        Map<String, String> bodyParamMap = new HashMap<String, String>();
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        doReturn(consultPersonResponse).when(restConsumerCirbeService).consultPerson(bodyParamMap);

        doReturn(listaTitulares).when(persoPropRepository).getListaTitulares(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(listaAvalistas).when(persoPropRepository).getListaAvalistas(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(peticionesExistentes).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsByRequestIdentifier(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class), any(String.class), any(Integer.class), any(String.class));

        doReturn(personRequestList).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        PetitionsTreatmentProcessResponse result = cirbeService.callTreatmentProcess(proposalRequest);
        assertNotNull(result);

    }

    @SuppressWarnings("deprecation")
    @Test
    public void callTreatmentProcessTestOK_AsyncNOK() throws Exception {

        ProposalRequestsSencolMotorDTO proposalRequest = new ProposalRequestsSencolMotorDTO();
        proposalRequest.setCenter("0282");
        proposalRequest.setCompany("0049");
        proposalRequest.setModificationUser("uwu");
        proposalRequest.setProposalNumber(1234);
        proposalRequest.setYear(2019);

        ConsultPersonProcessResponseVO consultPersonResponse = new ConsultPersonProcessResponseVO();
        List<PersonVO> personList = new ArrayList<>();
        PersonVO personVO = new PersonVO();
        personVO.setIntervencion("A11");
        List<SourceTypeVO> sourceTypeList = new ArrayList<>();
        SourceTypeVO sourceTypeVO = new SourceTypeVO();
        sourceTypeVO.setCriticidad("uwu");
        sourceTypeVO.setSourceType("CIRBE");
        sourceTypeList.add(sourceTypeVO);
        personVO.setSourceTypeList(sourceTypeList);
        personList.add(personVO);
        consultPersonResponse.setPersons(personList);

        List<PersoPropuestaEntity> listaTitulares = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaTitulares = new PersoPropuestaEntity();
        persoPropuestaTitulares.setFormint("uwu");
        PersoPropuestaEntityPK idT = new PersoPropuestaEntityPK();
        idT.setCenterId("0282");
        idT.setCompanyId("0049");
        idT.setIntervType("uwu");
        idT.setOrdintc(123);
        idT.setPersonCode(new BigDecimal("200"));
        idT.setPersonType("J");
        idT.setProposalNumber(new BigDecimal("1234"));
        idT.setProposalYear("2019");
        persoPropuestaTitulares.setId(idT);
        persoPropuestaTitulares.setImporAct(new BigDecimal("1234"));
        persoPropuestaTitulares.setIndProju("uwu");
        persoPropuestaTitulares.setIndrai("uwu");
        persoPropuestaTitulares.setModifierUser("uwu");
        persoPropuestaTitulares.setModifyDate(LocalDate.now());
        persoPropuestaTitulares.setPorParti(new BigDecimal("1234"));
        persoPropuestaTitulares.setRegMatri("uwu");
        listaTitulares.add(persoPropuestaTitulares);

        List<PersoPropuestaEntity> listaAvalistas = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaAvalistas = new PersoPropuestaEntity();
        PersoPropuestaEntityPK idA = new PersoPropuestaEntityPK();
        idA.setCenterId("0282");
        idA.setCompanyId("0049");
        idA.setIntervType("uwu");
        idA.setOrdintc(123);
        idA.setPersonCode(new BigDecimal("200"));
        idA.setPersonType("J");
        idA.setProposalNumber(new BigDecimal("1234"));
        idA.setProposalYear("2019");
        persoPropuestaAvalistas.setId(idA);
        listaAvalistas.add(persoPropuestaAvalistas);

        List<ProposalPersonRequests> peticionesExistentes = new ArrayList<>();

        List<PersonRequests> personRequestList = new ArrayList<>();
        PersonRequests personRequest = new PersonRequests();
        personRequest.setPetitionsNumber(1);
        personRequestList.add(personRequest);

        ReflectionTestUtils.setField(cirbeService, "sourceType", "uwu");
        Map<String, String> bodyParamMap = new HashMap<String, String>();
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        doReturn(consultPersonResponse).when(restConsumerCirbeService)
                .consultPerson(Matchers.<Map<String, String>> any());

        doReturn(listaTitulares).when(persoPropRepository).getListaTitulares(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(listaAvalistas).when(persoPropRepository).getListaAvalistas(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(peticionesExistentes).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsByRequestIdentifier(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class), any(String.class), any(Integer.class), any(String.class));

        doReturn(personRequestList).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        doThrow(new EmptyStackException()).when(cirbeAsyncHelper).callSasna(any(String.class), any(String.class),
                any(BigDecimal.class), any(String.class));

        PetitionsTreatmentProcessResponse result = cirbeService.callTreatmentProcess(proposalRequest);
        assertNotNull(result);

    }

    @Test
    public void callTreatmentProcessTestNOK() throws Exception {

        ProposalRequestsSencolMotorDTO proposalRequest = new ProposalRequestsSencolMotorDTO();
        proposalRequest.setCenter("0282");
        proposalRequest.setCompany("0049");
        proposalRequest.setModificationUser("uwu");
        proposalRequest.setProposalNumber(1234);
        proposalRequest.setYear(2019);

        ConsultPersonProcessResponseVO consultPersonResponse = new ConsultPersonProcessResponseVO();
        List<PersonVO> personList = new ArrayList<>();
        PersonVO personVO = new PersonVO();
        personVO.setIntervencion("A11");
        List<SourceTypeVO> sourceTypeList = new ArrayList<>();
        SourceTypeVO sourceTypeVO = new SourceTypeVO();
        sourceTypeVO.setCriticidad("uwu");
        sourceTypeVO.setSourceType("CIRBE");
        sourceTypeList.add(sourceTypeVO);
        personVO.setSourceTypeList(sourceTypeList);
        personList.add(personVO);
        consultPersonResponse.setPersons(personList);

        List<PersoPropuestaEntity> listaTitulares = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaTitulares = new PersoPropuestaEntity();
        persoPropuestaTitulares.setFormint("uwu");
        PersoPropuestaEntityPK idT = new PersoPropuestaEntityPK();
        idT.setCenterId("0282");
        idT.setCompanyId("0049");
        idT.setIntervType("uwu");
        idT.setOrdintc(123);
        idT.setPersonCode(new BigDecimal("200"));
        idT.setPersonType("J");
        idT.setProposalNumber(new BigDecimal("1234"));
        idT.setProposalYear("2019");
        persoPropuestaTitulares.setId(idT);
        persoPropuestaTitulares.setImporAct(new BigDecimal("1234"));
        persoPropuestaTitulares.setIndProju("uwu");
        persoPropuestaTitulares.setIndrai("uwu");
        persoPropuestaTitulares.setModifierUser("uwu");
        persoPropuestaTitulares.setModifyDate(LocalDate.now());
        persoPropuestaTitulares.setPorParti(new BigDecimal("1234"));
        persoPropuestaTitulares.setRegMatri("uwu");
        listaTitulares.add(persoPropuestaTitulares);

        List<PersoPropuestaEntity> listaAvalistas = new ArrayList<>();
        PersoPropuestaEntity persoPropuestaAvalistas = new PersoPropuestaEntity();
        PersoPropuestaEntityPK idA = new PersoPropuestaEntityPK();
        idA.setCenterId("0282");
        idA.setCompanyId("0049");
        idA.setIntervType("uwu");
        idA.setOrdintc(123);
        idA.setPersonCode(new BigDecimal("200"));
        idA.setPersonType("J");
        idA.setProposalNumber(new BigDecimal("1234"));
        idA.setProposalYear("2019");
        persoPropuestaAvalistas.setId(idA);
        listaAvalistas.add(persoPropuestaAvalistas);

        List<ProposalPersonRequests> peticionesExistentes = new ArrayList<>();

        List<PersonRequests> personRequestList = new ArrayList<>();
        PersonRequests personRequest = new PersonRequests();
        personRequest.setPetitionsNumber(1);
        personRequestList.add(personRequest);

        ReflectionTestUtils.setField(cirbeService, "sourceType", "uwu");
        Map<String, String> bodyParamMap = new HashMap<String, String>();
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        doReturn(consultPersonResponse).when(restConsumerCirbeService).consultPerson(bodyParamMap);

        doReturn(listaTitulares).when(persoPropRepository).getListaTitulares(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(listaAvalistas).when(persoPropRepository).getListaAvalistas(any(String.class),
                any(String.class), any(String.class), any(BigDecimal.class));

        doReturn(peticionesExistentes).when(proposalPersonRequestsRepository)
                .findProposalPersonRequestsByRequestIdentifier(any(String.class), any(String.class), any(Integer.class),
                        any(Integer.class), any(String.class), any(Integer.class), any(String.class));

        doReturn(personRequestList).when(personRequestsRepository).findPersonRequestByIdentifier(any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        doThrow(new EmptyStackException()).when(proposalPersonRequestsRepository)
                .save(any(ProposalPersonRequests.class));

        PetitionsTreatmentProcessResponse result = cirbeService.callTreatmentProcess(proposalRequest);
        assertNotNull(result);

    }

}
