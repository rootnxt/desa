package com.santander.darwin.invoice.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * BasicAspect
 * 
 * @author igndom
 *
 */
@Aspect
@Component
public class BasicAspect extends AbstractBaseAop {

	@Pointcut("execution(public * com.santander.darwin.invoice.web..*Controller+.*(..))")
	protected void logController() {
		// Do nothing
	}

	@Pointcut("execution(public * com.santander.darwin.invoice.service..*Service+.*(..))")
	protected void logService() {
		// Do nothing
	}

	@Pointcut("execution(private * com.santander.darwin.invoice.service..*Service+.*(..))")
	protected void logServicePrivate() {
		// Do nothing
	}

	@Pointcut("execution(public * com.santander.darwin.invoice.repository..*Repository+.*(..))")
	protected void logRepository() {
		// Do nothing
	}

	/**
	 * logMethod
	 * 
	 * @param pjp ProceedingJoinPoint
	 * @return Object
	 * @throws Throwable excepcion
	 */
	@Around("logController() || logService() || logRepository()")
	public Object logMethod(ProceedingJoinPoint pjp) throws Throwable {
		return logging(pjp);
	}

	/**
	 * logMethodPrivate
	 * 
	 * @param pjp ProceedingJoinPoint
	 * @return Object
	 * @throws Throwable excepcion
	 */
	@Around("logServicePrivate()")
	public Object logMethodPrivate(ProceedingJoinPoint pjp) throws Throwable {
		return loggingPrivate(pjp);
	}

}
