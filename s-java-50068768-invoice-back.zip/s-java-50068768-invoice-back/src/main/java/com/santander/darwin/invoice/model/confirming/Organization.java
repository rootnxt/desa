package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Organization.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Organization {
	// Datos de Organization
	private List<Document> documents;
	private OrganizationName organizationName;
}