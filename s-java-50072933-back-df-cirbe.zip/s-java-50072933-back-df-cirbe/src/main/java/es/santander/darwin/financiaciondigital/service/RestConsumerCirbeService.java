package es.santander.darwin.financiaciondigital.service;

import java.util.Map;

import es.santander.darwin.financiaciondigital.domain.ConsultPersonProcessResponseVO;
import es.santander.darwin.financiaciondigital.domain.OrchestratorMotorResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalDto;
import es.santander.darwin.financiaciondigital.domain.RecoveryEndpointRequest;
import es.santander.darwin.financiaciondigital.domain.RecoveryPhoneAndMailResponse;
import es.santander.darwin.financiaciondigital.domain.SendNotifDto;
import es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest;

/**
 * The Interface RestConsumerService.
 */
public interface RestConsumerCirbeService {

    /**
     * Sen noti sms and email.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param sendNotifDto the send notif dto
     * @return the send notif dto
     */
    SendNotifDto senNotiSmsOrEmail(String personType, Integer personCode, SendNotifDto sendNotifDto);

    /**
     * Gets the phone email.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param proposalRequest the proposal request
     * @return the phone email
     */
    RecoveryPhoneAndMailResponse recoveryPhoneMail(String personType, Integer personCode,
            ProposalRequest proposalRequest);

    /**
     * Orchestrator motor.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param callType the call type
     * @param body the body
     * @return the response entity
     */
    OrchestratorMotorResponse orchestratorMotor(String personType, Integer personCode,
            String callType, ProposalDto body);

    /**
     * Consult person.
     *
     * @param bodyParamMap the body param map
     * @return the consult person process response VO
     */
    ConsultPersonProcessResponseVO consultPerson(Map<String, String> bodyParamMap);

    /**
     * Recovery endpoint.
     *
     * @param url the url
     * @param request the request
     */
    void recoveryEndpoint(String url, RecoveryEndpointRequest request);

}
