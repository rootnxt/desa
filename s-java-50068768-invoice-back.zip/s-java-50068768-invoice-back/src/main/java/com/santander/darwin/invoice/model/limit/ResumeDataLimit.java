package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the amount 1.
 *
 * @return the amount 1
 */
@Getter

/**
 * Sets the amount 1.
 *
 * @param amount1 the new amount 1
 */
@Setter

/**
 * Instantiates a new resume data limit.
 */
@NoArgsConstructor
public class ResumeDataLimit {

    /** The amount 1. */
    private Integer amount1;

}
