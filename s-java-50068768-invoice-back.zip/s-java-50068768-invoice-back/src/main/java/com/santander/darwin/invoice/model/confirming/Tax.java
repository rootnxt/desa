package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Tax.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Tax {
	// Datos de Tax
	private String typeCode;
	private String rate;
}