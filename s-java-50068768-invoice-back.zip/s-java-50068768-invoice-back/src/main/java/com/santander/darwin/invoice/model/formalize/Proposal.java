package com.santander.darwin.invoice.model.formalize;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Proposal class
 *
 */
@Getter
@Setter
@Builder
public class Proposal implements Serializable {

	/** serial version uid */
    private static final long serialVersionUID = 1L;

    /** The cempresa */
    private BigDecimal cempresa;

    /** The ccentro */
    private BigDecimal ccentro;

    /** The aaa */
    private BigDecimal aaa;

    /** The cnumeric */
    private BigDecimal cnumeric;

}
