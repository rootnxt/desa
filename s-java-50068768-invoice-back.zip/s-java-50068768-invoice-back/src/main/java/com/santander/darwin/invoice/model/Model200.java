package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.model200.EconomicData;
import com.santander.darwin.invoice.model.model200.PersonalData;
import com.santander.darwin.invoice.model.model200.TaxSummary;
import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * Model200
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Model200 {

	// Datos personales
	@NotNull(message = "PERSONALDATANULL")
	private PersonalData personalData;
	// Datos economicos
	@NotNull(message = "ECONOMICDATANULL")
	private EconomicData economicData;
	// Tasas
	private TaxSummary taxSummary;
	// Notificaciones
	private boolean notifyCirbe;
	private boolean notifyAeat200;
	// Fechas
	private MongoLocalDateTime dateSend;
	private MongoLocalDateTime dateNotifyCirbe;
	private MongoLocalDateTime dateNotifyAeat200;
	// Modal AEAT
	private Modal modalAeat200;

}
