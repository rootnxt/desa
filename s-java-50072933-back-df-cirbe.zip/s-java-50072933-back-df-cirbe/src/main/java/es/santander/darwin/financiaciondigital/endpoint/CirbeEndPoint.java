package es.santander.darwin.financiaciondigital.endpoint;

import javax.xml.datatype.DatatypeConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.constant.ErrorConstants;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.service.CirbeService;
import es.santander.darwin.financiaciondigital.soap.GetPersonRequest;
import es.santander.darwin.financiaciondigital.soap.GetPersonResponse;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalResponse;
import es.santander.darwin.financiaciondigital.soap.ServiceFault;
import es.santander.darwin.financiaciondigital.soap.exceptions.ServiceFaultException;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class CirbeEndPoint.
 */
@Slf4j
@Endpoint
public class CirbeEndPoint {

    /** The cirbe service. */
    @Autowired
    private CirbeService cirbeService;

    /**
     * Gets the person request.
     *
     * @param request the request
     * @return the person request
     * @throws ServiceFaultException
     * @throws DigitalConsumptionServiceException
     */
    @PayloadRoot(namespace = Constants.NAME_SPACE, localPart = Constants.LOCAL_PART)
    @ResponsePayload
    public GetPersonResponse getPersonRequest(@RequestPayload GetPersonRequest request)
            throws ServiceFaultException, DigitalConsumptionServiceException {
        GetPersonResponse response = null;
        try {
            response = cirbeService.getPersonRequest(request);
        } catch (DigitalConsumptionServiceException e) {
            if (e.getDetailArgs()[0].toString().equals(ErrorConstants.ERROR_CODE_NULL_REQUEST)) {
                throw new ServiceFaultException(ErrorConstants.MESSAGE_ERROR, new ServiceFault(
                        ErrorConstants.ERROR_CODE_NULL_REQUEST, ErrorConstants.ERROR_NULL_REQUEST));
            } else {
                throw new ServiceFaultException(ErrorConstants.MESSAGE_ERROR, new ServiceFault(
                        e.getDetailArgs()[0].toString(), ErrorConstants.ERROR_DETAILS_PERSON_REQUESTS));
            }
        }
        return response;
    }

    /**
     * Gets the petitions of person and proposals.
     *
     * @param request the request
     * @return the petitions of person and proposals
     * @throws DatatypeConfigurationException the datatype configuration exception
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @PayloadRoot(namespace = Constants.NAME_SPACE, localPart = Constants.LOCAL_PART_PETITIONS)
    @ResponsePayload
    public PetitionsOfPersonAndProposalResponse getPetitionsOfPersonAndProposals(
            @RequestPayload PetitionsOfPersonAndProposalRequest request)
            throws DatatypeConfigurationException, DigitalConsumptionServiceException, ServiceFaultException {
        PetitionsOfPersonAndProposalResponse response = null;
        try {
            response = cirbeService.getPetitionsOfPersonAndProposalsResponse(request);
        } catch (DigitalConsumptionServiceException exc) {
            log.error(exc.getMessage());
            throw new ServiceFaultException(ErrorConstants.MESSAGE_ERROR, new ServiceFault(
                    exc.getDetailArgs()[0].toString(), ErrorConstants.ERROR_DETAILS_PERSON_REQUESTS));
        }
        return response;
    }
}
