package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BasicPersonDataResponseVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the basic person data response VO
 */
@Builder

/**
 * Instantiates a new basic person data response VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new basic person data response VO.
 *
 * @param documentCod the document cod
 * @param documentType the document type
 * @param fullName the full name
 * @param codPaisR the cod pais R
 * @param codPaisN the cod pais N
 * @param dateNac the date nac
 * @param codPers the cod pers
 * @param tipoPers the tipo pers
 * @param idEmpr the id empr
 */
@AllArgsConstructor
public class BasicPersonDataResponseVO {

    /** The documentCod. */
    private String documentCod;

    /** The documentType. */
    private String documentType;

    /** The fullName. */
    private String fullName;

    /** The codPaisR. */
    private String codPaisR;

    /** The codPaisN. */
    private String codPaisN;

    /** The dateNac. */
    private Date dateNac;

    /** The codpers. */
    private BigDecimal codPers;

    /** The tipopers. */
    private String tipoPers;

    /** The idempr. */
    private String idEmpr;

}