package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Product.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class RefinancingProduct {

	//Atributos bloque 1
	private String indInmpag;
	private String agroup;
	private String type;
	//Atributos bloque 2
	private String typeByDoc;
	private String name;
	private String ccc;
	private String contractId;
	//Atributos bloque 3
	private String iban;
	private String pan;
	private BigDecimal amount;
	//Atributos bloque 4
	private BigDecimal impactto;
	private BigDecimal impaptu2;
	private boolean noShowContract;
	//Atributos bloque 5
	private List<RefinancingProductDetail> details;
	private List<RefinancingProductDetail> moreDetails;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result + ((ccc == null) ? 0 : ccc.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		RefinancingProduct other = (RefinancingProduct) obj;
		return ccc != null && other.ccc != null && ccc.equals(other.ccc);
	}

}
