package com.santander.darwin.invoice.model.financiacion_digital;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * DetailFFNNGuarantor.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class DetailFFNNGuarantor{
	 // Texto
	 private String text;
	 // Datos
	 private List<DetailFFNN> negativeFiles;
}