package com.santander.darwin.invoice.model.orientados;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * OrientadoOutput.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class OrientadoOutput {

	// codigo
	private String codigo;
	
	// lista
	private List<Lista> lista;
}
