package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * CommonLangDesc model class.
 * 
 * @author luis.lopez
 *
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
public class CommonLangDesc extends CommonLang {

	/** The desc. */
	private String desc;

	/**
	 * Constructor
	 */
	public CommonLangDesc() {
		super();
	}

	/**
	 * Constructor
	 *
	 * @param lang String
	 * @param name String
	 */
	public CommonLangDesc(String lang, String name) {
		super(lang, name);
	}

	/**
	 * Constructor
	 *
	 * @param lang String
	 * @param name String
	 * @param desc String
	 */
	public CommonLangDesc(String lang, String name, String desc) {
		super(lang, name);
		this.desc = desc;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the infoText to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	

}
