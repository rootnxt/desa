package com.santander.darwin.invoice.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * InputDisplayPdfMailbox.java
 *
 * @author igndom
 *
 */
public class InputDisplayPdfMailbox {

	@NotNull
	@NotEmpty
	private String signId;
	@NotNull
	@NotEmpty
	private String gnId;
	@NotNull
	@NotEmpty
	private String gnTipoDoc;

	/**
	 * @return the signId
	 */
	public String getSignId() {
		return signId;
	}

	/**
	 * @param signId the signId to set
	 */
	public void setSignId(String signId) {
		this.signId = signId;
	}

	/**
	 * @return the gnId
	 */
	public String getGnId() {
		return gnId;
	}

	/**
	 * @param gnId the gnId to set
	 */
	public void setGnId(String gnId) {
		this.gnId = gnId;
	}

	/**
	 * @return the gnTipoDoc
	 */
	public String getGnTipoDoc() {
		return gnTipoDoc;
	}

	/**
	 * @param gnTipoDoc the gnTipoDoc to set
	 */
	public void setGnTipoDoc(String gnTipoDoc) {
		this.gnTipoDoc = gnTipoDoc;
	}

}
