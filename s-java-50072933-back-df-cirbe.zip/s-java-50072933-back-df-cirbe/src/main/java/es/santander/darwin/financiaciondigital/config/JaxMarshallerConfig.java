package es.santander.darwin.financiaciondigital.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLA;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLAResponse;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;

/**
 * The Class JaxMarshallerConfig.
 */
@Configuration
public class JaxMarshallerConfig {

    /** The marshaller. */
    @Autowired(required = false)
    @Qualifier("marshaller")
    private Jaxb2Marshaller marshaller;
    
    /**
     * Custom marshaller.
     *
     * @return the jaxb 2 marshaller
     */
    @Bean
    public Jaxb2Marshaller customMarshaller() {
        if (marshaller == null) {
            marshaller = new Jaxb2Marshaller();
            marshaller.setClassesToBeBound(getClassesToBeBound());
        }
        return marshaller;
    }

    /**
     * Gets the classes to be bound.
     *
     * @return the classes to be bound
     */
    private Class<?>[] getClassesToBeBound() {
        List<Class<?>> classes = new ArrayList<>();
        
        classes.add(AltModifCiriteRequest.class);
        classes.add(AltModifCiriteRequestResponse.class);
        classes.add(DatosUsuarioLA.class);
        classes.add(DatosUsuarioLAResponse.class);
       
        Class<?>[] classesArray = new Class<?>[classes.size()];
        return classes.toArray(classesArray);
    }
    

}
