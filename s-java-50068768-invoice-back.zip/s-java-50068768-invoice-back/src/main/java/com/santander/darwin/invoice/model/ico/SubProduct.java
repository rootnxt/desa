package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SubProduct.
 */

/**
 * Sets the name.
 *
 * @param name the new name
 */
@Setter

/**
 * Gets the name.
 *
 * @return the name
 */
@Getter

/**
 * Instantiates a new sub product.
 */

/**
 * Instantiates a new sub product.
 */
@NoArgsConstructor
public class SubProduct {
    
    /** The subproduct id. */
    private String subproductId;
    
    /** The name. */
    private String name;
}
