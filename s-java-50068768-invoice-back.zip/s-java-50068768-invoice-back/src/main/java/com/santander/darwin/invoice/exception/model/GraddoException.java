package com.santander.darwin.invoice.exception.model;

import com.santander.darwin.invoice.exception.GlobalException;

/**
 * AeatException.java
 *
 * @author luis.lopez
 *
 */
public class GraddoException extends GlobalException {

	/** The Serial Version */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 *
	 * @param lang  String

	 */
	public GraddoException(String lang) {
		super(lang);
	}

}
