/**
 * 
 */
package com.santander.darwin.invoice.model.document;

/**
 * SaveDocumentInput
 * 
 * @author josdon
 *
 */
public class SaveDocumentInput {

	private Proposal proposal;
	private String url;

	/**
	 * @return the proposal
	 */
	public Proposal getProposal() {
		return proposal;
	}

	/**
	 * @param proposal the proposal to set
	 */
	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

}
