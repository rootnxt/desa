/**
 * 
 */
package com.santander.darwin.invoice.model.limit;

import com.santander.darwin.invoice.model.UrlResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * DataLimitsUrlResponse 
 * @author josdon
 *
 */
@Getter
@Setter
public class DataLimitsUrlResponse {

	// Atributos de la clase
	private boolean onlyOriented;
	private boolean allowP2;
	private boolean p2;
	private UrlResponse urlResponse;
}
