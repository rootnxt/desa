package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the consolidado response
 */
@Builder

/**
 * Instantiates a new consolidado response.
 */
@NoArgsConstructor

/**
 * Instantiates a new consolidado response.
 *
 * @param methodResult the method result
 */
@AllArgsConstructor
public class ConsolidadoResponse {
    
    /** The method result. */
    private List<ConsolidadoDto> methodResult;
    
}
