package es.santander.darwin.financiaciondigital.soap;

// TODO: Auto-generated Javadoc
/**
 * The Class ServiceFault.
 */
public class ServiceFault {

    /** The error. */
    private String error;

    /** The description. */
    private String description;

    /**
     * Instantiates a new service fault.
     */
    public ServiceFault() {
    }

    /**
     * Instantiates a new service fault.
     *
     * @param error the error
     * @param description the description
     */
    public ServiceFault(String error, String description) {
        this.error = error;
        this.description = description;
    }

    /**
     * Gets the error.
     *
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * Sets the details.
     *
     * @param error the new details
     */
    public void setDetails(String error) {
        this.error = error;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
