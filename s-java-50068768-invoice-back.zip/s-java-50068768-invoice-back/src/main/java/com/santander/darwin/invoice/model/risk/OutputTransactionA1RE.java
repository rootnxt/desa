package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * OutputTransactionA1RE.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class OutputTransactionA1RE {

	private List<String> asocia;
	private String a1asoc;
	private List<String> cdindsn;
	private List<String> codmonct;
	private List<String> codsitdu;
	private List<String> contrnue;
	private List<String> idcentc;
	private List<String> idcentc1;
	private String idcent4;
	private List<String> idcontr;
	private List<String> idcontr1;
	private String idcontr4;
	private String idcontvi;
	private List<String> idemprc;
	private List<String> idemprc1;
	private String idempr4;
	private List<String> idprodc;
	private List<String> idprodc1;
	private String idprodvi;
	private String idprod4;
	private List<BigDecimal> impactto;
	private List<BigDecimal> impaptu2;
	private BigDecimal impbctr;
	private BigDecimal impmaxcn;
	private List<BigDecimal> imsalcto;
	private String indaviso;
	private String indicada;
	private String indicadb;
	private String indicadc;
	private String indicadd;
	private String indicade;
	private String indicadf;
	private String indicadg;
	private String indicadh;
	private String indreest;
	private String monimpo;
	private List<String> prodcon;
	private List<String> tipcont;
	private BigDecimal zcodpers;
	private String zcodprod;
	private String zidcentc;
	private String zidcontr;
	private String zidemprc;
	private BigDecimal zordintc;
	private String ztipinte;
	private String ztipoper;

}
