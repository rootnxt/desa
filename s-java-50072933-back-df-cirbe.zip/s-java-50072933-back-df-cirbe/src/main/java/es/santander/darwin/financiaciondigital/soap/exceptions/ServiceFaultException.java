package es.santander.darwin.financiaciondigital.soap.exceptions;

import es.santander.darwin.financiaciondigital.soap.ServiceFault;


/**
 * The Class ServiceFaultException.
 */
public class ServiceFaultException extends RuntimeException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8208728090050594122L;
    
    /** The service fault. */
    private ServiceFault serviceFault;

    /**
     * Instantiates a new service fault exception.
     *
     * @param message the message
     * @param serviceFault the service fault
     */
    public ServiceFaultException(String message, ServiceFault serviceFault) {
        super(message);
        this.serviceFault = serviceFault;
    }

    /**
     * Instantiates a new service fault exception.
     *
     * @param message the message
     * @param e the e
     * @param serviceFault the service fault
     */
    public ServiceFaultException(String message, Throwable e, ServiceFault serviceFault) {
        super(message, e);
        this.serviceFault = serviceFault;
    }

    /**
     * Gets the service fault.
     *
     * @return the service fault
     */
    public ServiceFault getServiceFault() {
        return serviceFault;
    }

    /**
     * Sets the service fault.
     *
     * @param serviceFault the new service fault
     */
    public void setServiceFault(ServiceFault serviceFault) {
        this.serviceFault = serviceFault;
    }
}
