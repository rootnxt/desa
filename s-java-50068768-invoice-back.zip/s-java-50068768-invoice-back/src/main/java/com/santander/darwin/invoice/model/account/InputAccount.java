package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * The InputFindAccount model class.
 *
 * @Autor luis.lopez
 */
@Setter
@Getter
public class InputAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The customer. */
	private Customer customer;

    /** The subproduct. */
    private SubproductClass subproduct;

    /** The currency. */
    private String currency;

    /** The relationType. */
    private String relationType;

    /** The interventionType. */
    private String interventionType;

    /** The operation. */
    private String operation;

    /** The repDetails. */
    private RepDetails repDetails;

    /**
     * getCustomer.
     *
     * @return the Customer.
     */
    public Customer getCustomer() {
        return new Customer(customer);
    }

    /**
     * getSubproduct.
     *
     * @return the Subproduct.
     */
    public SubproductClass getSubproduct() {
        return new SubproductClass(subproduct);
    }

    /**
     * getRepDetails.
     *
     * @return the RepDetails.
     */
    public RepDetails getRepDetails() {
        return new RepDetails(repDetails);
    }

    public void setCustomer(Customer customer) {
        this.customer = new Customer(customer);
    }

    public void setSubproduct(SubproductClass subproduct) {
        this.subproduct = new SubproductClass(subproduct);
    }

    public void setRepDetails(RepDetails repDetails) {
        this.repDetails = new RepDetails(repDetails);
    }

}
