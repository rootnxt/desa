package com.santander.darwin.invoice.model.customers;

public class CustomersData {
}
