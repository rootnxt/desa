package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * The Family Class.
 */
@Getter
@Setter
public class FamilyClass implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The family. */
    private String family;

    /** The familyId. */
    private String familyId;

    /** The balances. */
    private BalancesAdn balances;

    /** The groups. */
    private List<GroupClass> groups;

}
