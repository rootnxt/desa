//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.24 a las 09:57:53 PM EDT 
//


package es.santander.darwin.financiaciondigital.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para personAndProposalVO complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="personAndProposalVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="personType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="personCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="interventionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="srcList" type="{http://financiaciondigital.darwin.santander.es/soap}sourcesListVO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "personAndProposalVO", propOrder = {
    "personType",
    "personCode",
    "interventionType",
    "srcList"
})
public class PersonAndProposalVO {

    @XmlElement(required = true)
    protected String personType;
    protected int personCode;
    @XmlElement(required = true)
    protected String interventionType;
    @XmlElement(required = true)
    protected SourcesListVO srcList;

    /**
     * Obtiene el valor de la propiedad personType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersonType() {
        return personType;
    }

    /**
     * Define el valor de la propiedad personType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersonType(String value) {
        this.personType = value;
    }

    /**
     * Obtiene el valor de la propiedad personCode.
     * 
     */
    public int getPersonCode() {
        return personCode;
    }

    /**
     * Define el valor de la propiedad personCode.
     * 
     */
    public void setPersonCode(int value) {
        this.personCode = value;
    }

    /**
     * Obtiene el valor de la propiedad interventionType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterventionType() {
        return interventionType;
    }

    /**
     * Define el valor de la propiedad interventionType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterventionType(String value) {
        this.interventionType = value;
    }

    /**
     * Obtiene el valor de la propiedad srcList.
     * 
     * @return
     *     possible object is
     *     {@link SourcesListVO }
     *     
     */
    public SourcesListVO getSrcList() {
        return srcList;
    }

    /**
     * Define el valor de la propiedad srcList.
     * 
     * @param value
     *     allowed object is
     *     {@link SourcesListVO }
     *     
     */
    public void setSrcList(SourcesListVO value) {
        this.srcList = value;
    }

}
