/**
 * 
 */
package com.santander.darwin.invoice.constants;

/**
 * Security
 * 
 * @author ciber
 *
 */
public class Security {

	/**
	 * SECURITY_TYPE
	 *
	 * @return enum
	 */
	public enum SECURITY_TYPE {
		COOKIE, TOKEN, USER_PASS, NONE
	}
}
