package com.santander.darwin.invoice.model.limit;

import com.santander.darwin.invoice.model.simulation.Term;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the grouped products.
 *
 * @return the grouped products
 */
@Getter

/**
 * Sets the grouped products.
 *
 * @param groupedProducts
 *            the new grouped products
 */
@Setter

/**
 * Instantiates a new type finance products.
 */
@NoArgsConstructor
public class TypeFinanceProducts extends TypeFinance {

    /** The id. */
    private String id;

    /** The selected. */
    private boolean selected;
    
    /** The selected. */
    private String family;

    /** The grouped products. */
    private List<GroupedTypeFinanceProducts> groupedProducts;
    
    /** The financing. */
    private Financing financing;
    
    /** The months */
    private Term months;

}
