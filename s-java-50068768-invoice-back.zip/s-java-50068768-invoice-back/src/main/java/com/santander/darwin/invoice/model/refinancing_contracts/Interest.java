package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Interest.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Interest {
	
	//Datos del tin
	private BigDecimal tin;

}
