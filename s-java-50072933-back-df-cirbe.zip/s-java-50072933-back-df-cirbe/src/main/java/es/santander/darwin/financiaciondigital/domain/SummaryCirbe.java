package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the summary cirbe
 */
@Builder

/**
 * Instantiates a new summary cirbe.
 */
@NoArgsConstructor

/**
 * Instantiates a new summary cirbe.
 *
 * @param code the code
 * @param description the description
 */
@AllArgsConstructor
public class SummaryCirbe {
    
    /** The code. */
    private String code;
    
    /** The description. */
    private String description;

}
