package com.santander.darwin.invoice.model;

import java.util.Date;
import java.util.Optional;

/**
 * CommonDate
 * 
 * @author igndom
 *
 */
public class CommonDate {

	private String description;
	private Date value;

	/**
	 * Constructor
	 */
	public CommonDate() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param description String
	 * @param value       Date
	 */
	public CommonDate(String description, Date value) {
		super();
		this.description = description;
		this.value = (Date) value.clone();
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the value
	 */
	public Date getValue() {
		return Optional.ofNullable(value).map(Date::getTime).map(Date::new).orElse(null);
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(Date value) {
		this.value = Optional.ofNullable(value).map(Date::getTime).map(Date::new).orElse(null);
	}

}
