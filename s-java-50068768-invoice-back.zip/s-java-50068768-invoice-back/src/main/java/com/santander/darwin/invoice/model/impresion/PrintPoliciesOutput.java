package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

/**
 * The class PrintPoliciesOutput
 * 
 *
 */
@Getter
@Setter
public class PrintPoliciesOutput {
	/** The gnId. */
	private String gnId;
	
	/** The url. */
	private String url;
}
