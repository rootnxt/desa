/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InputTransactionA2TI 
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class InputTransactionA2TI {
	
	//INPUT DATA

	//Partenon alphanumeric (A) - Length (4)
	public String anoprop;

	//Partenon alphanumeric (A) - Length (4)
	public String anopropa;

	//Partenon alphanumeric (A) - Length (3)
	public String codmonsw;

	//Partenon alphanumeric (A) - Length (4)
	public String idcent;

	//Partenon alphanumeric (A) - Length (4)
	public String idcenta;

	//Partenon alphanumeric (A) - Length (4)
	public String idcentc;

	//Partenon alphanumeric (A) - Length (7)
	public String idcontrc;

	//Partenon alphanumeric (A) - Length (4)
	public String idempr;

	//Partenon alphanumeric (A) - Length (4)
	public String idempra;

	//Partenon alphanumeric (A) - Length (4)
	public String idemprc;

	//Partenon alphanumeric (A) - Length (3)
	public String idprodc;

	//Partenon unsigned numeric (N) - Length (15, 2)
	public BigDecimal impapro;

	//Partenon unsigned numeric (N) - Length (5, 0)
	public BigDecimal numprop;

	//Partenon unsigned numeric (N) - Length (5, 0)
	public BigDecimal numprop2;

	//Partenon alphanumeric (A) - Length (1)
	public String tipllama;

}
