package com.santander.darwin.invoice.config;

import com.santander.darwin.invoice.scheduled.CancelSolicitudesTask;
import com.santander.darwin.invoice.scheduled.DeleteSolicitudesTask;
import com.santander.darwin.invoice.scheduled.Notify24HoursWithoutActivityTask;
import com.santander.darwin.invoice.scheduled.ReportTask;
import com.santander.darwin.invoice.scheduled.TransferRecastTask;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;

/**
 * SchedulerConfig.java
 *
 * @author igndom
 *
 */
@Configuration
@EnableScheduling
@Slf4j
public class SchedulerConfig {

	@Value("${task.scheduler.deleteAllSolicitude:}")
	private String deleteAllSolicitude;

	@Value("${task.scheduler.cancelSolicitude:}")
	private String cancelSolicitude;

	@Value("${task.scheduler.transferRecast:}")
	private String transferRecast;

	@Value("${task.scheduler.notifyWithoutActivity:}")
	private String notifyWithoutActivity;

	@Value("${task.scheduler.csvDetailContracts:}")
	private String csvDetailContracts;

	@Value("${task.scheduler.report:}")
	private String report;

	private DeleteSolicitudesTask deleteSolicitudesTask;
	private CancelSolicitudesTask cancelSolicitudesTask;
	private TransferRecastTask transferRecastTask;
	private Notify24HoursWithoutActivityTask notify24HoursWithoutActivityTask;
	private ReportTask reportTask;

	/**
	 * Constructor Autowired
	 * 
	 * @param deleteSolicitudesTask            DeleteSolicitudesTask
	 * @param cancelSolicitudesTask            CancelSolicitudesTask
	 * @param transferRecastTask               TransferRecastTask
	 * @param notify24HoursWithoutActivityTask Notify24HoursWithoutActivityTask
	 * @param reportTask                       ReportTask
	 */
	@Autowired
	public SchedulerConfig(DeleteSolicitudesTask deleteSolicitudesTask, CancelSolicitudesTask cancelSolicitudesTask,
			TransferRecastTask transferRecastTask, Notify24HoursWithoutActivityTask notify24HoursWithoutActivityTask,
			ReportTask reportTask) {
		this.deleteSolicitudesTask = deleteSolicitudesTask;
		this.cancelSolicitudesTask = cancelSolicitudesTask;
		this.transferRecastTask = transferRecastTask;
		this.notify24HoursWithoutActivityTask = notify24HoursWithoutActivityTask;
		this.reportTask = reportTask;
	}

	/**
	 * schedulerBean
	 * 
	 * @return TaskScheduler
	 */
	@Bean
	public TaskScheduler schedulerBean() {
		log.info("Configurando tareas periodicas");
		TaskScheduler scheduler = null;
//        org.springframework.scheduling.support.CronSequenceGenerator
//        *segundo minuto hora mes año día_de_la_semana
//        Example patterns: 
//            •"0 0 * * * *" = the top of every hour of every day.
//            •"*/10 * * * * *" = every ten seconds.
//            •"0 0 8-10 * * *" = 8, 9 and 10 o'clock of every day.
//            •"0 0 6,19 * * *" = 6:00 AM and 7:00 PM every day.
//            •"0 0/30 8-10 * * *" = 8:00, 8:30, 9:00, 9:30, 10:00 and 10:30 every day.
//            •"0 0 9-17 * * MON-FRI" = on the hour nine-to-five weekdays
//            •"0 0 0 25 12 ?" = every Christmas Day at midnight
		scheduler = new ConcurrentTaskScheduler();
		if (deleteAllSolicitude != null && !deleteAllSolicitude.isEmpty()) {
			scheduler.schedule(deleteSolicitudesTask, new CronTrigger(deleteAllSolicitude));
		}

		if (cancelSolicitude != null && !cancelSolicitude.isEmpty()) {
			scheduler.schedule(cancelSolicitudesTask, new CronTrigger(cancelSolicitude));
		}

		if (transferRecast != null && !transferRecast.isEmpty()) {
			scheduler.schedule(transferRecastTask, new CronTrigger(transferRecast));
		}

		if (notifyWithoutActivity != null && !notifyWithoutActivity.isEmpty()) {
			scheduler.schedule(notify24HoursWithoutActivityTask, new CronTrigger(notifyWithoutActivity));
		}

		if (report != null && !report.isEmpty()) {
			scheduler.schedule(reportTask, new CronTrigger(report));
		}

		return scheduler;
	}
}
