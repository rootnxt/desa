package es.santander.darwin.financiaciondigital.config;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;

import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAClient;


/**
 * 
 * The Class DatosUsuarioLAConfig.
 * 
 */
@Configuration
public class DatosUsuarioLAConfig {

    /** The default uri. */
    @Value("${darwin.webservices.datosusuario.resources.defaultEndpoint}")
    private String defaultUri;

    /** The interceptors bean. */
    @Autowired
    private Map<String, ClientInterceptor> interceptorsBean;

    /** The interceptor name. */
    @Value("${darwin.webservices.datosusuario.security.name}")
    private String interceptorName;

    /** The custom marshaller. */
    @Autowired
    private Jaxb2Marshaller customMarshaller;

    /**
     * Gets the document WS client.
     *
     * @return the document WS client
     */
    @Bean
    public DatosUsuarioLAClient getDocumentWSClient() {
        DatosUsuarioLAClient suscribeProposalRecordWS = new DatosUsuarioLAClient();
        suscribeProposalRecordWS.setMarshaller(customMarshaller);
        suscribeProposalRecordWS.setUnmarshaller(customMarshaller);
        suscribeProposalRecordWS.setDefaultUri(defaultUri);
        
        ClientInterceptor[] clientInterceptor = new ClientInterceptor[0];
        
        if(interceptorsBean.get(interceptorName) != null) {
            clientInterceptor = new ClientInterceptor[] {  interceptorsBean.get(interceptorName)};
        }
        suscribeProposalRecordWS.setInterceptors(clientInterceptor);
        return suscribeProposalRecordWS;
    }
}
