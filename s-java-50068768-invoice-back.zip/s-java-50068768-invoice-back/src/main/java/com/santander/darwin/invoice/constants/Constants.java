package com.santander.darwin.invoice.constants;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Constants.
 *
 * @author igndom
 */
public class Constants {

	/** The Constant APP_FACTURAS_ID. */
	// Identificadores de aplicaciones
	public static final String APP_FACTURAS_ID = "5e39543440497258d8d24a5d";

	/** The Constant APP_FINANCIACION_DIG. */
	public static final String APP_FINANCIACION_DIG = "5e3954aa40497258d8d24b00";

	/** The Constant APP_REFINANCIACION. */
	public static final String APP_REFINANCIACION = "726566696e616e6465756461";

	/** The Constant APP_PRETROLCONTROL_ID. */
	public static final String APP_PRETROLCONTROL_ID = "636f72746f706c617a6f3336";

	/** The Constant STYLE_ERROR_PAGE_ICON_AND_BUTTON. */
	// Estilo de pantalla de error para mensaje de preconcedidos y orientados
	public static final String STYLE_ERROR_PAGE_ICON_AND_BUTTON = "icon-and-button";

	// APP
	public static final String DEVICE_APP = "App";

	//Indicador solicitudes creadas en omnicanal digital
	public static final String ADM_INDPROCE_AD = "AD";

	// Indicador para derivar propuesta a Oficina
	public static final String ADM_INDPROCE = "AO";

	// Indicador para derivar propuesta a Oficina productos no digitales
	public static final String ADM_INDPROCE_AX = "DO";

	// Indicador solicitudes creadas en omnicanal oficina
	public static final String ADM_INDPROCE_OM = "OM";

	// Canal para derivar propuesta a Oficina
	public static final String ADM_CANALCOM = "RED";

	// Canal operación para derivar propuesta a Oficina
	public static final String ADM_CANALOPE = "035";
	
	// Canal operación para derivar sancion online
	public static final String ADM_CANAL014 = "014";

	/** The Constant APP_AUTH_COOKIE. */
	// Cookie
	public static final String APP_AUTH_COOKIE = "cookie";

	/** The Constant APP_AUTH_TOKEN. */
	public static final String APP_AUTH_TOKEN = "token";

	/** The Constant UUID. */
	public static final String UUID = "UUID";

	/** The Constant BEARER_HEADER. */
	public static final String BEARER_HEADER = "Bearer ";

	/** The Constant X_CLIENT_ID. */
	public static final String X_CLIENT_ID = "X-ClientId";

	/** The Constant X_CLIENT_ID. */
	public static final String X_FORWARDED_FOR = "X-Forwarded-For";

	/** The Constant APP_INIT. */
	public static final String APP_INIT = "App-Init";

	/** The Constant X_ALIAS. */
	public static final String X_ALIAS = "x-alias";

	/** The Constant APP_TYPE_GENERAL. */
	// Tipologias de aplicaciones
	public static final String APP_TYPE_GENERAL = "01";

	/** The Constant APP_TYPE_PETROCONTROL_V1. */
	public static final String APP_TYPE_PETROCONTROL_V1 = "02";

	/** The Constant APP_TYPE_PETROCONTROL_V2. */
	public static final String APP_TYPE_PETROCONTROL_V2 = "03";

	/** The Constant APP_TYPE_REFINANCIACION. */
	public static final String APP_TYPE_REFINANCIACION = "04";

	/** The Constant SUBTYPOLOGY_CONFIRMING. */
	public static final String SUBTYPOLOGY_CONFIRMING = "CONFP";
	
	/** The Constant SUBTYPOLOGY_COMEX. */
	public static final String SUBTYPOLOGY_COMEX = "COMEX";

	/** The Constant SUBTYPOLOGY_PMP. */
	public static final String SUBTYPOLOGY_PMP = "PMP";
	
	/** The Constant TYPOLOGY_PMP. */
	public static final String TYPOLOGY_PMP = "PMP";
	
	/** The Constant CODSEG_MD. */
	public static final String CODSEG_MD = "MD";
	
	/** The Constant DEFAULT_ACODCAMP. */
	// Codigo de campaña por defecto
	public static final String DEFAULT_ACODCAMP = "OCD";

	/** The Constant JOB_USER. */
	// Nombre de los jobs
	public static final String JOB_USER = "JobUser";

	/** The Constant JOB_USER_RECAST. */
	public static final String JOB_USER_RECAST = "JobUserRecast";

	/** The Constant JOB_USER_TRANSFER. */
	public static final String JOB_USER_TRANSFER = "JobUserTransfer";

	/** The Constant JOB_USER_NOTIFY_WITHOUT_ACTIVITY. */
	public static final String JOB_USER_NOTIFY_WITHOUT_ACTIVITY = "JobUserNotify";

	/** The Constant SECRET_ALGORITHM. */
	// Encriptado de datos
	public static final String SECRET_ALGORITHM = "PBEWithMD5AndTripleDES";

	/** The Constant ENVIRONMENT_DEV. */
	// Environment
	public static final String ENVIRONMENT_DEV = "dev";

	/** The Constant ENVIRONMENT_PRE. */
	// Environment
	public static final String ENVIRONMENT_PRE = "pre";

	/** The Constant ENVIRONMENT_PRE. */
	// Environment
	public static final String ENVIRONMENT_PRO = "pro";

	
	/** The Constant AUTHORIZATION. */
	// Headers
	public static final String AUTHORIZATION = "Authorization";

	/** The Constant AUTHORIZATION_DESC. */
	public static final String AUTHORIZATION_DESC = "Bearer of authorization";

	/** The Constant KEY_CHANNEL_SANTANDER. */
	public static final String KEY_CHANNEL_SANTANDER = "X-Santander-Channel";


	/** The Constant KEY_ALIAS. */
	public static final String KEY_ALIAS = "X-Alias";

	/** The Constant KEY_FRAME_CHANNEL. */
	public static final String KEY_FRAME_CHANNEL = "X-Frame-Channel";

	/** The Constant REST_LANGUAGE. */
	public static final String REST_LANGUAGE = "Accept-Language";

	/** The Constant DEFAULT_LANGUAJE. */
	public static final String DEFAULT_LANGUAJE = "es-ES";

	/** The Constant DEFAULT_LANG. */
	public static final String DEFAULT_LANG = "es";

	/** The 014 Channel Constant. */
	public static final String CHANNEL_014 = "014";

	/** The Constant JURIDIC_PERSON. */
	// Tipos de personas
	public static final String JURIDIC_PERSON = "J";

	/** The Constant PHYSICAL_PERSON. */
	public static final String PHYSICAL_PERSON = "F";

	/** The Constant CONTRACT_JURIDIC_PERSON. */
	public static final String CONTRACT_JURIDIC_PERSON = "520";

	/** The Constant CHANNEL_INT. */
	// Canales utilizados
	public static final String CHANNEL_INT = "INT";

	/** The Constant CHANNEL_OFI. */
	public static final String CHANNEL_OFI = "OFI";

	/** The Constant CHANNEL_RED. */
	public static final String CHANNEL_RED = "RED";

	/** The Constant CHANNEL_EMP. */
	public static final String CHANNEL_EMP = "EMP";

	/** The Constant COMPANY. */
	public static final String COMPANY = "0049";

	/** The Constant COMPANY. */
	public static final String COMPANY_0030 = "0030";

	/** The Constant DEFAULT_DIFERINI. */
	public static final BigDecimal DEFAULT_DIFERINI = new BigDecimal(0);

	/** The Constant DEFAULT_DIFERNCI. */
	public static final BigDecimal DEFAULT_DIFERNCI = new BigDecimal(0);

	/** The Constant DEFAULT_PORIMFRA. */
	public static final BigDecimal DEFAULT_PORIMFRA = new BigDecimal(0);

	/** The Constant DEFAULT_PORINCRA. */
	public static final BigDecimal DEFAULT_PORINCRA = new BigDecimal(0);

	/** The Constant PRXY. */
	public static final String PRXY = "PRXY";

	/** The Constant TIPCONCE. */
	public static final String TIPCONCE = "P";

	/** The Constant LANGUAGE_ES. */
	public static final String LANGUAGE_ES = "es-ES";

	/** The Constant LANGUAGE_ES_SIGN. */
	public static final String LANGUAGE_ES_SIGN = "es_ES";
	
	/** The Constant COMMON_A. */
	public static final String COMMON_A = "A";

	/** The Constant COMMON_N. */
	// Datos comunes letras
	public static final String COMMON_N = "N";

	/** The Constant COMMON_C. */
	public static final String COMMON_C = "C";

	/** The Constant COMMON_S. */
	public static final String COMMON_S = "S";

	/** The Constant COMMON_O. */
	public static final String COMMON_O = "O";

	/** The Constant COMMON_F. */
	public static final String COMMON_F = "F";

	/** The Constant COMMON_0. */
	// Datos comunes numeros
	public static final String COMMON_1_NEGATIVE = "-1";
	
	public static final String COMMON_0 = "0";

	/** The Constant COMMON_1. */
	public static final String COMMON_1 = "1";

	/** The Constant COMMON_2. */
	public static final String COMMON_2 = "2";
	
	/** The Constant COMMON_99. */
	public static final String COMMON_99 = "99";
	
	/** The Constant COMMON_000. */
	public static final String COMMON_000 = "000";

	/** The Constant COMMON_999. */
	public static final String COMMON_999 = "999";
	
	/** The Constant INT_17. */
	public static final Integer INT_17 = 17;

	/** The Constant SIMPLE_COMMA. */
	// Comas y espacios en blanco
	public static final char SIMPLE_COMMA = ',';

	/** The Constant SIMPLE_SPACE. */
	public static final char SIMPLE_SPACE = ' ';

	/** The Constant COMMON_9999. */
	// Mas dados comunes
	public static final String COMMON_9999 = "9999";

	/** The Constant COMMON_99999. */
	public static final String COMMON_99999 = "99999";

	/** The Constant COMMON_00. */
	public static final String COMMON_00 = "00";

	/** The Constant COMMON_01. */
	public static final String COMMON_01 = "01";

	/** The Constant COMMON_03. */
	public static final String COMMON_03 = "03";

	/** The Constant COMMON_09. */
	public static final String COMMON_09 = "09";
	
	/** The Constant COMMON_CX. */
	public static final String COMMON_CX = "CX";
	
	/** The Constant COMMON_CX. */
	public static final String COMMON_CL = "CL";

	/** The Constant SIN_IMPAGOS. */
	public static final String SIN_IMPAGOS = "0";

	/** The Constant CON_IMPAGOS. */
	public static final String CON_IMPAGOS = "1";

	/** The Constant DEFAULT_PREFIX. */
	public static final String DEFAULT_PREFIX = "34";

	/** The Constant TIPO_DOMICILIO_HABITUAL. */
	public static final String TIPO_DOMICILIO_HABITUAL = "01";

	/** The Constant REFERENCE_RATE. */
	public static final String REFERENCE_RATE = "S30";

	/** The Constant NEXT_SIGN_NOW. */
	// Continuar de firma
	public static final String NEXT_SIGN_NOW = "now";

	/** The Constant NEXT_SIGN_LATER. */
	public static final String NEXT_SIGN_LATER = "later";

	/** The Constant LANG_ES. */
	// Idionas
	public static final String LANG_ES = "es";

	/** The Constant LANG_CA. */
	public static final String LANG_CA = "ca";

	/** The Constant LANG_EU. */
	public static final String LANG_EU = "eu";

	/** The Constant LANG_GL. */
	public static final String LANG_GL = "gl";

	/** The Constant LANG_DE. */
	public static final String LANG_DE = "de";

	/** The Constant LANG_EN. */
	public static final String LANG_EN = "en";

	/** The Constant LANG_ES_ES. */
	// Idiomas y dialectos
	public static final String LANG_ES_ES = "esES";

	/** The Constant LANG_ES_CA. */
	public static final String LANG_ES_CA = "esCA";

	/** The Constant LANG_ES_EU. */
	public static final String LANG_ES_EU = "esEU";

	/** The Constant LANG_ES_GL. */
	public static final String LANG_ES_GL = "esGL";

	/** The Constant LANG_DE_DE. */
	public static final String LANG_DE_DE = "deDE";

	/** The Constant LANG_EN_EN. */
	public static final String LANG_EN_EN = "enEN";

	/** The Constant LANG_EN_GB. */
	public static final String LANG_EN_GB = "enGB";

	/** The Constant MODEL_200_ID_MOD. */
	// Constants modelo 200
	public static final String MODEL_200_ID_MOD = "201";

	/** The Constant MODEL_200_ID_SIS_PET. */
	public static final String MODEL_200_ID_SIS_PET = "04";

	/** The Constant MODEL_200_SIS_PET. */
	public static final String MODEL_200_SIS_PET = "FINANCIACIONDIGITAL";

	/** The Constant MODEL_200_ID_VERSION. */
	public static final String MODEL_200_ID_VERSION = "2017";

	/** The Constant MODEL_200_IDIOMA. */
	public static final String MODEL_200_IDIOMA = "ES";

	/** The Constant MODEL_200_TIPO_DOC. */
	public static final String MODEL_200_TIPO_DOC = "1";

	/** The Constant VERSION_MOTOR_F1. */
	// Constans motor
	public static final String VERSION_MOTOR_F1 = "F1";

	/** The Constant VERSION_MOTOR_F2. */
	public static final String VERSION_MOTOR_F2 = "F2";

	/** The Constant OPCIL_A. */
	// Constantes aprobar o denegar
	public static final String OPCIL_A = "A";

	/** The Constant OPCIL_D. */
	public static final String OPCIL_D = "D";

	/** The Constant OPCIL_E. */
	public static final String OPCIL_E = "E";

	/** The Constant A1AGENDA_N. */
	public static final String A1AGENDA_N = "N";

	/** The Constant SXVALUE_A. */
	// Variables sx value
	public static final String SXVALUE_A = "A";

	/** The Constant SXVALUE_I. */
	public static final String SXVALUE_I = "I";

	/** The Constant CHANNEL_PRE_F. */
	// Canales personas F o J
	public static final String CHANNEL_PRE_F = "002";

	/** The Constant CHANNEL_PRE_J. */
	public static final String CHANNEL_PRE_J = "014";

	// Operaciones de riesgos
	/** The Constant CLIENT_PE2 */
	public static final String CLIENT_PE2 = "PE2";

	/** The Constant CLIENT_PE1 */
	public static final String CLIENT_PE1 = "PE1";

	/** The Constant CLIENT_AUT */
	public static final String CLIENT_AUT = "AUT";

	/** The Constant OPERATION_TYPE_RISK_01. */
	// se modifica para que siempre sea 02
	public static final String OPERATION_TYPE_RISK_01 = "02";

	/** The Constant OPERATION_TYPE_RISK_02. */
	public static final String OPERATION_TYPE_RISK_02 = "02";

	/** The Constant SYSTEM_DECISION_OKAC. */
	// Decisiones de riesgos
	public static final String SYSTEM_DECISION_OKAC = "AC";

	/** The Constant SYSTEM_DECISION_OKAS. */
	public static final String SYSTEM_DECISION_OKAS = "AS";
	
	/** The Constant SYSTEM_DECISION_OKAR. */
	public static final String SYSTEM_DECISION_OKAR = "AR";

	/** The Constant SYSTEM_DECISION_OZ. */
	public static final String SYSTEM_DECISION_OZ = "OZ";

	/** The Constant SYSTEM_DECISION_OD. */
	public static final String SYSTEM_DECISION_OD = "OD";

	/** The Constant SYSTEM_DECISION_Q3. */
	public static final String SYSTEM_DECISION_Q3 = "Q3";

	/** The Constant SYSTEM_DECISION_E1. */
	public static final String SYSTEM_DECISION_E1 = "E1";

	/** The Constant SYSTEM_DECISION_E2. */
	public static final String SYSTEM_DECISION_E2 = "E2";
	
	/** The Constant SYSTEM_DECISION_E3.  */
	public static final String SYSTEM_DECISION_E3 = "E3";

	/** The Constant SYSTEM_DECISION_KODG. */
	public static final String SYSTEM_DECISION_KODG = "DG";

	/** The Constant SYSTEM_DECISION_KODL. */
	public static final String SYSTEM_DECISION_KODL = "DL";
	
	/** The Constant SYSTEM_DECISION_EL (Elevacion). */
	public static final String GROUP_DECISION_RV = "RV";

	// Constantes a nivel general

	/** The Constant EURO. */
	public static final String EURO = "EUR";

	/** The PRODUCT_143 Constant.  */
	public static final String PRODUCT_143 = "143";

	/** The DEFAULT_SUBPRODUCT Constant.  */
	public static final String SUBPRODUCT_512 = "512";

	/** The DEFAULT_OPERATION Constant. */
	public static final String OPERATION_L = "L";

	/** The ORDER_0 Constant. */
	public static final BigDecimal ORDER_0 = new BigDecimal(0);

	/** The ENTITY_EMPTY Constant. */
	public static final String ENTITY_BLANK = "    ";

	/** The CENTER_EMPTY Constant. */
	public static final String CENTER_BLANK = "    ";

	/** The PRODUCT_EMPTY Constant. */
	public static final String PRODUCT_BLANK = "   ";

	/** The NUMBER_EMPTY Constant. */
	public static final String NUMBER_BLANK = "       ";

	/** The Constant STATE_SIGN. */
	public static final String STATE_SIGN = "A";

	/** The Constant A1CODSEG. */
	public static final String A1CODSEG = "PN";

	/** The Constant LITERAL_01. */
	public static final String LITERAL_01 = "01";

	/** The Constant LITERAL_03. */
	public static final String LITERAL_03 = "03";
	
	/** The Constant LITERAL_44. */
	public static final String LITERAL_44 = "44";

	/** The Constant LITERAL_04. */
	public static final String LITERAL_04 = "04";

	/** The Constant LITERAL_33. */
	public static final String LITERAL_33 = "33";

	/** The Constant LITERAL_07. */
	public static final String LITERAL_07 = "07";

	/** The Constant Z_COTLOCAL. */
	public static final String Z_COTLOCAL = "01";

	/** The Constant Z_COTLOCAL_10. */
	public static final String Z_COTLOCAL_10 = "10";

	/** The Constant CRITERIO_ACEPTACION. */
	public static final String CRITERIO_ACEPTACION = "01";

	/** The Constant CODEST. */
	// Otras constantes generales
	public static final String CODEST = "01";

	/** The Constant A1OPCI1. */
	public static final String A1OPCI1 = "SI";

	/** The Constant COMMON_X. */
	public static final String COMMON_X = "X";

	/** The Constant A1EXPLIC. */
	public static final String A1EXPLIC = "Text aprob";

	/** The Constant DENY_PROPOSAL_03. */
	// Mas constantes generales
	public static final String DENY_PROPOSAL_03 = "03";

	/** The Constant APPROVE_PROPOSAL_02. */
	public static final String APPROVE_PROPOSAL_02 = "02";

	/** The Constant APPROVE_PROPOSAL_01. */
	public static final String APPROVE_PROPOSAL_01 = "01";

	/** The Constant CONTRACT_OPERATION_TYPE. */
	public static final String CONTRACT_OPERATION_TYPE = "99";

	/** The Constant PLAZO_MESES. */
	public static final String PLAZO_MESES = "M";

	/** The Constant BANCA_ELECTRONICA. */
	public static final String BANCA_ELECTRONICA = "FG";

	/** The Constant DESC_F_GO. */
	public static final String DESC_F_GO = "F&GO";

	/** The Constant TYPE_BOX. */
	public static final String TYPE_BOX = "B022";

	/** The Constant CAT_BOX. */
	public static final String CAT_BOX = "0007";

	/** The Constant TYPE_EXP. */
	public static final String TYPE_EXP = "FIRMAS";

	/** The Constant TYPE_HIRING_LOAN. */
	// Tipo de contratacion
	public static final String TYPE_HIRING_LOAN = "prestamo-anticipo-facturas";

	/** The Constant TYPE_HIRING_CREDIT. */
	public static final String TYPE_HIRING_CREDIT = "credito-anticipo-facturas";

	/** The Constant DESC_SIGN. */
	public static final String DESC_SIGN = "Financiación";

	/** The Constant TYPE_CIR_GENERIC. */
	public static final String TYPE_CIR_GENERIC = "PE";

	/** The Constant TYPE_SIGN_POSITIONS. */
	public static final String TYPE_SIGN_POSITIONS = "P";

	/** The Constant OPINATOR_PRODUCT. */
	// Se añaden nuevas variables para el opinator
	public static final String OPINATOR_PRODUCT = "Financia&Go";

	/** The Constant OPINATOR_OPERATIVE_FIRMA. */
	public static final String OPINATOR_OPERATIVE_FIRMA = "Pendiente_Firma";

	/** The Constant OPINATOR_OPERATIVE_RESUMEN. */
	public static final String OPINATOR_OPERATIVE_RESUMEN = "Resumen";

	/** The Constant COD_ERROR_VALIDSEGMENTACION. */
	// Codigos de errores
	public static final String COD_ERROR_VALIDSEGMENTACION = "PS_0546";

	/** The Constant COD_ERROR_KO_BASTANTEO. */
	public static final String COD_ERROR_KO_BASTANTEO = "02";

	/** The Constant RETURN_CODE_OK. */
	public static final String RETURN_CODE_OK = "00";

	/** The Constant RETURN_CODE_KO. */
	public static final String RETURN_CODE_KO = "99";

	/** The Constant SUB_APPLICATION_CIRBE. */
	// Firma
	public static final String SUB_APPLICATION_CIRBE = "AD";

	/** The Constant SIGN02. */
	public static final String SIGN02 = "SIGN02";

	/** The Constant SIGNATURE_POSITIONS. */
	public static final String SIGNATURE_POSITIONS = "posiciones";

	/** The Constant SIGNATURE_CRYPTOCALCULATOR. */
	public static final String SIGNATURE_CRYPTOCALCULATOR = "criptocalculadora";

	/** The Constant SIGNATURE_OTP. */
	public static final String SIGNATURE_OTP = "otp";

	/** The Constant XML_OPERATION. */
	// DAtos xml de firma
	public static final String XML_OPERATION = "<?xml version='1.0' encoding='UTF-8'?><altaServicioWallet>"
			+ "<codSmsTraducible>PATFIR_OTP0036                                 </codSmsTraducible></altaServicioWallet>";

	/** The Constant TYPOLOGY_PRESTAMO. */
	// Tipologias
	public static final String TYPOLOGY_PRESTAMO = "P";

	/** The Constant TYPOLOGY_CREDITO. */
	public static final String TYPOLOGY_CREDITO = "C";

	/** The Constant FIOC_OK. */
	// Retorno ok de fioc
	public static final String FIOC_OK = "00";

	/** The Constant COMMON_KO. */
	// Retorno gsfir
	public static final String COMMON_KO = "KO";
	public static final String COMMON_ERROR = "ERROR";

	/** The Constant COMMON_OK. */
	public static final String COMMON_OK = "OK";
	public static final String COMMON_IN_PROGRESS = "EN CURSO";

	/** The Constant MODE_VERSION_ONE. */
	// Versiones de aplicaciones
	public static final String MODE_VERSION_ONE = "1";

	/** The Constant MODE_VERSION_SECOND. */
	public static final String MODE_VERSION_SECOND = "2";

	/** The Constant MODE_VERSION_THREE. */
	public static final String MODE_VERSION_THREE = "3";

	/** The Constant MODE_VERSION_FOUR. */
	public static final String MODE_VERSION_FOUR = "4";
	
	/** The Constant MODE_VERSION_FIVE. Para la redirección de la solicitud en simulación */
	public static final String MODE_VERSION_FIVE_PMP = "5";

	/** The Constant SIGN_TYPE_ONE. */
	// Tipos de firma
	public static final Integer SIGN_TYPE_ONE = 1;

	/** The Constant SIGN_TYPE_TOW. */
	public static final Integer SIGN_TYPE_TOW = 2;

	/** The Constant SIGN_TYPE_THREE. */
	public static final Integer SIGN_TYPE_THREE = 3;

	/** The Constant PRODUCT_PRESTAMOS. */
	// Tipos de productos
	public static final String PRODUCT_PRESTAMOS = "P";

	/** The Constant PRODUCT_CREDITOS. */
	public static final String PRODUCT_CREDITOS = "C";

	/** The Constant PRODUCT_CUENTAS. */
	public static final String PRODUCT_CUENTAS = "CC";

	/** The Constant PRODUCT_TARJETAS. */
	public static final String PRODUCT_TARJETAS = "T";

	/** The Constant TYPE_MOBILE. */
	// Tipo
	public static final String TYPE_MOBILE = "T";

	/** The Constant TYPE_MAIL. */
	public static final String TYPE_MAIL = "I";

	/** The Constant TYPE_PRESTAMOS. */
	// Descripcion tipo de productos
	public static final String TYPE_PRESTAMOS = "loan";

	/** The Constant TYPE_CREDITOS. */
	public static final String TYPE_CREDITOS = "credit";

	/** The Constant TYPE_CUENTAS. */
	public static final String TYPE_CUENTAS = "account";

	/** The Constant TYPE_TARJETAS. */
	public static final String TYPE_TARJETAS = "card";

	/** The Constant MAX_SIZE_SMS. */
	// Tamñano maximo de sms
	public static final Integer MAX_SIZE_SMS = 160;

	/** The Constant MODAL_TITLE. */
	public static final String MODAL_TITLE = "Error";

	/** Datos necesarios para el front *. */
	public static final String PERCENT = "percent";


	public static final String CONCEPTS = "concept";

	/** The Constant DATE. */
	public static final String DATE = "date";

	/** The Constant CURRENCY. */
	public static final String CURRENCY = "currency";

	/** The Constant MONTHS_FRONT. */
	public static final String MONTHS_FRONT = "months";

	/** The Constant MONTHS_FRONT. */
	public static final String NO_MONTHS_FRONT = "no_months";

	/** The Constant DAYS_FRONT. */
	public static final String DAYS_FRONT = "days";

	/** The Constant DELETE_BY_CCC. */
	public static final String DELETE_BY_CCC = "deleteByCcc";

	/** The Constant CCC_ID. */
	public static final String CCC_ID = "contractId";

	/** The Constant CCC_ID_TOW. */
	public static final String CCC_ID_TOW = "contractIdTow";

	/** The Constant IBAN. */
	// Otros datos necesarios para el front
	public static final String IBAN = "iban";

	/** The Constant PAN. */
	public static final String PAN = "pan";

	/** The Constant PRODUCT_DETAIL. */
	public static final String PRODUCT_DETAIL = "productDetail";

	/** The Constant PRODUCT_MORE_DETAILS. */
	public static final String PRODUCT_MORE_DETAILS = "productMoreDetails";

	/** The Constant AMOUNT. */
	public static final String AMOUNT = "amount";

	/** The Constant REFINANCED_DEBT. */
	public static final String REFINANCED_DEBT = "refinancedDebt";

	/** The Constant DEFAULT_PRODUCT. */
	// Producto por defecto. Utilizado version 3
	public static final String DEFAULT_PRODUCT = "0000000000000";

	/** The Constant MTDL_URL_VERSIONS. */
	// Redirecciones simulation
	public static final String MTDL_URL_VERSIONS = "/simulation/v";
	
	// Redirecciones simulation PMP. Para la redirección de la solicitud en simulación
	public static final String MTDL_URL_VERSIONS_PMP = "/pmp/simulation";

	/** The Constant MTDL_URL_VERSION_01. */
	public static final String MTDL_URL_VERSION_01 = "1/summary";

	/** The Constant MTDL_URL_VERSION_02. */
	public static final String MTDL_URL_VERSION_02 = "2/pending";

	/** The Constant STATUS_ARM_ONGOING. */
	// Estados de arm
	public static final String STATUS_ARM_ONGOING = "Ongoing";

	/** The Constant STATUS_ARM_CANCELLED. */
	public static final String STATUS_ARM_CANCELLED = "Cancelled";

	/** The Constant STATUS_ARM_ADDITIONAL. */
	public static final String STATUS_ARM_ADDITIONAL = "Additional authorization required";

	/** The Constant STATUS_ARM_COMPLETED. */
	public static final String STATUS_ARM_COMPLETED = "Completed";

	/** The Constant REG_EXP_RECAST_LINE. */
	// Expresiones regulares
	public static final String REG_EXP_RECAST_LINE = "^[\\p{Digit} JF]{20,}$";

	/** The Constant REG_EXP_TRANSFER_LINE. */
	public static final String REG_EXP_TRANSFER_LINE = "^[\\p{Digit}]{70,}$";

	/** The Constant REG_EXP_OPERATION_ID. */
	public static final String REG_EXP_OPERATION_ID = "^[\\p{L}\\p{Digit} _-]{10,60}$";
	
	/** The Constant REG_EXP_PROPOSAL_ID. */
	public static final String REG_EXP_PROPOSAL_ID = "^[\\p{Digit}]{17}$";

	/** The Constant INDPROCE_AD. */
	// Improcede ad
	public static final String INDPROCE_AD = "AD";

	/** The Constant NUM_PERSONA_CLI_EMPRESAS. */
	// Tipos de documento avalistas
	public static final String NUM_PERSONA_CLI_EMPRESAS = "gnIdEmpresas";

	/** The Constant NUM_PERSONA_CLI_PARTICULARES. */
	public static final String NUM_PERSONA_CLI_PARTICULARES = "gnIdParticulares";

	/** COMMISSIONS *. */
	public static final ImmutableList<String> ORDINALS = new ImmutableList.Builder<String>().add("PRIMER")
			.add("SEGUNDO").add("TERCER").add("CUARTO").add("QUINTO").add("SEXTO").add("SEPTIMO").add("OCTAVO")
			.add("RESTO").build();

	/** The Constant OPEN_COMMISSION_ID. */
	public static final String OPEN_COMMISSION_ID = "01";

	/** The Constant TIN_ID. */
	public static final String TIN_ID = "02";

	/** The Constant STRETCH_ID. */
	public static final String STRETCH_ID = "03";

	/** The Constant STRETCH_DESC. */
	public static final String STRETCH_DESC = "%s (%d - %d %s)";

	/** The Constant AVAILABILITY_COMMISSION_ID. */
	// Datos de comisiones
	public static final String AVAILABILITY_COMMISSION_ID = "04";

	/** The Constant AVAILABILITY_COMMISSION_MIN_ID. */
	public static final String AVAILABILITY_COMMISSION_MIN_ID = "041";
	
	/** The Constant COMISION_DISP_ID. */
	public static final String COMISION_DISP_ID = "04";

	/** The Constant APERTURA_ID. */
	public static final String APERTURA_ID = "01";
	
	/** The Constant TAE_ID. */
	public static final String TAE_ID = "05";

	/** The Constant IMPCUOTA_ID. */
	public static final String IMPCUOTA_ID = "06";

	/** The Constant AMOUNT_ID. */
	public static final String AMOUNT_ID = "061";

	/** Idioma *. */
	public static final String IVFN = "IVFN";
	
	/** Comex **/
	public static final String IVFC = "IVFC";

	/** The Constant IVRD. */
	public static final String IVRD = "IVRD";

	/** The Constant MONTHS. */
	public static final String MONTHS = "MONTHS";

	/** The Constant MONTH. */
	public static final String MONTH = "MONTH";

	/** The Constant PLAZO. */
	public static final String PLAZO = "IVFNPLAZO";

	/** The Constant IVFNPLAZOPRO. */
	public static final String IVFNPLAZOPRO = "IVFNPLAZOPRO";

	/** The Constant IVFNINTFIN. */
	public static final String IVFNINTFIN = "IVFNINTFIN";

	/** The Constant IVFNCOMFIN. */
	public static final String IVFNCOMFIN = "IVFNCOMFIN";

	/** The Constant IVFNCOMAF. */
	public static final String IVFNCOMAF = "IVFNCOMAF";

	/** The Constant COMMISSION. */
	// Datos de idioma
	public static final String COMMISSION = "IVFNCOMMISSION";
	
	/** The IVFNCOMMISSION02. */
	public static final String IVFNCOMMISSION02 = "IVFNCOMMISSION02";

	/** The Constant INTERESTS_EXPIRATION_DATE. */
	public static final String INTERESTS_EXPIRATION_DATE = "IVFNINTERESTSEXPIRATIONDATE";

	/** The Constant INTERESTS_DEADLINE. */
	public static final String INTERESTS_DEADLINE = "IVFNINTERESTSDEADLINE";

	/** The Constant INTERESTS_INTEREST. */
	public static final String INTERESTS_INTEREST = "IVFNINTERESTSINTEREST";

	/** The Constant COMMISSION01. */
	// Otros datos de idioma
	public static final String COMMISSION01 = "IVFNCOMMISSION01";

	/** The Constant INTERESTS_INTERESTS_TOTAL. */
	public static final String INTERESTS_INTERESTS_TOTAL = "IVFNINTERESTSTOTAL";

	/** INTEREST *. */
	public static final String IVFNINTERESTSEXPIRATIONDATE = "IVFNINTERESTSEXPIRATIONDATE";

	/** The Constant IVFNINTERESTSDEADLINE. */
	public static final String IVFNINTERESTSDEADLINE = "IVFNINTERESTSDEADLINE";

	/** The Constant IVFNINTERESTSINTEREST. */
	// Inteses
	public static final String IVFNINTERESTSINTEREST = "IVFNINTERESTSINTEREST";

	/** The Constant IVFNINTERESTSTOTAL. */
	public static final String IVFNINTERESTSTOTAL = "IVFNINTERESTSTOTAL";

	/** The Constant MESSAGE_INVOICE_VALIDATION_OPERATION_ID. */
	// Mensajes de validacion
	public static final String MESSAGE_INVOICE_VALIDATION_OPERATION_ID = "OperationId Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_PERSON_TYPE. */
	public static final String MESSAGE_INVOICE_VALIDATION_PERSON_TYPE = "Tipo de persona Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_PERSON_NUMBER. */
	public static final String MESSAGE_INVOICE_VALIDATION_PERSON_NUMBER = "Código de persona incorrecto";

	/** The Constant MESSAGE_INVOICE_VALIDATION_DOCUMENT_TYPE. */
	public static final String MESSAGE_INVOICE_VALIDATION_DOCUMENT_TYPE = "Tipo de documento Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_DOCUMENT_NUMBER. */
	public static final String MESSAGE_INVOICE_VALIDATION_DOCUMENT_NUMBER = "Número de documento Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_USERID. */
	// Otros mensajes de validacion
	public static final String MESSAGE_INVOICE_VALIDATION_USERID = "UserId Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_PRODUCT. */
	public static final String MESSAGE_INVOICE_VALIDATION_PRODUCT = "Producto Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_CONTRACT. */
	public static final String MESSAGE_INVOICE_VALIDATION_CONTRACT = "Contrato Obligatorio";

	/** The Constant MESSAGE_INVOICE_VALIDATION_DATA. */
	public static final String MESSAGE_INVOICE_VALIDATION_DATA = "Data Obligatorio";

	/** The Constant RUTA_TEMPLATES_XML. */
	// Ruta de las plantillas xml
	public static final String RUTA_TEMPLATES_XML = "/templates/";

	/** The Constant PRINTED_TEMPLATE_CODE. */
	// Datos de los documentos
	public static final String PRINTED_TEMPLATE_CODE = "JR";
	public static final String PRINTED_CREDIT_TEMPLATE_CODE = "JT";

	/** The Constant DIGITALIZED_TEMPLATE_CODE. */
	public static final String DIGITALIZED_TEMPLATE_CODE = "JS";
	public static final String DIGITALIZED_CREDIT_TEMPLATE_CODE = "JU";
	
	/** The Constant PRINTED_TEMPLATE_CODE. */
	// Datos de los documentos
	public static final String PRINTED_COMEX_TEMPLATE_CODE = "JRC";

	/** The Constant PRINTED_CONFP_TEMPLATE_CODE */
	public static final String PRINTED_CONFP_TEMPLATE_CODE = "JRP";

	/** The Constant PIOL. */
	public static final String PIOL = "PIOL";

	/** The Constant PDF_EXT. */
	public static final String PDF_EXT = ".pdf";

	/** The Constant SIGN_POSITION_CODE. */
	// Tipos de firma
	public static final String SIGN_POSITION_CODE = "01";

	/** The Constant SIGN_POSITION_DES. */
	public static final String SIGN_POSITION_DES = "Firma mediante posiciones";

	/** The Constant SIGN_KEY_CODE. */
	public static final String SIGN_KEY_CODE = "02";

	/** The Constant SIGN_KEY_DES. */
	public static final String SIGN_KEY_DES = "Firma mediante clave criptocalculadora";

	/** The Constant NUMAPODERADOS. */
	// Campos firmantes
	public static final String NUMAPODERADOS = "numapoderados";

	/** The Constant NUMFIRMAS. */
	public static final String NUMFIRMAS = "numfirmas";

	/** The Constant USUARIOFIRMANTE. */
	public static final String USUARIOFIRMANTE = "usuariofirmante";

	/** The Constant ORDER_FIRST_RECENTLY. */
	// Tipo de ordenacion
	public static final Integer ORDER_FIRST_RECENTLY = 1;

	/** The Constant AUTONOMOUS_CODSEG_PE. */
	// Plazo proveedor autonomos
	public static final String AUTONOMOUS_CODSEG_PE = "PE";

	/** The Constant AUTONOMOUS_HIDDEN_TEN. */
	public static final String AUTONOMOUS_HIDDEN_TEN = "10";

	/** The Constant DEFAULT_FORMAT_DATE. */
	// Default date
	public static final String DEFAULT_FORMAT_DATE = "dd/MM/yyyy";

	/** The Constant ENGLISH_FORMAT_DATE. */
	// English date
	public static final String ENGLISH_FORMAT_DATE = "MM/dd/yyyy";

	/** The Constant DEFAULT_REVERSE_FORMAT_DATE. */
	// Default reverse date
	public static final String DATE_TIME_LYNX = "yyyyMMddHHmmss";

	/** The Constant DEFAULT_REVERSE_FORMAT_DATE. */
	// Default reverse date
	public static final String DATE_LYNX = "yyyyMMdd";

	// FORMAT_DATE_DOWNLOAD_DOCUMENT
	public static final String FORMAT_DATE_DOWNLOAD_DOCUMENT = "dd-MM-yyyy";
	
	// Default reverse date
	public static final String DEFAULT_REVERSE_FORMAT_DATE = "yyyy-MM-dd";

	/** The Constant DEFAULT_REVERSE_FORMAT_YEAR_DATE. */
	public static final String DEFAULT_REVERSE_FORMAT_YEAR_DATE = "yyyy";

	/** The Constant CSV_FORMAT_DATE. */
	// YYYYMMDD
	public static final String CSV_FORMAT_DATE = "yyyyMMdd";
	
	/** The Constant DATE_FORMATTER_TIMESTAMP. */
	public static final String DATE_FORMATTER_TIMESTAMP = "yyyy-MM-dd'T'HH:mm:ss.000'Z'";

	/** The Constant SURVEY_TYPE_OPINATOR. */
	// Tipo de encuesta
	public static final String SURVEY_TYPE_OPINATOR = "OPINATOR";

	/** The Constant SURVEY_TYPE_NPS. */
	public static final String SURVEY_TYPE_NPS = "NPS";

	/** The Constant SERVICE_CODE_RC. */
	// Alta servicio BE códigos de servicios
	public static final String SERVICE_CODE_RC = "RC";

	/** The Constant SERVICE_CODE_Y9. */
	public static final String SERVICE_CODE_Y9 = "Y9";

	/** The Constant SERVICE_CODE_R3. */
	public static final String SERVICE_CODE_R3 = "R3";
	
	/** The Constant SERVICE_CODE_EX. */
	public static final String SERVICE_CODE_EX = "EX";
	
	/** The Constant SERVICE_CODE_GT. */
	public static final String SERVICE_CODE_GT = "GT";
	
	/** The Constant SERVICE_CODE_TI. */
	public static final String SERVICE_CODE_TI = "TI";
	
	/** The Constant SERVICE_CODE_FD. */
	public static final String SERVICE_CODE_FD = "FD";
	/** The Constant SERVICE_CODE_FD. */
	public static final String SERVICE_CODE_EA_HN = "EA,HN";

	/** The Constant REGISTER_SERVICE_CODE_PA. */
	public static final String REGISTER_SERVICE_CODE_PA = "RC";

	/** The Constant Y9_RC. */
	public static final String Y9_RC = "44,04";

	/** The Constant CONF_TYPE_PROPOSAL_DESC. */
	// Constants Formalizacion Confirming
	public static final String CONF_TYPE_PROPOSAL_DESC = "Normal";

	/** The Constant CONF_ORIGIN_CODE. */
	public static final String CONF_ORIGIN_CODE = "PE";

	/** The Constant CONF_ORIGIN_DESC. */
	public static final String CONF_ORIGIN_DESC = "Pequeñas Empresas";

	/** The Constant CONF_LOCATION_CODE. */
	public static final String CONF_LOCATION_CODE = "01";

	/** The Constant CONF_LOCATION_DESC. */
	public static final String CONF_LOCATION_DESC = "SUCURSAL";

	/** The Constant CONF_APP_STATE_CODE. */
	// 04 Temporal hasta que funcione 02
	public static final String CONF_APP_STATE_CODE = "02";

	/** The Constant CONF_APP_STATE_DESC. */
	public static final String CONF_APP_STATE_DESC = "APROBADA";

	/** The Constant CONF_LOAN_PURPOSE_CODE. */
	public static final String CONF_LOAN_PURPOSE_CODE = "99";

	/** The Constant CONF_LOAN_PURPOSE_DESC. */
	public static final String CONF_LOAN_PURPOSE_DESC = "Varios";

	/** The Constant CONF_CHANNEL_DESC. */
	public static final String CONF_CHANNEL_DESC = "Digital";

	/** The Constant CONF_CONCEPT_212_DESC. */
	// Constants Formalizacion Confirming
	public static final String CONF_CONCEPT_212_DESC = "Comisión apertura";

	/*** The constant IVFNCMD (Commision de Modificacion) ***/
	public static final String IVFNCMD = "IVFNCMD";

	/*** The constant IVFNCML (Commision de Modificacion) ***/
	public static final String IVFNCML = "IVFNCML";

	/** The constant IVFNCAR (Comisión de anulación asistido) ***/
	public static final String IVFNCAR = "IVFNCAR";

	/** The constant IVFNCAN (Comisión de anulación no asistido) ***/
	public static final String IVFNCAN = "IVFNCAN";

	/** The constant IVFNINTMOR (Interes de demora) ***/
	public static final String IVFNINTMOR = "IVFNINTMOR";
	
	// NUEVOS CONCEPTOS - 19-01-2024
	
	/** The Constant CONF_CONCEPT_CML_DESC. */
	public static final String CONF_CONCEPT_CML_DESC = "Comisión modificación no asistido";

	/** The Constant CONF_CONCEPT_CML_CODE. */
	public static final String CONF_CONCEPT_CML_CODE = "CML";

	/** The Constant CONF_CONCEPT_CMD_DESC. */
	public static final String CONF_CONCEPT_CMD_DESC = "Comisión modificación asistido";

	/** The Constant CONF_CONCEPT_CMD_CODE. */
	public static final String CONF_CONCEPT_CMD_CODE = "CMD";

	/** The Constant CONF_CONCEPT_CAN_DESC. */
	public static final String CONF_CONCEPT_CAN_DESC = "Comisión anulacion no asistido";

	/** The Constant CONF_CONCEPT_CAN_CODE. */
	public static final String CONF_CONCEPT_CAN_CODE = "CAN";

	/** The Constant CONF_CONCEPT_CAR_DESC. */
	public static final String CONF_CONCEPT_CAR_DESC = "Comisión anulacion asistido";

	/** The Constant CONF_CONCEPT_CAR_CODE. */
	public static final String CONF_CONCEPT_CAR_CODE = "CAR";

	/** The Constant CONF_CONCEPT_212_CODE. */
	public static final String CONF_CONCEPT_212_CODE = "212";

	/** The Constant CONF_CONCEPT_AM2_DESC. */
	public static final String CONF_CONCEPT_AM2_DESC = "Comisión anticipo";

	/** The Constant CONF_CONCEPT_AM2_CODE. */
	public static final String CONF_CONCEPT_AM2_CODE = "AM2";

	/** The Constant CONF_CONCEPT_AM3_DESC. */
	// Constants Formalizacion Confirming
	public static final String CONF_CONCEPT_AM3_DESC = "Tipo";

	/** The Constant CONF_CONCEPT_AM3_CODE. */
	public static final String CONF_CONCEPT_AM3_CODE = "AM3";

	/** The Constant CONF_CONCEPT_PRICE_TYPE_DESC. */
	// Constants Formalizacion Confirming
	public static final String CONF_CONCEPT_PRICE_TYPE_DESC = "Estándar";

	/** The Constant CONF_CONCEPT_PRICE_TYPE_CODE. */
	public static final String CONF_CONCEPT_PRICE_TYPE_CODE = "E";

	/** The Constant CONF_CONCEPT_RATE_INDICATOR_DESC. */
	public static final String CONF_CONCEPT_RATE_INDICATOR_DESC = "Variable";

	/** The Constant CONF_CONCEPT_RATE_INDICATOR_DESC. */
	public static final String CONF_CONCEPT_RATE_INDICATOR_DESC_F = "Fijo";

	/** The Constant CONF_CONCEPT_RATE_INDICATOR_CODE. */
	public static final String CONF_CONCEPT_RATE_INDICATOR_CODE = "V";

	/** The Constant CONF_CONCEPT_RATE_INDICATOR_CODE. */
	public static final String CONF_CONCEPT_RATE_INDICATOR_CODE_F = "F";

	/** The Constant CONF_REL_TYPE_DESC. */
	// Constants Formalizacion Confirming
	public static final String CONF_REL_TYPE_DESC = "Titular";

	/** The Constant CONF_REL_TYPE_CODE. */
	public static final String CONF_REL_TYPE_CODE = "T";

	/** The Constant CONF_PAY_TYPE_CODE. */
	public static final String CONF_PAY_TYPE_CODE = "A";

	/** The Constant CONF_ACCOUNT_TYPE. */
	public static final String CONF_ACCOUNT_TYPE = "BBAN";

	/** The Constant CONF_PERCENT_PARTICIPATION. */
	public static final String CONF_PERCENT_PARTICIPATION = "100";

	/** The Constant CONF_REL_TYPE_GUARANTOR_DESC. */
	public static final String CONF_REL_TYPE_GUARANTOR_DESC = "Avalista";

	/** The Constant CONF_REL_TYPE_GUARANTOR_CODE. */
	public static final String CONF_REL_TYPE_GUARANTOR_CODE = "A";

	/** The Constant CONF_DOCUMENT_NIF. */
	public static final String CONF_DOCUMENT_NIF = "N";

	/** The Constant CONF_DOCUMENT_CIF. */
	public static final String CONF_DOCUMENT_CIF = "S";

	/** The Constant CONF_MNEMO_NATIONAL. */
	// Constants Formalizacion Confirming
	public static final String CONF_MNEMO_NATIONAL = "N";

	/** The Constant CONF_MNEMO_INTERNATIONAL. */
	public static final String CONF_MNEMO_INTERNATIONAL = "I";

	/** The Constant LYNX_ONLINE_FLAG. */
	public static final String LYNX_ONLINE_FLAG = "1";
	
	/** The Constant LYNX_RESPONSE_REQ_FLAG. */
	public static final String LYNX_RESPONSE_REQ_FLAG = "1";
	
	/** The Constant LYNX_MESSAGE_TYPE. */
	public static final String LYNX_MESSAGE_TYPE = "PB";
	
	/** The Constant LYNX_COMPANY. */
	public static final String LYNX_COMPANY = "0049";
	
	/** The Constant LYNX_CHANNEL_EMP. */
	public static final String LYNX_CHANNEL_EMP = "EMP";
	
	/** The Constant LYNX_COUNTRY. */
	public static final String LYNX_COUNTRY = "ES";
	
	/** The Constant LYNX_AUTN_METHOD. */
	public static final String LYNX_AUTN_METHOD = "01";
	
	/** The Constant LYNX_CREDIT_FLAG. */
	public static final String LYNX_CREDIT_FLAG = "2";
	
	/** The Constant LYNX_CREDIT_FLAG. */
	public static final String LYNX_LOAN_FLAG = "1";

	/** The Constant LYNX_IP_ADDRESS. */
	public static final String LYNX_IP_ADDRESS = "${ipAddress}";
	
	/** The Constant LYNX_HOST_ID. */
	public static final String LYNX_HOST_ID = "08";
	
	/** The Constant LYNX_RESPONSE_CODE. */
	public static final String LYNX_RESPONSE_CODE = "000";
	
	/** The Constant LYNX_RESPONSE_CODE. */
	public static final String LYNX_CURRENCY = "EUR";
	
	/** The Constant LYNX_PROCESS_FLAG. */
	public static final String LYNX_PROCESS_FLAG = "02";
	
	/** The Constant LYNX_OPERATION_TYPE. */
	public static final String LYNX_OPERATION_TYPE = "100";
	
	/** The Constant LYNX_OPERATION_SUBTYPE. */
	public static final String LYNX_OPERATION_SUBTYPE = "BB";

	/** The Constant BALANCE. */
	// Type PSD2
	public static final String BALANCE = "BALANCE";

	/** The Constant CIRBE. */
	public static final String CIRBE = "CIRBE";
	
	/** The Constant CONFIRMING_LITERAL */
	public static final String CONFIRMING_LITERAL = "Confirming";

	/**
	 * The Constant MODELS_AEAT. Pantalla de modelos Agencia Tributaria
	 * additional-csv
	 */
	public static final String MODELS_AEAT = "MODELS";
	public static final String MODELS_AEAT_EXENTO = "01";
	public static final String MODELS_AEAT_NO_EXENTO = "00";

	/** The Constant AGGREGATOR. */
	public static final String AGGREGATOR = "AGGREGATOR";

	/** The Constant INTERVINIENTE. */
	public static final String INTERVINIENTE = "INTERVINIENTE";

	/** The Constant CONTRATACION. */
	public static final String CONTRATACION = "HIRING";

	/** The Constant FFNN_COD_01. */
	// Constants Detail FFNN
	public static final String FFNN_COD_01 = "01";

	/** The Constant FFNN_COD_03. */
	public static final String FFNN_COD_03 = "03";

	/** The Constant FFNN_DESC_01. */
	public static final String FFNN_DESC_01 = "Morosidad Externa";

	/** The Constant FFNN_DESC_03. */
	public static final String FFNN_DESC_03 = "Demandas Judiciales";

	/** The Constant FFNN_DESC_ORIGIN. */
	public static final String FFNN_DESC_ORIGIN = "ASNEF";
	
	/** The Constant RIESGO_ABIERTO. */
	public static final String RIESGO_ABIERTO = "OC";
	
	/** The Constant RIESGO_CERRADO. */
	public static final String RIESGO_CERRADO = "CC";

	/** The Constant PSD2_AGGREGATION_STATE_OK. */
	// Estado de PSD2
	public static final String PSD2_AGGREGATION_STATE_OK = "01";

	/** The Constant PSD2_AGGREGATION_STATE_KO. */
	public static final String PSD2_AGGREGATION_STATE_KO = "02";
	
	/** The Constant REPLACE_PRODUCT. */
	public static final String REPLACE_PRODUCT = "{producto}";
	
	/** The Constant ADD_URL_KPIS. */
	public static final String ADD_URL_KPIS = "?agileVariables=A0531T1&inputVariables=A0531T1,A0997,A0981,PROPUIMPORTE"
			+ ",T1FINANCIEROCPLIM,T1TOTALPAPCOMERLIM,A0984,A0997,A0960,A0970,A0991,A1978,A1102,A81221,A8127,A0977";

	/** The Constant X_SANTANDER_CHANNEL */
	public static final String X_SANTANDER_CHANNEL = "X-Santander-Channel";
	
	/** The Constant CHANNEL_002 */
	public static final String CHANNEL_002 = "002"; //PARTICULARES

	/** The Constant CODE_EXCEPTION. */
	// Error
	public static final String CODE_EXCEPTION = "Error HttpStatusCodeException {}";
	
	/** The Constant EXECUTE_QUERY. */
	public static final String EXECUTE_QUERY = "Execute Query: {}";
	
	/** The Constant EXECUTE_QUERY_SCHEMA. */
	public static final String EXECUTE_QUERY_SCHEMA = "Execute Query schema: {}";

	/** The Constant GUARANTOR_NO_DATA_OBLIGATORY. */
	// Sin datos obligatorios en avalistas
	public static final String GUARANTOR_NO_DATA_OBLIGATORY = "A10000ERROR EN DATOS OBLIG";
	
	// Error genérico
	public static final String ERROR_GENERIC = "Error -> {}";
	
	// PMP MVP2 TRAMOS PRECIOS
	// NOVENTA
	public static final String NOVENTA = "90";
	// CIENTOVEINTE
	public static final String CIENTOVEINTE = "120";
	// CIENTOCINCUENTA
	public static final String CIENTOCINCUENTA = "150";
	// CIENTOOCHENTA
	public static final String CIENTOOCHENTA = "180";
	// DOSCIENTOSSETENTA
	public static final String DOSCIENTOSSETENTA = "270";
	// TRESCIENTOSSESENTAYCINCO
	public static final String TRESCIENTOSSESENTAYCINCO = "365";
	// QUINIENTOSCUARENTA
	public static final String QUINIENTOSCUARENTA = "540";
	// SETECIENTOSVEINTE
	public static final String SETECIENTOSVEINTE = "720";
	// TRESCIENTOSSESENTA
	public static final String TRESCIENTOSSESENTA = "360";
	// CERO
	public static final String CERO = "0";
	// NUEVENUEVENUEVE
	public static final String NUEVENUEVENUEVE = "999";
	
	// OPTION_FO
	public static final String OPTION_FO = "FO";
	
	// Caracteres char
 	public static final char CHAR_COMA = ',';
 	public static final char CHAR_SEMICOLON = ';';

	 public static final Boolean IVFN_TRUE = Boolean.TRUE;
	public static final Boolean IVFN_FALSE = Boolean.FALSE;

	/** PSD2_TYPES. */
	public static final Map<String, String> PSD2_TYPES = ImmutableMap.<String, String>builder()
			.put(BALANCE, StateFront.STATE_DATA.getCode()).put(CIRBE, StateFront.STATE_INFO_SCREEN.getCode())
			.put(MODELS_AEAT, StateFront.STATE_MODEL_AEAT.getCode())
			.put(INTERVINIENTE, StateFront.STATE_GUARANTORS.getCode())
			.put(CONTRATACION, StateFront.STATE_HIRING.getCode()).put(AGGREGATOR, StateFront.STATE_AGGREGATOR.getCode())
			.build();

	/** TEMPLATE_TYPES. */
	public static final Map<String, String> TEMPLATE_TYPES = ImmutableMap.<String, String>builder()
			.put(PRINTED_TEMPLATE_CODE, "ImpresoFinanciacionFactura.ftl")
			.put(DIGITALIZED_TEMPLATE_CODE, "ImpresoFinanciacionFacturaDig.ftl")
			.put(PRINTED_COMEX_TEMPLATE_CODE, "ImpresoComex.ftl")
	        .put(PRINTED_CONFP_TEMPLATE_CODE,"ImpresoPagoAgil.ftl").build();

	/** TEMPLATE_TYPES_GNIDOC. */
	public static final Map<String, String> TEMPLATE_TYPES_GNIDOC = ImmutableMap.<String, String>builder()
			.put(PRINTED_TEMPLATE_CODE, "IMP_PRESTAMO_PO").put(DIGITALIZED_TEMPLATE_CODE, "PRESTAMO_PO")
			.put("QD", "PRESTAMO_PO").build();

	/** STATES_APP_ACTIVE. */
	public static final List<String> STATES_APP_ACTIVE = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_NOT_INIT.getCode(), StateFront.STATE_SIMULATION.getCode(),
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_BILLIN_LIST.getCode(),
			StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_HIRING.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(), StateFront.STATE_REPRESENTATIVES.getCode(),
			StateFront.STATE_DATA.getCode(), StateFront.STATE_INFO_SCREEN.getCode(),
			StateFront.STATE_AGGREGATOR.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode(),
			StateFront.STATE_KPIS.getCode(), StateFront.STATE_END_SUCCESS.getCode(),
			StateFront.STATE_END_EMAIL.getCode(), StateFront.STATE_END_PROXIES.getCode(),
			StateFront.STATE_END_SIGNATURE.getCode(), StateFront.STATE_END_ERROR.getCode(),
			StateFront.STATE_END_BOX.getCode(), StateFront.STATE_END_OFFICE.getCode(),
			StateFront.STATE_WACOM_SIGNATURE.getCode()));

	/** ESTADO DE SOLICITUDES ACTIVAS CON LA PANTALLA REQUESTS. */
	public static final List<String> STATES_APP_ACTIVE_REQUESTS = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_NOT_INIT.getCode(), StateFront.STATE_SIMULATION.getCode(),
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_BILLIN_LIST.getCode(),
			StateFront.STATE_HIRING.getCode(), StateFront.STATE_MODEL_AEAT.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(), StateFront.STATE_REPRESENTATIVES.getCode(),
			StateFront.STATE_DATA.getCode(), StateFront.STATE_INFO_SCREEN.getCode(),
			StateFront.STATE_AGGREGATOR.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode(),
			StateFront.STATE_KPIS.getCode(), StateFront.STATE_END_SUCCESS.getCode(),
			StateFront.STATE_END_EMAIL.getCode(), StateFront.STATE_END_PROXIES.getCode(),
			StateFront.STATE_END_ERROR.getCode(), StateFront.STATE_REQUESTS.getCode(),
			StateFront.STATE_END_SIGNATURE.getCode(), StateFront.STATE_END_BOX.getCode(),
			StateFront.STATE_END_OFFICE.getCode(), StateFront.STATE_END_CANCEL_PROPOSAL.getCode(),
			StateFront.STATE_WACOM_SIGNATURE.getCode()));

	/** STATES_APP_NOT_FORMALIZED. */
	public static final List<String> STATES_APP_NOT_FORMALIZED = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_NOT_INIT.getCode(), StateFront.STATE_SIMULATION.getCode(),
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_BILLIN_LIST.getCode(),
			StateFront.STATE_DATA.getCode(), StateFront.STATE_INFO_SCREEN.getCode(),
			StateFront.STATE_AGGREGATOR.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode(),
			StateFront.STATE_KPIS.getCode(), StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_HIRING.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(), StateFront.STATE_REPRESENTATIVES.getCode(),
			StateFront.STATE_END_PROXIES.getCode(), StateFront.STATE_END_EMAIL.getCode(),
			StateFront.STATE_END_ERROR.getCode(),
			StateFront.STATE_WACOM_SIGNATURE.getCode()));

	/** STATES_APP_NOT_FORMALIZED INIT. */
	public static final List<String> STATES_APP_NOT_FORMALIZED_NOT_INIT = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_SIMULATION.getCode(),
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_BILLIN_LIST.getCode(),
			StateFront.STATE_DATA.getCode(), StateFront.STATE_INFO_SCREEN.getCode(),
			StateFront.STATE_AGGREGATOR.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode(),
			StateFront.STATE_KPIS.getCode(), StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_HIRING.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(),
			StateFront.STATE_END_PROXIES.getCode(), StateFront.STATE_END_EMAIL.getCode(),
			StateFront.STATE_END_ERROR.getCode(),
			StateFront.STATE_WACOM_SIGNATURE.getCode()));

	/** STATES_APP_NOT_FORMALIZED OFFICE. */
	public static final List<String> STATES_APP_NOT_FORMALIZED_OFFICE = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_NOT_INIT.getCode(), StateFront.STATE_SIMULATION.getCode(),
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_BILLIN_LIST.getCode(),
			StateFront.STATE_DATA.getCode(), StateFront.STATE_INFO_SCREEN.getCode(),
			StateFront.STATE_AGGREGATOR.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode(),
			StateFront.STATE_KPIS.getCode(), StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_HIRING.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(), StateFront.STATE_REPRESENTATIVES.getCode(),
			StateFront.STATE_END_PROXIES.getCode(), StateFront.STATE_END_EMAIL.getCode(),
			StateFront.STATE_END_SIGNATURE.getCode(), StateFront.STATE_END_ERROR.getCode(),
			StateFront.STATE_END_OFFICE.getCode(), StateFront.STATE_WACOM_SIGNATURE.getCode()));

	/** MODE_V1V2. */
	protected static final String[] MODE_V1V2 = { MODE_VERSION_ONE, MODE_VERSION_SECOND };

	/** MODE_V3. */
	protected static final String[] MODE_V3 = { MODE_VERSION_THREE };

	/** STATES_APP_END. */
	public static final List<String> STATES_APP_END = Collections
			.unmodifiableList(Arrays.asList(StateFront.STATE_END.getCode(), StateFront.STATE_END_SUCCESS.getCode(),
					StateFront.STATE_END_EMAIL.getCode(), StateFront.STATE_END_PROXIES.getCode(),
					StateFront.STATE_END_ERROR.getCode(), StateFront.STATE_END_SIGNATURE.getCode(),
					StateFront.STATE_END_BOX.getCode(), StateFront.STATE_END_SERVICES_ACTIVATION.getCode()));

	/** STATES_SHOW_NEW. */
	public static final List<String> STATES_SHOW_NEW = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_HIRING.getCode(), StateFront.STATE_DATA.getCode(),
			StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_AGGREGATOR.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(), StateFront.STATE_SIGNING_OTP.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode(), StateFront.STATE_REPRESENTATIVES.getCode()));

	/** SECURITY CONTROL. */
	public static final List<String> SECURITY_STATES_CONTROL_SIMULATION = Collections
			.unmodifiableList(Arrays.asList(StateFront.STATE_SIMULATION.getCode(),
					StateFront.STATE_SIMULATION.getCode(), StateFront.STATE_REQUESTS.getCode()));

	/** The Constant SECURITY_STATES_CONTROL_AGREGGATOR. */
	public static final List<String> SECURITY_STATES_CONTROL_AGREGGATOR = Collections
			.unmodifiableList(Arrays.asList(StateFront.STATE_GUARANTORS.getCode(), StateFront.STATE_DATA.getCode(),
					StateFront.STATE_MODEL_AEAT.getCode(), StateFront.STATE_AGGREGATOR.getCode()));

	/** The Constant SECURITY_STATES_CONTROL_END. */
	public static final List<String> SECURITY_STATES_CONTROL_END = Collections.unmodifiableList(
			Arrays.asList(StateFront.STATE_END_SUCCESS.getCode(), StateFront.STATE_END_EMAIL.getCode(),
					StateFront.STATE_END_ERROR.getCode(), StateFront.STATE_END_PROXIES.getCode(),
					StateFront.STATE_INFO_SCREEN.getCode(), StateFront.STATE_END_SIGNATURE.getCode(),
					StateFront.STATE_END_DENIED.getCode(), StateFront.STATE_END.getCode(),
					StateFront.STATE_END_BOX.getCode(), StateFront.STATE_AGGREGATOR_PENDING_NOTIFY.getCode()));

	/** The Constant SECURITY_STATES_CONTROL_GENERAL. */
	public static final List<String> SECURITY_STATES_CONTROL_GENERAL = Collections.unmodifiableList(Arrays.asList(
			StateFront.STATE_HIRING.getCode(), StateFront.STATE_REPRESENTATIVES.getCode(),
			StateFront.STATE_CONFIRMING_SIGNER.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO.getCode(),
			StateFront.STATE_SIGNING_OTP.getCode(), StateFront.STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR.getCode(),
			StateFront.STATE_SIGNING_OTP_GUARANTOR.getCode()));

	/** The Constant PROPOSAL_SOLICITUDE_REQUEST. */
	public static final List<String> PROPOSAL_SOLICITUDE_REQUEST = Collections
			.unmodifiableList(Arrays.asList(StateProposal.PROPOSAL_APPROVED.getCode(),
					StateProposal.PROPOSAL_REQUESTED.getCode(), StateProposal.PROPOSAL_PREFORMALIZED.getCode()));
	
	/** The Constant PROPOSAL_SOLICITUDE_HEADER. */
	public static final List<String> PROPOSAL_SOLICITUDE_HEADER = Collections.unmodifiableList(
			Arrays.asList(StateProposal.PROPOSAL_APPROVED.getCode(), StateProposal.PROPOSAL_WITHOUT_PROPOSAL.getCode(),
					StateProposal.PROPOSAL_PARTIALLY_FORMALIZED.getCode(), StateProposal.PROPOSAL_FORMALIZED.getCode(),
					StateProposal.PROPOSAL_DENIED.getCode(), StateProposal.PROPOSAL_DOWN.getCode(),
					StateProposal.PROPOSAL_EXPIRED_BY_EXPIRATION.getCode(),
					StateProposal.PROPOSAL_NON_FORMALIZED.getCode(), StateProposal.PROPOSAL_UNRESOLVED.getCode(),
					StateProposal.PROPOSAL_REQUESTED.getCode(), StateProposal.PROPOSAL_PREFORMALIZED.getCode()));
			
	/** PREVALIDATION_ERRORS. */
	public static final List<String> PREVALIDATION_ERRORS = Collections
			.unmodifiableList(Arrays.asList(ErrorServiceConstants.IVFNERRORFINANCERANGE,
					ErrorServiceConstants.IVFNNOTLIMITP2ERROR, ErrorServiceConstants.IVFNERRORFIOC,
					ErrorServiceConstants.IVFNERRORLISTAS, ErrorServiceConstants.IVFNERRORBASTANTEO,
					ErrorServiceConstants.IVFNERRORFFNNINTERNOS, ErrorServiceConstants.IVFNERRORFFNNEXTERNOS));

	/** LIMITS ERRORS**/
	public static final List<String> LIMITS_ERRORS = Collections
			.unmodifiableList(Arrays.asList(ErrorServiceConstants.IVFNERRORNOLIMIT,
					ErrorServiceConstants.IVFNNOTLIMITP2ERROR, ErrorServiceConstants.IVFNERRORFINANCERANGE,
					ErrorServiceConstants.IVFNNOTLIMITP3ERROR));

	/** IND_PROC_EMP_LIST. */
	public static final List<String> IND_PROC_EMP_LIST = Collections
			.unmodifiableList(Arrays.asList("OM","AD"));

	/** IND_PROC_OFI_LIST. */
	public static final List<String> IND_PROC_OFI_LIST = Collections
			.unmodifiableList(Arrays.asList("OM","AD","AO"));

	/** The Constant LOCALE_ES. */
    public static final Locale LOCALE_ES = new Locale("es");
    
	public static final DecimalFormat FORMATTER = (DecimalFormat) NumberFormat.getNumberInstance(LOCALE_ES);
	
	/** STATES_APP_END_LIST1. */
	public static final ImmutableList<String> STATES_APP_END_LIST1 = new ImmutableList.Builder<String>()
			.addAll(STATES_APP_END).build();

	/** APP_LANG. */
	public static final ImmutableList<String> APP_LANG = new ImmutableList.Builder<String>().add("ca").add("de")
			.add("en").add("es").add("eu").add("ga").build();
	
	/** APP_LANG. */
	public static final ImmutableList<String> BE_CODES_COMEX = new ImmutableList.Builder<String>().add("EX").add("TI")
			.add("GT").build();
	
	public static final ImmutableList<String> BE_CODES_COMEX_WITHOUT_GT = new ImmutableList.Builder<String>().add("EX").add("TI").build();
	
	/** PROGRESS_SIMULATION_MAP. */
	public static final Map<Integer, String> PROGRESS_SIMULATION_MAP = ImmutableMap.<Integer, String>builder()
			.put(1, "0,10").put(2, "10,30").put(3, "30,50").put(4, "50,80").put(5, "80,98").build();

	/** THE ASSET APPLICATION DOCUMENT CODE. */
	public static final String ASSET_APP_TEMPLATE = "1Q";
	
	/** THE ASSET APPLICATION DOCUMENT CODE. */
	public static final String ASSET_APP_TEMPLATE_BIDI = "CC";

	/** THE ASSET APPLICATION DOCUMENT VERSION. */
	public static final String ASSET_APP_VERSION = "0012015";
	
	/** THE ASSET APPLICATION DOCUMENT TYPE. */
	public static final String ASSET_APP_DOCTYPE = "SOL_ACT_PRP";
	
	/** THE CLIENT DOCTYPE. */
	public static final String CLIENT_DOCTYPE = "C";
	
	/** THE LITERAL CLIENT DOCTYPE. */
	public static final String LIT_CLIENT_DOCTYPE = "Cliente";
	
	/** THE CLIENT DOCTYPE. */
	public static final String REQUEST_DOCTYPE = "S";
	
	/** THE LITERAL CLIENT DOCTYPE. */
	public static final String LIT_REQUES_DOCTYPE = "Solicitud";
	
	/** THE CLIENT DOCTYPE. */
	public static final String OPERATION_DOCTYPE = "O";
	
	/** THE LITERAL CLIENT DOCTYPE. */
	public static final String LIT_OPERATION_DOCTYPE = "Operación";

	/** THE ASSET APPLICATION DOCUMENT DESCRIPTION. */
	public static final String ASSET_APP_DESC = "Solicitud de Activo";
	
	public static final String IMPRES_KO = "KO";
	
	public static final String IMPRES_ERROR = "Error {}";

    public static final String CLOSED_TERM = "CLOSED";

    public static final String OPEN_TERM = "OPEN";

    public static final String FIXED = "fixed";

    public static final String SLIDER = "slider";

    /** PENDING DOCUMENT STATUS **/
	public static final String PENDING_DOC = "01";

    /** ACCEPTED DOCUMENT STATUS **/
	public static final String ACCEPTED_DOC = "02";

    /** REJECTED DOCUMENT STATUS **/
	public static final String REJECTED_DOC = "03";
	
    /** REJECTED DOCUMENT STATUS **/
	public static final String SIGN_01 = "01";
    /** REJECTED DOCUMENT STATUS **/
	public static final String SIGN_02 = "02";
    /** REJECTED DOCUMENT STATUS **/
	public static final String SIGN_03 = "03";
	
    /** PROCCESS FLAG VALUES **/
	public static final String PROC_FLAG_AD = "AD";
    public static final String PROC_FLAG_AO = "AO";
    public static final String PROC_FLAG_OM = "OM";
    

    /** SMART PRICING VALUES */
    public static final String SMART_PRICING_LIT = "smartpricing";
    public static final String CRISOL_LIT = "crisol";

	/** The Constant COD_ADMWEB. */
	public static final String COD_ADMWEB = "ADMWEB";


	// LA FECHA DE OTORGAMIENTO NO PUEDE SER ANTERIOR A LA FECHA DE PRE-FORMALIZACION
	public static final String PN0554 = "PN0554";

	/** centros usuarios PRO */
	public static final List<String> USER_ALL_CENTERS = Collections
			.unmodifiableList(Arrays.asList("3294","3295","3296"));
	
	/** The Constant COD_ADMW. */
	public static final String COD_ADMW = "ADMW";

	/** Holder Literal */
	public static final String HOLDER_LIT = "HOLDER";

	/** Smart Pricing Risk Operation Code */
	public static final String SP_RISK_OP = "02";
	
	/** ALREADY_ID_SMART_PRICING Literal */
	public static final String ALREADY_ID_SMART_PRICING = "There is already a proposal with that id";

	/** Texto  para identificar el error de centro invalido */
	public static final String TXTERRORCENTROINVALIDO="A10000CENTRO NO VALIDO";

	/**
	 * Constructor privado.
	 */
	private Constants() {
		throw new IllegalStateException("Utility class");
	}
}