package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class BalancesAdn.
 */

/**
 * Gets the available balance.
 *
 * @return the available balance
 */
@Getter

/**
 * Sets the available balance.
 *
 * @param availableBalance the new available balance
 */
@Setter
public class BalancesAdn {

	/** The limit. */
	private AmountAdn limit;

	/** The drawn balance. */
	private AmountAdn drawnBalance;

	/** The available balance. */
	private AmountAdn availableBalance;

}
