package com.santander.darwin.invoice.model.crisol;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Item devuelvo por precios crisol
 *
 * @author josdon
 *
 */
@Getter
@Setter
public class RecommendedPriceItem {

	// Codigo de concepto
	private String settlementConceptCode;

	// Descripcion
	private String conceptDescription;

	//Valor
	private BigDecimal recommendedValue;

	//Valor
	private BigDecimal stretchFrom;
	//Valor
	private BigDecimal stretchTo;

	//Valor
	private String referenceRate;

}
