package com.santander.darwin.invoice.exception.model;

/**
 * Error levels for objects {@link GlobalErrorBean}
 *
 * @author wercilla
 *
 */
public enum ErrorAppType {

	/**
	 * Type FORM
	 */
	FORM("FORM"),
	/**
	 * Type PAGE
	 */
	PAGE("PAGE"),
	
	/**
	 * Type PAGE
	 */
	PAGEURL("PAGE-URL"),
	
	PAGEURLB("PAGE_URL"),
	
	/**
	 * Type MODAL
	 */
	MODAL("MODAL"),

	/**
	 * Type MODAL
	 */
	MODALCUSTOM("MODAL-CUSTOM"),

	/**
	 * Type FALDON
	 */
	FALDON("FALDON"),
	
	/**
	 * Type ALERT
	 */
	ALERT("ALERT");

	private String code;

	/**
	 * Instantiate a new state front type.
	 *
	 * @param code the code
	 */
	ErrorAppType(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Get state from code.
	 *
	 * @param code the code
	 * @return StateFrontType
	 */
	public static ErrorAppType getStateFromCode(String code) {
		for (ErrorAppType stateFrontType : ErrorAppType.values()) {
			if (stateFrontType.getCode().equals(code)) {
				return stateFrontType;
			}
		}
		return null;
	}

}
