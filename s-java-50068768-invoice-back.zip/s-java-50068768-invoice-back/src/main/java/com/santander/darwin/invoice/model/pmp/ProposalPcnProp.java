package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * ProposalPcnProp model
 */
@Getter
@Setter
public class ProposalPcnProp {
	
	/** The idempr. O7504_IDEMPR. */
    private String idempr;
	
}
