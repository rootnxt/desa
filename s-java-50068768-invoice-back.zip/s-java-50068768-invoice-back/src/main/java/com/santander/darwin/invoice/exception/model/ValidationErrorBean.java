package com.santander.darwin.invoice.exception.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ValidationErrorBean.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ValidationErrorBean extends AbstractGlobalErrorBean {

	// Serial version
	private static final long serialVersionUID = -4958726911804411895L;

	// Para swagger
	@Schema(example = "PAGE", description = "Type of error")
	// Type
	private String type;
	// Para swagger
	@Schema(example = "Internal error", description = "Message of error")
	// Message
	private String message;
	// Para swagger
	@Schema(example = "WEB", description = "Type of presentation")
	// Presentation
	private String presentation;
	
	// style
	private String style;
	
	@Schema(example = "/documentation", description = "Type of url")
	// Url
	private String url;
	
	// app
	private String nameApp;
	
	// channel
	private String channel;

}
