package es.santander.darwin.financiaciondigital.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import es.santander.darwin.financiaciondigital.constant.PersonType;
import es.santander.darwin.financiaciondigital.constant.Urls;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolDto;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolMotorDTO;
import es.santander.darwin.financiaciondigital.exceptions.handler.DigitalConsumptionServiceExceptionHandler;
import es.santander.darwin.financiaciondigital.service.impl.CirbeSasnaServiceImpl;
import es.santander.darwin.financiaciondigital.service.impl.CirbeServiceImpl;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;
import es.santander.darwin.financiaciondigital.web.CirbeController;

/**
 * The Class CirbeControllerTest.
 */
public class CirbeControllerTest {

    /** The mock mvc. */
    private MockMvc mockMvc;

    /** The cirbe service impl. */
    @Mock
    private CirbeServiceImpl cirbeServiceImpl;

    /** The cirbe sasna service impl. */
    @Mock
    private CirbeSasnaServiceImpl cirbeSasnaServiceImpl;

    /** The cirbe controller. */
    @InjectMocks
    private CirbeController cirbeController;

    /**
     * Inits the.
     */
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders
                .standaloneSetup(cirbeController)
                .setControllerAdvice(new DigitalConsumptionServiceExceptionHandler())
                .build();
    }

    /**
     * Sencol cirbe test OK 1.
     *
     * @throws Exception the exception
     */
    @Test
    public void callCirbeTestOK() throws Exception {
        ProposalRequestsSencolDto body = TestDataUtil.fillDummyObject(new ProposalRequestsSencolDto());
        ObjectMapper mapper = new ObjectMapper();

        cirbeServiceImpl.callSencol(body);
        String request = mapper.writeValueAsString(body);

        this.mockMvc.perform(post(Urls.URL_SENCOL)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(request)
                .header("Authorization", "token"))
                .andExpect(status().is(200));
    }

    /**
     * Call cirbe test NOK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callCirbeTestNOK() throws Exception {
        ProposalRequestsSencolDto body = TestDataUtil.fillDummyObject(new ProposalRequestsSencolDto());
        cirbeServiceImpl.callSencol(body);

        this.mockMvc.perform(post(Urls.URL_SENCOL)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "token"))
                .andExpect(status().is(400));
    }

    /**
     * Call sasna test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callSasnaTestOK() throws Exception {

        cirbeSasnaServiceImpl.callSasna("0049", PersonType.JURIDICAL.getValue(), new BigDecimal("200"), "CIRBE");

        this.mockMvc.perform(post(Urls.URL_SASNA, "J", 200)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .param("companyId", "0049")
                .param("sourceType", "CIRBE")
                .header("Authorization", "token"))
                .andExpect(status().is(200));
    }

    /**
     * Call sasna test NOK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callSasnaTestNOK() throws Exception {

        cirbeSasnaServiceImpl.callSasna("0049", PersonType.JURIDICAL.getValue(), new BigDecimal("200"), "CIRBE");

        this.mockMvc.perform(post(Urls.URL_SASNA, "J", 200)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .param("companyId", "0049")
                .header("Authorization", "token"))
                .andExpect(status().is(400));
    }

    /**
     * Call petitions treatment process test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callPetitionsTreatmentProcessTestOK() throws Exception{
        
        ProposalRequestsSencolMotorDTO proposalRequest = TestDataUtil.fillDummyObject(new ProposalRequestsSencolMotorDTO());
        proposalRequest.setYear(2019);
        proposalRequest.setProposalNumber(1234);
        
        ObjectMapper mapper = new ObjectMapper();

        String request = mapper.writeValueAsString(proposalRequest);

        cirbeServiceImpl.callTreatmentProcess(proposalRequest);
        
        this.mockMvc.perform(post(Urls.URL_SENCOL_MOTOR)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(request)
                .header("Authorization", "token"))
                .andExpect(status().is(200));
    }
    
    /**
     * Call petitions treatment process test NOK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callPetitionsTreatmentProcessTestNOK() throws Exception{
        
        ProposalRequestsSencolMotorDTO proposalRequest = TestDataUtil.fillDummyObject(new ProposalRequestsSencolMotorDTO());
        
        cirbeServiceImpl.callTreatmentProcess(proposalRequest);
        
        this.mockMvc.perform(post(Urls.URL_SENCOL_MOTOR)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "token"))
                .andExpect(status().is(400));
    }
}
