package com.santander.darwin.invoice.model.complejas;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the fecha PMP.
 *
 * @return the fecha PMP
 */
@Getter

/**
 * Sets the fecha PMP.
 *
 * @param fechaPMP the new fecha PMP
 */
@Setter
public class DocumentPiPmp {
    
    /** The numero PMP. */
    private String numeroPMP;
    
    /** The fecha PMP. */
    private String fechaPMP;
}
