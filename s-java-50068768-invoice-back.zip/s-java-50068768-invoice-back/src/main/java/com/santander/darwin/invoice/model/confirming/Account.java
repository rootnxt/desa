package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Account.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Account{
	// Datos de la cuenta
    private String accountId;
    private String accountIdType;
    private BaseCurrency baseCurrency;
}