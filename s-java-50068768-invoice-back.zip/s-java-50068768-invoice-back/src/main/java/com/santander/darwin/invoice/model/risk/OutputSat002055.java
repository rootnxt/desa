package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;


/**
 * OutputSat002055.java
 *
 * @author igndom
 *
 */
public class OutputSat002055 {

	private List<String> idempr;
	private List<String> idcent;
	private List<String> anoprop;
	private List<BigDecimal> numprop;
	private List<String> indgesto;

	public List<String> getIdempr() {
		return idempr;
	}

	public void setIdempr(List<String> idempr) {
		this.idempr = idempr;
	}

	public List<String> getIdcent() {
		return idcent;
	}

	public void setIdcent(List<String> idcent) {
		this.idcent = idcent;
	}

	public List<String> getAnoprop() {
		return anoprop;
	}

	public void setAnoprop(List<String> anoprop) {
		this.anoprop = anoprop;
	}

	public List<BigDecimal> getNumprop() {
		return numprop;
	}

	public void setNumprop(List<BigDecimal> numprop) {
		this.numprop = numprop;
	}

	public List<String> getIndgesto() {
		return indgesto;
	}

	public void setIndgesto(List<String> indgesto) {
		this.indgesto = indgesto;
	}

}
