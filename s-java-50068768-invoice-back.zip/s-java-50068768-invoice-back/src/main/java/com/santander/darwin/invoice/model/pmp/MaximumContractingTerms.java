package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * The MaximumContractingTerms Class.
 */
@Getter
@Setter
public class MaximumContractingTerms{
   
    /** The contract. */
    private String contract;
    
    /** The draft. */
    private String draft;
    
    /** The guarantee. */
    private String guarantee;

}
