package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * The
 * Output
 * DatosCentro
 * Dto
 * model
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OutputDatosCentro implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * outputCentroList
     * */
    private List<OutputCentro> outputCentroList;

}
