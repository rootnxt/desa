package com.santander.darwin.invoice.model.model200;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Manager.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Manager200 {

	// Id for object
	@Schema(example = "B73939274", description = "Number identifier of manager")
	private String nif;
	// Name of the object
	@Schema(example = "LUCAS Y MARTINEZ HIJOS SL", description = "Name of manager")
	private String managerName;

}
