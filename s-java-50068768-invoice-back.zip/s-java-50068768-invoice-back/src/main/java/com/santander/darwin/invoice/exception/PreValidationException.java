package com.santander.darwin.invoice.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.http.HttpStatus;

import java.util.UUID;

/**
 * PreValidationException.java
 *
 * @author igndom
 *
 */
public class PreValidationException extends GlobalException {

	private static final long serialVersionUID = 6722182163890181110L;

	private final String operationId;
	private final String appId;
	private final String shortMessage;
	@JsonProperty("DetailedMessage")
	private final String detailedMessage;

	/**
	 * Constructor
	 *
	 * @param lang String
	 */
	public PreValidationException(String lang) {
		super(UUID.randomUUID(), System.currentTimeMillis(), lang);
		this.operationId = null;
		this.appId = null;
		this.shortMessage = null;
		this.detailedMessage = null;
	}

	/**
	 * Constructor
	 *
	 * @param code String
	 * @param lang String
	 */
	public PreValidationException(String code, String lang) {
		super(UUID.randomUUID(), System.currentTimeMillis(), String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
				code, lang);
		this.operationId = null;
		this.appId = null;
		this.shortMessage = null;
		this.detailedMessage = null;
	}

	/**
	 * Constructor
	 *
	 * @param status String
	 * @param code   String
	 * @param lang   String
	 */
	public PreValidationException(String status, String code, String lang) {
		super(UUID.randomUUID(), System.currentTimeMillis(), status, code, lang);
		this.operationId = null;
		this.appId = null;
		this.shortMessage = null;
		this.detailedMessage = null;
	}

	/**
	 * Constructor
	 *
	 * @param status          String
	 * @param code            String
	 * @param lang            String
	 * @param detailedMessage String
	 */
	public PreValidationException(String status, String code, String lang, String detailedMessage) {
		super(UUID.randomUUID(), System.currentTimeMillis(), status, code, lang);
		this.operationId = null;
		this.appId = null;
		this.shortMessage = null;
		this.detailedMessage = detailedMessage;
	}

	/**
	 * Constructor
	 *
	 * @param operationId     String
	 * @param status          String
	 * @param code            String
	 * @param lang            String
	 * @param detailedMessage String
	 */
	public PreValidationException(String operationId, String status, String code, String lang, String detailedMessage) {
		super(UUID.randomUUID(), System.currentTimeMillis(), status, code, lang);
		this.operationId = operationId;
		this.appId = null;
		this.shortMessage = null;
		this.detailedMessage = detailedMessage;
	}

	/**
	 * @return the operationId
	 */
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @return the shortMessage
	 */
	public String getShortMessage() {
		return shortMessage;
	}

	/**
	 * @return the detailedMessage
	 */
	public String getDetailedMessage() {
		return detailedMessage;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

}
