/**
 * 
 */
package com.santander.darwin.invoice.model;

import java.math.BigDecimal;

/**
 * CreditLimitOutput
 * 
 * @author josdon
 *
 */
public class CreditLimitOutput {

	private BigDecimal min;
	private BigDecimal max;
	private BigDecimal finance;
	private BigDecimal limit;
	private boolean oriented;
	private boolean preconceded;
	private String currency;
	private String range;

	/**
	 * @return the min
	 */
	public BigDecimal getMin() {
		return min;
	}

	/**
	 * @param min the min to set
	 */
	public void setMin(BigDecimal min) {
		this.min = min;
	}

	/**
	 * @return the max
	 */
	public BigDecimal getMax() {
		return max;
	}

	/**
	 * @param max the max to set
	 */
	public void setMax(BigDecimal max) {
		this.max = max;
	}

	/**
	 * @return the finance
	 */
	public BigDecimal getFinance() {
		return finance;
	}

	/**
	 * @param finance the finance to set
	 */
	public void setFinance(BigDecimal finance) {
		this.finance = finance;
	}

	/**
	 * @return the limit
	 */
	public BigDecimal getLimit() {
		return limit;
	}

	/**
	 * @param limit the limit to set
	 */
	public void setLimit(BigDecimal limit) {
		this.limit = limit;
	}

	/**
	 * @return the oriented
	 */
	public boolean isOriented() {
		return oriented;
	}

	/**
	 * @param oriented the oriented to set
	 */
	public void setOriented(boolean oriented) {
		this.oriented = oriented;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the preconceded
	 */
	public boolean isPreconceded() {
		return preconceded;
	}

	/**
	 * @param preconceded the preconceded to set
	 */
	public void setPreconceded(boolean preconceded) {
		this.preconceded = preconceded;
	}

	/**
	 * @return the range
	 */
	public String getRange() {
		return range;
	}

	/**
	 * @param range the range to set
	 */
	public void setRange(String range) {
		this.range = range;
	}

}
