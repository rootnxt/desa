package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * InvoiceFinancing.java
 *
 * @author x574726
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceFinancingDocuments {

	// Identificador en mongo
	@JsonIgnore
	private String id;
	// Identificador de operacion en arm
	@JsonIgnore
	private String operationId;
	// Documentos a imprimir
	private List<Document> documents;
	// Tipo de firma
	private String typeSign;

}