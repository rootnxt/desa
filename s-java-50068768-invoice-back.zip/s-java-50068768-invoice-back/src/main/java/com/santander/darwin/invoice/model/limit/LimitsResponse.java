package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Gets the limits.
 *
 * @return the limits
 */
@Getter

/**
 * Sets the limits.
 *
 * @param limits the new limits
 */
@Setter
public class LimitsResponse {

    /** The limits. */
    private List<DataLimitOutput> limits;

}
