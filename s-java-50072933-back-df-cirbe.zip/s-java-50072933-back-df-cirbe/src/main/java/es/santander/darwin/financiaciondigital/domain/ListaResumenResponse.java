package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Sets the garantias formales total.
 *
 * @param garantiasFormalesTotal the new garantias formales total
 */
@Data

/**
 * Builds the.
 *
 * @return the lista resumen response
 */
@Builder

/**
 * Instantiates a new lista resumen response.
 */
@NoArgsConstructor

/**
 * Instantiates a new lista resumen response.
 *
 * @param fecha the fecha
 * @param indicadorNuevoAcredit the indicador nuevo acredit
 * @param santander the santander
 * @param restoGrupo the resto grupo
 * @param otrasEntidades the otras entidades
 * @param total the total
 * @param cuota the cuota
 * @param morosidadTotal the morosidad total
 * @param riesgoIndirectoTotal the riesgo indirecto total
 * @param garantiasRealesTotal the garantias reales total
 * @param garantiasFormalesTotal the garantias formales total
 */
@AllArgsConstructor

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@EqualsAndHashCode(callSuper = false)
public class ListaResumenResponse {
    
    /** The fecha. */
    private String fecha;
    
    /** The indicador nuevo acredit. */
    private String indicadorNuevoAcredit;
    
    /** The santander. */
    private SummaryImports santander;
    
    /** The resto grupo. */
    private SummaryImports restoGrupo;
    
    /** The otras entidades. */
    private SummaryImports otrasEntidades;
    
    /** The total. */
    private SummaryImports total;
    
    /** The cuota. */
    private SummaryImports cuota;
    
    /** The morosidad total. */
    private SummaryImports morosidadTotal;
    
    /** The riesgo indirecto total. */
    private SummaryImports riesgoIndirectoTotal;
    
    /** The garantias reales total. */
    private SummaryImports garantiasRealesTotal;
    
    /** The garantias formales total. */
    private SummaryImports garantiasFormalesTotal;

}
