package com.santander.darwin.invoice.config;

import java.io.Serializable;

/**
 * DataSourceParamsBean
 * 
 * @author ciber
 *
 */
public class DataSourceParamsBean implements Serializable {

	private static final long serialVersionUID = 1303662484211649971L;

	private String dbPoolName;
	private String driver;
    private transient String user;
    private transient String pass;

	/**
	 * Constrcutor
	 * 
	 * @param dbPoolName String
	 * @param driver     String
	 * @param user       String
	 * @param pass       String
	 * 
	 * @return DataSourceParamsBean
	 */
	public DataSourceParamsBean(String dbPoolName, String driver, String user, String pass) {

		this.dbPoolName = dbPoolName;
		this.driver = driver;
		this.user = user;
		this.pass = pass;
	}

	/**
	 * @return the dbPoolName
	 */
	public String getDbPoolName() {
		return dbPoolName;
	}

	/**
	 * @param dbPoolName the dbPoolName to set
	 */
	public void setDbPoolName(String dbPoolName) {
		this.dbPoolName = dbPoolName;
	}

	/**
	 * @return the driver
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}

}
