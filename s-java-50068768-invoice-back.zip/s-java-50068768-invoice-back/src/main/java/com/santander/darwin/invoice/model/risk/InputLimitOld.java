package com.santander.darwin.invoice.model.risk;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * InputLimit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InputLimitOld {

	// Variables

	// Para swagger
	@Schema(example = "J", description = "Type of person")
	@JsonProperty("PersonType")
	@NotNull(message = "PERSONTYPE")
	private String personType;

	// Para swagger
	@Schema(example = "120", description = "Number of person")
	@JsonProperty("PersonNumber")
	@NotNull(message = "PERSONNUMBER")
	private String personNumber;

	// Para swagger
	@Schema(example = "143", description = "Type")
	@JsonProperty("Type")
	@NotNull(message = "TYPE")
	private String type;

	// Para swagger
	@Schema(example = "152", description = "Subtype")
	@JsonProperty("SubType")
	@NotNull(message = "SUBTYPE")
	private String subType;

	// Para swagger
	@Schema(example = "000007", description = "Reference")
	@JsonProperty("ReferenceStandard")
	@NotNull(message = "REFERENCESTANDARD")
	private String referenceStandard;

	// Para swagger
	@Schema(example = "0049", description = "Company")
	@JsonProperty("Company")
	@NotNull(message = "COMPANY")
	private String company;

	// Para swagger
	@Schema(example = "OCD001", description = "Campaign")
	private String campaign;

	// Para swagger
	@Schema(example = "T05", description = "Family")
	private String family;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}