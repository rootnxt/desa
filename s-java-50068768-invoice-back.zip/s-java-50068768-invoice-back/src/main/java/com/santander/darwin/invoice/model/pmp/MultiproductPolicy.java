/**
 * 
 */
package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * MultiproductPolicy.java
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class MultiproductPolicy {
	
	// Atributos de la clase
	 private String policyNumber;
	 private String description;
	 private String dueDate;
	 private List<Participant> participants;
	 
}
