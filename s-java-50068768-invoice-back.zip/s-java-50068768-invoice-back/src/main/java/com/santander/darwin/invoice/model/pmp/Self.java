package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a
 * new Link
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Self {
    /** The self. */
    private String href;
}
