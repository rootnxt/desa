package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CommissionSummary
 * 
 * @author igndom
 *
 */
@Getter
@Setter
public class CommissionSummary extends CommonCommissionSummary {

	/** Periods */
	private List<Period> periods;
	/** Minimum Amount */
	private String minimumAmount;
	/** Maximum Amount */
	private String maximumAmount;

	/**
	 * Constructor
	 */
	public CommissionSummary() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param description String
	 * @param value       Object
	 */
	public CommissionSummary(String description, Object value) {
		super(description, value);
	}

	/**
	 * Constructor
	 * 
	 * @param id          String
	 * @param description String
	 * @param value       Object
	 */
	public CommissionSummary(String id, String description, Object value) {
		super(id, description, value);
	}

}
