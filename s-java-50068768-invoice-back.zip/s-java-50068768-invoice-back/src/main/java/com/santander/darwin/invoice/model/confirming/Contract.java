package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Contract.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Contract {
	// Datos de Contract
	private String company;
	private String center;
	private String number;
}