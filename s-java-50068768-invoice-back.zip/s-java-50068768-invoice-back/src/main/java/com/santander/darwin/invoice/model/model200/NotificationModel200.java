package com.santander.darwin.invoice.model.model200;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * NotificationModel200.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class NotificationModel200 extends NotificationModel200Old {

	// Person Type (F/J)
	// Para swagger
	@Schema(example = "J", description = "Type of Person")
	@Pattern(regexp = "[F|J]", message = "PERSONTYPEINVALID")
	private String personType;
	// Person Number 
	// Para swagger
	@Schema(example = "123456", description = "Number of Person")
	@NotNull(message = "PERSONCODENULL") 
	private Integer personNumber;
}
