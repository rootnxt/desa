package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * OTPData.java
 *
 * @author igndom
 *
 */
public class OTPData {

	private String codeOtp;
	@JsonIgnore
	private String ticketOtp;
	private boolean allowOtp;

	/**
	 * @return the codeOtp
	 */
	public String getCodeOtp() {
		return codeOtp;
	}

	/**
	 * @param codeOtp the codeOtp to set
	 */
	public void setCodeOtp(String codeOtp) {
		this.codeOtp = codeOtp;
	}

	/**
	 * @return the ticketOtp
	 */
	public String getTicketOtp() {
		return ticketOtp;
	}

	/**
	 * @param ticketOtp the ticketOtp to set
	 */
	public void setTicketOtp(String ticketOtp) {
		this.ticketOtp = ticketOtp;
	}

	/**
	 * @return the allowOtp
	 */
	public boolean isAllowOtp() {
		return allowOtp;
	}

	/**
	 * @param allowOtp the allowOtp to set
	 */
	public void setAllowOtp(boolean allowOtp) {
		this.allowOtp = allowOtp;
	}

}
