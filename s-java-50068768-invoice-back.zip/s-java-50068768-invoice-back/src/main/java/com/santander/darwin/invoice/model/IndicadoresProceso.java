package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * IndicadoresOrdofe.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class IndicadoresProceso {

	// Datos
	// Para swagger
	@Schema(example = "AD", description = "Indicator of process")
	private String indProce;
	// Para swagger
	@Schema(example = "RED", description = "canal operacion")
	private String canalOpe;
	// Para swagger
	@Schema(example = "RED", description = "canal comercializacion")
	private String canalCom;

}
