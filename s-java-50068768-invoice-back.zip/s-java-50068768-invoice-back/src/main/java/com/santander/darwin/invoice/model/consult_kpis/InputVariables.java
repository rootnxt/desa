package com.santander.darwin.invoice.model.consult_kpis;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class InputVariables.
 */

/**
 * Gets the a0960.
 *
 * @return the a0960
 */
@Getter

/**
 * Sets the a0960.
 *
 * @param a0960 the new a0960
 */
@Setter
public class InputVariables {
	
	/** The a 0977. */
	@JsonProperty("A0977") 
	private String a0977;
	
	/** The a 1978. */
	@JsonProperty("A1978") 
	private String a1978;
	
	/** The a 0997. */
	@JsonProperty("A0997") 
	private String a0997;
	
	/** The p ROPUIMPORTE. */
	@JsonProperty("PROPUIMPORTE") 
	private String propuImporte;
	
	/** The t 1 TOTALPAPCOMERLIM. */
	@JsonProperty("T1TOTALPAPCOMERLIM") 
	private String t1TotalPapComerlim;
	
	/** The a 0991. */
	@JsonProperty("A0991") 
	private String a0991;
	
	/** The a 0981. */
	@JsonProperty("A0981") 
	private String a0981;
	
	/** The a 0970. */
	@JsonProperty("A0970") 
	private String a0970;
	
	/** The a 0984. */
	@JsonProperty("A0984") 
	private String a0984;
	
	/** The t 1 FINANCIEROCPLIM. */
	@JsonProperty("T1FINANCIEROCPLIM") 
	private String t1FinancieroCplim;
	
	/** The a 0960. */
	@JsonProperty("A0960") 
	private String a0960;
	
}
