package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class Constants.
 */
public class Constants {

    /** The Constant EMPTY. */
    public static final String EMPTY = "";
    
    /** The Constant APP_NAME. */
    public static final String APP_NAME = "CIRBE";
    
    /** The Constant CODE_NOACREDITADO_CIRBEACTUALIZADA. */
    public static final String CODE_NOACREDITADO_CIRBEACTUALIZADA = "10";

    /** The Constant PROPUESTA_RGO. */
    public static final String PROPUESTA_RGO = "PROPUESTA_RGO_09";
    
    /** The Constant PERSOPROP_03. */
    public static final String PERSOPROP_03 = "PERSO_PROPUESTA_03";
    
    /** The Constant MESSAGE_NOACREDITADO_CIRBEACTUALIZADA. */
    public static final String MESSAGE_NOACREDITADO_CIRBEACTUALIZADA =
            "Persona que NO es un nuevo acreditado y tiene CIRBE actualizada";

    /** The Constant CODE_ACREDITADO_CIRBENOACTUALIZADA. */
    public static final String CODE_ACREDITADO_CIRBENOACTUALIZADA = "20";

    /** The Constant MESSAGE_ACREDITADO_CIRBENOACTUALIZADA. */
    public static final String MESSAGE_ACREDITADO_CIRBENOACTUALIZADA =
            "Persona que NO es un nuevo acreditado y no tiene CIRBE actualizada.";

    /** The Constant CODE_NOACREDITADO_CIRBENOACTUALIZADA. */
    public static final String CODE_NOACREDITADO_CIRBENOACTUALIZADA = "30";

    /** The Constant MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA. */
    public static final String MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA =
            "Persona que SI es un nuevo acreditado y no tiene CIRBE";

    /** The Constant CODE_NO_RESIDENTE. */
    public static final String CODE_NO_RESIDENTE = "70";

    /** The Constant MESSAGE_NO_RESIDENTE. */
    public static final String MESSAGE_NO_RESIDENTE = "Persona NO Residente";

    /** The Constant CODE_PETICION_MAXIMA. */
    public static final String CODE_PETICION_MAXIMA = "80";

    /** The Constant MESSAGE_PETICION_MAXIMA. */
    public static final String MESSAGE_PETICION_MAXIMA = "Se han superado el máximo de peticiones";

    /** The Constant VALUE_01. */
    public static final String VALUE_01 = "01";

    /** The Constant VALUE_02. */
    public static final String VALUE_02 = "02";

    /** The Constant VALUE_03. */
    public static final String VALUE_03 = "03";

    /** The Constant VALUE_100. */
    public static final String VALUE_100 = "100";

    /** The Constant VALUE_101. */
    public static final String VALUE_101 = "101";

    /** The Constant VALUE_102. */
    public static final String VALUE_102 = "102";

    /** The Constant VALUE_BLANK. */
    public static final String VALUE_BLANK = "";

    /** The Constant SPACE. */
    public static final String SPACE = " ";

    /** The Constant VALUE_S. */
    public static final String VALUE_S = "S";

    /** The Constant VALUE_N. */
    public static final String VALUE_N = "N";

    /** The Constant COD_PAIS_ES. */
    public static final String COD_PAIS_ES = "ES";

    /** The Constant NAME_SPACE. */
    public static final String NAME_SPACE = "http://financiaciondigital.darwin.santander.es/soap";

    /** The Constant LOCAL_PART. */
    public static final String LOCAL_PART = "getPersonRequest";

    /** The Constant ALPHANUMERIC_REGEX_FILTER. */
    public static final String ALPHANUMERIC_REGEX_FILTER = "[^a-zA-Z0-9]";

    /** The Constant ERROR_CAMPOS_NULOS_O_VACIOS. */
    public static final String ERROR_CAMPOS_NULOS_O_VACIOS = "Campos nulos o vacíos en request: ";

    /** The Constant COMMA. */
    public static final String COMMA = ",";

    /** The Constant COMPANY. */
    public static final String COMPANY = "company";

    /** The Constant CENTER. */
    public static final String CENTER = "center";

    /** The Constant YEAR. */
    public static final String YEAR = "year";

    /** The Constant PROPOSAL_NUMBER. */
    public static final String PROPOSAL_NUMBER = "proposal number";

    /** The Constant VALUE_4. */
    public static final Integer VALUE_4 = 4;

    /** The Constant VALUE_1. */
    public static final Integer VALUE_1 = 1;

    /** The Constant VALUE_9. */
    public static final Integer VALUE_9 = 9;

    /** The Constant VALUE_100000. */
    public static final Integer VALUE_100000 = 100000;

    /** The Constant PROPUESTA_CORRECTA_COD. */
    public static final String PROPUESTA_CORRECTA_COD = "00";

    /** The Constant PROPUESTA_CORRECTA_MSG. */
    public static final String PROPUESTA_CORRECTA_MSG = "Propuesta procesada correctamente";
    
    /** The Constant CIRBE. */
    public static final String CIRBE = "CIRBE";
    
    /** The Constant INICIAL_TITULAR. */
    public static final String INICIAL_TITULAR = "T";
    
    /** The Constant INICIAL_AVALISTA. */
    public static final String INICIAL_AVALISTA = "A";
    
    /** The Constant CONSTANTS_B0001. */
    public static final String CONSTANTS_B0001 = "B0001";

    /** The Constant SOURCE_STATE_OK. */
    public static final String SOURCE_STATE_OK = "02";
    
    /** The Constant SOURCE_STATE_04. */
    public static final String SOURCE_STATE_04 = "04";

    /** The Constant CRITICALITY_GRADE. */
    public static final String CRITICALITY_GRADE = "1";
    
    /** The Constant SOURCE_STATE_NOK. */
    public static final String SOURCE_STATE_PDT = "01";

    /** The Constant PROCESS_INDICATOR. */
    public static final String PROCESS_INDICATOR = "FD";

    /** The Constant IDENT_NOTI_0. */
    public static final Integer IDENT_NOTI_0 = 0;
    
    /** The Constant IDENT_NOTI_1. */
    public static final Integer IDENT_NOTI_1 = 1;
    
    /** The Constant CALL_TYPE. */
    public static final String CALL_TYPE = "F2";
    
    /** The Constant CODESTAD. */
    public static final String CODESTAD = "01";
    
    /** The Constant CODE_SUCCESS. */
    public static final String CODE_SUCCESS = "00";

    /** The Constant MESSAGE_SUCCESS. */
    public static final String MESSAGE_SUCCESS = "Proceso realizado Correctamente";
    
    /** The Constant FORMAT_DATE. */
    public static final String FORMAT_DATE = "dd/MM/yyyy";
    
    /** The Constant CONSTANT_CONTRATACION. */
    public static final String CONSTANT_CONTRATACION = "Contratación";
    
    /** The Constant SUBJECT_REQUEST_OF. */
    public static final String SUBJECT_REQUEST_OF = "Solicitud de ";
    
    /** The Constant PROPOSAL_STATE_02. */
    public static final String PROPOSAL_STATE_02 = "02";
    
    /** The Constant PROPOSAL_STATE_06. */
    public static final String PROPOSAL_STATE_06 = "06";
    
    /** The Constant IDIOMA_ISO. */
    public static final String IDIOMA_ISO = "es";

    /** The Constant DIALECTO_ISO. */
    public static final String DIALECTO_ISO = "ES";

    /** The Constant CANAL_MARCO. */
    public static final String CANAL_MARCO = "EMP";
    
    /** The Constant TYPE_INTERVENTIONAVAL. */
    public static final String TYPE_INTERVENTIONAVAL = "A";
    
    /** The Constant TYPE_INTERVENTIONINTER. */
    public static final String TYPE_INTERVENTIONINTER = "T";
    
    public static final String LOCAL_PART_PETITIONS = "petitionsOfPersonAndProposalRequest";
    
    /**
     * Instantiates a new constants.
     */
    private Constants() {
        super();
    }

}
