package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * OutputSignExp.java
 *
 * @author igndom
 *
 */
public class OutputSignExp {

	private int idExpSec;
	private String version;

	/**
	 * @return the idExpSec
	 */
	public int getIdExpSec() {
		return idExpSec;
	}

	/**
	 * @param idExpSec the idExpSec to set
	 */
	public void setIdExpSec(int idExpSec) {
		this.idExpSec = idExpSec;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

}
