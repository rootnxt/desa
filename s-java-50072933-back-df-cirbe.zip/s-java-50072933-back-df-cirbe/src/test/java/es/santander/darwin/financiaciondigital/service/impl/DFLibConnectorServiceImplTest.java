package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataRequestVO;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionLibException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.lib.bean.TrxRequestBodyPSBMv2;
import es.santander.darwin.financiaciondigital.lib.bean.TrxResponseBodyPSBMv2;
import es.santander.darwin.financiaciondigital.lib.service.TrxLibraryService;
import es.santander.darwin.financiaciondigital.service.DFLibConnectorService;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

/**
 * The Class DFLibConnectorServiceImplTest.
 */
public class DFLibConnectorServiceImplTest {

    /** The trx library service. */
    @Mock
    private TrxLibraryService trxLibraryService;

    /** The d F lib connector service. */
    @InjectMocks
    private DFLibConnectorService dFLibConnectorService = new DFLibConnectorServiceImpl();

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Gets the basic person data test OK.
     *
     * @return the basic person data test OK
     * @throws Exception the exception
     */
    @Test
    public void getBasicPersonDataTestOK() throws Exception {

        TrxResponseBodyPSBMv2 responseTrx = TestDataUtil.fillDummyObject(new TrxResponseBodyPSBMv2());
        List<String> codpaisn = Arrays.asList("es", "es", "es");
        List<LocalDate> fecnac = Arrays.asList(LocalDate.now(), LocalDate.now(), LocalDate.now());
        responseTrx.setFecnac(fecnac);
        responseTrx.setCodpaisn(codpaisn);

        BasicPersonDataRequestVO request = new BasicPersonDataRequestVO();
        request.setCodpers(new BigDecimal("200"));
        request.setIdempr("0049");
        request.setTipopers("J");

        doReturn(responseTrx).when(trxLibraryService).trxPSBMv2(any(TrxRequestBodyPSBMv2.class));

        BasicPersonDataResponseVO result = dFLibConnectorService.getBasicPersonData(request);
        assertNotNull(result);

    }

    /**
     * Gets the basic person data test null.
     *
     * @return the basic person data test null
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getBasicPersonDataTestNull() throws Exception {

        TrxResponseBodyPSBMv2 responseTrx = new TrxResponseBodyPSBMv2();
        List<String> lit301 = Arrays.asList();
        responseTrx.setLit301(lit301);

        BasicPersonDataRequestVO request = new BasicPersonDataRequestVO();
        request.setCodpers(new BigDecimal("200"));
        request.setIdempr("0049");
        request.setTipopers("J");

        List<BasicPersonDataResponseVO> basicPersonDataList = new ArrayList<BasicPersonDataResponseVO>();
        BasicPersonDataResponseVO bean = new BasicPersonDataResponseVO();
        basicPersonDataList.add(bean);

        doReturn(responseTrx).when(trxLibraryService).trxPSBMv2(any(TrxRequestBodyPSBMv2.class));

        BasicPersonDataResponseVO result = dFLibConnectorService.getBasicPersonData(request);
        assertNotNull(result);

    }

    /**
     * Gets the basic person data test NOK.
     *
     * @return the basic person data test NOK
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws DigitalConsumptionLibException the digital consumption lib exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getBasicPersonDataTestNOK() throws DigitalConsumptionServiceException, DigitalConsumptionLibException {

        TrxResponseBodyPSBMv2 responseTrx = TestDataUtil.fillDummyObject(new TrxResponseBodyPSBMv2());
        List<String> codpaisn = Arrays.asList("es", "es", "es");
        List<LocalDate> fecnac = Arrays.asList(LocalDate.now(), LocalDate.now(), LocalDate.now());
        responseTrx.setFecnac(fecnac);
        responseTrx.setCodpaisn(codpaisn);

        Throwable t = new Throwable();
        DigitalConsumptionLibException e = new DigitalConsumptionLibException("uwu", "200", t);

        BasicPersonDataRequestVO request = new BasicPersonDataRequestVO();
        request.setCodpers(new BigDecimal("200"));
        request.setIdempr("0049");
        request.setTipopers("J");

        when(trxLibraryService.trxPSBMv2(any(TrxRequestBodyPSBMv2.class))).thenThrow(e);
        dFLibConnectorService.getBasicPersonData(request);

    }

    /**
     * Gets the basic person data test NOK 2.
     *
     * @return the basic person data test NOK 2
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void getBasicPersonDataTestNOK2() throws Exception {

        TrxResponseBodyPSBMv2 responseTrx = TestDataUtil.fillDummyObject(new TrxResponseBodyPSBMv2());
        List<String> codpaisn = Arrays.asList("es", "es", "es");
        List<LocalDate> fecnac = Arrays.asList(LocalDate.now(), LocalDate.now(), LocalDate.now());
        responseTrx.setFecnac(fecnac);
        responseTrx.setCodpaisn(codpaisn);

        BasicPersonDataRequestVO request = new BasicPersonDataRequestVO();
        request.setCodpers(new BigDecimal("200"));
        request.setIdempr("0049");
        request.setTipopers("J");

        when(trxLibraryService.trxPSBMv2(any(TrxRequestBodyPSBMv2.class)))
                .thenThrow(DigitalConsumptionLibException.class);
        dFLibConnectorService.getBasicPersonData(request);

    }

}
