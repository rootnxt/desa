package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.confirming.ContactInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Confirming.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Confirming {

	// Informacion de contacto
	private ContactInfo contactInfo;

}
