package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * OutputSat002506.java
 *
 * @author igndom
 *
 */
public class OutputSat002506 {
	
	private List<String> a1codseg;
	private List<String> a8anopro;
	private List<String> a8cenloc;
	private List<String> a8codest;
	private List<String> a8emploc;
	private List<Date> a8fealta;
	private List<String> a8idcent;
	private List<String> a8idempr;
	private List<String> a8idsegm;
	private List<String> a8lit17;
	private List<BigDecimal> a8numpro;
	private List<BigDecimal> a8plazop;
	private List<String> a8timest;
	private List<BigDecimal> lnumeco;

	/**
	 * @return the a1codseg
	 */
	public List<String> getA1codseg() {
		return a1codseg;
	}

	/**
	 * @param a1codseg the a1codseg to set
	 */
	public void setA1codseg(List<String> a1codseg) {
		this.a1codseg = a1codseg;
	}

	/**
	 * @return the a8anopro
	 */
	public List<String> getA8anopro() {
		return a8anopro;
	}

	/**
	 * @param a8anopro the a8anopro to set
	 */
	public void setA8anopro(List<String> a8anopro) {
		this.a8anopro = a8anopro;
	}

	/**
	 * @return the a8cenloc
	 */
	public List<String> getA8cenloc() {
		return a8cenloc;
	}

	/**
	 * @param a8cenloc the a8cenloc to set
	 */
	public void setA8cenloc(List<String> a8cenloc) {
		this.a8cenloc = a8cenloc;
	}

	/**
	 * @return the a8codest
	 */
	public List<String> getA8codest() {
		return a8codest;
	}

	/**
	 * @param a8codest the a8codest to set
	 */
	public void setA8codest(List<String> a8codest) {
		this.a8codest = a8codest;
	}

	/**
	 * @return the a8emploc
	 */
	public List<String> getA8emploc() {
		return a8emploc;
	}

	/**
	 * @param a8emploc the a8emploc to set
	 */
	public void setA8emploc(List<String> a8emploc) {
		this.a8emploc = a8emploc;
	}

	/**
	 * @return the a8fealta
	 */
	public List<Date> getA8fealta() {
		return a8fealta;
	}

	/**
	 * @param a8fealta the a8fealta to set
	 */
	public void setA8fealta(List<Date> a8fealta) {
		this.a8fealta = a8fealta;
	}

	/**
	 * @return the a8idcent
	 */
	public List<String> getA8idcent() {
		return a8idcent;
	}

	/**
	 * @param a8idcent the a8idcent to set
	 */
	public void setA8idcent(List<String> a8idcent) {
		this.a8idcent = a8idcent;
	}

	/**
	 * @return the a8idempr
	 */
	public List<String> getA8idempr() {
		return a8idempr;
	}

	/**
	 * @param a8idempr the a8idempr to set
	 */
	public void setA8idempr(List<String> a8idempr) {
		this.a8idempr = a8idempr;
	}

	/**
	 * @return the a8idsegm
	 */
	public List<String> getA8idsegm() {
		return a8idsegm;
	}

	/**
	 * @param a8idsegm the a8idsegm to set
	 */
	public void setA8idsegm(List<String> a8idsegm) {
		this.a8idsegm = a8idsegm;
	}

	/**
	 * @return the a8lit17
	 */
	public List<String> getA8lit17() {
		return a8lit17;
	}

	/**
	 * @param a8lit17 the a8lit17 to set
	 */
	public void setA8lit17(List<String> a8lit17) {
		this.a8lit17 = a8lit17;
	}

	/**
	 * @return the a8numpro
	 */
	public List<BigDecimal> getA8numpro() {
		return a8numpro;
	}

	/**
	 * @param a8numpro the a8numpro to set
	 */
	public void setA8numpro(List<BigDecimal> a8numpro) {
		this.a8numpro = a8numpro;
	}

	/**
	 * @return the a8plazop
	 */
	public List<BigDecimal> getA8plazop() {
		return a8plazop;
	}

	/**
	 * @param a8plazop the a8plazop to set
	 */
	public void setA8plazop(List<BigDecimal> a8plazop) {
		this.a8plazop = a8plazop;
	}

	/**
	 * @return the a8timest
	 */
	public List<String> getA8timest() {
		return a8timest;
	}

	/**
	 * @param a8timest the a8timest to set
	 */
	public void setA8timest(List<String> a8timest) {
		this.a8timest = a8timest;
	}

	/**
	 * @return the lnumeco
	 */
	public List<BigDecimal> getLnumeco() {
		return lnumeco;
	}

	/**
	 * @param lnumeco the lnumeco to set
	 */
	public void setLnumeco(List<BigDecimal> lnumeco) {
		this.lnumeco = lnumeco;
	}

}
