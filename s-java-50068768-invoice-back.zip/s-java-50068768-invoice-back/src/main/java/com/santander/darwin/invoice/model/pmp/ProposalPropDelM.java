package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ProposalPropDelM model
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProposalPropDelM {
	
	/** The modules. T3520_CODMODU. */
    private String modules;
	
	/** The groups. T3520_CODAGRUP. */
	private String groups;
	
	/** The consumptionType. T3520_TPIMPUT. */
	private String consumptionType;
	
}
