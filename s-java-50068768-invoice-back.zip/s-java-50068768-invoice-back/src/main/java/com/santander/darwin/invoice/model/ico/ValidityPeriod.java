package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ValidityPeriod.
 */

/**
 * Sets the end date.
 *
 * @param endDate the new end date
 */
@Setter

/**
 * Gets the end date.
 *
 * @return the end date
 */
@Getter

/**
 * Instantiates a new validity period.
 */
@NoArgsConstructor
public class ValidityPeriod {
	
	/** The start date. */
	private String startDate;
	
	/** The end date. */
	private String endDate;
}
