package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Sat2406RequestDTO.java
 *
 * @author igndom
 *
 */
public class Sat2406RequestDTO {

	private String coddocps;
	private String tipdocps;

	/**
	 * @return the coddocps
	 */
	public String getCoddocps() {
		return coddocps;
	}

	/**
	 * @param coddocps the coddocps to set
	 */
	public void setCoddocps(String coddocps) {
		this.coddocps = coddocps;
	}

	/**
	 * @return the tipdocps
	 */
	public String getTipdocps() {
		return tipdocps;
	}

	/**
	 * @param tipdocps the tipdocps to set
	 */
	public void setTipdocps(String tipdocps) {
		this.tipdocps = tipdocps;
	}

}
