package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CancelRefinancing.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CancelRefinancing {

	// personData
	private PersonData personData;
	
	// refinancerContract
	private RefinancerContract refinancerContract;
	
	// refinancerData
	private RefinancerData refinancerData;
	
	// refinancedContractData
	private List<RefinancedContractData> refinancedContractData;
}
