package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Interest.java
 *
 * @author igndom
 *
 */
public class Interest {

	private CommonDate expirationDate;
	private CommonCommission deadLine;
	@JsonProperty("interest")
	private CommonCommission interestPorcent;
	private CommonCommission openCommission;
	private CommonCommission total;

	/**
	 * @return the expirationDate
	 */
	public CommonDate getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(CommonDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the deadLine
	 */
	public CommonCommission getDeadLine() {
		return deadLine;
	}

	/**
	 * @param deadLine the deadLine to set
	 */
	public void setDeadLine(CommonCommission deadLine) {
		this.deadLine = deadLine;
	}

	/**
	 * @return the interestPorcent
	 */
	public CommonCommission getInterestPorcent() {
		return interestPorcent;
	}

	/**
	 * @param interestPorcent the interestPorcent to set
	 */
	public void setInterestPorcent(CommonCommission interestPorcent) {
		this.interestPorcent = interestPorcent;
	}

	/**
	 * @return the openCommission
	 */
	public CommonCommission getOpenCommission() {
		return openCommission;
	}

	/**
	 * @param openCommission the openCommission to set
	 */
	public void setOpenCommission(CommonCommission openCommission) {
		this.openCommission = openCommission;
	}

	/**
	 * @return the total
	 */
	public CommonCommission getTotal() {
		return total;
	}

	/**
	 * @param total the total to set
	 */
	public void setTotal(CommonCommission total) {
		this.total = total;
	}

}
