package com.santander.darwin.invoice.model.arm;

import com.santander.darwin.invoice.model.sign_juridic.Firmante;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * DataPendingSign
 * 
 * @author igndom
 *
 */
@Getter
@Setter
public class DataPendingSign {

	private List<Firmante> firmantes;
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Data [firmantes=" + firmantes + "]";
	}

}
