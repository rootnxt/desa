package com.santander.darwin.invoice.model.crisol;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * End.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CrisolPricesInputBase{

	//Atributos de la clase
	private String proposalInd;
	private String callTypeInd;
	
	// Usuario quee realiza la transaccion
	private String user; 
	
	// Datos constantes
	private BigDecimal spid; 
	private BigDecimal model; 
	private String scoring; 
	
	
	// Persona y tipo de persona
	private String customerInd; 
	private String customerType; 
	private Integer customerCode; 
	private String riskAssessment; 
	private String billingStretchAssessment; 
	private String segmentAssessment;
	
	// Datos de la propuesta
	private String company; 
	private String branch; 
	private String year; 
	private BigDecimal proposalNumber;
	
	// Datos del producto
	private String productType; 
	private String productSubtype; 
	private String referenceStandard; 
	
	// ESPADMEMP-6534
	private String stretchInd;

}
