package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * The ProposalData model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class ProposalData implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /** The proposal. */
    private Proposal proposal;

    /** The stateProposal. */
    private String stateProposal;
    
    /** The proposalCode. */
    private String stateProposalCode;

    /** The employeeApplicant. */
    private String employeeApplicant;

    /** The circuit. */
    private String circuit;

}
