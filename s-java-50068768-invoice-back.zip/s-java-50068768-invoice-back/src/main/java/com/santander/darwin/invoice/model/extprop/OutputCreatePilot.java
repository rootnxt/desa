package com.santander.darwin.invoice.model.extprop;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * InputConsultProposal.
 *
 * @author seresc
 */

@Getter
@Setter
public class OutputCreatePilot {

    /** The url. */
	@Schema(example = "https://invoice.pru.bsch/simulation?proposal=00490075007520241028", description = "The url")
    private String url;

}
