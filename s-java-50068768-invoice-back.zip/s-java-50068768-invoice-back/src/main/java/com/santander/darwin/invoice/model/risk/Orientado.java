package com.santander.darwin.invoice.model.risk;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Orientado.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Orientado {

	// Variables

	// Para swagger
	@Schema(example = "9999999", description = "Max of amount")
	private BigDecimal maxAmount;
	// Para swagger
	@Schema(example = "1", description = "Min of amount")
	private BigDecimal minAmount;
	// Para swagger
	@Schema(example = "9999999", description = "Limit of amount")
	private BigDecimal limit;
	// Para swagger
	@Schema(example = "2021-01-01", description = "Date of init")
	private String initDate;
	// Para swagger
	@Schema(example = "2021-12-31", description = "Date of end")
	private String endDate;
	// Para swagger
	@Schema(example = "OCD001", description = "Campaign of oriented")
	private String campaign;
	// Para swagger
	@Schema(example = "T05", description = "Family of oriented")
	private String family;
}
