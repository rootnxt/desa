package com.santander.darwin.invoice.aop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santander.darwin.invoice.utils.BasicUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

/**
 * AbstractBaseAop
 * 
 * @author igndom
 *
 */
@Slf4j
public abstract class AbstractBaseAop {

	// Lineas stackTrace
	private static final int NUM_LINES_STACK = 4;

	/**
	 * Comentario para sonar
	 */
	@Autowired
	protected MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

	/**
	 * Comentario para sonar
	 */
	protected AbstractBaseAop() {
		// Esta log debuf habilitado
		if (log.isDebugEnabled()) {
			// Se logea inicio aspecto
			log.debug("Iniciando Aspecto... {}", this.getClass().getName());
		}
	}

	/**
	 * Comentario para sonar
	 */
	protected Object logging(ProceedingJoinPoint pjp) throws Throwable {
		// Se crea la instancia del log
		final var logger = LoggerFactory.getLogger(pjp.getTarget().getClass());
		// Nombre methodo
		var name = pjp.getSignature().toString();
		// Se comprueba si el log info esta habilitado
		if (logger.isInfoEnabled()) {
			// Se logea el nombre del metodo
			logger.info("Llamando a: {}",name);
		}

		return getResultadoProceed(pjp, name);
	}

	/**
	 * Comentario para sonar
	 */
	private Object getResultadoProceed(ProceedingJoinPoint pjp, String name) throws Throwable {
		// Se comprueba si el log de debug esta habilitado
		if (log.isDebugEnabled()) {
			// Se muestran los parametros de entrada
			showParameters(pjp);
		}

		Object resultadoProceed = null;
		try {
			// Se ejecuta el metodo
			resultadoProceed = pjp.proceed();
		} catch (Throwable e) {
			// Se logea el error
			log.error("error en la llamada al método: {} traza: \n", name,
					BasicUtils.reduceNumberLinesStackTrace(e, NUM_LINES_STACK));
			throw e;
		}
		return resultadoProceed;
	}

	/**
	 * Comentario para sonar
	 */
	private void showParameters(ProceedingJoinPoint pjp) {
		// Se cogen los argumentos del metodo
		Object[] argumentos = pjp.getArgs();
		// Se comprueba que que haya argumentos
		if (argumentos != null && argumentos.length > 0) {
			var contador = 0;
			// Se imprimen los argumentos
			for (var i = 0; i < argumentos.length; i++, contador++) {
				if (argumentos[i] == null) {
					log.debug("arg[{}] -> null", contador);
				} else {
					var stringObject = convertObjectToString(argumentos[i]);
					log.debug("arg[{}] -> {}", contador, stringObject);
				}
			}
		}
	}

	/**
	 * Comentario para sonar
	 */
	private String convertObjectToString(Object argumento) {
		String resultado = null;
		if (argumento != null) {
			try {
				Class<?> clase = argumento.getClass();
				// Eliminamos los objetos InvoiceFinancing y InsertDocumentInput por tamaño
                if (clase.getName().startsWith("com.santander.darwin.invoice")
						&& !clase.getName().contains("FilterResponseWrapper")
						&& !clase.getName().contains("InvoiceFinancing")
						&& !clase.getName().contains("InsertDocumentInput")) {
					var objectMapper = mappingJackson2HttpMessageConverter.getObjectMapper();
					resultado = objectMapper.writeValueAsString(argumento);
				} else {
					// Se pinta el objeto
					resultado = argumento.toString();
				}
			} catch (JsonProcessingException e) {
				log.error("Log exception", BasicUtils.reduceNumberLinesStackTrace(e, 1));
				resultado = "ERROR!";
			}
		}
		return resultado;
	}

	/**
	 * Comentario para sonar
	 */
	protected Object loggingPrivate(ProceedingJoinPoint pjp) throws Throwable {
		final var logger = LoggerFactory.getLogger(pjp.getTarget().getClass());
		var name = pjp.getSignature().toString();
		if (logger.isInfoEnabled()) {
			logger.info("Method private\nLlamando a: {}", name);
		}

		Object resultadoProceed = null;
		try {
			resultadoProceed = pjp.proceed();
		} catch (Throwable e) {
			log.error("error en la llamada al método: {} traza: \n", name,
					BasicUtils.reduceNumberLinesStackTrace(e, NUM_LINES_STACK));
			throw e;
		}
		return resultadoProceed;
	}

}
