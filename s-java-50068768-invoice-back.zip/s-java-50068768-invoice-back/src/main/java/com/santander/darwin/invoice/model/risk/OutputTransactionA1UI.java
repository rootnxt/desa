/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * OutputTransactionA1UI
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class OutputTransactionA1UI {
	
	//OUTPUT DATA

	//Partenon alphanumeric (A) - Length (2)
	public String cdestva1;

	//Partenon alphanumeric (A) - Length (2)
	public String cdestva2;

	//Partenon alphanumeric (A) - Length (2)
	public String codretor;

	//Partenon alphanumeric (A) - Length (2)
	public String codretrc;

	//Partenon date (D1) - Length (8)
	public Date fechvtoc;

	//Partenon alphanumeric (A) - Length (6)
	public String mensa01;

	//Partenon alphanumeric (A) - Length (15)
	public String nomtbt;

	//Partenon alphanumeric (A) - Length (50)
	public String obser;

	//Partenon signed numeric (L) - Length (5, 0)
	public BigDecimal sqlcode;

}
