package com.santander.darwin.invoice.model.hiring;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ContactInfo.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class PreformalizationInfo {

	// Variables

	// Fecha vencimiento 
	private String expiredDate;
	// Fecha preformalizacion
	private String preformDate;
	// Flag para saber si se han modificado las fechas de los calendarios en el front.
	// Se usa para el filtrado de solicitudes
	private boolean updateDate;
	// Canal de preformalizacion
	private String channel;

	// Día de cargo
	private int chargeDays;
	// indicador
	private boolean preformalized;


}
