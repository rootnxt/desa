package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The InputPersonData model class.
 *
 * 
 */
@Getter
@Setter
public class InputPersonData {
	/** codpoli. */
    private String codpoli;
    
    /** codprod. */
    private List<String> codprod;
    
    /** codsprod. */
    private List<String> codsprod;
    
    /** empresac. */
    private List<String> empresac;
    
    /** idcentr. */
    private List<String> idcentr;
    
    /** idcontr. */
    private List<String> idcontr;
    
    /** idempr. */
    private String idempr;
    
    /** indcon. */
    private String indcon;
    
    /** indice. */
    private int indice;
    
    /** indpolit. */
    private List<String> indpolit;
    
    /** indvigen. */
    private String indvigen;
    
    /** nmrdomic. */
    private List<Integer> nmrdomic;
}
