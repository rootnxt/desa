package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProductGen.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProductGen extends Product {

	// Variables de producto
	private String gtype;
	private String gsubType;
	private String greference;
	
	// Variables de documento
	private String docName;
	private String typDocument;

}
