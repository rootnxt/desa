/**
 *
 */
package com.santander.darwin.invoice.exception;

import com.santander.darwin.invoice.exception.model.ErrorAppType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * ModalException
 * 
 * @author josdon
 *
 */
public class ModalException extends GlobalException {

	private static final long serialVersionUID = -2450970287495434840L;

	private final List<String> codes;
	private final String app;

	/**
	 * Constructor
	 *
	 * @param code String
	 * @param lang String
	 * @param app  String
	 */
	public ModalException(String code, String lang, String app) {
		super(code, lang, ErrorAppType.MODAL.getCode());
		this.codes = Collections.unmodifiableList(Arrays.asList(code));
		this.app = app;
	}

	/**
	 * @return the codes
	 */
	public List<String> getCodes() {
		return codes;
	}

	/**
	 * @return the app
	 */
	public String getApp() {
		return app;
	}

}
