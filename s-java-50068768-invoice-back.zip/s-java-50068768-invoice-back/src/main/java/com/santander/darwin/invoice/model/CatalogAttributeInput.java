package com.santander.darwin.invoice.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Entrada de la consulta de atributos de catálogo de productos
 * 
 */
@Getter
@Setter
@Builder
public class CatalogAttributeInput {

	/**
	 * atribfi3
	 */
    private String atribfi3;

	/**
	 * atribrel
	 */
    private String atribrel;

	/**
	 * codsprod
	 */
    private String codsprod;

	/**
	 * coestrex
	 */
    private String coestrex;

	/**
	 * desc10
	 */
    private String desc10;

	/**
	 * descp25a
	 */
    private String descp25a;

	/**
	 * descri25
	 */
    private String descri25;

	/**
	 * grupor
	 */
    private String grupor;

	/**
	 * idempr
	 */
    private String idempr;

	/**
	 * rellamad
	 */
    private String rellamad;

	/**
	 * tipoac
	 */
    private String tipoac;
    
}
