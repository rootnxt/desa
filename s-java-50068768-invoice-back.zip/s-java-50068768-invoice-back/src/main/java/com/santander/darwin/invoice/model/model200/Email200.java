package com.santander.darwin.invoice.model.model200;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Email200.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Email200 {
	
	// Mail modelo 200
	private String email;
}
