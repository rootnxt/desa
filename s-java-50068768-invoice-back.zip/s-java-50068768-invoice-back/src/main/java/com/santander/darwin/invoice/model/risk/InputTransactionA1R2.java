package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputTransactionA1R2.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputTransactionA1R2 extends TransactionA1R2 {

	private String anoprop;
	private BigDecimal asacion;
	private String auxilia5;
	private String a1agenda;
	private String a1codseg;
	private String a1comref;
	private String a1opci1;
	private String a1r2f5;
	private String codcesta;
	private String codiri;
	private String codmonsw;
	private String coestref;
	private List<String> comentaz;
	private String cotlocal;
	private String dlocali1;
	private String dsituaci;
	private String idcent;
	private String idempr;
	private String idprod;
	private String idstipro;
	private BigDecimal impaprob;
	private BigDecimal impcarga;
	private BigDecimal impcob;
	private BigDecimal impesp;
	private String indfconv;
	private String liter201;
	private BigDecimal numprop;
	private String opcil;
	private BigDecimal probcscr;
	private String timestam;
	private String zcotesta;
	private String zcotloca;

}
