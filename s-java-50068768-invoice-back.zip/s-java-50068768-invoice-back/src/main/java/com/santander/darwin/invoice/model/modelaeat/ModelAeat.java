/*
 * 
 */
package com.santander.darwin.invoice.model.modelaeat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Instantiates a new models csv.
 */
@NoArgsConstructor
@Getter
@Setter
public class ModelAeat {

	// Listado de modelos adicionales al 200 de agencia tributaria
	// Datos personales
	@NotNull(message = "MODELSCSVLISTNULL")
	// Listado de modelos de AEAT
	private List<ModelsCsv> csvList;
	
	// Exento o no
	private Boolean withOutIva;
	private boolean sencolExecute;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}
