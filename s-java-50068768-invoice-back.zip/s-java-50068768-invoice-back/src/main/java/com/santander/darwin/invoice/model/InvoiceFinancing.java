package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.help.Help;
import com.santander.darwin.invoice.model.simulation.Condition;
import com.santander.darwin.invoice.model.simulation.Disposition;
import com.santander.darwin.invoice.model.soap.NUMPERSONACLIENTEType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;
import java.util.List;

/**
 * InvoiceFinancing.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceFinancing extends InvoiceFinancingExtends {

	// Identificador en mongo
	@Id
	private String id;
	// Identificador de operacion en arm
	private String operationId;
	private String indProce;
	private boolean transfer;
	private String signId;
	private String mode;
	private String lang;
	private String stateFront;
	private String stateProposal;
	// Datos de ayuda
	private Help help;
	// Cliente solicitante
	private NUMPERSONACLIENTEType person;
	private String userId;
	// Financiacion sin redondeo
	private BigDecimal financeAux;
	private BigDecimal amountPorcePar;
	// Datos de firma
	private Sign sign;
	private Disposition disposition;
	private String currency;
	private boolean oriented;
	private boolean hiddenOffice;
	// Intereses del prestamo
	private Interest interests;
	// Condiciones comex
	private Condition conditions;
	// Datos del modelo 200
	private Model200 model200;
	// URLs pantalla final
	private String surveyUrl;
	private String supernetUrl;
	// Facturas a financiar
	private List<InvoiceExtends> invoices;
	// Plazo de financiacion
	private List<Month> months;
	private String range;
	// Comisions de la financiacion
	private List<Commission> commissions;
	// Listado de cuentas del cliente
	private List<Account> accounts;
	// Documentos a imprimir
	private List<Document> documents;

} 