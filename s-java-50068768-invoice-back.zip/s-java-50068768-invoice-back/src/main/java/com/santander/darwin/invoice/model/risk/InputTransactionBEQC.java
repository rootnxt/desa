package com.santander.darwin.invoice.model.risk;

/**
 * InputTransactionBEQC.java
 *
 * @author igndom
 *
 */
public class InputTransactionBEQC {

	private String canalbe;
	private String cdusuar;

	/**
	 * @return the canalbe
	 */
	public String getCanalbe() {
		return canalbe;
	}

	/**
	 * @param canalbe the canalbe to set
	 */
	public void setCanalbe(String canalbe) {
		this.canalbe = canalbe;
	}

	/**
	 * @return the cdusuar
	 */
	public String getCdusuar() {
		return cdusuar;
	}

	/**
	 * @param cdusuar the cdusuar to set
	 */
	public void setCdusuar(String cdusuar) {
		this.cdusuar = cdusuar;
	}

}
