package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * The Data model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class Data implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The user. */
    private User user;

    /** The proposal. */
    private ProposalData proposalData;

}
