package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the limits.
 *
 * @return the limits
 */
@Getter

/**
 * Sets the limits.
 *
 * @param limits the new limits
 */
@Setter

/**
 * Instantiates a new section limit.
 */
@NoArgsConstructor
public class SectionLimit {

    /** The limits. */
    private List<DataLimitOutput> limits;
    
    /** The additionLimits. */
    private List<DataLimitOutput> additionLimits;
    
    /** The only oriented*/
    private boolean onlyOriented;
    
    /** The type P2, P1 or AUT*/
    private boolean allowP2;
    
    /** P2*/
    private boolean p2;

}
