package com.santander.darwin.invoice.model.app_extra;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

/**
 * InvoiceAppExtra.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceAppExtra {

	@Id
	private String id;
	// ID del app
	private String app;
	// Duracion propuestas
	private String proposedDuration;
	// App informe
	private boolean report;

	// Variables relacinadas con uploadAndUpdateDocument
	private int checkDocumentTries;
	private long checkDocumentSleep;
	
	// App informe
	private boolean allCenter;
	private String userCenters;

	// Mostramos las solicitudes de todos los centros
	private boolean showAllCenter;
}