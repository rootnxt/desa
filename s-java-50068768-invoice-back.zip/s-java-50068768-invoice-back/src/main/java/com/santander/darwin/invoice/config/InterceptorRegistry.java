package com.santander.darwin.invoice.config;

import com.santander.darwin.invoice.utils.interceptor.SessionInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * This class registers the RequestNameHandlerInterceptorAdapter to the interceptors registry.
 * The registration enables the interceptor to extract the http request's controller and action names.
 */
@EnableWebMvc
@Configuration
public class InterceptorRegistry implements WebMvcConfigurer {

    // Atributos de clase
    @Autowired
    SessionInterceptor sessionInterceptor;

    /**
     * addInterceptors
     * @param  registry the registry
     */
    @Override
    public void addInterceptors(org.springframework.web.servlet.config.annotation.InterceptorRegistry registry) {
        registry.addInterceptor(sessionInterceptor);
    }
}
