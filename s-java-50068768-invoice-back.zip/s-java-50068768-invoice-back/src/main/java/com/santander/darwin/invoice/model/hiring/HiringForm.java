package com.santander.darwin.invoice.model.hiring;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * HiringForm.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class HiringForm {

	// URL Iframe formulario de contratacion
	private String urlIframe;

}
