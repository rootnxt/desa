/**
 * 
 */
package com.santander.darwin.invoice.model.graddo;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class SendToGraddoOutput.
 *
 * @author x574726
 */

@Getter
@Setter
public class SendToGraddoOutput {
	
	/** The filename. */
	private String filename;
	
}
