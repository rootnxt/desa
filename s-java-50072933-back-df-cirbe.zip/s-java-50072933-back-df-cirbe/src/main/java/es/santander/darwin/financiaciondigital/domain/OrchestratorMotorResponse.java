package es.santander.darwin.financiaciondigital.domain;

import lombok.Builder;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the orchestrator motor response
 */
@Builder

/**
 * Instantiates a new orchestrator motor response.
 */
@NoArgsConstructor

/**
 * Instantiates a new orchestrator motor response.
 *
 * @param reportMotor the report motor
 * @param descriptionReport the description report
 */
@AllArgsConstructor
public class OrchestratorMotorResponse{


    /** The report motor. */
    private String reportMotor;

    /** The description report. */
    private String descriptionReport;



}
