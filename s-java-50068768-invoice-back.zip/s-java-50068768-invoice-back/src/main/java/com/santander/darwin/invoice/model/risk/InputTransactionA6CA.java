package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputTransactionA6CA.java
 *
 * @author igndom
 *
 */
public class InputTransactionA6CA {

	private String canalpre;
	private List<BigDecimal> codpers;
	private String coesref;
	private String idprod;
	private String idsprod;
	private List<String> tipopers;

	/**
	 * @return the canalpre
	 */
	public String getCanalpre() {
		return canalpre;
	}

	/**
	 * @param canalpre the canalpre to set
	 */
	public void setCanalpre(String canalpre) {
		this.canalpre = canalpre;
	}

	/**
	 * @return the codpers
	 */
	public List<BigDecimal> getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(List<BigDecimal> codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the coesref
	 */
	public String getCoesref() {
		return coesref;
	}

	/**
	 * @param coesref the coesref to set
	 */
	public void setCoesref(String coesref) {
		this.coesref = coesref;
	}

	/**
	 * @return the idprod
	 */
	public String getIdprod() {
		return idprod;
	}

	/**
	 * @param idprod the idprod to set
	 */
	public void setIdprod(String idprod) {
		this.idprod = idprod;
	}

	/**
	 * @return the idsprod
	 */
	public String getIdsprod() {
		return idsprod;
	}

	/**
	 * @param idsprod the idsprod to set
	 */
	public void setIdsprod(String idsprod) {
		this.idsprod = idsprod;
	}

	/**
	 * @return the tipopers
	 */
	public List<String> getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(List<String> tipopers) {
		this.tipopers = tipopers;
	}

}
