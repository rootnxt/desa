package com.santander.darwin.invoice.model.refinancing_contracts;

import com.santander.darwin.invoice.model.common.ContractCommon;

/**
 * ClientContract.java
 *
 * @author igndom
 *
 */
public class ClientContract extends ContractCommon {

	private String tipoOperacion;
	private int codPers;
	private String tipoPers;

	/**
	 * @return the tipoOperacion
	 */
	public String getTipoOperacion() {
		return tipoOperacion;
	}

	/**
	 * @param tipoOperacion the tipoOperacion to set
	 */
	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	/**
	 * @return the codPers
	 */
	public int getCodPers() {
		return codPers;
	}

	/**
	 * @param codPers the codPers to set
	 */
	public void setCodPers(int codPers) {
		this.codPers = codPers;
	}

	/**
	 * @return the tipoPers
	 */
	public String getTipoPers() {
		return tipoPers;
	}

	/**
	 * @param tipoPers the tipoPers to set
	 */
	public void setTipoPers(String tipoPers) {
		this.tipoPers = tipoPers;
	}

}
