package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.santander.darwin.financiaciondigital.domain.ConsultPersonResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsultPersonProcessResponseVO;
import es.santander.darwin.financiaciondigital.domain.OrchestratorMotorResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalDto;
import es.santander.darwin.financiaciondigital.domain.RecoveryPhoneAndMailResponse;
import es.santander.darwin.financiaciondigital.domain.SendNotifDto;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

/**
 * The Class RestConsumerCirbeServiceImplTest.
 */
public class RestConsumerCirbeServiceImplTest {

    /** The rest template. */
    @Mock
    private RestTemplate restTemplate;

    /** The json mapper. */
    @Mock
    private ObjectMapper jsonMapper;

    /** The rest consumer cirbe service. */
    @InjectMocks
    private RestConsumerCirbeService restConsumerCirbeService = new RestConsumerCirbeServiceImpl();

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Sen noti sms or email test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void senNotiSmsOrEmailTestOK() throws Exception {

        SendNotifDto sendNotifDto = TestDataUtil.fillDummyObject(new SendNotifDto());

        ReflectionTestUtils.setField(restConsumerCirbeService, "aeatNoti", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(sendNotifDto, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        SendNotifDto result = restConsumerCirbeService.senNotiSmsOrEmail("J", 200, sendNotifDto);
        assertNotNull(result);

    }

    /**
     * Sen noti sms or email test NOK.
     *
     * @throws Exception the exception
     */
    @Test(expected = Exception.class)
    public void senNotiSmsOrEmailTestNOK() throws Exception {

        SendNotifDto sendNotifDto = TestDataUtil.fillDummyObject(new SendNotifDto());

        ReflectionTestUtils.setField(restConsumerCirbeService, "aeatNoti", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(sendNotifDto, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        SendNotifDto result = restConsumerCirbeService.senNotiSmsOrEmail(any(String.class), any(Integer.class),
                any(SendNotifDto.class));
        assertNotNull(result);

    }

    /**
     * Recovery phone mail test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void recoveryPhoneMailTestOK() throws Exception {

        RecoveryPhoneAndMailResponse phoneMailResponse =
                TestDataUtil.fillDummyObject(new RecoveryPhoneAndMailResponse());
        ProposalRequest proposalRequest = TestDataUtil.fillDummyObject(new ProposalRequest());

        ReflectionTestUtils.setField(restConsumerCirbeService, "recoveryPhoneMail", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(phoneMailResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        RecoveryPhoneAndMailResponse result = restConsumerCirbeService.recoveryPhoneMail("J", 200, proposalRequest);
        assertNotNull(result);

    }

    /**
     * Orchestrator motor test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void orchestratorMotorTestOK() throws Exception {

        OrchestratorMotorResponse motorResponse = TestDataUtil.fillDummyObject(new OrchestratorMotorResponse());
        ProposalDto body = TestDataUtil.fillDummyObject(new ProposalDto());

        ReflectionTestUtils.setField(restConsumerCirbeService, "motorUrl", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(motorResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        OrchestratorMotorResponse result = restConsumerCirbeService.orchestratorMotor("J", 200, "uwu", body);
        assertNotNull(result);

    }

    /**
     * Consult person test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void consultPersonTestOK() throws Exception {

        ConsultPersonProcessResponseVO personResponse = TestDataUtil.fillDummyObject(new ConsultPersonProcessResponseVO());

        ReflectionTestUtils.setField(restConsumerCirbeService, "sencolMotorUrlService", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(personResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));
        Map<String, String> bodyParamMap = new HashMap<String, String>();

        //Set your request body params
        bodyParamMap.put("centerId", "0001");
        bodyParamMap.put("proposalYear", "2019");
        bodyParamMap.put("proposalNumber", "4911");
        bodyParamMap.put("companyId", "0049");
        ConsultPersonProcessResponseVO result =
                restConsumerCirbeService.consultPerson(bodyParamMap);
        assertNotNull(result);

    }
    
    
    
    @Test(expected = DigitalConsumptionInternalException.class)
    public void callRestNOK() throws Exception {

        OrchestratorMotorResponse motorResponse = TestDataUtil.fillDummyObject(new OrchestratorMotorResponse());
        ProposalDto body = TestDataUtil.fillDummyObject(new ProposalDto());

        ReflectionTestUtils.setField(restConsumerCirbeService, "motorUrl", "uwu");

        ResponseEntity<?> response = new ResponseEntity<>(motorResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));
        
        doThrow(JsonParseException.class).when(jsonMapper).writeValueAsString(any(Object.class));

        OrchestratorMotorResponse result = restConsumerCirbeService.orchestratorMotor("J", 200, "uwu", body);
        assertNotNull(result);

    }
    
    @Test(expected = DigitalConsumptionInternalException.class)
    public void callRestNOK2() throws Exception {

        ProposalDto body = TestDataUtil.fillDummyObject(new ProposalDto());

        ReflectionTestUtils.setField(restConsumerCirbeService, "motorUrl", "uwu");
        
        RestClientResponseException e = new RestClientResponseException("uwu", 01, "uwu01", null, null, null);

        doThrow(e).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));
        
        OrchestratorMotorResponse result = restConsumerCirbeService.orchestratorMotor("J", 200, "uwu", body);
        assertNotNull(result);

    }

}
