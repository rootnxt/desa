package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Capital.java
 *
 * @author igndom
 *
 */
public class Capital {

	private String amount;
	private Exchange exchange;

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the exchange
	 */
	public Exchange getExchange() {
		return exchange;
	}

	/**
	 * @param exchange the exchange to set
	 */
	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

}
