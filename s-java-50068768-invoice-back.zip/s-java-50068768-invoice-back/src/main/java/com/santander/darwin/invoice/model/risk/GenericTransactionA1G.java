package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * GenericTransactionA1G.java
 *
 * @author igndom
 *
 */
public class GenericTransactionA1G {

	private String canalpre;
	private BigDecimal codpers;
	private String idempr;
	private String tipopers;

	/**
	 * @return the canalpre
	 */
	public String getCanalpre() {
		return canalpre;
	}

	/**
	 * @param canalpre the canalpre to set
	 */
	public void setCanalpre(String canalpre) {
		this.canalpre = canalpre;
	}

	/**
	 * @return the codpers
	 */
	public BigDecimal getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(BigDecimal codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}
}
