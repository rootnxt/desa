package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * OutputTransactionA1R2.java
 *
 * @author igndom
 *
 */
public class OutputTransactionA1R2 extends TransactionA1R2 {

	private String auxilia5;
	private String a1comref;
	private String a1r2f5;
	private String a1r2ok;
	private String a8sitrgo;
	private String codiri;
	private List<String> comentaz;
	private String cotestad;
	private String cotlocal;
	private BigDecimal dias1;
	private String dlocali1;
	private String dsituaci;
	private BigDecimal impaprob;

	public String getAuxilia5() {
		return auxilia5;
	}

	public void setAuxilia5(String auxilia5) {
		this.auxilia5 = auxilia5;
	}

	public String getA1comref() {
		return a1comref;
	}

	public void setA1comref(String a1comref) {
		this.a1comref = a1comref;
	}

	public String getA1r2f5() {
		return a1r2f5;
	}

	public void setA1r2f5(String a1r2f5) {
		this.a1r2f5 = a1r2f5;
	}

	public String getA1r2ok() {
		return a1r2ok;
	}

	public void setA1r2ok(String a1r2ok) {
		this.a1r2ok = a1r2ok;
	}

	public String getA8sitrgo() {
		return a8sitrgo;
	}

	public void setA8sitrgo(String a8sitrgo) {
		this.a8sitrgo = a8sitrgo;
	}

	public String getCodiri() {
		return codiri;
	}

	public void setCodiri(String codiri) {
		this.codiri = codiri;
	}

	public List<String> getComentaz() {
		return comentaz;
	}

	public void setComentaz(List<String> comentaz) {
		this.comentaz = comentaz;
	}

	public String getCotestad() {
		return cotestad;
	}

	public void setCotestad(String cotestad) {
		this.cotestad = cotestad;
	}

	public String getCotlocal() {
		return cotlocal;
	}

	public void setCotlocal(String cotlocal) {
		this.cotlocal = cotlocal;
	}

	public BigDecimal getDias1() {
		return dias1;
	}

	public void setDias1(BigDecimal dias1) {
		this.dias1 = dias1;
	}

	public String getDlocali1() {
		return dlocali1;
	}

	public void setDlocali1(String dlocali1) {
		this.dlocali1 = dlocali1;
	}

	public String getDsituaci() {
		return dsituaci;
	}

	public void setDsituaci(String dsituaci) {
		this.dsituaci = dsituaci;
	}

	public BigDecimal getImpaprob() {
		return impaprob;
	}

	public void setImpaprob(BigDecimal impaprob) {
		this.impaprob = impaprob;
	}
}
