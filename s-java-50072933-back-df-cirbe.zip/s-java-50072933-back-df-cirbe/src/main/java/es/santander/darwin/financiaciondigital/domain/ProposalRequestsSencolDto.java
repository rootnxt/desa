package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ProposalRequestsSencolDto.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the proposal requests sencol dto
 */
@Builder

/**
 * Instantiates a new proposal requests sencol dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new proposal requests sencol dto.
 *
 * @param companyId the company id
 * @param userRequest the user request
 * @param personList the person list
 */
@AllArgsConstructor
public class ProposalRequestsSencolDto {

    /** The company id. */
    @Size(min = 4, max = 4)
    @NotNull
    /** The company id. */
    private String companyId;

    /** The user request. */
    @NotNull
    /** The center id. */
    private String userRequest;

    /** The person list. */
    private List<PersonDtoRequest> personList;
}
