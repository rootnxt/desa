package com.santander.darwin.invoice.model.proceeding_guarantor;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Docs.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Docs {

	// codgdoc
	private String codgdoc;
	private String personNumberDoc;
	
	// intervTypeDoc
	private String intervTypeDoc;
	private String status;
	private String country;
	private String language;
	
	// typeDoc
	private String typeDoc;
	private String gnId;
	private String indDigSealing;
	private String indPreContract;
	
	// typologyDoc
	private String typologyDoc;
	private int numSignRea;
	private int numSignReq;
	
	// signers
	private List<Signers> signers;

}
