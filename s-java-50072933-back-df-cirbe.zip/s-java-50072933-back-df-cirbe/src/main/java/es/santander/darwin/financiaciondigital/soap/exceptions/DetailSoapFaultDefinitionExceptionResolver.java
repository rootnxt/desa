package es.santander.darwin.financiaciondigital.soap.exceptions;

import javax.xml.namespace.QName;

import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;

import es.santander.darwin.financiaciondigital.soap.ServiceFault;

/**
 * The Class DetailSoapFaultDefinitionExceptionResolver.
 */
public class DetailSoapFaultDefinitionExceptionResolver extends SoapFaultMappingExceptionResolver {

    /** The Constant ERROR. */
    private static final QName ERROR = new QName("error");

    /** The Constant DESCRIPTION. */
    private static final QName DESCRIPTION = new QName("description");

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.ws.soap.server.endpoint.AbstractSoapFaultDefinitionExceptionResolver#customizeFault(java.lang
     * .Object, java.lang.Exception, org.springframework.ws.soap.SoapFault)
     */
    @Override
    protected void customizeFault(Object endpoint, Exception ex, SoapFault fault) {
        logger.warn("Exception processed ", ex);
        if (ex instanceof ServiceFaultException) {
            ServiceFault serviceFault = ((ServiceFaultException) ex).getServiceFault();
            SoapFaultDetail detail = fault.addFaultDetail();
            detail.addFaultDetailElement(ERROR).addText(serviceFault.getError());
            detail.addFaultDetailElement(DESCRIPTION).addText(serviceFault.getDescription());
        }
    }
}
