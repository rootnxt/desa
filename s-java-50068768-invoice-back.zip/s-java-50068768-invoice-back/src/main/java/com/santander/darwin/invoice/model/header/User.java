package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * The User model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The fullName. */
    private String fullName;

    /** The documentType. */
    private String documentType;

    /** The documentCode. */
    private String documentCode;

    /** The employeeUid. */
    private String employeeUid;

    /** The employeeNumber. */
    private String employeeNumber;

    /** The segment. */
    private String segment;

    /** The center */
    private String center;

}