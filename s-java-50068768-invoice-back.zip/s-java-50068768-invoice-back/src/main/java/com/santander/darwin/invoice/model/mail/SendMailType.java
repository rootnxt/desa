/**
 *
 */
package com.santander.darwin.invoice.model.mail;

import com.santander.darwin.invoice.repository.MailRepository.TypeMail;
import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * SendMailType
 * 
 * @author jmdonate
 *
 */
@Getter
@Setter
public class SendMailType {

	private String subject;
	private String template;
	private String[] usersMails;
	private TypeMail type;
	private String filename;
	private boolean attachment;
	private File[] files;
	private List<String> lines;
	private Map<String, Object> map;
	
	/**
	 * Constructor
	 *
	 * @param map   Map
	 * @param usersMails String[]
	 * @param type       TypeMail
	 */
	public SendMailType(Map<String, Object> map, String[] usersMails, TypeMail type) {
		super();
		this.map = map;
		this.usersMails = usersMails.clone();
		this.type = type;
	}

	/**
	 * Constructor
	 *
	 * @param usersMails String[]
	 * @param type       TypeMail
	 */
	public SendMailType(String[] usersMails, TypeMail type) {
		super();
		this.usersMails = usersMails.clone();
		this.type = type;
	}

	/**
	 * Constructor
	 * 
	 * @param template   String
	 * @param usersMails String[]
	 * @param type       TypeMail
	 */
	public SendMailType(String template, String[] usersMails, TypeMail type) {
		super();
		this.template = template;
		this.usersMails = usersMails.clone();
		this.type = type;
		this.files = new File[0];
	}

	/**
	 * @return the usersMails
	 */
	public String[] getUsersMails() {
		return usersMails.clone();
	}

	/**
	 * @param usersMails the usersMails to set
	 */
	public void setUsersMails(String[] usersMails) {
		this.usersMails = usersMails.clone();
	}

	/**
	 * @return the file
	 */
	public File[] getFiles() {
		return files.clone();
	}

	/**
	 * @param file the file to set
	 */
	public void setFiles(File[] files) {
		this.files = files.clone();
	}

	/**
	 * SendMailType.java
	 *
	 * @author igndom
	 *
	 */
	@Getter
	@Setter
	public static class RepresentativeMail {

		private String name;
		private String phone;
		private String email;

	}

}
