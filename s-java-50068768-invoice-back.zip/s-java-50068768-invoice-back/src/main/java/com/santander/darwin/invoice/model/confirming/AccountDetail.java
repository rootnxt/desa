package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * AccountDetail.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class AccountDetail {
	// Datos de la cuenta
	private String paymentTypeCode;
	private String paymentTypeDescription;
	private Account account;
}