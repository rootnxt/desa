package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.domain.OrchestratorMotorResponse;
import es.santander.darwin.financiaciondigital.domain.PersonDtoRequest;
import es.santander.darwin.financiaciondigital.domain.ProposalDto;
import es.santander.darwin.financiaciondigital.domain.RecoveryPhoneAndMailResponse;
import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.domain.SendNotifDto;
import es.santander.darwin.financiaciondigital.dto.PropuestaRgoDto;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntityPK;
import es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest;
import es.santander.darwin.financiaciondigital.lib.model.ProposalPersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.ProposedInformation;
import es.santander.darwin.financiaciondigital.lib.model.bean.Person;
import es.santander.darwin.financiaciondigital.lib.model.bean.ProcessIdentifier;
import es.santander.darwin.financiaciondigital.lib.model.bean.Product;
import es.santander.darwin.financiaciondigital.lib.model.bean.ProposalCode;
import es.santander.darwin.financiaciondigital.lib.model.bean.ProposalData;
import es.santander.darwin.financiaciondigital.lib.model.bean.RequestPersonIdentifier;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAService;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import es.santander.darwin.financiaciondigital.soap.repositories.PropuestaRgoJpaRepository;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

public class CirbeAsyncHelperTest {

    @InjectMocks
    private CirbeAsyncHelper cirbeAsyncHelper = new CirbeAsyncHelper();

    @Mock
    private RestConsumerCirbeService restConsumerCirbeService;

    @Mock
    private PropuestaRgoJpaRepository propuestaRgoJpaRepository;

    @Mock
    private CirbeSasnaServiceImpl cirbeSasnaServiceImpl;

    @Mock
    private RestConsumerService restConsumerService;

    @Mock
    private DatosUsuarioLAService datosUsuarioLA;

    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void callSasnaTestOK() throws Exception {

        SasnaResponse sasnaResponse = new SasnaResponse();
        sasnaResponse.setCode("");
        sasnaResponse.setMessage("");

        doReturn(sasnaResponse).when(cirbeSasnaServiceImpl).callSasna(any(String.class), any(String.class),
                any(BigDecimal.class), any(String.class));

        Future<SasnaResponse> result = cirbeAsyncHelper.callSasna(any(String.class), any(String.class),
                any(BigDecimal.class), any(String.class));

        assertNotNull(result);

    }

    @Test
    public void getSendNotifAsyncTestOK() throws Exception {

        restConsumerCirbeService.senNotiSmsOrEmail(any(String.class), any(Integer.class), any(SendNotifDto.class));
        Future<Void> result =
                cirbeAsyncHelper.getSendNotifAsync(any(String.class), any(Integer.class), any(SendNotifDto.class));
        assertNotNull(result);
    }

    @Ignore
    @Test(expected = DigitalConsumptionInternalException.class)
    public void getSendNotifAsyncTestNOK() throws Exception {

        doThrow(Exception.class).when(restConsumerCirbeService).senNotiSmsOrEmail(
                any(String.class), any(Integer.class),
                any(SendNotifDto.class));
        Future<Void> result =
                cirbeAsyncHelper.getSendNotifAsync(any(String.class), any(Integer.class), any(SendNotifDto.class));
        assertNotNull(result);
    }

    @Test
    public void callOrchestratorAsyncTestOK() throws Exception {

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        Future<OrchestratorMotorResponse> responseFuture =
                cirbeAsyncHelper.callOrchestratorAsync(any(String.class), any(Integer.class),
                        any(String.class), any(ProposalDto.class));
        assertNotNull(responseFuture);

    }

    @Test
    public void callModResolutionsTestOK() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        // doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
        // any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
        // any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }

    @Test(expected = DigitalConsumptionServiceException.class)
    public void callModResolutionsTestOK2() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }

    @Test(expected = DigitalConsumptionServiceException.class)
    public void callModResolutionsTestOK3() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }

    @Test
    public void callModResolutionsTestOK4() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        ProposedInformation proposedInformation = TestDataUtil.fillDummyObject(new ProposedInformation());
        ProcessIdentifier processIdentifier = TestDataUtil.fillDummyObject(new ProcessIdentifier());
        ProposalCode proposalCode = new ProposalCode();
        proposalCode.setCenter("0282");
        proposalCode.setCompany("0049");
        proposalCode.setProposalNumber(12345);
        proposalCode.setYear(2019);
        processIdentifier.setProposalCode(proposalCode);
        Person person = new Person();
        person.setPersonCode(1234);
        person.setPersonType("J");
        processIdentifier.setPerson(person);
        Product product = TestDataUtil.fillDummyObject(new Product());
        processIdentifier.setProduct(product);
        ProposalData proposalData = new ProposalData();
        proposalData.setUpdateProposalTimestamp(LocalDateTime.now());
        proposalData.setProposalState("02");
        proposedInformation.setProposalData(proposalData);
        proposedInformation.setProcessIdentifier(processIdentifier);
        
        ReflectionTestUtils.setField(cirbeAsyncHelper, "smsAC", "uwu");
        ReflectionTestUtils.setField(cirbeAsyncHelper, "mailAC", "uwu");
        ReflectionTestUtils.setField(cirbeAsyncHelper, "contrat", "uwu");

        RecoveryPhoneAndMailResponse email = new RecoveryPhoneAndMailResponse();
        email.setEmail("uwu@uwu.cl");
        email.setInternationalPrefix("+34");
        email.setPhoneNumber("1234567");

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposedInformation).when(restConsumerService).sencolUpdate(any(String.class), any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        doReturn(email).when(restConsumerCirbeService).recoveryPhoneMail(any(String.class), any(Integer.class),
                any(ProposalRequest.class));
        
        doReturn("uwu").when(datosUsuarioLA).getUserName(any(String.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }
    
    @Test
    public void callModResolutionsTestOK5() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        ProposedInformation proposedInformation = TestDataUtil.fillDummyObject(new ProposedInformation());
        ProcessIdentifier processIdentifier = TestDataUtil.fillDummyObject(new ProcessIdentifier());
        ProposalCode proposalCode = new ProposalCode();
        proposalCode.setCenter("0282");
        proposalCode.setCompany("0049");
        proposalCode.setProposalNumber(12345);
        proposalCode.setYear(2019);
        processIdentifier.setProposalCode(proposalCode);
        Person person = new Person();
        person.setPersonCode(1234);
        person.setPersonType("J");
        processIdentifier.setPerson(person);
        Product product = TestDataUtil.fillDummyObject(new Product());
        processIdentifier.setProduct(product);
        ProposalData proposalData = new ProposalData();
        proposalData.setUpdateProposalTimestamp(LocalDateTime.now());
        proposalData.setProposalState("06");
        proposedInformation.setProposalData(proposalData);
        proposedInformation.setProcessIdentifier(processIdentifier);
        
        ReflectionTestUtils.setField(cirbeAsyncHelper, "smsDL", "uwu");
        ReflectionTestUtils.setField(cirbeAsyncHelper, "mailDL", "uwu");

        RecoveryPhoneAndMailResponse email = new RecoveryPhoneAndMailResponse();
        email.setEmail("uwu@uwu.cl");
        email.setInternationalPrefix("+34");
        email.setPhoneNumber("1234567");

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposedInformation).when(restConsumerService).sencolUpdate(any(String.class), any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        doReturn(email).when(restConsumerCirbeService).recoveryPhoneMail(any(String.class), any(Integer.class),
                any(ProposalRequest.class));
        
        doReturn("uwu").when(datosUsuarioLA).getUserName(any(String.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }
    
    @Test
    public void callModResolutionsTestOK6() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("02");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }
    
    @Test
    public void callModResolutionsTestOK7() throws Exception {
        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonRequest.setSubApplication("sencol");
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("02");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        PersonDtoRequest person = PersonDtoRequest.builder()
        		.bdeCode("bdeCode")
        		.bdeDescription("bdescription")
        		.personType("F")
        		.personCode(new BigDecimal(12034))
        		.build();
        
        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        doReturn("www.santander.cl/cirbe/sencol").when(restConsumerService)
        	.getValidEndpoint(Constants.APP_NAME, proposalPersonRequest.getSubApplication());
        
        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, person);
        assertNotNull(responseFuture);
    }
    
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callModResolutionsTestNOK1() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("02");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doThrow(EmptyStackException.class).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

		Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null );
        assertNotNull(responseFuture);
    }
    
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callModResolutionsTestNOK2() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doThrow(EmptyStackException.class).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }
    
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callModResolutionsTestNOK3() throws Exception {

        List<ProposalPersonRequests> proposalPersonResponseList = new ArrayList<>();
        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
        requestPersonIdentifier.setCenterId("0282");
        requestPersonIdentifier.setCompanyId("0049");
        requestPersonIdentifier.setPersonCode(1234);
        requestPersonIdentifier.setPersonType("J");
        requestPersonIdentifier.setProposalNumber(12345);
        requestPersonIdentifier.setProposalYear(2019);
        requestPersonIdentifier.setSourceType("uwu");
        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
        proposalPersonRequest.setInterventionType("uwu");
        proposalPersonRequest.setModificationDate(new Date());
        proposalPersonRequest.setModificationUser("uwu");
        proposalPersonRequest.setProcessIndicator("uwu");
        proposalPersonRequest.setSourceState("uwu");
        proposalPersonRequest.setId("1234");
        proposalPersonRequest.setCriticalityData("uwu");
        proposalPersonRequest.setAdmissionDate(new Date());
        proposalPersonResponseList.add(proposalPersonRequest);

        ProposedInformation proposedInformation = TestDataUtil.fillDummyObject(new ProposedInformation());
        ProcessIdentifier processIdentifier = TestDataUtil.fillDummyObject(new ProcessIdentifier());
        ProposalCode proposalCode = new ProposalCode();
        proposalCode.setCenter("0282");
        proposalCode.setCompany("0049");
        proposalCode.setProposalNumber(12345);
        proposalCode.setYear(2019);
        processIdentifier.setProposalCode(proposalCode);
        Person person = new Person();
        person.setPersonCode(1234);
        person.setPersonType("J");
        processIdentifier.setPerson(person);
        Product product = TestDataUtil.fillDummyObject(new Product());
        processIdentifier.setProduct(product);
        ProposalData proposalData = new ProposalData();
        proposalData.setUpdateProposalTimestamp(LocalDateTime.now());
        proposalData.setProposalState("06");
        proposedInformation.setProposalData(proposalData);
        proposedInformation.setProcessIdentifier(processIdentifier);
        
        ReflectionTestUtils.setField(cirbeAsyncHelper, "smsDL", "uwu");
        ReflectionTestUtils.setField(cirbeAsyncHelper, "mailDL", "uwu");

        RecoveryPhoneAndMailResponse email = new RecoveryPhoneAndMailResponse();
        email.setEmail("uwu@uwu.cl");
        email.setInternationalPrefix("+34");
        email.setPhoneNumber("1234567");

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        propuestaRgoEntity.get().setCotestad("01");
        propuestaRgoEntity.get().setIndproce("FD");

        OrchestratorMotorResponse response = new OrchestratorMotorResponse();
        response.setDescriptionReport("uwu");
        response.setReportMotor("uwu");

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        doReturn(response).when(restConsumerCirbeService).orchestratorMotor(any(String.class), any(Integer.class),
                any(String.class), any(ProposalDto.class));

        doThrow(EmptyStackException.class).when(restConsumerService).sencolUpdate(any(String.class), any(String.class),
                any(String.class), any(Integer.class), any(String.class));

        doReturn(email).when(restConsumerCirbeService).recoveryPhoneMail(any(String.class), any(Integer.class),
                any(ProposalRequest.class));
        
        doReturn("uwu").when(datosUsuarioLA).getUserName(any(String.class));

        doReturn(proposalPersonResponseList).when(restConsumerService).getProposalRequestsUpdate(any(String.class),
                any(Integer.class), any(String.class), any(String.class), any(String.class), any(Integer.class),
                any(String.class));

        Future<SencolResponse> responseFuture =
                cirbeAsyncHelper.callModResolutions(proposalPersonResponseList, null);
        assertNotNull(responseFuture);
    }

    @Test
    public void callPropuestaRgoDtoTestOK() throws Exception {

        Optional<PropuestaRgoEntity> propuestaRgoEntity =
                Optional.of(TestDataUtil.fillDummyObject(new PropuestaRgoEntity()));

        doReturn(propuestaRgoEntity).when(propuestaRgoJpaRepository).findById(any(PropuestaRgoEntityPK.class));

        Future<PropuestaRgoDto> responseFuture =
                cirbeAsyncHelper.callPropuestaRgoDto("0049", "0282", "2019", new BigDecimal("1234"));
        assertNotNull(responseFuture);
    }

}
