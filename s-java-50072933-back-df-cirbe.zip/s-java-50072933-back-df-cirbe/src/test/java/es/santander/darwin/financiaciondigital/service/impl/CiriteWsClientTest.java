package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import es.santander.darwin.financiaciondigital.service.CiriteWsClient;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

/**
 * The Class CiriteWsClientTest.
 */
public class CiriteWsClientTest {

    /** The web service gateway support. */
    @Mock
    private WebServiceGatewaySupport webServiceGatewaySupport;

    /** The web service template. */
    @Mock
    private WebServiceTemplate webServiceTemplate;

    /** The cirite ws client. */
    @InjectMocks
    private CiriteWsClient ciriteWsClient;

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Cirite ws client test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void CiriteWsClientTestOK() throws Exception {

        AltModifCiriteRequestResponse response = TestDataUtil.fillDummyObject(new AltModifCiriteRequestResponse());
        AltModifCiriteRequest request = new AltModifCiriteRequest();

        doReturn(response).when(webServiceTemplate).marshalSendAndReceive(any(String.class),
                any(AltModifCiriteRequest.class), any(SoapActionCallback.class));
        
        ReflectionTestUtils.setField(ciriteWsClient, "soapAction", "uwu");

        AltModifCiriteRequestResponse result =
                ciriteWsClient.executeSoapRequest("endpoint", request);
        assertNotNull(result);

    }

}
