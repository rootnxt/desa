package com.santander.darwin.invoice.constants;

/**
 * The Class SwaggerConstants.
 */
public class SwaggerConstants {
	
	/** The Constant TAG_NAME. */
	public static final String TAG_NAME = "Piloto";
	
	/** The Constant TAG_DESCRIPTION. */
	public static final String TAG_DESCRIPTION = "Piloto controllers";

	/** The Constant CODE_200. */
	public static final String CODE_200 = "200";

	/** The Constant CODE_400. */
	public static final String CODE_400 = "400";

	/** The Constant CODE_401. */
	public static final String CODE_401 = "401";

	/** The Constant CODE_403. */
	public static final String CODE_403 = "403";

	/** The Constant CODE_404. */
	public static final String CODE_404 = "404";

	/** The Constant CODE_500. */
	public static final String CODE_500 = "500";

	/** The Constant OK. */
	public static final String OK = "OK";

	/** The Constant BAD_REQUEST. */
	public static final String BAD_REQUEST = "BAD REQUEST";

	/** The Constant UNAUTHORIZED. */
	public static final String UNAUTHORIZED = "UNAUTHORIZED";

	/** The Constant FORBIDDEN. */
	public static final String FORBIDDEN = "FORBIDDEN";

	/** The Constant NOT_FOUND. */
	public static final String NOT_FOUND = "NOT FOUND";

	/** The Constant INTERNAL_SERVER_ERROR. */
	public static final String INTERNAL_SERVER_ERROR = "INTERNAL SERVER ERROR";

	/** The Constant SUMMARY_API_COND. */
	public static final String SUMMARY_CREATE_PILOT = "Create pilot";
	
	/** The Constant SUMMARY_API_COND_DES_CONSULTA. */
	public static final String SUMMARY_CREATE_PILOT_DES = "This service create pilot";
	
	/**
	 * Comentario para sonar
	 */
	private SwaggerConstants() {
		throw new IllegalStateException("Utility class");
	}
	
}
