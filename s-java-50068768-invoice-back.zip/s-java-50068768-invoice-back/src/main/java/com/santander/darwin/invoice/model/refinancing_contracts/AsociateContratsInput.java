/**
 * 
 */
package com.santander.darwin.invoice.model.refinancing_contracts;

import java.math.BigDecimal;

/**
 * AsociateContratsInput
 * 
 * @author josdon
 *
 */
public class AsociateContratsInput {

	// Partenon alphanumeric (A) - Length (4)
	private String anoprop;

	// Partenon alphanumeric (A) - Length (1)
	private String asocia;

	// Partenon alphanumeric (A) - Length (42)
	private String a1oculto;

	// Partenon alphanumeric (A) - Length (3)
	private String codmonct;

	// Partenon alphanumeric (A) - Length (4)
	private String idcent;

	// Partenon alphanumeric (A) - Length (4)
	private String idcentc;

	// Partenon alphanumeric (A) - Length (7)
	private String idcontr;

	// Partenon alphanumeric (A) - Length (4)
	private String idempr;

	// Partenon alphanumeric (A) - Length (4)
	private String idemprc;

	// Partenon alphanumeric (A) - Length (3)
	private String idprodc;

	// Partenon signed numeric (L) - Length (16, 2)
	private BigDecimal impactto;

	// Partenon signed numeric (L) - Length (18, 2)
	private BigDecimal impaptu2;

	// Partenon unsigned numeric (N) - Length (5, 0)
	private BigDecimal numprop;

	/**
	 * @return the anoprop
	 */
	public String getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(String anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the asocia
	 */
	public String getAsocia() {
		return asocia;
	}

	/**
	 * @param asocia the asocia to set
	 */
	public void setAsocia(String asocia) {
		this.asocia = asocia;
	}

	/**
	 * @return the a1oculto
	 */
	public String getA1oculto() {
		return a1oculto;
	}

	/**
	 * @param a1oculto the a1oculto to set
	 */
	public void setA1oculto(String a1oculto) {
		this.a1oculto = a1oculto;
	}

	/**
	 * @return the codmonct
	 */
	public String getCodmonct() {
		return codmonct;
	}

	/**
	 * @param codmonct the codmonct to set
	 */
	public void setCodmonct(String codmonct) {
		this.codmonct = codmonct;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idcentc
	 */
	public String getIdcentc() {
		return idcentc;
	}

	/**
	 * @param idcentc the idcentc to set
	 */
	public void setIdcentc(String idcentc) {
		this.idcentc = idcentc;
	}

	/**
	 * @return the idcontr
	 */
	public String getIdcontr() {
		return idcontr;
	}

	/**
	 * @param idcontr the idcontr to set
	 */
	public void setIdcontr(String idcontr) {
		this.idcontr = idcontr;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the idemprc
	 */
	public String getIdemprc() {
		return idemprc;
	}

	/**
	 * @param idemprc the idemprc to set
	 */
	public void setIdemprc(String idemprc) {
		this.idemprc = idemprc;
	}

	/**
	 * @return the idprodc
	 */
	public String getIdprodc() {
		return idprodc;
	}

	/**
	 * @param idprodc the idprodc to set
	 */
	public void setIdprodc(String idprodc) {
		this.idprodc = idprodc;
	}

	/**
	 * @return the impactto
	 */
	public BigDecimal getImpactto() {
		return impactto;
	}

	/**
	 * @param impactto the impactto to set
	 */
	public void setImpactto(BigDecimal impactto) {
		this.impactto = impactto;
	}

	/**
	 * @return the impaptu2
	 */
	public BigDecimal getImpaptu2() {
		return impaptu2;
	}

	/**
	 * @param impaptu2 the impaptu2 to set
	 */
	public void setImpaptu2(BigDecimal impaptu2) {
		this.impaptu2 = impaptu2;
	}

	/**
	 * @return the numprop
	 */
	public BigDecimal getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(BigDecimal numprop) {
		this.numprop = numprop;
	}

}
