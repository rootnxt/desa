package com.santander.darwin.invoice.model.proceeding_guarantor;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Signer.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Signer {
	
	// personNumber 
    private String personNumber;
    private String fullName;
    private String intervType;
    
    // identityDocument
	private String identityDocument;
	
	// represented
	private List<SignerRepresented> represented;
}
