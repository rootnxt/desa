package es.santander.darwin.financiaciondigital.soap.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import es.santander.darwin.financiaciondigital.constant.Queries;
import es.santander.darwin.financiaciondigital.lib.model.ProposalPersonRequests;

/**
 * The Interface ProposalPersonRequestsRepository.
 */
@Repository
public interface ProposalPersonRequestsRepository extends MongoRepository<ProposalPersonRequests, String> {
    
    /**
     * Find proposal person requests for petitions.
     *
     * @param company the company
     * @param center the center
     * @param proposalYear the proposal year
     * @param proposalNumber the proposal number
     * @return the proposal person requests
     */
    @Query(Queries.PROPOSAL_PERSON_REQUEST_FOR_PETITIONS)
    List<ProposalPersonRequests> findProposalPersonRequestsForPetitions(String company, String center, int proposalYear,
            int proposalNumber);
    
    /**
     * Find proposal person requests by request identifier.
     *
     * @param company the company
     * @param center the center
     * @param proposalYear the proposal year
     * @param proposalNumber the proposal number
     * @param personType the person type
     * @param personCode the person code
     * @param sourceType the source type
     * @return the list
     */
    @Query(Queries.PROPOSAL_PERSON_REQUEST_BY_IDENTIFIER)
    List<ProposalPersonRequests> findProposalPersonRequestsByRequestIdentifier(String company, String center,
            int proposalYear, int proposalNumber, String personType, int personCode, String sourceType);

}
