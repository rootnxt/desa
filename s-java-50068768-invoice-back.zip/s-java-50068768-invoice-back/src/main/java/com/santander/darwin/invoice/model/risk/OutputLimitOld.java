package com.santander.darwin.invoice.model.risk;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * OutputLimit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class OutputLimitOld {

	// Variables

	// Para swagger
	@Schema(example = "S", description = "Ind of campaign")
	@JsonProperty("IndCampaign")
	@NotNull(message = "INDCAMPAIGN")
	private String indCampaign;

	// Para swagger
	@Schema(example = "OCD001", description = "Code of campaign")
	@JsonProperty("codCampaign")
	@NotNull(message = "CODCAMPAIGN")
	private String codCampaign;

	// Para swagger
	@Schema(example = "EUR", description = "Currency")
	@JsonProperty("Currency")
	@NotNull(message = "CURRENCY")
	private String currency;

	// Para swagger
	@Schema(example = "T05", description = "Triad of fam")
	@JsonProperty("FamTriad")
	@NotNull(message = "FAMTRIAD")
	private String famTriad;

	// Para swagger
	@Schema(example = "999999", description = "Max of amount")
	@JsonProperty("MaxAmount")
	@NotNull(message = "MAXAMOUNT")
	private BigDecimal maxAmount;

	// Para swagger
	@Schema(example = "1", description = "Min of amount")
	@JsonProperty("MinAmount")
	@NotNull(message = "MINAMOUNT")
	private BigDecimal minAmount;

	// Para swagger
	@Schema(example = "999999", description = "Limit")
	@JsonProperty("Limit")
	@NotNull(message = "LIMIT")
	private BigDecimal limit;

	// Para swagger
	@Schema(example = "2", description = "Term")
	@JsonProperty("Plazo")
	@NotNull(message = "PLAZO")
	private BigDecimal plazo;

	private List<Orientado> orientado;

}
