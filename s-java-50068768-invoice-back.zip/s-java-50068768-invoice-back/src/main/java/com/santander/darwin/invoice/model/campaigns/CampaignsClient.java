package com.santander.darwin.invoice.model.campaigns;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CampaignsClient.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CampaignsClient {

	// entries
	private List<Campaign> entries;
}