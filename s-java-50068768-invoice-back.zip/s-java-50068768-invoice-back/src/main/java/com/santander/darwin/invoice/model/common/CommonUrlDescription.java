package com.santander.darwin.invoice.model.common;

/**
 * CommonUrlDescription.java
 *
 * @author igndom
 *
 */
public class CommonUrlDescription {
	
	private String url;
	private String description;

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
