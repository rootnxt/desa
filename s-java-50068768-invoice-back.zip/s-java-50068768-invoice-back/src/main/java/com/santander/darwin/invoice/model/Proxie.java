package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Proxie.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Proxie extends CommonData {

	// Atributos de la clase
	private List<Representative> proxies;
	private boolean signed;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;
}
