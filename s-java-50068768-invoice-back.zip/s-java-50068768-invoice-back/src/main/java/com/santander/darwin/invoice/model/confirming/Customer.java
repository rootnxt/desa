package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Customer.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Customer {
	// Datos de Customer
	private Person person;
	private ContactPoint contactPoint;
	// Datos de Customer
	private Organization organization;
	private String customerId;
}