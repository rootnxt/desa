package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Person.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Person {
	// Datos de Person
	private PersonName personName;
	private Object economicActivity;
	private Object documents;
}