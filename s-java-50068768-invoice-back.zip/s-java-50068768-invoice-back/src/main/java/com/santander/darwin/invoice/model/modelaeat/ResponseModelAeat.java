/**
 * 
 */
package com.santander.darwin.invoice.model.modelaeat;

import lombok.Getter;
import lombok.Setter;

/**
 * ResponseModelAeat
 * @author josdon
 *
 */
@Getter
@Setter
public class ResponseModelAeat {
	
	// OK, EN CURSO, Mensaje de error
	private String estado;

}
