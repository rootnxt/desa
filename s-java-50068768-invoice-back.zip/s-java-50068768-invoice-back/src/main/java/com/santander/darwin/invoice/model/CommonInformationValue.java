package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

/**
 * CommonInformationValue class
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class CommonInformationValue extends CommonInformation {

	// Value
	private String value;
	
	// color
	private String color;

	/**
	 * Constructor default
	 */
	public CommonInformationValue() {
		super();
	}

	/**
	 * Constructor with params
	 * @param id the id
	 * @param name the name
	 * @param value the value
	 */
	public CommonInformationValue(String id, String name, String value) {
		super(id, name);
		this.value = value;
	}

	

}
