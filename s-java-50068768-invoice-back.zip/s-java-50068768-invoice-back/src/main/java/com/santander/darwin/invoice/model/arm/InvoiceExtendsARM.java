package com.santander.darwin.invoice.model.arm;

import com.santander.darwin.invoice.model.Invoice;

import java.math.BigDecimal;

/**
 * InvoiceExtendsARM.java
 *
 * @author igndom
 *
 */
public class InvoiceExtendsARM extends Invoice {

	//Variable de financiacion
	private BigDecimal finance;

	/**
	 * @return the finance
	 */
	public BigDecimal getFinance() {
		return finance;
	}

	/**
	 * @param finance the finance to set
	 */
	public void setFinance(BigDecimal finance) {
		this.finance = finance;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// ToString enviado a arm
		return "[invoiceId:" + getInvoiceId() + ",invoiceSerialAndNumber:" + getInvoiceSerialAndNumber()
				+ ",invoiceCreationDate:" + getInvoiceCreationDate() + ",invoiceDate:" + getInvoiceDate()
				+ ",invoiceExpirationDate:" + getInvoiceExpirationDate() + ",invoicePaymentDate:"
				+ getInvoicePaymentDate() + ",invoiceTotal:" + getInvoiceTotal() + ",invoiceName:" + getInvoiceName()
				+ ",invoiceDocument:" + getInvoiceDocument() + ",invoiceCurrency:" + getInvoiceCurrency() + ",finance:"
				+ finance + "]";
	}

}
