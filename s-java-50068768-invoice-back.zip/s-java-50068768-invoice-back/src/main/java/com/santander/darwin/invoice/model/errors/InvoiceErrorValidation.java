package com.santander.darwin.invoice.model.errors;

import org.springframework.data.annotation.Id;

import java.io.Serializable;

/**
 * InvoiceErrorValidation.java
 *
 * @author igndom
 *
 */
public class InvoiceErrorValidation implements Serializable {

	private static final long serialVersionUID = 3155563758082002122L;

	@Id
    private transient String id;
	private String code;
	private String shortMessage;
	private String detailMessageES;
	private String detailMessageCA;
	private String detailMessageEU;
	private String detailMessageGL;
	private String detailMessageDE;
	private String detailMessageEN;
	private String channel;

	/**
	 * Constructor
	 *
	 */
	public InvoiceErrorValidation() {
		super();
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the shortMessage
	 */
	public String getShortMessage() {
		return shortMessage;
	}

	/**
	 * @param shortMessage the shortMessage to set
	 */
	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}

	/**
	 * @return the detailMessageES
	 */
	public String getDetailMessageES() {
		return detailMessageES;
	}

	/**
	 * @param detailMessageES the detailMessageES to set
	 */
	public void setDetailMessageES(String detailMessageES) {
		this.detailMessageES = detailMessageES;
	}

	/**
	 * @return the detailMessageCA
	 */
	public String getDetailMessageCA() {
		return detailMessageCA;
	}

	/**
	 * @param detailMessageCA the detailMessageCA to set
	 */
	public void setDetailMessageCA(String detailMessageCA) {
		this.detailMessageCA = detailMessageCA;
	}

	/**
	 * @return the detailMessageEU
	 */
	public String getDetailMessageEU() {
		return detailMessageEU;
	}

	/**
	 * @param detailMessageEU the detailMessageEU to set
	 */
	public void setDetailMessageEU(String detailMessageEU) {
		this.detailMessageEU = detailMessageEU;
	}

	/**
	 * @return the detailMessageGL
	 */
	public String getDetailMessageGL() {
		return detailMessageGL;
	}

	/**
	 * @param detailMessageGL the detailMessageGL to set
	 */
	public void setDetailMessageGL(String detailMessageGL) {
		this.detailMessageGL = detailMessageGL;
	}

	/**
	 * @return the detailMessageDE
	 */
	public String getDetailMessageDE() {
		return detailMessageDE;
	}

	/**
	 * @param detailMessageDE the detailMessageDE to set
	 */
	public void setDetailMessageDE(String detailMessageDE) {
		this.detailMessageDE = detailMessageDE;
	}

	/**
	 * @return the detailMessageEN
	 */
	public String getDetailMessageEN() {
		return detailMessageEN;
	}

	/**
	 * @param detailMessageEN the detailMessageEN to set
	 */
	public void setDetailMessageEN(String detailMessageEN) {
		this.detailMessageEN = detailMessageEN;
	}
	
	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

}
