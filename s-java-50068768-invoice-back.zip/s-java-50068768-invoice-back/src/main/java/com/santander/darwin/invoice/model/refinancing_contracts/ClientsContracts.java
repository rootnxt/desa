package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * ClientsContracts.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class ClientsContracts {
	
	// clientesContratos
	private List<ClientContract> clientesContratos;

}
