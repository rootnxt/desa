package com.santander.darwin.invoice.converter;

import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

/**
 * StringToMongoLocalDateTimeConverter
 * 
 * @author igndom
 *
 */
public class StringToMongoLocalDateTimeConverter implements Converter<String, MongoLocalDateTime> {

	// Source
	private static final TypeDescriptor SOURCE = TypeDescriptor.valueOf(String.class);
	// Target
	private static final TypeDescriptor TARGET = TypeDescriptor.valueOf(MongoLocalDateTime.class);

	@Override
	public MongoLocalDateTime convert(String source) {
		try {
			// Convertidor custom de string a mongo
			return MongoLocalDateTime.of(LocalDateTime.parse(source, MongoLocalDateTime.DATE_FORMATTER));
		} catch (DateTimeParseException ex) {
			// Fallo al intentar convertir
			throw new ConversionFailedException(SOURCE, TARGET, source, ex);
		}
	}
}
