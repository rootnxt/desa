package es.santander.darwin.financiaciondigital.service.impl;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.RegExUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.constant.ErrorConstants;
import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.domain.ConsultPersonProcessResponseVO;
import es.santander.darwin.financiaciondigital.domain.PersonVO;
import es.santander.darwin.financiaciondigital.domain.PetitionsTreatmentProcessResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolDto;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolMotorDTO;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.domain.SourceTypeVO;
import es.santander.darwin.financiaciondigital.dto.PropuestaRgoDto;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.jpa.model.PersoPropuestaEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntityPK;
import es.santander.darwin.financiaciondigital.lib.model.PersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.ProposalPersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.bean.PersonDto;
import es.santander.darwin.financiaciondigital.lib.model.bean.ProposalRequestsSencol;
import es.santander.darwin.financiaciondigital.lib.model.bean.RequestPersonIdentifier;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.CirbeService;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import es.santander.darwin.financiaciondigital.soap.DataPerson;
import es.santander.darwin.financiaciondigital.soap.GetPersonRequest;
import es.santander.darwin.financiaciondigital.soap.GetPersonResponse;
import es.santander.darwin.financiaciondigital.soap.PersAndPropsListVO;
import es.santander.darwin.financiaciondigital.soap.PersonAndProposalVO;
import es.santander.darwin.financiaciondigital.soap.PersonListVO;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalResponse;
import es.santander.darwin.financiaciondigital.soap.SourcesListVO;
import es.santander.darwin.financiaciondigital.soap.SourcesVO;
import es.santander.darwin.financiaciondigital.soap.repositories.PersonProposalJpaRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.PersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.ProposalPersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.PropuestaRgoJpaRepository;
import lombok.extern.slf4j.Slf4j;

/** The Constant log. */
@Slf4j
@Service
public class CirbeServiceImpl implements CirbeService {

    /** The rest consumer service. */
    @Autowired
    private RestConsumerService restConsumerService;

    /** The rest consumer cirbe service. */
    @Autowired
    private RestConsumerCirbeService restConsumerCirbeService;

    /** The cirbe async service. */
    @Autowired
    private CirbeAsyncHelper cirbeAsyncHelper;

    /** The information control process repository. */
    @Autowired
    private PersonRequestsRepository personRequestsRepository;

    /** The proposal person requests repository. */
    @Autowired
    private ProposalPersonRequestsRepository proposalPersonRequestsRepository;

    /** The propuesta rgo jpa repository. */
    @Autowired
    private PropuestaRgoJpaRepository propuestaRgoJpaRepository;

    /** The perso prop repository. */
    @Autowired
    private PersonProposalJpaRepository persoPropRepository;

    /** The parametro corte. */
    @Value("${cirbe.consolidado.parametro-corte}")
    private Integer parametroCorte;

    /** The limite peticiones. */
    @Value("${cirbe.limite-peticiones}")
    private Integer limitePeticiones;

    /** The mock alta. */
    @Value("${cirbe.mockAlta}")
    private String mockAlta;

    /** The res alta. */
    @Value("${cirbe.resAlta}")
    private String resAlta;

    /** The source type. */
    @Value("${cirbe.sourceType}")
    private String sourceType;

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.CirbeService#callSencol(es.
     * santander.darwin.financiaciondigital. domain.ProposalRequestsSencolDto)
     */
    @Override
    public SencolResponse callSencol(ProposalRequestsSencolDto body)
            throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {
        SencolResponse response = new SencolResponse();
        List<ProposalPersonRequests> proposalPersonResponseList = null;
        ProposalRequestsSencol proposal = null;
        PersonRequests personRequests = null;
        Future<SencolResponse> callModSencol = null;
        int i = 0;
        try {
            validationNullsPerson(body);
            validationLengthPerson(body);
            do {
                if (body.getPersonList().get(i).getBdeCode().equals(Constants.CONSTANTS_B0001)) {
                    try {
                        cirbeAsyncHelper.callSasna(body.getCompanyId(),
                                body.getPersonList().get(i).getPersonType(),
                                body.getPersonList().get(i).getPersonCode(), body.getUserRequest());
                        log.info("$$$$$$ Send Sasna: Proceso realizado correctamente");
                        i++;
                    } catch (Exception e) {
                        log.info("$$$$$$ Send Sasna: Proceso fallido");
                        throw new DigitalConsumptionServiceException(e,
                                ExceptionsErrorConstants.ERROR_DETAIL_SENCOL_SASNA);
                    }
                } else {
                    proposal = getProposalRequests(body, i);
                    personRequests = restConsumerService.sencolPersonRequests(proposal);

                    proposalPersonResponseList = restConsumerService.sencolProposalPersonRequests(
                            personRequests.getPersonRequestIdentifier().getPersonType(),
                            personRequests.getPersonRequestIdentifier().getPersonCode(),
                            personRequests.getPersonRequestIdentifier().getSourceType());
                    if (0 != proposalPersonResponseList.size()) {
                        try {
                            callModSencol = cirbeAsyncHelper.callModResolutions(proposalPersonResponseList,
                            		body.getPersonList().get(i));
                            log.info("$$$$$$ Send Modulo Resolution: Proceso realizado correctamente");
                            i++;
                        } catch (Exception ex) {
                            log.info("$$$$$$ Send Modulo Resolution: Proceso Fallido");
                            DigitalConsumptionServiceException e = (DigitalConsumptionServiceException) ex.getCause();
                            throw e;
                        }
                    } else {
                        i++;
                    }
                }

            } while (body.getPersonList().size() > i);
            response.setCode(Constants.CODE_SUCCESS);
            response.setMessage(Constants.MESSAGE_SUCCESS);
            return response;
        } catch (DigitalConsumptionServiceException e) {
            response = exceptionsCondicions(e);
            return response;
        }
    }

    /**
     * Gets the proposal requests.
     *
     * @param body the body
     * @return the proposal requests
     */
    private ProposalRequestsSencol getProposalRequests(ProposalRequestsSencolDto body, int i) {
        ProposalRequestsSencol proposal = new ProposalRequestsSencol();
        proposal.setCompanyId(body.getCompanyId());
        proposal.setUserRequest(body.getUserRequest());
        PersonDto person = new PersonDto();
        person.setPersonCode(body.getPersonList().get(i).getPersonCode());
        person.setPersonType(body.getPersonList().get(i).getPersonType());
        person.setBdeCode(body.getPersonList().get(i).getBdeCode());
        person.setBdeDescription(body.getPersonList().get(i).getBdeDescription());
        List<PersonDto> personList = new ArrayList<PersonDto>();
        personList.add(person);
        proposal.setPersonList(personList);
        return proposal;
    }

    /**
     * Exceptions condicions.
     *
     * @param e the e
     * @return the sencol response
     */
    private SencolResponse exceptionsCondicions(DigitalConsumptionServiceException e) {
        SencolResponse response = new SencolResponse();
        if (e.getMessage() != null) {
            if (e.getDetailArgs()[0].toString().equals(ErrorMessagesConstants.ERROR_DETAIL_SENCOL_SASNA)) {
                response.setCode(ErrorConstants.ERROR_CODE_SENCOL_10);
                response.setMessage(MessageFormat.format(ErrorConstants.ERROR_MESSAGE_SENCOL,
                        ErrorConstants.ERROR_DETAIL_SENCOL_SASNA));
                return response;
            }
            if (e.getDetailArgs()[0].toString().equals(ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PERSON_REQUESTS)) {
                response.setCode(ErrorConstants.ERROR_CODE_SENCOL_20);
                response.setMessage(MessageFormat.format(ErrorConstants.ERROR_MESSAGE_SENCOL,
                        ErrorConstants.ERROR_DETAIL_SENCOL_PERSON_REQUESTS));
                return response;
            }
            if (e.getDetailArgs()[0].toString()
                    .equals(ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS)) {
                response.setCode(ErrorConstants.ERROR_CODE_SENCOL_30);
                response.setMessage(MessageFormat.format(ErrorConstants.ERROR_MESSAGE_SENCOL,
                        ErrorConstants.ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS));
                return response;
            }
            if (e.getDetailArgs()[0].toString().equals(ErrorMessagesConstants.ERROR_DETAIL_SENCOL_PROPOSAL_STATE)) {
                response.setCode(ErrorConstants.ERROR_CODE_SENCOL_40);
                response.setMessage(MessageFormat.format(ErrorConstants.ERROR_MESSAGE_SENCOL,
                        ErrorConstants.ERROR_DETAIL_SENCOL_PROPOSAL_STATE));
                return response;
            }
            if (e.getDetailArgs()[0].toString().equals(ErrorMessagesConstants.ERROR_DETAIL_SENCOL_MOTOR)) {
                response.setCode(ErrorConstants.ERROR_CODE_SENCOL_50);
                response.setMessage(MessageFormat.format(ErrorConstants.ERROR_MESSAGE_SENCOL,
                        ErrorConstants.ERROR_DETAIL_SENCOL_MOTOR));
                return response;
            }
            response.setCode(ErrorConstants.ERROR_CODE_SENCOL_100);
            response.setMessage(ErrorConstants.ERROR_MESSAGE_SENCOL_GENERIC);
            return response;
        }
        return response;
    }

    /**
     * Validation length person.
     *
     * @param request the request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void validationLengthPerson(ProposalRequestsSencolDto request)
            throws DigitalConsumptionServiceException {
        try {
            String errors = "";
            DigitalConsumptionServiceException e = null;
            for (int i = 0; i < request.getPersonList().size(); i++) {
                if (Constants.VALUE_4.intValue() > request.getCompanyId().length()
                        || request.getCompanyId().length() > Constants.VALUE_4.intValue()) {
                    errors = ErrorConstants.MESSAGE_COMPANYID + Constants.COMMA;
                }
                if (Constants.VALUE_1.intValue() > request.getPersonList().get(i).getPersonType().length()
                        || request.getPersonList().get(i).getPersonType().length() > Constants.VALUE_1.intValue()) {
                    errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONTYPE + Constants.COMMA;
                }
                if (Constants.VALUE_9.intValue() < String.valueOf(request.getPersonList().get(i).getPersonCode())
                        .length()) {
                    errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONCODE;
                }
                if (!errors.isEmpty()) {
                    errors = (errors.substring(errors.length() - 1).equals(Constants.COMMA))
                            ? errors.substring(0, errors.length() - 1)
                            : errors;
                    throw new DigitalConsumptionServiceException(e,
                            ErrorConstants.ERROR_LENGTH_ERROR + errors);
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Validation nulls.
     *
     * @param request the request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void validationNullsPerson(ProposalRequestsSencolDto request)
            throws DigitalConsumptionServiceException {
        try {
            String errors = "";
            DigitalConsumptionServiceException e = null;
            for (int i = 0; i < request.getPersonList().size(); i++) {
                if (Constants.VALUE_BLANK.equals(request.getCompanyId()) || null == request.getCompanyId()) {
                    errors = Constants.SPACE + ErrorConstants.MESSAGE_COMPANYID + Constants.COMMA;
                }
                if (Constants.VALUE_BLANK.equals(request.getPersonList().get(i).getPersonType())
                        || null == request.getPersonList().get(i).getPersonType()) {
                    errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONTYPE + Constants.COMMA;
                }
                if (null == request.getPersonList().get(i).getPersonCode()) {
                    errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONCODE;
                }
                if (!errors.isEmpty()) {
                    errors = (errors.substring(errors.length() - 1).equals(Constants.COMMA))
                            ? errors.substring(0, errors.length() - 1)
                            : errors;
                    throw new DigitalConsumptionServiceException(e, ErrorConstants.MESSAGE_FIELD_REQUIRED + errors);
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Gets the proposal person requests for petitions.
     *
     * @param company the company
     * @param center the center
     * @param proposalYear the proposal year
     * @param proposalNumber the proposal number
     * @return the proposal person requests for petitions
     */
    private List<ProposalPersonRequests> getProposalPersonRequestsForPetitions(String company, String center,
            int proposalYear, int proposalNumber) {
        List<ProposalPersonRequests> proposalPersonRequest = proposalPersonRequestsRepository
                .findProposalPersonRequestsForPetitions(company, center, proposalYear, proposalNumber);
        return proposalPersonRequest;
    }

    /**
     * Gets the person requests for petitions.
     *
     * @param companyId the company id
     * @param personType the person type
     * @param personCode the person code
     * @param sourceType the source type
     * @return the person requests for petitions
     */
    private List<PersonRequests> getPersonRequestsForPetitions(String companyId, String personType, int personCode,
            String sourceType) {
        List<PersonRequests> personRequestList =
                personRequestsRepository.findPersonRequestByIdentifier(companyId, personType, personCode, sourceType);
        return personRequestList;
    }

    /**
     * Gets the data proposal RGO.
     *
     * @param idEmpr the id empr
     * @param idCent the id cent
     * @param year the year
     * @param numPropo the num propo
     * @return the data proposal RGO
     */
    public PropuestaRgoDto getDataProposalRGO(String idEmpr, String idCent, String year, BigDecimal numPropo) {
        PropuestaRgoDto pptaDto = new PropuestaRgoDto();
        PropuestaRgoEntityPK pk =
                PropuestaRgoEntityPK.builder().anoprop(year).idcent(idCent).idempr(idEmpr).numprop(numPropo).build();
        Optional<PropuestaRgoEntity> proposalRgo = propuestaRgoJpaRepository.findById(pk);
        if (proposalRgo.isPresent()) {
            pptaDto = PropuestaRgoDto.builder().cotestad(proposalRgo.get().getCotestad())
                    .indproce(proposalRgo.get().getIndproce()).build();
        }
        return pptaDto;
    }

    /**
     * Gets the xml gregorian change.
     *
     * @param fecha the fecha
     * @return the xml gregorian change
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.CirbeService#getXmlGregorianChange(java.util.Date)
     */
    XMLGregorianCalendar getXmlGregorianChange(Date fecha)
            throws DatatypeConfigurationException {
        GregorianCalendar calendario = new GregorianCalendar();
        XMLGregorianCalendar xmlCalendario = null;
        calendario.setTime(fecha);
        xmlCalendario = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendario);
        return xmlCalendario;
    }

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.CirbeService#getPersonRequest(es.santander.darwin.
     * financiaciondigital.lib.model.PersonRequests)
     */
    @Override
    public GetPersonResponse getPersonRequest(GetPersonRequest proposalRequests)
            throws DigitalConsumptionServiceException {
        GetPersonResponse proposalResponse = new GetPersonResponse();
        DataPerson person = null;
        PersonListVO personListVo = new PersonListVO();
        // BasicPersonDataRequestVO requests=new BasicPersonDataRequestVO();
        try {
            // requests.setIdempr(proposalRequests.getCompanyID());
            // requests.setCodpers(proposalRequests.getPersonCode());
            // requests.setTipopers(proposalRequests.getPersonType());
            validationNulls(proposalRequests);
            validationLength(proposalRequests);
            List<PersonRequests> personRequests = personRequestsRepository.findPersonRequestForPetitions2(
                    proposalRequests.getCompanyID(),
                    proposalRequests.getPersonType(),
                    proposalRequests.getPersonCode().intValue());
            // BasicPersonDataResponseVO response=libConnectorSvc.getBasicPersonData(requests);
            if (0 != personRequests.size()) {
                proposalResponse.setDocumentCode("");
                proposalResponse.setDocumentType("");
                for (int i = 0; i < personRequests.size(); i++) {
                    person = new DataPerson();
                    XMLGregorianCalendar admissionCalendar = null;
                    XMLGregorianCalendar modificationCalendar = null;
                    person.setModificationUser(personRequests.get(i).getModificationUser());
                    person.setNewAccreditedIndicator(personRequests.get(i).getNewAccreditedIndicator());
                    person.setPetitionsNumber(personRequests.get(i).getPetitionsNumber());
                    person.setRespExtCode(personRequests.get(i).getRespExtCode());
                    person.setRespExtDescCode(personRequests.get(i).getRespExtDescCode());
                    person.setSourceState(personRequests.get(i).getSourceState());
                    person.setSourceType(personRequests.get(i).getPersonRequestIdentifier().getSourceType());

                    try {
                        admissionCalendar = getXmlGregorianChange(personRequests.get(i).getAdmissionDate());
                        modificationCalendar = getXmlGregorianChange(personRequests.get(i).getModificationDate());
                        person.setAdmissionDate(admissionCalendar);
                        person.setModificationDate(modificationCalendar);
                        personListVo.getDataPersonLists().add(person);
                    } catch (DatatypeConfigurationException e) {
                        throw new DigitalConsumptionServiceException(e,
                                ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC);
                    }
                }
                proposalResponse.getDataPersonLists().add(personListVo);
            } else {
                DigitalConsumptionServiceException e = null;
                throw new DigitalConsumptionServiceException(e,
                        ErrorConstants.ERROR_CODE_NULL_REQUEST);
            }
            return proposalResponse;
        } catch (DigitalConsumptionServiceException e) {
            throw e;
        }
    }

    /**
     * Validation length.
     *
     * @param request the request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void validationLength(GetPersonRequest request)
            throws DigitalConsumptionServiceException {
        try {
            String errors = "";
            DigitalConsumptionServiceException e = null;
            if (Constants.VALUE_4.intValue() > request.getCompanyID().length()
                    || request.getCompanyID().length() > Constants.VALUE_4.intValue()) {
                errors = ErrorConstants.MESSAGE_COMPANYID + Constants.COMMA;
            }
            if (Constants.VALUE_1.intValue() > request.getPersonType().length()
                    || request.getPersonType().length() > Constants.VALUE_1.intValue()) {
                errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONTYPE + Constants.COMMA;
            }
            if (Constants.VALUE_9.intValue() < String.valueOf(request.getPersonCode()).length()) {
                errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONCODE;
            }
            if (!errors.isEmpty()) {
                errors = (errors.substring(errors.length() - 1).equals(Constants.COMMA))
                        ? errors.substring(0, errors.length() - 1)
                        : errors;
                throw new DigitalConsumptionServiceException(e,
                        ErrorConstants.ERROR_LENGTH_ERROR + errors);
            }
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Validation nulls.
     *
     * @param request the request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void validationNulls(GetPersonRequest request)
            throws DigitalConsumptionServiceException {
        try {
            String errors = "";
            DigitalConsumptionServiceException e = null;
            if (Constants.VALUE_BLANK.equals(request.getCompanyID()) || null == request.getCompanyID()) {
                errors = Constants.SPACE + ErrorConstants.MESSAGE_COMPANYID + Constants.COMMA;
            }
            if (Constants.VALUE_BLANK.equals(request.getPersonType()) || null == request.getPersonType()) {
                errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONTYPE + Constants.COMMA;
            }
            if (null == request.getPersonCode()) {
                errors += Constants.SPACE + ErrorConstants.MESSAGE_PERSONCODE;
            }
            if (!errors.isEmpty()) {
                errors = (errors.substring(errors.length() - 1).equals(Constants.COMMA))
                        ? errors.substring(0, errors.length() - 1)
                        : errors;
                throw new DigitalConsumptionServiceException(e,
                        ErrorConstants.MESSAGE_FIELD_REQUIRED + errors);
            }
        } catch (Exception e) {
            throw e;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.CirbeService#getPetitionsOfPersonAndProposalsResponse(es.
     * santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest)
     */
    public PetitionsOfPersonAndProposalResponse getPetitionsOfPersonAndProposalsResponse(
            PetitionsOfPersonAndProposalRequest request)
            throws DatatypeConfigurationException, DigitalConsumptionServiceException {
        try {
            validatePetitionsOfPersonAndProposalsResponse(request);
            PetitionsOfPersonAndProposalResponse response = new PetitionsOfPersonAndProposalResponse();
            PropuestaRgoDto propuestaRgoDto = getDataProposalRGO(request.getCompany(), request.getCenter(),
                    request.getYear(), new BigDecimal(request.getProposalNumber()));
            response.setProposalState(propuestaRgoDto.getCotestad());
            response.setProcessIndicator(
                    RegExUtils.removeAll(propuestaRgoDto.getIndproce(), Constants.ALPHANUMERIC_REGEX_FILTER));
            List<ProposalPersonRequests> proposalPersonRequestsList =
                    getProposalPersonRequestsForPetitions(request.getCompany(), request.getCenter(),
                            Integer.parseInt(request.getYear()), Integer.parseInt(request.getProposalNumber()));
            PersonAndProposalVO personAndProposalVo;
            List<PersonAndProposalVO> listOfPersonAndProposals = new ArrayList<>();
            PersAndPropsListVO persAndPropsListVo = new PersAndPropsListVO();
            List<PersonRequests> personRequestsList;
            SourcesListVO sourcesListVo;
            List<SourcesVO> listOfSources;
            SourcesVO sourcesVo;
            // Verificamos si la lista de proposalPersonRequests trae datos si no recuperamos los titulares de la
            // propuesta y el tipo de intervencion
            if (proposalPersonRequestsList != null && !proposalPersonRequestsList.isEmpty()) {
                for (ProposalPersonRequests ppRequest : proposalPersonRequestsList) {
                    sourcesListVo = new SourcesListVO();
                    personAndProposalVo = new PersonAndProposalVO();
                    personRequestsList = getPersonRequestsForPetitions(request.getCompany(),
                            ppRequest.getRequestPersonIdentifier().getPersonType(),
                            ppRequest.getRequestPersonIdentifier().getPersonCode(),
                            ppRequest.getRequestPersonIdentifier().getSourceType());
                    listOfSources = new ArrayList<>();
                    for (PersonRequests persRequest : personRequestsList) {
                        sourcesVo = new SourcesVO();
                        sourcesVo.setSourceType(ppRequest.getRequestPersonIdentifier().getSourceType());
                        sourcesVo.setSourceState(ppRequest.getSourceState());
                        sourcesVo.setCriticalityOfIntervener(ppRequest.getCriticalityData());
                        sourcesVo.setNewAccreditedIndicator(persRequest.getNewAccreditedIndicator());
                        sourcesVo.setNumberOfSourcePetitions(persRequest.getPetitionsNumber());
                        sourcesVo.setResponseCodeOfExternalSource(persRequest.getRespExtCode());
                        sourcesVo.setResponseDescriptionOfExternalSource(persRequest.getRespExtDescCode());
                        try {
                            sourcesVo.setAdmissionDate(getXmlGregorianChange(persRequest.getAdmissionDate()));
                            sourcesVo
                                    .setModificationDate(getXmlGregorianChange(persRequest.getModificationDate()));
                        } catch (DatatypeConfigurationException dce) {
                            log.error(dce.getMessage());
                            throw (dce);
                        }
                        sourcesVo.setModificationUser(persRequest.getModificationUser());
                        listOfSources.add(sourcesVo);
                    }
                    sourcesListVo.getSourcesList().addAll(listOfSources);
                    personAndProposalVo.setPersonType(ppRequest.getRequestPersonIdentifier().getPersonType());
                    personAndProposalVo.setPersonCode(ppRequest.getRequestPersonIdentifier().getPersonCode());
                    personAndProposalVo.setInterventionType(ppRequest.getInterventionType());
                    personAndProposalVo.setSrcList(sourcesListVo);
                    listOfPersonAndProposals.add(personAndProposalVo);
                }
            } else {
                personAndProposalVo = new PersonAndProposalVO();

                List<PersoPropuestaEntity> listaTitulares =
                        persoPropRepository.getListaTitulares(request.getCompany(), request.getCenter(),
                                request.getYear(), new BigDecimal(request.getProposalNumber()));
                List<PersoPropuestaEntity> listaAvalistas =
                        persoPropRepository.getListaAvalistas(request.getCompany(), request.getCenter(),
                                request.getYear(), new BigDecimal(request.getProposalNumber()));
                if (listaTitulares != null && !listaTitulares.isEmpty()) {

                    getListPersonRequest(request, listaTitulares, listOfPersonAndProposals,
                            Constants.TYPE_INTERVENTIONINTER);

                }
                if (listaAvalistas != null && !listaAvalistas.isEmpty()) {
                    getListPersonRequest(request, listaAvalistas, listOfPersonAndProposals,
                            Constants.TYPE_INTERVENTIONAVAL);
                }

            }

            List<PersonAndProposalVO> personListTemp = new ArrayList<PersonAndProposalVO>();
            PersonAndProposalVO personProposalTemp = new PersonAndProposalVO();
            int j = 0;
            for (int i = 0; i < listOfPersonAndProposals.size(); i++) {
                if (i > 0 &&
                        listOfPersonAndProposals.get(i - 1).getPersonCode() == listOfPersonAndProposals.get(i)
                                .getPersonCode()) {
                    if (!personListTemp.get(j).getSrcList().getSourcesList().isEmpty()) {
                        personListTemp.get(j).getSrcList().getSourcesList()
                                .add(listOfPersonAndProposals.get(i).getSrcList().getSourcesList().get(0));
                    }

                } else {
                    personProposalTemp = listOfPersonAndProposals.get(i);
                    personListTemp.add(personProposalTemp);
                    j = personListTemp.size() - 1;
                }

            }
            persAndPropsListVo.getPersonList().addAll(personListTemp);

            response.getPersList().add(persAndPropsListVo);
            return response;
        } catch (DigitalConsumptionServiceException e) {
            throw e;
        }
    }

    /**
     * Sets the proposal person.
     *
     * @param listOfSources the list of sources
     * @param personRequestListTitulares the person request list titulares
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    private void setProposalPerson(List<SourcesVO> listOfSources, List<PersonRequests> personRequestListTitulares)
            throws DatatypeConfigurationException {
        SourcesVO sourcesVo;
        for (PersonRequests persRequest : personRequestListTitulares) {
            sourcesVo = new SourcesVO();
            sourcesVo.setSourceType(persRequest.getPersonRequestIdentifier().getSourceType());
            sourcesVo.setSourceState(persRequest.getSourceState());
            sourcesVo.setCriticalityOfIntervener(Constants.VALUE_BLANK);
            sourcesVo.setNewAccreditedIndicator(persRequest.getNewAccreditedIndicator());
            sourcesVo.setNumberOfSourcePetitions(persRequest.getPetitionsNumber());
            sourcesVo.setResponseCodeOfExternalSource(persRequest.getRespExtCode());
            sourcesVo.setResponseDescriptionOfExternalSource(persRequest.getRespExtDescCode());
            try {
                sourcesVo.setAdmissionDate(getXmlGregorianChange(persRequest.getAdmissionDate()));
                sourcesVo
                        .setModificationDate(getXmlGregorianChange(persRequest.getModificationDate()));
            } catch (DatatypeConfigurationException dce) {
                log.error(dce.getMessage());
                throw (dce);
            }
            sourcesVo.setModificationUser(persRequest.getModificationUser());
            listOfSources.add(sourcesVo);
        }
    }

    /**
     * Gets the list person request.
     *
     * @param request the request
     * @param listaAvalistas the lista avalistas
     * @param listOfPersonAndProposals the list of person and proposals
     * @return the list person request
     * @throws DatatypeConfigurationException the datatype configuration exception
     */
    private void getListPersonRequest(PetitionsOfPersonAndProposalRequest request,
            List<PersoPropuestaEntity> listaAvalistas, List<PersonAndProposalVO> listOfPersonAndProposals, String type)
            throws DatatypeConfigurationException {
        List<PersonRequests> personRequestList = new ArrayList<>();
        PersonAndProposalVO personAndProposalVo;
        List<SourcesVO> listOfSources;
        SourcesListVO sourcesListVo;
        int avalistasKont = 1;
        for (PersoPropuestaEntity avalistas : listaAvalistas) {
            sourcesListVo = new SourcesListVO();
            listOfSources = new ArrayList<>();
            personAndProposalVo = new PersonAndProposalVO();
            personRequestList =
                    personRequestsRepository.findPersonRequestForPetitions2(request.getCompany(),
                            avalistas.getId().getPersonType(),
                            avalistas.getId().getPersonCode().intValue());
            setProposalPerson(listOfSources, personRequestList);
            sourcesListVo.getSourcesList().addAll(listOfSources);
            personAndProposalVo.setPersonType(avalistas.getId().getPersonType());
            personAndProposalVo.setPersonCode(avalistas.getId().getPersonCode().intValue());
            personAndProposalVo.setInterventionType(
                    type + Constants.VALUE_BLANK
                            + (avalistas.getId().getIntervType() != null
                                    ? Integer.parseInt(avalistas.getId().getIntervType())
                                    : Constants.VALUE_BLANK));
            personAndProposalVo.setSrcList(sourcesListVo);
            listOfPersonAndProposals.add(personAndProposalVo);
            if (avalistasKont == 4) {
                break;
            }
            avalistasKont++;
        }
    }

    /**
     * Validate petitions of person and proposals response.
     *
     * @param request the request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private void validatePetitionsOfPersonAndProposalsResponse(PetitionsOfPersonAndProposalRequest request)
            throws DigitalConsumptionServiceException {
        List<String> camposNulos = new ArrayList<>();
        List<String> camposVacios = new ArrayList<>();
        if (request.getCompany() == null) {
            camposNulos.add(Constants.COMPANY);
        } else {
            if (request.getCompany().length() != Constants.VALUE_4.intValue()) {
                camposVacios.add(Constants.COMPANY);
            }
        }
        if (request.getCenter() == null) {
            camposNulos.add(Constants.CENTER);
        } else {
            if (request.getCenter().length() != Constants.VALUE_4.intValue()) {
                camposVacios.add(Constants.CENTER);
            }
        }
        if (request.getYear() == null) {
            camposNulos.add(Constants.YEAR);
        } else {
            if (request.getYear().length() != Constants.VALUE_4.intValue()) {
                camposVacios.add(Constants.YEAR);
            }
        }
        if (request.getProposalNumber() == null) {
            camposNulos.add(Constants.PROPOSAL_NUMBER);
        } else {
            if (request.getProposalNumber().length() <= 0
                    || request.getProposalNumber().length() >= Constants.VALUE_100000.intValue()) {
                camposVacios.add(Constants.PROPOSAL_NUMBER);
            }
        }

        if (!camposNulos.isEmpty() || !camposVacios.isEmpty()) {
            DigitalConsumptionServiceException e = null;
            String errores = Constants.ERROR_CAMPOS_NULOS_O_VACIOS;
            for (String error : camposNulos) {
                errores += error + Constants.COMMA;
            }
            for (String error : camposVacios) {
                errores += error + Constants.COMMA;
            }
            if (errores.endsWith(Constants.COMMA)) {
                errores = errores.substring(0, errores.length() - 1);
            }
            throw new DigitalConsumptionServiceException(e,
                    ErrorConstants.ERROR_LENGTH_OR_NULL + errores);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.CirbeService#callTreatmentProcess(es.santander.darwin.
     * financiaciondigital.domain.ProposalRequestsSencolMotorDTO, java.lang.String)
     */
    public PetitionsTreatmentProcessResponse callTreatmentProcess(ProposalRequestsSencolMotorDTO proposalRequest)
            throws DigitalConsumptionServiceException {
        PetitionsTreatmentProcessResponse response = new PetitionsTreatmentProcessResponse();
        String empresa = proposalRequest.getCompany();
        String center = proposalRequest.getCenter();
        Integer year = proposalRequest.getYear();
        Integer propNumb = proposalRequest.getProposalNumber();
        Map<String, String> bodyParamMap = new HashMap<String, String>();

        // Set your request body params
        bodyParamMap.put("centerId", center);
        bodyParamMap.put("proposalYear", Integer.toString(proposalRequest.getYear()));
        bodyParamMap.put("proposalNumber", Integer.toString(propNumb));
        bodyParamMap.put("companyId", empresa);
        
        log.info("Invocando el servicio de recuperar fuentes de motor" + bodyParamMap.toString());
        
        ConsultPersonProcessResponseVO consultPersonResponse =
                restConsumerCirbeService.consultPerson(bodyParamMap);
        
        if (consultPersonResponse == null || consultPersonResponse.getPersons().isEmpty()) {
            response.setResponseMessage(ErrorConstants.ERROR_PERSONA_ASOCIADA);
            response.setErrorCode(ErrorConstants.COD_ERROR_SIN_PERSONA_ASOCIADA_PROPUESTA);
            return response;
        }
        List<PersoPropuestaEntity> listaTitulares =
                persoPropRepository.getListaTitulares(empresa, center, year.toString(), new BigDecimal(propNumb));
        List<PersoPropuestaEntity> listaAvalistas =
                persoPropRepository.getListaAvalistas(empresa, center, year.toString(), new BigDecimal(propNumb));

        for (PersonVO persona : consultPersonResponse.getPersons()) {
        	log.info("Tratando interviniente: " + persona.getIntervencion());
        	
            int numInterviniente = Character.digit(persona.getIntervencion().charAt(1), 10);
            for (SourceTypeVO source : persona.getSourceTypeList()) {
            	log.info("Tratando fuente: " + source.toString());
                PersoPropuestaEntity interviniente = null;

                if (persona.getIntervencion().startsWith(Constants.INICIAL_TITULAR)) {
                    if (listaTitulares != null && !listaTitulares.isEmpty()) {
                        interviniente = new PersoPropuestaEntity();
                        interviniente = listaTitulares.get(numInterviniente - 1);
                    }

                }
                if (persona.getIntervencion().startsWith(Constants.INICIAL_AVALISTA)) {
                    if (listaAvalistas != null && !listaAvalistas.isEmpty()) {
                        interviniente = new PersoPropuestaEntity();
                        interviniente = listaAvalistas.get(numInterviniente - 1);
                    }

                }
                if (interviniente != null) {
                    List<ProposalPersonRequests> peticionesExistentes = proposalPersonRequestsRepository
                            .findProposalPersonRequestsByRequestIdentifier(empresa, center, year, propNumb,
                                    interviniente.getId().getPersonType(),
                                    interviniente.getId().getPersonCode().intValue(),
                                    source.getSourceType());
                    if (peticionesExistentes.isEmpty()) {
                        if (source.getSourceType().equalsIgnoreCase(Constants.CIRBE)) {
                            List<PersonRequests> personRequestList =
                                    personRequestsRepository.findPersonRequestByIdentifier(empresa,
                                            interviniente.getId().getPersonType(),
                                            interviniente.getId().getPersonCode().intValue(), sourceType);
                            for (PersonRequests persReq : personRequestList) {
                                persReq.setPetitionsNumber(0);
                            }
                            personRequestsRepository.saveAll(personRequestList);
                            try {
                                cirbeAsyncHelper.callSasna(empresa,
                                        interviniente.getId().getPersonType(),
                                        new BigDecimal(interviniente.getId().getPersonCode().intValue()),
                                        proposalRequest.getModificationUser());
                            } catch (Exception exc) {
                                response.setErrorCode(ErrorConstants.COD_ERROR_SASNA_CALL);
                                response.setErrorMessage(ErrorConstants.MESSAGE_ERROR_CALL_SASNA);
                            }
                        }
                        PropuestaRgoDto propuestaRgo =
                                getDataProposalRGO(empresa, center, year.toString(), new BigDecimal(propNumb));
                        ProposalPersonRequests proposalPersonRequest = new ProposalPersonRequests();
                        RequestPersonIdentifier requestPersonIdentifier = new RequestPersonIdentifier();
                        requestPersonIdentifier.setCompanyId(empresa);
                        requestPersonIdentifier.setCenterId(center);
                        requestPersonIdentifier.setProposalYear(Integer.valueOf(year));
                        requestPersonIdentifier.setProposalNumber(propNumb.intValue());
                        requestPersonIdentifier.setPersonType(interviniente.getId().getPersonType());
                        requestPersonIdentifier.setPersonCode(interviniente.getId().getPersonCode().intValue());
                        requestPersonIdentifier.setSourceType(source.getSourceType());
                        proposalPersonRequest.setRequestPersonIdentifier(requestPersonIdentifier);
                        proposalPersonRequest.setSourceState(Constants.VALUE_01);
                        proposalPersonRequest.setCriticalityData(
                                source.getCriticidad() != null ? source.getCriticidad() : Constants.EMPTY);
                        proposalPersonRequest.setProcessIndicator(propuestaRgo.getIndproce());
                        proposalPersonRequest.setInterventionType(persona.getIntervencion());
                        proposalPersonRequest.setAdmissionDate(new Date());
                        proposalPersonRequest.setModificationDate(new Date());
                        proposalPersonRequest.setModificationUser(proposalRequest.getModificationUser());
                        proposalPersonRequest.setSubApplication(proposalRequest.getSubApplication());
                        try {
                            proposalPersonRequestsRepository.save(proposalPersonRequest);
                            log.info("Interviniente guardado de forma correcta en la coleccion proposalPersonRequests");
                        } catch (Exception exc) {
                            response.setErrorCode(ErrorConstants.COD_ERROR_ACCESO_PET_PERS_PROP);
                            response.setErrorMessage(ErrorConstants.MESSAGE_ERROR_ACCESO_PET_PERS_PROP);

                        }
                    }
                }

            }
        }
        response.setResponseMessage(Constants.PROPUESTA_CORRECTA_MSG);
        response.setErrorCode(Constants.PROPUESTA_CORRECTA_COD);
        return response;
    }
}
