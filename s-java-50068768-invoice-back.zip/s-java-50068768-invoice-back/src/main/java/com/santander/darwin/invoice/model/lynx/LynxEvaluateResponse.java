/**
 * 
 */
package com.santander.darwin.invoice.model.lynx;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class LynxEvaluateResponse.
 */

/**
 * Checks if is ind contingency.
 *
 * @return true, if is ind contingency
 */

/**
 * Checks if is ind contingency.
 *
 * @return true, if is ind contingency
 */
@Getter

/**
 * Sets the ind contingency.
 *
 * @param indContingency the new ind contingency
 */

/**
 * Sets the ind contingency.
 *
 * @param indContingency the new ind contingency
 */

/**
 * Sets the ind contingency.
 *
 * @param indContingency the new ind contingency
 */
@Setter
public class LynxEvaluateResponse {
	
	/** The fraud id. */
	private String fraudId;
	
	/** The reference id. */
	private String referenceId;
	
	/** The customer id. */
	private String customerId;
	
	/** The operation type. */
	private String operationType;
	
	/** The operation subtype. */
	private String operationSubtype;
	
	/** The call type. */
	private String callType;
	
	/** The meta data. */
	private String metaData;
	
	/** The status. */
	private String status;
	
	/** The score. */
	private int score;
	
	/** The ind contingency. */
	private boolean indContingency;

}
