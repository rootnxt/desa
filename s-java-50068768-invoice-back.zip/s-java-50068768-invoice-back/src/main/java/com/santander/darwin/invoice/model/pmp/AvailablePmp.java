package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * AvailablePmp model
 */
@Getter
@Setter
public class AvailablePmp {
	
	/** The idempr. */
    private String idempr;
	
}
