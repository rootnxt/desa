package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Trxa1meRequestDTO.java
 *
 * @author igndom
 *
 */
public class Trxa1meRequestDTO {

	public Trxa1meRequestDTO() {
		// Constructor por defecto
	}

}
