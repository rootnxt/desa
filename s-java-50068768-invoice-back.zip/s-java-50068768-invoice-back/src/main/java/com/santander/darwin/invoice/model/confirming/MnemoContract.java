package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * MnemoContracts.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class MnemoContract {
	
	//Código Mnemo
	private String mnemo;
	
	// Contrato confirming
	private Contract contract;

}