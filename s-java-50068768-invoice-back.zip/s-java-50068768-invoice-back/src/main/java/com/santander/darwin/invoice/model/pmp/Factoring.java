package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Factoring model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Factoring {
    /** id */
    private int id;
    /** name */
    private String name;
    /** description */
    private String description;
    /** financing */
    private Financing financing;
    /** product Months */
    private ProductMonths productMonths;
}
