package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * InvoiceFinancing.java
 *
 * @author x574726
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class DocumentDataOutput {
	
	// Documentos a imprimir
	private List<DocumentData> documents;
	// Tipo de firma
	private String typeSign;

}
