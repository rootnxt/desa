
package com.santander.darwin.invoice.model.psd2;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the criticality.
 *
 * @return the criticality
 */
@Getter

/**
 * Sets the criticality.
 *
 * @param criticality the new criticality
 */
@Setter

/**
 * Instantiates a new source variable.
 */
@NoArgsConstructor

/**
 * Instantiates a new source variable.
 *
 * @param type the type
 * @param criticality the criticality
 */
@AllArgsConstructor
public class SourceVariable {

    /** The type. */
    private String type;
    
    /** The criticality. */
    private String criticality;

}
