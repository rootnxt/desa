package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class SwaggerConstants.
 */
public class SwaggerConstants {

    /** The auth. */
    public static final String AUTH = "Authorization";

    /** The data type string. */
    public static final String DATA_TYPE_STRING = "string";

    /** The param type header. */
    public static final String PARAM_TYPE_HEADER = "header";

    /** The param type path. */
    public static final String PARAM_TYPE_PATH = "path";

    /** The param type path. */
    public static final String PARAM_TYPE_QUERY = "query";

    /** The token header desc. */
    public static final String TOKEN_HEADER_DESC = "User authentication token";

    /** The channel param name. */
    public static final String CHANNEL_PARAM_NAME = "X-Santander-Channel";

    /** The channel param value. */
    public static final String CHANNEL_PARAM_VALUE = "Channel";

    /** The channel param allowable values. */
    public static final String CHANNEL_PARAM_ALLOWABLES_VALUES = "INT, OFI";

    /** The Constant MSG_API_OPERATION_VALUE. */
    public static final String MSG_API_OPERATION_VALUE = "SASNA";

    /** The data type person type. */
    public static final String DATA_TYPE_PERSON_TYPE = "PersonType";

    /** The person type param name. */
    public static final String PERSON_TYPE_PARAM_NAME = "personType";

    /** The person type param value. */
    public static final String PERSON_TYPE_PARAM_VALUE = "Person Type (F=PHYSICAL, J=JURIDICAL)";

    /** The person type param allowable values. */
    public static final String PERSON_TYPE_PARAM_ALLOWABLES_VALUES = "F, J";

    /** The person code param name. */
    public static final String PERSON_CODE_PARAM_NAME = "personCode";

    /** The person code param value. */
    public static final String PERSON_CODE_PARAM_VALUE = "Person Code";

    /**
     * Instantiates a new swagger constants.
     */
    private SwaggerConstants() {
        super();
    }

}
