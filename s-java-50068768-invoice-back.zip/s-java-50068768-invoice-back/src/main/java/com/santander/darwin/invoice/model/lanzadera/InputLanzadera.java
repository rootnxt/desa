package com.santander.darwin.invoice.model.lanzadera;

import com.santander.darwin.invoice.model.soap.DOCUMPERSONACORPORATIVOType;
import com.santander.darwin.invoice.model.soap.NUMPERSONACLIENTEType;

/**
 * InputLanzadera.java
 *
 * @author igndom
 *
 */
public class InputLanzadera {

	private NUMPERSONACLIENTEType person;
	private String user;
	private String pass;
	private DOCUMPERSONACORPORATIVOType document;

	/**
	 * @return the person
	 */
	public NUMPERSONACLIENTEType getPerson() {
		return person;
	}

	/**
	 * @param person the person to set
	 */
	public void setPerson(NUMPERSONACLIENTEType person) {
		this.person = person;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}

	/**
	 * @return the document
	 */
	public DOCUMPERSONACORPORATIVOType getDocument() {
		return document;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(DOCUMPERSONACORPORATIVOType document) {
		this.document = document;
	}

}
