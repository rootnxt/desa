package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * OutputSat002415.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class OutputSat002415 {

	private List<String> a1estado;
	private List<String> a1lit030;
	private List<String> a1nomper;
	private List<String> a8estref;
	private List<BigDecimal> clocaliz;
	private List<String> codcesta;
	private List<String> cpmoneda;
	private List<BigDecimal> csituaci;
	private List<String> descr023;
	private List<String> dlocaliz;
	private List<String> dpmoneda;
	private List<String> dsituaci;
	private List<String> idprod;
	private List<String> idstipro;
	private List<BigDecimal> importpn;
	private List<BigDecimal> pnplazo;
	private List<String> timestam;
	private List<String> a8codest;
	private List<String> a8dessit;

}
