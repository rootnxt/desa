package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * IntervPmp model
 */
@Getter
@Setter
public class IntervPmp {
	
	/** The idempr. */
    private String idempr;
	
}
