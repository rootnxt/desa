package com.santander.darwin.invoice.constants;

/**
 * CommonConstants
 * 
 * @author ciber
 *
 */
public class CommonConstants {
	/**
	 * Comentario para sonar
	 */

	// Caracteres char
	public static final char CHAR_BAR = '|';
	public static final char CHAR_COMA = ',';
	public static final char CHAR_SEMICOLON = ';';
	public static final char CHAR_MAS = '+';
	
	// Caracteres str
	public static final String STR_BAR = "|";
	public static final String STR_COMA = ",";
	public static final String STR_PUNTO = ".";
	public static final String STR_SEMICOLON = ";";
	public static final String STR_COLON = ":";
	public static final String STR_VACIO = "";
	public static final String STR_ESPACIO = " ";
	public static final String STR_ASK = "*";
	
	public static final String STR_MAS = "+";
	public static final String STR_IGUAL = "=";
	public static final String STR_GUION = "-";
	public static final String STR_GUION_BAJO = "_";
	public static final String STR_SLASH = "/";
	public static final String STR_LF = "\n";
	public static final String STR_TAB = "\t";
	public static final String STR_LT = "<";
	public static final String STR_GT = ">";
	public static final String STR_COMILLAS_DOBLES = "\"";

	// Mayor y menor
	public static final String STR_UNICODE_LT = "&lt;";
	public static final String STR_UNICODE_GT = "&gt;";

	// Simbolos
	public static final String STR_AMPERSAND = "&";
	public static final String STR_INTERROGANTE = "?";
	public static final String STR_BARRA = "\\";
	public static final String STR_EUR_SYMBOL = "€";
	public static final String STR_EUR_DESC = "EUR";
	public static final String STR_PORCENTAJE = "%";
	public static final String STR_ARROBA = "@";

	// Seguridad
	public static final String SECURITY_NEWUNIVERSALCOOKIE = "NewUniversalCookie";
	public static final String SECURITY_NEWUNIVERSALCOOKIEEQUAL = "NewUniversalCookie=";
	public static final String SECURITY_TOKEN = "token";
	public static final String SECURITY_USER = "user";
	public static final String SECURITY_PASS = "pass";
	public static final String SECURITY_CANAL = "canal";

	// Respuestas
	public static final String SI = "S";
	public static final String NO = "N";
	public static final String YES = "Y";

	// Datos empresa
	public static final String ISB_EMPRESA = "0049";
	public static final String ISB_EMPRESAASOCIADA_SPNT = "0000";
	public static final String ISB_EMPRESAASOCIADA_SPB = "0013";

	// Canales
	public static final String ISB_CANAL_INT = "INT";
	public static final String ISB_CANAL_MOV = "MOV";
	public static final String ISB_CANAL_OFI = "OFI";
	public static final String ISB_CANAL_EMP = "EMP";
	public static final String ISB_CANAL_CIC = "CIC";

	// Tipo persona
	public static final String TIPO_PERSONA_FISICA = "F";
	public static final String TIPO_PERSONA_JURIDICA = "J";

	// PROPERTY FILE NAMES
	public static final String PROPERTY_BBDD_NAME = "bbdd";
	public static final String PROPERTY_WS_NAME = "ws";

	// WS PROPERTIES
	public static final String PROPERTY_WS_ENDPOINT = ".endpoint";
	public static final String PROPERTY_WS_MOCK = ".mock";

	// BBDD PROPERTIES
	public static final String PROPERTY_BBDD_POOLNAME = ".dbPoolName";
	public static final String PROPERTY_BBDD_DRIVER = ".driver";
	public static final String PROPERTY_BBDD_USER = ".user";
	public static final String PROPERTY_BBDD_PASS = ".pass";

	// APP CONSTANTS
	public static final String APPCONSTANTS_APPLOCALTION = "appLocation";
	public static final String APPCONSTANTS_APPLOCALTION_CERT = "appLocationCert";
	public static final String APPCONSTANTS_APPLOCALTION_CLASSPATH = "appLocationClasspath";
	public static final String APPCONSTANTS_APP_WEBINF = "WEB-INF";
	
	// MVP CONSTANTS
	public static final int MVP_FOUR = 4;

	// PMP REPOSITORY
	public static final String IDEMPR = "idempr";
	public static final String IDCENT = "idcent";

	public static final String CODE_101 = "101";
	public static final String CODE_AM_3 = "AM3";
	public static final String TYPE_02 = "02";
	public static final String TYPE_05 = "05";

	/** The POLICY_NUMBER constant. */
	public static final String POLICY_NUMBER = "policyNumber";

	/** The TIPO_PERS constant. */
	public static final String TIPO_PERS = "tipoPers";

	/** The COD_PERS constant. */
	public static final String COD_PERS = "codPers";

	/** The TYPE_SIGN constant. */
	public static final String TYPE_SIGN = "typeSign";

	/** TheCOD_PERS_DEFAULT constant. */
	public static final int COD_PERS_DEFAULT = 0;
	
	/** The SIGNATURE_MODE_MANUSCRITA constant. */
	public static final String SIGNATURE_MODE_MANUSCRITA = "03";
	
	/** The Constant ALL_PROPOSAL. */
	public static final String ALL_PROPOSAL = "allProposal";

	/** The OPERATION ID constant. */
	public static final String OPERATION_ID = "operationId";



	/**
	 * Comentario para sonar
	 */
	private CommonConstants() {
		throw new IllegalStateException("Utility class");
	}
}
