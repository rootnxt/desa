/**
 * 
 */
package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * Mnemo information Class
 * 
 * @author x574726
 *
 */

@Getter
@Setter
public class MnemoInformation {

	/**
	 * National Mnemo
	 */
	private String nationalMnemo;

	/**
	 * International Mnemo
	 */
	private String internationalMnemo;
	
}
