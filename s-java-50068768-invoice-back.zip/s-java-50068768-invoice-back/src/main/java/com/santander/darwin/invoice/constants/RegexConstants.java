package com.santander.darwin.invoice.constants;

/**
 * RegexConstants.java
 *
 * @author igndom
 *
 */
public class RegexConstants {

	// Regex modo version
	public static final String REGEX_MODE = "[1234]{1}";
	
	// Regex Digitos
	public static final String REGEX_DIGIT = "[0-9]{4,6}";

	// Regex moviles y fijos
	public static final String REGEX_PREFIX_SPAIN = "^[0-9]{1,3}$";
	public static final String REGEX_MOBILE_SPAIN = "^[6-7]{1}[0-9]{8}$";

	// Regex caracteres especiales
	public static final String REGEX_DOT = "\\.";
	public static final String REGEX_START_NUMBER = "[^\\d]";
	
	// Espacio blanco
	public static final String REGEX_WHITE_SPACE = "(?=\\s)";
	
	// Agregador 
	public static final String REGEX_AGGREGATION = "(\\w+)-(\\w+)";
	
	// Regex tildes y acentos 
    public static final String REGEX_COMBINING_DIACRITICAL = "[\\p{InCombiningDiacriticalMarks}]";
    
    // Soloca caracteres
    public static final String REGEX_ALPHA_DATA = "[^\\p{Alpha}]";
    
    
    

	private RegexConstants() {
		throw new IllegalStateException("Utility class");
	}
}
