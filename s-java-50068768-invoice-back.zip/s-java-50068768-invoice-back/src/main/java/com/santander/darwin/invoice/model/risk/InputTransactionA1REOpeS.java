package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * InputTransactionA1REOpeS.java
 *
 * @author igndom
 *
 */
public class InputTransactionA1REOpeS extends InputTransactionA1RE {

	private BigDecimal zcodpers;
	private String zcodprod;
	private String zidcentc;
	private String zidcontr;
	private String zidemprc;
	private BigDecimal zordintc;
	private String ztipinte;
	private String ztipoper;

	/**
	 * @return the zcodpers
	 */
	public BigDecimal getZcodpers() {
		return zcodpers;
	}

	/**
	 * @param zcodpers the zcodpers to set
	 */
	public void setZcodpers(BigDecimal zcodpers) {
		this.zcodpers = zcodpers;
	}

	/**
	 * @return the zcodprod
	 */
	public String getZcodprod() {
		return zcodprod;
	}

	/**
	 * @param zcodprod the zcodprod to set
	 */
	public void setZcodprod(String zcodprod) {
		this.zcodprod = zcodprod;
	}

	/**
	 * @return the zidcentc
	 */
	public String getZidcentc() {
		return zidcentc;
	}

	/**
	 * @param zidcentc the zidcentc to set
	 */
	public void setZidcentc(String zidcentc) {
		this.zidcentc = zidcentc;
	}

	/**
	 * @return the zidcontr
	 */
	public String getZidcontr() {
		return zidcontr;
	}

	/**
	 * @param zidcontr the zidcontr to set
	 */
	public void setZidcontr(String zidcontr) {
		this.zidcontr = zidcontr;
	}

	/**
	 * @return the zidemprc
	 */
	public String getZidemprc() {
		return zidemprc;
	}

	/**
	 * @param zidemprc the zidemprc to set
	 */
	public void setZidemprc(String zidemprc) {
		this.zidemprc = zidemprc;
	}

	/**
	 * @return the zordintc
	 */
	public BigDecimal getZordintc() {
		return zordintc;
	}

	/**
	 * @param zordintc the zordintc to set
	 */
	public void setZordintc(BigDecimal zordintc) {
		this.zordintc = zordintc;
	}

	/**
	 * @return the ztipinte
	 */
	public String getZtipinte() {
		return ztipinte;
	}

	/**
	 * @param ztipinte the ztipinte to set
	 */
	public void setZtipinte(String ztipinte) {
		this.ztipinte = ztipinte;
	}

	/**
	 * @return the ztipoper
	 */
	public String getZtipoper() {
		return ztipoper;
	}

	/**
	 * @param ztipoper the ztipoper to set
	 */
	public void setZtipoper(String ztipoper) {
		this.ztipoper = ztipoper;
	}

}
