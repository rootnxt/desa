package com.santander.darwin.invoice.exception;

import java.util.UUID;

/**
 * GenericException.java
 *
 * @author igndom
 *
 */
public class GenericException extends GlobalException {

	private static final long serialVersionUID = -8332782870266238978L;

	private final String type;
	private final String operationId;
	private final String app;

	/**
	 * Constructor
	 *
	 * @param lang String
	 * @param app  String
	 */
	public GenericException(String lang, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), lang);
		this.type = null;
		this.operationId = null;
		this.app = app;
	}

	/**
	 * Constructor
	 *
	 * @param code String
	 * @param lang String
	 * @param app  String
	 */
	public GenericException(String code, String lang, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), code, lang);
		this.type = null;
		this.operationId = null;
		this.app = app;
	}

	/**
	 * Constructor
	 *
	 * @param code   String
	 * @param status int
	 * @param lang   String
	 * @param app    String
	 */
	public GenericException(String code, int status, String lang, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), String.valueOf(status), code, lang);
		this.type = null;
		this.operationId = null;
		this.app = app;
	}

	/**
	 * Constructor
	 *
	 * @param code        String
	 * @param lang        String
	 * @param operationId String
	 * @param app         String
	 */
	public GenericException(String code, String lang, String operationId, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), code, lang);
		this.type = null;
		this.operationId = operationId;
		this.app = app;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return the operationId
	 */
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @return the app
	 */
	public String getApp() {
		return app;
	}

}
