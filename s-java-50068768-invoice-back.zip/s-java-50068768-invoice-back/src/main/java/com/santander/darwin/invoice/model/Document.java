package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

/**
 * Document.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Document {
	
	/** The code. */
	private String code;
	
	/** The code. */
	private String codeDig;

	/** The description. */
	private String description;
	
	/**The print flag.  */
	private boolean print;
	
	/** The signed flag. */
	private boolean signed;
	
	/** The sent flag. */
	private boolean sent;
	
	/** The uploaded document name. */
	private String uploadedDocumentName;
	
	/** The reason for rejection. */
	private String reasonForRejection;
	
	/** The gnId. */
	private String gnId;
	
	/** The gnId. */
	private String gnIdSign;
	
	/** The gn tipo doc. */
	private String gnTipoDoc;
	
	/** The gn tipo doc. */
	private String gnTipoDocDig;

	/** The tipo doc. */
	private String tipoDoc;
	
	/** The desc tipo doc. */
	private String descTipoDoc;
	
	/** The num person. */
	private String numPerson;
	
	/** The person name. */
	private String personName;
	
	/** The printing date. */
	private String printingDate;
	
	/** The printing user. */
	private String printingUser;

	/** The originalFilename. */
	private String originalFilename;

	/** The updateAcl. */
	private boolean updateAcl;

	/** The SignExp expediente de firma generado */
	private String signExp;
	
	/** The StatusSign estado de la firma */
	private String statusSign;
	
	/**
	 * Constructor
	 *
	 */
	public Document() {
		super();
	}

	/**
	 * Constructor
	 *
	 * @param code        String
	 * @param description String
	 */
	public Document(String code, String description) {
		super();
		this.code = code;
		this.description = description;
		this.print = false;
		this.signed = false;
		this.sent = false;
	}
	
}
