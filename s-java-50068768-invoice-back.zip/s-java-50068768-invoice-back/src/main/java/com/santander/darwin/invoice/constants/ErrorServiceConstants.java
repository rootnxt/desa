
package com.santander.darwin.invoice.constants;

/**
 * ErrorServiceConstants
 * 
 * @author igndom
 *
 */
public class ErrorServiceConstants {

	/**** ERRORES DEFAULT ****/
	// Error generico
	public static final String IV_SHORT_MESSAGE_DEFAULT = "INVOICE FINANCE ERROR";
	// Error generico
	public static final String IV_DETAIL_MESSAGE_DEFAULT = "<p>Lo sentimos, hay algún problema y no podemos continuar con la financiación.</p>" +
			"<p class='message'>Por favor, inténtalo más tarde.</p>";
	
	/**** SI EL STATEFRONT != 3 DARA ESTE ERROR QUE YA FUE AVANZADA ***/
	public static final String IVFNSTATEINCONTRACTNOTVALID = "IVFNSTATEINCONTRACTNOTVALID";

	/**** CONTROL REDIRECCION ****/
	public static final String IVFNGENERICREDIRECT = "IVFNGENERICREDIRECT";

	/**** CÓDIGOS EN ARM ****/

	// COMPLETED
	// Operación completada.
	public static final String IVFNOPCOMPLETED = "IVFNOPCOMPLETED";

	// PENDING
	// La operación ha quedado pendiente de firma.
	public static final String IVFNPENDING = "IVFNPENDING";

	// PENDINGCIRBE
	// Solicitud pendiente de cirbe.
	public static final String IVFNPENDINGCIRBE = "IVFNPENDINGCIRBE";

	// PENDINGDATA
	// Solicitud pendiente de más datos.
	public static final String IVFNPENDINGDATA = "IVFNPENDINGDATA";

	// CANCELLED - ERROR
	// El usuario no ha podido completar la operación.
	public static final String IVFNGENERICERROR = "IVFNGENERICERROR";
	public static final String IVFNPREVGENERICERROR = "IVFNPREVGENERICERROR";

	// CANCELLED - ABANDON
	// El usuario ha abandonado el proceso.
	public static final String IVFNUSERABANDON = "IVFNUSERABANDON";

	public static final String IVFNOPERATIONIDEXISTENTE = "IVFNOPERATIONIDEXISTENTE";

	/**** ERRORES EN LA PANTALLA NUEVA ****/

	// Lo sentimos, pero no podemos continuar con la contratación.
	public static final String IVFNERRORNOLIMIT = "IVFNERRORNOLIMIT";

	// Importe de la operacion fuera de rango
	public static final String IVFNERRORFINANCERANGE = "IVFNERRORFINANCERANGE";

	// App no existente
	public static final String EXTSIGNERSAPPNOTEXISTERROR ="EXTSIGNERSAPPNOTEXISTERROR";

	// Errors limite P2
	// el usuario de P2 no tenga límites, se le mostrará esta pantalla,
	// IVFNNOTLIMITP2ERROR
	public static final String IVFNNOTLIMITP2ERROR = "IVFNNOTLIMITP2ERROR";

	// Errors limite P3
	// el usuario de P3 no tenga límites, se le mostrará esta pantalla,
	public static final String IVFNNOTLIMITP3ERROR = "IVFNNOTLIMITP3ERROR";

	// el usuario sea un usuario de P1, se le mostrará IVFNLIMITP1ERROR:
	public static final String IVFNLIMITP1ERROR = "IVFNLIMITP1ERROR";
	
	// el usuario sea un usuario de P1, se le mostrará IVFNLIMITP1ERROR sólo desde APP-mobile
	public static final String IVFNLIMITP1ERRORAPP = "IVFNLIMITP1ERRORAPP";
	
	// el usuario tenga límites en pantalla de limites,
	public static final String IVFNNOTLIMITPLIMITSERROR = "IVFNNOTLIMITPLIMITSERROR";

	// Lo sentimos, este producto no puede ser contratado
	public static final String IVNFNOORIENTED = "IVNFNOORIENTED";

	// Lo sentimos, contacta con superlinea para revisar tus permisos de firma
	public static final String IVFNERRORBASTANTEO = "IVFNERRORBASTANTEO";

	// Error FFNN generico para informe
	public static final String IVFNERRORFFNN = "IVFNERRORFFNN";

	// Lo sentimos, pero no podemos continuar con la contratación.
	public static final String IVFNERRORFFNNEXTERNOS = "IVFNERRORFFNNEXTERNOS";

	// Lo sentimos, pero no podemos continuar con la contratación.
	public static final String IVFNERRORFFNNINTERNOS = "IVFNERRORFFNNINTERNOS";

	// Lo sentimos, contacta con superlinea para revisar tus permisos de firma
	public static final String IVFNERRORFIOC = "IVFNERRORFIOC";

	// Lo sentimos, pero no podemos continuar con la contratación.
	public static final String IVFNERRORLISTAS = "IVFNERRORLISTAS";
	
	// Lo sentimos, no se puede imprimir el fichero por error en el servicio.
	public static final String IVFNERRORPRINTDOC = "IVFNERRORPRINTDOC";

	// Lo sentimos, pero ya has contratado todos los productos disponibles.
	public static final String IVFNERRORNOPRODUCTSAVAILABLE = "IVFNERRORNOPRODUCTSAVAILABLE";
	public static final String IVFNERRORNOPRODUCTSAVAILABLEUNIQUE = "IVFNERRORNOPRODUCTSAVAILABLEUNIQUE";

	// No tiene contratos pendientes de impago.
	public static final String IVFNERRORNOIMPAGOS = "IVFNERRORNOIMPAGOS";
	// Importe esté fuera del rango de mínimo o máximo del catálogo.
	public static final String IVFNERRORIMPORTRD = "IVFNERRORIMPORTRD";

	/**** ERRORES DENTRO DE LA APP ****/
	// No tienen facturas
	public static final String IVFNERRORNOINVOICEDATA = "IVFNERRORNOINVOICEDATA";

	public static final String IVFNERRORNOINVOICE = "IVFNERRORNOINVOICE";

	// No viene el campo importe en la version 3
	public static final String IVINVOICESDATAIMPORTE = "IVINVOICESDATAIMPORTE";

	// Datos incompletos
	public static final String IVFNDATAINCOMPLETE = "IVFNDATAINCOMPLETE";

	// No se han encontrado registros en base de datos con los parametros que se han
	// pasado.
	public static final String IVFNERRORNOTFOUND = "IVFNERRORNOTFOUND";
	// No existen solicitudes a mostrar.
	public static final String IVFNSOLICITUDELISTEMPTY = "IVFNSOLICITUDELISTEMPTY";

	// No se puede realizar la operación.
	public static final String IVFNERRORARMINVALID = "IVFNERRORARMINVALID";

	// No se existe la cuenta seleccionada
	public static final String IVFNACCOUNTNOTFOUND = "IVFNACCOUNTNOTFOUND";

	// Firma introducida incorrecta
	public static final String IVFNSIGNINCORRECT = "IVFNSIGNINCORRECT";

	// OTP incorrecto
	public static final String IVFNOTPINCORRECT = "IVFNOTPINCORRECT";

	// Formulario incorrecto
	public static final String IVFNINCORRECTFORM = "IVFNINCORRECTFORM";

	// Error al formalizar la propuesta
	public static final String IVFNFORMALIZEDERROR = "IVFNFORMALIZEDERROR";
	
	//Error 1 en la validación de la preformalizacion de la propuesta
	public static final String IVFNERRORPREFORMALIZEVALIDATION1 = "IVFNERRORPREFORMALIZEVALIDATION1"; 
	
	//Error 2 en la validación de la preformalización de la propuesta
	public static final String IVFNERRORPREFORMALIZEVALIDATION2 = "IVFNERRORPREFORMALIZEVALIDATION2";
	
	//Error 3 en la validación de la anulacion de la  preformalizacion de la propuesta
	public static final String IVFNERRORPREFORMALIZEVALIDATION3 = "IVFNERRORPREFORMALIZEVALIDATION3"; 
	
	//Error 2 en la validación de la preformalización de la propuesta
	public static final String IVFNERRORPREFORMALIZEVALIDATION4 = "IVFNERRORPREFORMALIZEVALIDATION4";

	// Error al generar el documento
	public static final String IVFNDOCUMENTERROR = "IVFNDOCUMENTERROR";

	// Error. Formalizacion denegada por el motor
	public static final String IVFNPROPOSALDENIED = "IVFNPROPOSALDENIED";

	/**** CIRBE ****/

	// Pendiente de Cirbe
	public static final String IVFNCIRBEPENDING = "IVFNCIRBEPENDING";

	// Para verificar su identidad, necesitamos acceder a sus datos.
	public static final String IVFNCIRBEMODAL = "IVFNCIRBEMODAL";

	/** MODELO 200 **/
	// El CSV introducido no se corresponde con la persona titular de la solicitud
	public static final String IVFNERRORM200_06 = "IVFNERRORM200_06";
	// Se ha producido un error en ls descarga del modelo
	public static final String IVFNERRORM200_99 = "IVFNERRORM200_99";

	// Texto email
	public static final String IVFNSMSM200OK = "IVFNSMSM200OK";
	public static final String IVFNSMSM200KO = "IVFNSMSM200KO";
	public static final String IVFNMAILM200OK = "IVFNMAILM200OK";
	public static final String IVFNMAILM200KO = "IVFNMAILM200KO";

	// notificar sin actividad
	public static final String IVFNSMSNOTIFY = "IVFNSMSNOTIFY";
	public static final String IVFNMAILNOTIFY = "IVFNMAILNOTIFY";

	public static final String IVFNMAILCIRBEOK = "IVFNMAILCIRBEOK";
	public static final String IVFNMAILCIRBEKO = "IVFNMAILCIRBEKO";
	public static final String IVFNSMSCIRBEOK = "IVFNSMSCIRBEOK";
	public static final String IVFNSMSCIRBEKO = "IVFNSMSCIRBEKO";
	/****************/

	//
	public static final String IVFNMAILAVALISTAS = "IVFNMAILAVALISTAS";
	public static final String IVFNSMSAVALISTAS = "IVFNSMSAVALISTAS";
	public static final String IVFNMAILAPODERADOS = "IVFNMAILAPODERADOS";
	public static final String IVFNSMSAPODERADOS = "IVFNSMSAPODERADOS";

	public static final String IVFNMAILPMPENDCONTRACT = "IVFNMAILPMPENDCONTRACT";
	
	// Codigo de notificaciones a los avalistas
	public static final String IVFNMAILGUARANTORCONFIRMING = "IVFNMAILGUARANTORCONFIRMING";
	public static final String IVFNSMSGUARANTORCONFIRMING = "IVFNSMSGUARANTORCONFIRMING";

	/** SERVIDOR FTP **/
	// Error al conectar con el ftp
	public static final String IVFNSFTPCONNECTIONERROR = "IVFNSFTPCONNECTIONERROR";

	// Datos incompletos
	public static final String IVFNDATACOMPLETE = "IVFNDATACOMPLETE";

	// Datos oK
	public static final String IVFNDATAOK = "IVFNDATAOK";

	// Error Servicio Lynx
	public static final String IVFNERRORLYNX = "IVFNERRORLYNX";

	/**** ERRORES DE FIRMA ****/
	// No tiene firma
	public static final String IVFNSIGNNOTSIGN = "IVFNSIGNNOTSIGN";
	// No tiene facultades en bastanteo
	public static final String IVFNSIGNNOTFACULTATS = "IVFNSIGNNOTFACULTATS";
	// Firma no completada ya que la empresa es multiapoderada
	public static final String IVFNSIGNNOTCOMPLETE = "IVFNSIGNNOTCOMPLETE";
	// Token de firma caducado
	public static final String IVFNTOKENSIGNEXPIRED = "IVFNTOKENSIGNEXPIRED";

	/** ERROR EN IMPRESION **/
	public static final String IVFNDOCNOTPRINTED = "IVFNDOCNOTPRINTED";

	/***** ERRORES DE FIRMAR LUEGO ****/
	// Estamos experimentando un error, procederemos a dar de baja la solicitud
	public static final String IVFNERRORBUZONEMPRESAS400 = "IVFNERRORBUZONEMPRESAS400";
	// Estamos experimentado un error, vuelve a intentarlo y si el error persiste
	// ponte en contacto en nuestro teléfono de asistencia gratuito
	public static final String IVFNERRORBUZONEMPRESAS500 = "IVFNERRORBUZONEMPRESAS500";
	// Error, emails incorrectos
	public static final String IVFNEMAILINCORRECT = "IVFNEMAILINCORRECT";

	public static final String IVFNPHONENOTVALID = "IVFNPHONENOTVALID";

	public static final String IVFNERRORVALIDATIONRD = "IVFNERRORVALIDATIONRD";

	public static final String IVFNPRODUCTPRESTAMO = "IVFNPRODUCTPRESTAMO";
	public static final String IVFNPRODUCTCREDITO = "IVFNPRODUCTCREDITO";
	public static final String IVFNPRODUCTTARJETA = "IVFNPRODUCTTARJETA";
	public static final String IVFNPRODUCTDESCUBIERTO = "IVFNPRODUCTDESCUBIERTO";

	public static final String IVFNPRODUCTDETAILDESCRIPTIONLIMIT = "IVFNPRODUCTDETAILDESCRIPTIONLIMIT";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONBALANCE = "IVFNPRODUCTDETAILDESCRIPTIONBALANCE";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONCAPITAL = "IVFNPRODUCTDETAILDESCRIPTIONCAPITAL";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONDISPOSED = "IVFNPRODUCTDETAILDESCRIPTIONDISPOSED";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONSHARE = "IVFNPRODUCTDETAILDESCRIPTIONSHARE";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONDATE = "IVFNPRODUCTDETAILDESCRIPTIONDATE";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONTYPE = "IVFNPRODUCTDETAILDESCRIPTIONTYPE";
	public static final String IVFNPRODUCTDETAILDESCRIPTIONDUEDATE = "IVFNPRODUCTDETAILDESCRIPTIONDUEDATE";
	
	public static final String IVFNREFERENCEINDEX = "IVFNREFERENCEINDEX";

	public static final String IVFNGUARANTORTYPEONEPERSON = "IVFNGUARANTORTYPEONEPERSON";
	public static final String IVFNGUARANTORTYPEMOREPERSON = "IVFNGUARANTORTYPEMOREPERSON";

	public static final String IVFNERRORFIRMAAVALISTA = "IVFNERRORFIRMAAVALISTA";
	public static final String IVFNERRORFIRMAAVALISTAAPODERADO = "IVFNERRORFIRMAAVALISTAAPODERADO";

	public static final String IVFNHELPDOUBTS = "IVFNHELPDOUBTS";
	public static final String IVFNHELPMANAGER = "IVFNHELPMANAGER";
	public static final String IVFNHELPQUESTIONS = "IVFNHELPQUESTIONS";
	public static final String IVFNHELPTUTORIALS = "IVFNHELPTUTORIALS";

	// Mas detalles TARJETAS
	public static final String IVFNUNPAIDCAPITAL = "IVFNUNPAIDCAPITAL";
	public static final String IVFNUNPAIDCOMMISSIONS = "IVFNUNPAIDCOMMISSIONS";
	public static final String IVFNUNPAIDORDINARYINTEREST = "IVFNUNPAIDORDINARYINTEREST";
	public static final String IVFNUNPAIDODEFAULTINTEREST = "IVFNUNPAIDODEFAULTINTEREST";
	// Mas detalles PRESTAMOS
	public static final String IVFNUNPAIDOAMOUNTINSTALLMENT = "IVFNUNPAIDOAMOUNTINSTALLMENT";
	public static final String IVFNUNPAIDCURRENTYEAR = "IVFNUNPAIDCURRENTYEAR";
	public static final String IVFNUNPAIDCBACKYEAR = "IVFNUNPAIDCBACKYEAR";
	public static final String IVFNUNPAIDCMAIL = "IVFNUNPAIDCMAIL";
	public static final String IVFNUNPAIDDEBT = "IVFNUNPAIDDEBT";

	// Codigos de error pantalla final de firma modo 4. Descripcion en el front
	public static final String IVFNSIGNMORESIGNATURES = "IVFNSIGNMORESIGNATURES";
	public static final String IVFNSIGNNOMORESIGNATURESNOGUARANTOR = "IVFNSIGNNOMORESIGNATURESNOGUARANTOR";
	public static final String IVFNSIGNNOMORESIGNATURESGUARANTOR = "IVFNSIGNNOMORESIGNATURESGUARANTOR";
	public static final String IVFNSIGNLATERGUARANTORS = "IVFNSIGNLATERGUARANTORS";

	// Codigos de finalizacion de pantalla final con modo de firma 3
	public static final String IVFNMOREREPRESENTATIVE = "IVFNMOREREPRESENTATIVE";
	public static final String IVFNOTHERREPRESENTATIVE = "IVFNOTHERREPRESENTATIVE";
	public static final String IVFNONEREPRESENTATIVE = "IVFNONEREPRESENTATIVE";

	// Finalizacion de apoderados y avalistas
	public static final String IVFNREPRESENTATIVEGUARANTORS = "IVFNREPRESENTATIVEGUARANTORS";
	public static final String IVFNOTHERGUARANTORS = "IVFNOTHERGUARANTORS";

	// Finalizacion de apoderados y avalistas, con firma 3 y Refinaciación
	public static final String IVFNREPRESENTATIVEGUARANTORSREFIS = "IVFNREPRESENTATIVEGUARANTORSREFIS";
	public static final String IVFNREPRESENTATIVEGUARANTORSMEREFIS = "IVFNREPRESENTATIVEGUARANTORSMEREFIS";
	public static final String IVFNSIGNLATERREFIS = "IVFNSIGNLATERREFIS";
	public static final String IVFNSIGNLATERMEREFIS = "IVFNSIGNLATERMEREFIS";

	// Codigos de envio de mail para diferentes formalizaciones
	public static final String IVFNMAILOFICCEERRORREGISTRY = "IVFNMAILOFICCEERRORREGISTRY";
	public static final String IVFNMAILOFICCEERRORREPLICATION = "IVFNMAILOFICCEERRORREPLICATION";
	public static final String IVFNMAILOFICCEGENERIC = "IVFNMAILOFICCEGENERIC";

	// Apoderado consultivo
	public static final String IVFNCONSULTATIONREPRESENTATIVE = "IVFNCONSULTATIONREPRESENTATIVE";

	// Error en seleccion de avalistas
	public static final String IVFNGUARANTORERROR = "IVFNGUARANTORERROR";
	public static final String IVFNGUARANTORNOTLOGGEDERROR = "IVFNGUARANTORNOTLOGGEDERROR";

	// Error en seleccion de firmantes
	public static final String IVFNREPRESENTATIVEERROR = "IVFNREPRESENTATIVEERROR";

	// Mail GDPR ContactInfo Confirming
	public static final String IVFNMAILGDPR = "IVFNMAILGDPR";

	// Cabecera Formalizacion
	public static final String IVFNHEADFORMALIZATION = "IVFNHEADFORMALIZATION";

	// Pie Formalizacion
	public static final String IVFNFOOTFORMALIZATION = "IVFNFOOTFORMALIZATION";

	// Mensaje Enhorabuena, Email de contratacion PA
	public static final String IVFNCONGRATULATIONSFORMALIZATION="IVFNCONGRATULATIONSFORMALIZATION";
	
	// Contratación
	public static final String IVFHIRINGMESSAGE="IVFHIRINGMESSAGE";
	
	// Confirmación
	public static final String IVFNCONFIRMATION= "IVFNCONFIRMATION";
	
	// Financiacion Empresas
	public static final String IVFNBUSINESSFINANCING= "IVFNBUSINESSFINANCING";
	
	//Interes de financiacion
	public static final String IVFNINTFIN = "IVFNINTFIN";
	
	//Comision de financiacion
	public static final String IVFNCOMFIN = "IVFNCOMFIN";
	

	
	//Apertura / Renovacion
	public static final String IVFNCOMAF = "IVFNCOMAF";
	
	//Comision de anulacion asistido
	public static final String IVFNCAR = "IVFNCAR";
	
	//Comision de anulacion no asistido
	public static final String IVFNCAN = "IVFNCAN";
	
	//Comisión de modificación de financiación realizada en canal
    public static final String IVFNCML = "IVFNCML";
	
    //Comisión de modificación de financiación no realizada en canal
    public static final String IVFNCMD = "IVFNCMD";
    
    //Euribor
    public static final String IVFNEURIBOR="IVFNEURIBOR";
	
	// Importe Total
	public static final String IVFNTOTALIMPORT = "IVFNTOTALIMPORT";	
	
	//Plazo 
	public static final String IVFNPLAZO = "IVFNPLAZO";
	
	
	//Plazo de financiacion
	public static final String IVFNPLAZOPRO= "IVFNPLAZOPRO";
	// Mnemo tooltip
	public static final String IVFNMNEMOTOOLTIP = "IVFNMNEMOTOOLTIP";
	// Cuenta asociada
	public static final String IVFNACCOUNT = "IVFNACCOUNT";
	// Pagos nacionales
	public static final String IVFNATIONALPAY = "IVFNATIONALPAY";
	// Pagos internacionales
	public static final String IVFNINTERNATIONALPAY = "IVFNINTERNATIONALPAY";

	// Meses
	public static final String IVFNMONTHS = "IVFNMONTHS";
	public static final String IVFNMONTH = "IVFNMONTH";

	// Dias
	public static final String IVFNDAY = "IVFNDAY";
	public static final String IVFNDAYS = "IVFNDAYS";

	// Condiciones de contratacion
	public static final String IVFNHIRINGCONDITIONS = "IVFNHIRINGCONDITIONS";

	// SMS formalización (apoderados y avalistas) Confirming
	public static final String IVFNSMSFORMALIZATIONCONFIRMING = "IVFNSMSFORMALIZATIONCONFIRMING";

	// Error Nmeos
	public static final String IVFNMNEMOCERROR = "IVFNMNEMOCERROR";

	// Texto detalle FFNN avalista
	public static final String IVFFFNNTEXTGUARANTORS = "IVFFFNNTEXTGUARANTORS";

	// Aviso de error FFNN Avalistas
	public static final String IVFFFNNGUARANTORSERROR = "IVFFFNNGUARANTORSERROR";

	//
	// Notificaciones PSD2
	// Notificacion 02-ko, online
	public static final String IVFNPSD2AGREGRADORERROR = "IVFNPSD2AGREGRADORERROR";
	public static final String IVFNMAILPSD2ERROR = "IVFNMAILPSD2ERROR";
	public static final String IVFNSMSPSD2ERROR = "IVFNSMSPSD2ERROR";
	// Denegada
	public static final String IVFNMAILPSD2DENEGADA = "IVFNMAILPSD2DENEGADA";
	public static final String IVFNSMSPSD2DENEGADA = "IVFNSMSPSD2DENEGADA";
	// OK
	public static final String IVFNMAILPSD2OK = "IVFNMAILPSD2OK";
	public static final String IVFNSMSPSD2OK = "IVFNSMSPSD2OK";

	// Fecha de borrado de control de firma 3 para productos psd2 con clientes
	// orientados
	public static final String IVFNDATEDELETECONTROLSIGNPSD2 = "IVFNDATEDELETECONTROLSIGNPSD2";

	public static final String IVFNGUARANTORNODATAOBLIGATORY = "IVFNGUARANTORNODATAOBLIGATORY";

	// EMAIL al formalizar la propuesta
	public static final String IVFNMAILERRORFORMALIZATION = "IVFNMAILERRORFORMALIZATION";

	// Aviso sobre utilizacion de navegador
	public static final String IVFNWARNINGBACKBROWSER = "IVFNWARNINGBACKBROWSER";
	
	// Error modelos csv
	public static final String IVFNMODELSCSVERROR = "IVFNMODELSCSVERROR";
	public static final String IVFNMODEL = "IVFNMODEL";
	public static final String IVFNAEATERROR = "IVFNAEATERROR";
	public static final String IVFNADDITIONALCSVKO = "IVFNADDITIONALCSVKO";
	
	// Notificación a Oficina y Gestor PYMES
	public static final String IVFNMAILOFICCEPYMES = "IVFNMAILOFICCEPYMES";
	
	// Notificación a Oficina y Gestor PYMES PMP 
	public static final String IVFNMAILOFICCEPYMESPMP = "IVFNMAILOFICCEPYMESPMP";
	
	// Notificación operacion a Oficina
	public static final String IVFNMAILTRANSFEROFFICECOMEX = "IVFNMAILTRANSFEROFFICECOMEX";
	
	// Notificación operacion a Oficina final
	public static final String IVFNMAILFINCOMEX = "IVFNMAILFINCOMEX";
	
	// No existe informacion sobre kpis
	public static final String IVFNKPINODATA = "IVFNKPINODATA";

	// Notificación operacion cuando no tiene Servicio GT
	public static final String IVFNMAILNOGTCOMEX = "IVFNMAILNOGTCOMEX";
	
	//Textos pintar pantallas finales
	public static final String IVFNRESULTTRANSFEROFFICE = "IVFNRESULTTRANSFEROFFICE";
	public static final String IVFNRESULTSANCTION = "IVFNRESULTSANCTION";
	public static final String IVFNRESUTSERVICEACTIVATION = "IVFNRESUTSERVICEACTIVATION";
	public static final String IVFNRESULTCANCELPROPOSAL = "IVFNRESULTCANCELPROPOSAL";
	public static final String IVFNIMPORTFINANCEEND = "IVFNIMPORTFINANCEEND";
	
	

	//Ningún interviniente pertenece a PMP
	public static final String IVFNPMPERRORINTERVENERS = "IVFNPMPERRORINTERVENERS";

	public static final String IVFNPMPERROR = "IVFNPMPERROR";
	
	// Error mensaje final usuario
	public static final String IVFNRESULTTRANSFEROFFICEPMP = "IVFNRESULTTRANSFEROFFICEPMP";
	
	// Mensaje de oficina no han firmado todos los firmantes
	public static final String IVFNWACOMERRORSIGNERS = "IVFNWACOMERRORSIGNERS";

	// Error oficina motor y propuestas
	public static final String IVFNERRORMOTOR = "IVFNERRORMOTOR";
	public static final String IVFNERRORAPROVALPPTAPRECIOS = "IVFNERRORAPROVALPPTAPRECIOS";
	public static final String IVFNERRORAPROVALPPTARIESGOS = "IVFNERRORAPROVALPPTARIESGOS";

	public static final String IVFNERRORPREFORMPPTA = "IVFNERRORPREFORMPPTA";

	// Mensaje de comienzo de concatenación
	public static final String IVFNMESSAGEBEGINNING = "IVFNMESSAGEBEGINNING";

	// Mensaje de fin de concatenación
	public static final String IVFNMESSAGEEND = "IVFNMESSAGEEND";

	// Mensaje de plazo superior a 96 meses.
	public static final String IVFNEXCEEDED96 = "IVFNEXCEEDED96";

	// Mensaje cuando no tiene interviniente con contrato cmc válido.
	public static final String IVFNINVALIDCMC = "IVFNINVALIDCMC";

	// Mensaje cuando importe supera los 50000 €.
	public static final String IVFNEXCEEDED50000 = "IVFNEXCEEDED50000";

	// Mensaje cuando no tiene intervinientes apoderados.
	public static final String IVFNNOINTERVENER = "IVFNNOINTERVENER";

	// Mensaje de error de cancelado de expediente
	public static final String IVFNCANCELSOLICITUDEERROR = "IVFNCANCELSOLICITUDEERROR";

	// Mensaje cuando falla la validacion de fioc.
	public static final String IVFNERRORTRXFIOC = "IVFNERRORTRXFIOC";

	// Errores de formalizacion
	public static final String IVFNFORMALIZEDERRORBUZON = "IVFNFORMALIZEDERRORBUZON";
	public static final String IVFNFORMALIZEDERRORBUZONPREFORM = "IVFNFORMALIZEDERRORBUZONPREFORM";

	public static final String IVFNFORMALIZEDERRORWACOM = "IVFNFORMALIZEDERRORWACOM";

	public static final String IVFNCANCELFORMALIZEDERRORDAY = "IVFNCANCELFORMALIZEDERRORDAY";

	public static final String IVFNCANCELFORMALIZEDERROR = "IVFNCANCELFORMALIZEDERROR";

	/** cmc en pago agil*/
	public static final String IVFNIMPORTFINANCEENDPA = "IVFNIMPORTFINANCEENDPA";

	/** Intervener-guarantor**/
	public static final String IVFNINTERVENERGUARANTOR = "IVFNINTERVENERGUARANTOR";

	/** Centro no valido */
	public static final String IVFNINVALIDCENTER="IVFNINVALIDCENTER";

	private ErrorServiceConstants() {
		throw new IllegalStateException("Utility class");
	}
}