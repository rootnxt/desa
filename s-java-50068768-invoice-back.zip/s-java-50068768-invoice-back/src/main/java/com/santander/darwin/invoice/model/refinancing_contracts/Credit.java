package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Credit.java
 *
 * @author igndom
 *
 */
public class Credit extends CommonRefinancing {

	private String irregularEntryDate;
	private String dueDate;
	private String tin;
	private BalancesCredit balances;

	/**
	 * @return the irregularEntryDate
	 */
	public String getIrregularEntryDate() {
		return irregularEntryDate;
	}

	/**
	 * @param irregularEntryDate the irregularEntryDate to set
	 */
	public void setIrregularEntryDate(String irregularEntryDate) {
		this.irregularEntryDate = irregularEntryDate;
	}

	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return the tin
	 */
	public String getTin() {
		return tin;
	}

	/**
	 * @param tin the tin to set
	 */
	public void setTin(String tin) {
		this.tin = tin;
	}

	/**
	 * @return the balances
	 */
	public BalancesCredit getBalances() {
		return balances;
	}

	/**
	 * @param balances the balances to set
	 */
	public void setBalances(BalancesCredit balances) {
		this.balances = balances;
	}

}
