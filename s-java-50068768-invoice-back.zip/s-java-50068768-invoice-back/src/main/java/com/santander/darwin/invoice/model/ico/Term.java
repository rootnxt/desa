package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Term.
 */

/**
 * Sets the months.
 *
 * @param months the new months
 */
@Setter

/**
 * Gets the months.
 *
 * @return the months
 */
@Getter

/**
 * Instantiates a new term.
 */
@NoArgsConstructor
public class Term {
	 
 	/** The months. */
 	private int months;
}
