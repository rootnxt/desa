package es.santander.darwin.financiaciondigital.util.converters;

import java.beans.PropertyEditorSupport;
import java.math.BigDecimal;

import org.springframework.util.NumberUtils;

/**
 * The Class BigDecimalCustomEditor.
 */
public class BigDecimalCustomEditor extends PropertyEditorSupport {

    /*
     * (non-Javadoc)
     * 
     * @see java.beans.PropertyEditorSupport#setAsText(java.lang.String)
     */
    @Override
    public void setAsText(String text) {
        BigDecimal numberValue = NumberUtils.parseNumber(text, BigDecimal.class);
        this.setValue(numberValue);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.beans.PropertyEditorSupport#getAsText()
     */
    @Override
    public String getAsText() {
        Object value = getValue();
        if (value == null) {
            return "";
        } else {
            return value.toString();
        }
    }

}
