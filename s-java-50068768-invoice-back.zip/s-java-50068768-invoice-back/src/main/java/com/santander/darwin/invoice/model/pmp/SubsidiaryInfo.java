package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a
 * new SubsidiaryInfo
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubsidiaryInfo {
    /** The personType. */
    private String personType;
    /** The personCode. */
    private int personCode;
    /** The tipDoc. */
    private String tipDoc;
    /** The cif. */
    private String cif;
    /** The companyName. */
    private String companyName;
}
