package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SourceTypeVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the source type VO
 */
@Builder

/**
 * Instantiates a new source type VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new source type VO.
 *
 * @param sourceType the source type
 * @param criticidad the criticidad
 */
@AllArgsConstructor
public class SourceTypeVO {

    /** The source type. */
    private String sourceType;
    
    /** The criticality. */
    private String criticidad; 
}
