package es.santander.darwin.financiaciondigital.jpa.model;

import java.io.Serializable;

/**
 * The Class SerializableParent.
 */
public class SerializableParent implements Serializable{
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1381167501193874667L;

}
