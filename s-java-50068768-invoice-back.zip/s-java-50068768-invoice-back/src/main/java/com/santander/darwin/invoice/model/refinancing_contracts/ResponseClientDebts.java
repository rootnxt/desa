package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * ResponseClientDebts.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ResponseClientDebts {
	
	// Variables
	private List<ClientDebts> clientes;

}
