package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Optional;

/**
 * The
 * DatosCentro
 * Dto
 * model
 *
 */
@Getter
@EqualsAndHashCode
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DatosCentro implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * idtipvia
     * */
    private String idtipvia;

    /**
     * nomvia
     * */
    private String nomvia;

    /**
     * numvia
     * */
    private String numvia;

    /**
     * nomplaz
     * */
    private String nomplaz;

    /**
     * distrito
     * */
    private String distrito;

    /**
     * centerId
     * */
    @Setter
    private String centerId;

    /** Trimming
     * setting
     * idtipvia. */
    public void setIdtipvia(String idtipvia) {
        this.idtipvia = Optional.ofNullable(idtipvia).map(String::trim).orElse(null);
    }

    /** Trimming
     * setting
     * nomvia. */
    public void setNomvia(String nomvia) {
        this.nomvia = Optional.ofNullable(nomvia).map(String::trim).orElse(null);
    }

    /** Trimming
     * setting
     * numvia. */
    public void setNumvia(String numvia) {
        this.numvia = Optional.ofNullable(numvia).map(String::trim).orElse(null);
    }

    /** Trimming
     * setting
     * nomplaz. */
    public void setNomplaz(String nomplaz) {
        this.nomplaz = Optional.ofNullable(nomplaz).map(String::trim).orElse(null);
    }

    /** Trimming
     * setting
     * distrito. */
    public void setDistrito(String distrito) {
        this.distrito = Optional.ofNullable(distrito).map(String::trim).orElse(null);
    }
}
