package com.santander.darwin.invoice.model.help;

import com.santander.darwin.invoice.model.common.CommonUrlDescription;

/**
 * Doubts.java
 *
 * @author igndom
 *
 */
public class Doubts {

	private String title;
	private CommonUrlDescription questions;
	private CommonUrlDescription tutorials;

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the questions
	 */
	public CommonUrlDescription getQuestions() {
		return questions;
	}

	/**
	 * @param questions the questions to set
	 */
	public void setQuestions(CommonUrlDescription questions) {
		this.questions = questions;
	}

	/**
	 * @return the tutorials
	 */
	public CommonUrlDescription getTutorials() {
		return tutorials;
	}

	/**
	 * @param tutorials the tutorials to set
	 */
	public void setTutorials(CommonUrlDescription tutorials) {
		this.tutorials = tutorials;
	}

}
