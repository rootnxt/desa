package es.santander.darwin.financiaciondigital.service;

import java.math.BigDecimal;

import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;

public interface CirbeSasnaService {

    /**
     * Call sasna.
     *
     * @param companyId the company id
     * @param personType the person type
     * @param personCode the person code
     * @param petitionUser the petition user
     * @return the string
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    SasnaResponse callSasna(String companyId, String personType, BigDecimal personCode, String petitionUser)
            throws DigitalConsumptionServiceException;

}
