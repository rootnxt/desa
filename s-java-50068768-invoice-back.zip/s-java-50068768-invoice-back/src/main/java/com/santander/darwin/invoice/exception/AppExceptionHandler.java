package com.santander.darwin.invoice.exception;

import com.santander.darwin.invoice.constants.Constants;
import com.santander.darwin.invoice.constants.ErrorServiceConstants;
import com.santander.darwin.invoice.constants.StateFront;
import com.santander.darwin.invoice.exception.model.ErrorAppType;
import com.santander.darwin.invoice.exception.model.PreValidationErrorBean;
import com.santander.darwin.invoice.exception.model.ValidationErrorBean;
import com.santander.darwin.invoice.model.InvoiceFinancing;
import com.santander.darwin.invoice.model.errors.InvoiceErrorValidation;
import com.santander.darwin.invoice.model.mtdl_url.InvoiceMtdlUrl;
import com.santander.darwin.invoice.model.sgrerrores.SGRRequest;
import com.santander.darwin.invoice.model.sgrerrores.SGRRetorno;
import com.santander.darwin.invoice.repository.db.InvoiceFinancingRepository;
import com.santander.darwin.invoice.repository.db.InvoiceMtdlUrlRepository;
import com.santander.darwin.invoice.repository.rest.SGRErroresRepository;
import com.santander.darwin.invoice.service.ArmService;
import com.santander.darwin.invoice.service.InvoiceErrorValidationService;
import com.santander.darwin.invoice.utils.BasicUtils;
import com.santander.darwin.invoice.utils.CodeErrorExceptionUtils;
import com.santander.darwin.invoice.utils.MessageUtils;
import com.santander.darwin.invoice.utils.StringBasicTowUtils;
import com.santander.darwin.invoice.utils.Utils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

/**
 * the AppExceptionHandler
 * 
 * @author igndom
 *
 */
@Component
@ControllerAdvice
@Slf4j
public class AppExceptionHandler extends ResponseEntityExceptionHandler {

	public static final int NUMBER_LINES_SHOW = 5;
	
	private static final String IVFNNOTLIMITERROR = "IVFNNOTLIMITERROR";

	// Servicio arm
	private ArmService armService;
	// Utils
	private Utils utils;
	
	// Repository mdtl url
	private InvoiceMtdlUrlRepository mtdlUrlRepository;
	
	/** The sgr errores repository. */
	private SGRErroresRepository sgrErroresRepository;
	
	/** The Invoice Financing repository. */
	private InvoiceFinancingRepository invoiceFinancingRepository;
	
	/** The StringBasicTowUtils. */
	private StringBasicTowUtils stringBasicTowUtils;

	/**
	 * Constructor Autowired.
	 *
	 * @param armService ArmService
	 * @param utils      Utils
	 * @param mtdlUrlRepository      InvoiceMtdlUrlRepository
	 * @param invoiceErrorValidationService InvoiceErrorValidationService
	 * @param sgrErroresRepository the sgr errores repository
	 * @param invoiceFinancingRepository InvoiceFinancingRepository
	 * @param stringBasicTowUtils StringBasicTowUtils
	 * 
	 */
	@Autowired
	public AppExceptionHandler(ArmService armService, Utils utils, InvoiceMtdlUrlRepository mtdlUrlRepository,
			InvoiceErrorValidationService invoiceErrorValidationService, SGRErroresRepository sgrErroresRepository, 
			InvoiceFinancingRepository invoiceFinancingRepository, StringBasicTowUtils stringBasicTowUtils) {
		this.armService = armService;
		this.utils = utils;
		this.mtdlUrlRepository = mtdlUrlRepository;
		this.sgrErroresRepository = sgrErroresRepository;
		this.invoiceFinancingRepository = invoiceFinancingRepository;
		this.stringBasicTowUtils = stringBasicTowUtils;
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		log.error("Exception: MethodArgumentNotValidException");
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()));
		// comentario
		errorBean.setCode(ErrorServiceConstants.IVFNDATAINCOMPLETE);
		// comentario
		if (log.isDebugEnabled()) {
			ex.getBindingResult().getFieldErrors().stream().forEach((FieldError p) -> log.error(p.getDefaultMessage()));
		}

		// comentario
		InvoiceErrorValidation errMessages = armService
				.getErrorMessagesByCode(ErrorServiceConstants.IVFNDATAINCOMPLETE, Constants.CHANNEL_EMP);
		// comentario
		errorBean.setMessage(MessageUtils.getDetailMessageByLang(errMessages, Constants.DEFAULT_LANG));
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGE.getCode());
		// comentario
		errorBean.setPresentation(utils.getApp(Constants.APP_FACTURAS_ID, Constants.CHANNEL_EMP).getPresentation());
		return new ResponseEntity<>(errorBean, headers, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	protected ResponseEntity<Object> exception(ConstraintViolationException e, HttpServletRequest request) {
		log.error("Exception: ConstraintViolationException");
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()));
		// comentario
		errorBean.setCode(ErrorServiceConstants.IVFNDATAINCOMPLETE);
		// comentario
		if (log.isDebugEnabled()) {
			e.getConstraintViolations().stream()
					.forEach((ConstraintViolation<?> p) -> log.error("{}-{}", p.getPropertyPath(), p.getMessage()));
		}

		InvoiceErrorValidation errMessages = armService
				.getErrorMessagesByCode(ErrorServiceConstants.IVFNDATAINCOMPLETE, Constants.CHANNEL_EMP);
		// comentario
		errorBean.setMessage(MessageUtils.getDetailMessageByLang(errMessages, Constants.DEFAULT_LANG));
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGE.getCode());
		// comentario
		errorBean.setPresentation(utils.getApp(Constants.APP_FACTURAS_ID, Constants.CHANNEL_EMP).getPresentation());
		return new ResponseEntity<>(errorBean, headers, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	protected ResponseEntity<Object> exception(Exception e, HttpServletRequest request) {
		log.error("Exception: exception {}", BasicUtils.reduceNumberLinesStackTrace(e, NUMBER_LINES_SHOW));
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
		// comentario
		errorBean.setCode(ErrorServiceConstants.IVFNGENERICERROR);
		// comentario
		errorBean.setMessage(ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT);
		// comentario
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGE.getCode());
		// comentario
		errorBean.setPresentation(utils.getApp(Constants.APP_FACTURAS_ID, Constants.CHANNEL_EMP).getPresentation());
		return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(PmpControllerException.class)
	protected ResponseEntity<Object> exceptionPmp(PmpControllerException e, HttpServletRequest request) {
		log.error("Exception: exception {}", BasicUtils.reduceNumberLinesStackTrace(e, NUMBER_LINES_SHOW));
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
		// comentario
		String code = e.getCode() == null || e.getCode().isEmpty()
				? ErrorServiceConstants.IVFNGENERICERROR
				: e.getCode();
		errorBean.setCode(code);
		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(),
				Constants.CHANNEL_EMP);
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));
		// comentario
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGE.getCode());
		// comentario
		errorBean.setPresentation(utils.getApp(Constants.APP_FACTURAS_ID, Constants.CHANNEL_EMP).getPresentation());
		return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	private void callArm(GenericException e) {

		if (e.getOperationId() != null && !e.getOperationId().isEmpty()
				&& utils.isArmApp(e.getApp(), Constants.CHANNEL_EMP)) {
			// Validamos que este en ARM si la app tiene el arm a true en mongo
			try {
				// comentario
				armService.updateCancelled(e.getOperationId(), ErrorServiceConstants.IVFNGENERICERROR, e.getLang(),
						Constants.CHANNEL_EMP);
			} catch (Exception exx) {
				log.error("Error ", exx);
			}
		}
	}

	@ExceptionHandler(GenericException.class)
	protected ResponseEntity<Object> genericException(GenericException e, HttpServletRequest request) {
		log.error("Exception: GenericException");
		// Recogemos el canal
		String channel = stringBasicTowUtils.getChannelRequest(request);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		String status = e.getStatus() == null || e.getStatus().isEmpty()
				? String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())
				: e.getStatus();
		// comentario
		errorBean.setStatus(status);
		// comentario
		errorBean.setPresentation(utils.getApp(e.getApp(), channel).getPresentation());
		// comentario
		if (e.getCode() == null || StringUtils.EMPTY.equalsIgnoreCase(e.getCode())) {
			errorBean.setCode(ErrorServiceConstants.IVFNGENERICERROR);
		} else {
			errorBean.setCode(e.getCode());
		}

		// Llamada a arm
		callArm(e);

		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(),
				channel);
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGE.getCode());
		// comentario
		errorBean.setCode(ErrorServiceConstants.IVFNGENERICERROR);
		// Rellenamos mensaje y tipos del error
		fillErrorBeanMessage(errorBean , e, channel);
		
		errorBean.setNameApp(utils.getApp(e.getApp(), channel).getDescription().get(0).getName());
		 if(ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION1.equalsIgnoreCase(e.getCode())||
					ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION2.equalsIgnoreCase(e.getCode()) ||
					ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION3.equalsIgnoreCase(e.getCode()) ||
					ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION4.equalsIgnoreCase(e.getCode()) 				
					) {
			 return new ResponseEntity<>(errorBean, headers, HttpStatus.BAD_REQUEST);
		 }
		 else if(Constants.PREVALIDATION_ERRORS.contains(e.getCode())) {
			errorBean.setStatus(String.valueOf(HttpStatus.ACCEPTED.value()));
			return new ResponseEntity<>(errorBean, headers, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	/**
	 * Fill error bean message.
	 *
	 * @param errorBean the error bean
	 * @param e the e
	 * @param channel the channel
	 */
	private void fillErrorBeanMessage(ValidationErrorBean errorBean, GenericException e, String channel) {
		// Casuistica control de error preconcedidos y orientados
		// Casuistica denegada
		if (ErrorServiceConstants.IVFNERRORFINANCERANGE.equalsIgnoreCase(e.getCode())
				|| ErrorServiceConstants.IVFNPROPOSALDENIED.equalsIgnoreCase(e.getCode())) {
			errorBean.setPresentation(Constants.CONF_APP_STATE_CODE);
			errorBean.setStyle(Constants.STYLE_ERROR_PAGE_ICON_AND_BUTTON);

			if (ErrorServiceConstants.IVFNPROPOSALDENIED.equalsIgnoreCase(e.getCode())
					&& channel.equals(Constants.CHANNEL_OFI)) {
				// Obtenemos el operationId para consultar la colección de Mongo

				generateMsg (e,errorBean);
			}

		} else if (ErrorServiceConstants.IVFNNOTLIMITP2ERROR.equalsIgnoreCase(e.getCode())
				|| ErrorServiceConstants.IVFNNOTLIMITP3ERROR.equalsIgnoreCase(e.getCode())
				|| ErrorServiceConstants.IVFNNOTLIMITPLIMITSERROR.equalsIgnoreCase(e.getCode())) {
			// comentario
			errorBean.setCode(ErrorServiceConstants.IVFNNOTLIMITP2ERROR);
			errorBean.setUrl(mtdlUrlRepository.findByStateFront(StateFront.STATE_PYMES_END_ERROR_NO_LIMITS.getCode())
					.map(InvoiceMtdlUrl::getUrl).orElse(StringUtils.EMPTY));
			errorBean.setType(ErrorAppType.PAGEURLB.getCode());
			errorBean.setStyle(Constants.STYLE_ERROR_PAGE_ICON_AND_BUTTON);
			errorBean.setChannel(channel);
		} else if(ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION1.equalsIgnoreCase(e.getCode())||
				ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION2.equalsIgnoreCase(e.getCode()) ||
				ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION3.equalsIgnoreCase(e.getCode()) ||
				ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION4.equalsIgnoreCase(e.getCode()) 				
				) {
		    errorBean.setCode(e.getCode());
		    errorBean.setStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()));
			errorBean.setUrl(ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION2.equalsIgnoreCase(e.getCode())||
					ErrorServiceConstants.IVFNERRORPREFORMALIZEVALIDATION4.equalsIgnoreCase(e.getCode())
					?"/requests":null);
		}
		else {
			log.debug("No se hace nada");
		}

	}

	/**
	 * Call SGR error.
	 *
	 * @param e the e
	 * @return the string
	 */
	private void generateMsg (GenericException e, ValidationErrorBean errorBean) {
		
		if (e.getOperationId() != null && !e.getOperationId().isEmpty()) {

			String operationId = e.getOperationId();
			InvoiceFinancing ivf = invoiceFinancingRepository.findByOperationId(operationId).get(0);
			String errMessageStr = errorBean.getMessage();

			// Reemplazamos las variables de la URL
			errMessageStr = errMessageStr.replace("{empresa}", ivf.getProposal().getCompany());
			errMessageStr = errMessageStr.replace("{centro}", ivf.getProposal().getCenter());
			errMessageStr = errMessageStr.replace("{anyo}", ivf.getProposal().getYear());
			errMessageStr = errMessageStr.replace("{numeroPropuesta}",
					Integer.toString(ivf.getProposal().getNumber().intValue()));
			errMessageStr = errMessageStr.replace("{tipoPersona}", ivf.getPerson().getTIPODEPERSONA());
			errMessageStr = errMessageStr.replace("{codigoPersona}",
					Integer.toString(ivf.getPerson().getCODIGODEPERSONA()));

			// Sustituimos el mensaje
			errorBean.setMessage(errMessageStr);
		}
		
	}
	
	
	@ExceptionHandler(PageUrlException.class)
	protected ResponseEntity<Object> pageUrlException(PageUrlException e, HttpServletRequest request) {
		log.error("Exception: PageUrlException");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));

		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.PAGEURL.getCode());
		// comentario
		errorBean.setCode(ErrorServiceConstants.IVFNGENERICREDIRECT);
		
		// url de redireccion
		errorBean.setUrl(e.getUrl());
		

		return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(ModalCustomException.class)
	protected ResponseEntity<Object> exception(ModalCustomException e, HttpServletRequest request) {
		log.error("Exception: ModalCustomException");
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = buildModalException(e.getCode(), e.getApp(), e.getLang());
		errorBean.setType(ErrorAppType.MODALCUSTOM.getCode());

		return new ResponseEntity<>(errorBean, headers, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(ModalException.class)
	protected ResponseEntity<Object> modalException(ModalException e, HttpServletRequest request) {
		log.error("Exception: ModalException");
		// comentario
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = buildModalException(e.getCode(), e.getApp(), e.getLang());
		errorBean.setType(ErrorAppType.MODAL.getCode());

		return new ResponseEntity<>(errorBean, headers, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(ServiceException.class)
	protected ResponseEntity<Object> exception(ServiceException e, HttpServletRequest request) {
		log.error("Exception: ServiceException");
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.UNPROCESSABLE_ENTITY.value()));
		// comentario
		errorBean.setCode(e.getCode());
		// comentario
		errorBean.setPresentation(utils.getApp(e.getApp(), Constants.CHANNEL_EMP).getPresentation());

		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(),
				Constants.CHANNEL_EMP);
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));
		// comentario
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.FORM.getCode());

		return new ResponseEntity<>(errorBean, headers, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	/**
	 * service channel exception.
	 *
	 * @param e the e
	 * @param request the request
	 * @return the response entity
	 */
	@ExceptionHandler(ServiceChannelException.class)
	protected ResponseEntity<Object> exception(ServiceChannelException e, HttpServletRequest request) {
		log.error("Exception: ServiceChannelException");
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.UNPROCESSABLE_ENTITY.value()));
		// comentario
		errorBean.setCode(e.getCode());

		// comentario
		errorBean.setPresentation(utils.getApp(e.getApp(), e.getChannel()).getPresentation());

		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(),
				e.getChannel());
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));
		// comentario
		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.FORM.getCode());

		return new ResponseEntity<>(errorBean, headers, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(PreValidationException.class)
	protected ResponseEntity<Object> preValidationException(PreValidationException e, HttpServletRequest request) {
		log.error("Exception: PreValidationException");
		// comentario
		HttpHeaders headers = new HttpHeaders();
		// comentario
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		PreValidationErrorBean errorBean = new PreValidationErrorBean();
		// comentario
		errorBean.setStatus(e.getStatus());
		errorBean.setCode(e.getCode());
		errorBean.setTimestamp(System.currentTimeMillis());

		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(), Constants.CHANNEL_EMP);
		errorBean.setShortMessage(errMessages.getShortMessage());
		if (e.getStatus().equalsIgnoreCase(String.valueOf(HttpStatus.BAD_REQUEST.value()))) {
			errorBean.setDetailedMessage(e.getDetailedMessage());
		} else {
			errorBean.setDetailedMessage(MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));
		}

		// Obtenemos el operationId y el invocante y consultamos la aplicacion
		if (e.getOperationId() != null && utils.isArmApp(e.getAppId(), Constants.CHANNEL_EMP)) {
			// Validamos que este en ARM si la app tiene el arm a true en mongo
			try {
				armService.updateCancelled(e.getOperationId(), ErrorServiceConstants.IVFNGENERICERROR, e.getLang(),
						Constants.CHANNEL_EMP);
			} catch (Exception ex) {
				log.error("Exception: updateCancelled -> ", ex);
			}
		}
		return new ResponseEntity<>(errorBean, headers,
				e.getStatus().equalsIgnoreCase(String.valueOf(HttpStatus.BAD_REQUEST.value())) ? HttpStatus.BAD_REQUEST
						: HttpStatus.NO_CONTENT);
	}

	/**
	 * SGR service exception.
	 *
	 * @param e the e
	 * @param request the request
	 * @return the response entity
	 */
	@ExceptionHandler(SGRServiceException.class)
	protected ResponseEntity<Object> sGRServiceException(SGRServiceException e, HttpServletRequest request) {
		log.error("Exception: SGRServiceException");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		String status = e.getStatus() == null || e.getStatus().isEmpty()
				? String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())
				: e.getStatus();
		// comentario
		errorBean.setStatus(status);
		// comentario
		errorBean.setPresentation(utils.getApp(e.getApp(), e.getChannel()).getPresentation());
		// comentario
		errorBean.setCode(e.getCode());

		// Llamada a Gestor de errores
		// comentario
		errorBean.setMessage(callSGRError(e));
		
		// Llamada a arm si no existe error
		if(ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT.equals(errorBean.getMessage()) || 
				IVFNNOTLIMITERROR.equals(errorBean.getMessage()) ||
				ErrorServiceConstants.IVFNSTATEINCONTRACTNOTVALID.equals(errorBean.getMessage())) {
		   InvoiceErrorValidation errMessagesArm = armService.getErrorMessagesByCode(errorBean.getCode(),
				e.getChannel());
		   errorBean.setMessage(errMessagesArm == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessagesArm, e.getLang()));
		}
		if(!Constants.CHANNEL_OFI.equalsIgnoreCase(e.getChannel())){
			errorBean.setMessage(ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT);
		}

		errorBean.setCode(ErrorServiceConstants.IVFNGENERICERROR);

		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.ALERT.getCode());

		errorBean.setNameApp(utils.getApp(e.getApp(), e.getChannel()).getDescription().get(0).getName());

		
		return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

	/**
	 * SGR code service exception.
	 *
	 * @param e the e
	 * @param request the request
	 * @return the response entity
	 */
	@ExceptionHandler(SGRCodeServiceException.class)
	protected ResponseEntity<Object> sGRCodeServiceException(SGRCodeServiceException e, HttpServletRequest request) {
		log.error("Exception: SGRCodeServiceException");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		// comentario
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		String status = e.getStatus() == null || e.getStatus().isEmpty()
				? String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())
				: e.getStatus();
		// comentario
		errorBean.setStatus(status);
		// comentario
		errorBean.setPresentation(utils.getApp(e.getApp(), e.getChannel()).getPresentation());
		// comentario
		errorBean.setCode(e.getCode());

		// Llamada a Gestor de errores
		// comentario
		SGRServiceException sgrExp = new SGRServiceException(e.getLang(), e.getApp(), e.getCode(), e.getUsuario(), e.getEntidad(),e.getOficina(), e.getChannel());

		errorBean.setMessage(callSGRError(sgrExp));

		// Ponemos el de invoice
		// comentario
		errorBean.setCode(e.getInvoiceCode());

		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(),
				e.getChannel());
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, e.getLang()));

		if(!Constants.CHANNEL_OFI.equalsIgnoreCase(e.getChannel()) && !Constants.LIMITS_ERRORS.contains(e.getCode())){
			errorBean.setMessage(ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT);
		}

		errorBean.setTimestamp(System.currentTimeMillis());
		// comentario
		errorBean.setType(ErrorAppType.ALERT.getCode());

		errorBean.setNameApp(utils.getApp(e.getApp(), e.getChannel()).getDescription().get(0).getName());


		return new ResponseEntity<>(errorBean, headers, HttpStatus.INTERNAL_SERVER_ERROR);

	}
	
	/**
	 * Call SGR error.
	 *
	 * @param e the e
	 * @return the string
	 */
	private String callSGRError(SGRServiceException e) {
		// Datos para servicio SGR
		SGRRequest requestErrores = new SGRRequest();
		// Codigo
		requestErrores.setCodRetorno(CodeErrorExceptionUtils.getCodErrorFromHttpException(e.getCode()));
		// Entidad
		requestErrores.setCodEntidad(e.getEntidad());
		// Oficina
		requestErrores.setCodOficina(e.getOficina());
		// Usuario
		requestErrores.setIdUsuario(e.getUsuario());
		// Llamada a Gestor de errores
		SGRRetorno errMessages = null;
		try {
		  errMessages = sgrErroresRepository.getSGRError(requestErrores);
		  if (errMessages.getParametria()==0 || errMessages.getParametria()==9) {
			  errMessages.setDescLarga(requestErrores.getCodRetorno());
		  }
		} catch (Exception ex) {
			log.error("Error al recuperar mensaje gestor de errores",ex);
		}
		
	
		// comentario
		return (errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: errMessages.getDescLarga());
	}

	private ValidationErrorBean buildModalException(String code, String app, String lang) {
		ValidationErrorBean errorBean = new ValidationErrorBean();
		// comentario
		errorBean.setStatus(String.valueOf(HttpStatus.UNPROCESSABLE_ENTITY.value()));
		errorBean.setCode(code);
		errorBean.setPresentation(utils.getApp(app, Constants.CHANNEL_EMP).getPresentation());
		errorBean.setTimestamp(System.currentTimeMillis());

		// comentario
		InvoiceErrorValidation errMessages = armService.getErrorMessagesByCode(errorBean.getCode(), Constants.CHANNEL_EMP);
		errorBean.setMessage(errMessages == null ? ErrorServiceConstants.IV_DETAIL_MESSAGE_DEFAULT
				: MessageUtils.getDetailMessageByLang(errMessages, lang));

		return errorBean;
	}

}
