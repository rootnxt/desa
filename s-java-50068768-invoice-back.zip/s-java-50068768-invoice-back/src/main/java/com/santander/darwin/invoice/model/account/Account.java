package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The Account model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class Account implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The contract. */
    private Contract contract;

    /** The newContract. */
    private Contract newContract;

    /** The subproduct. */
    private SubproductClass subproduct;

    /** The ordenInt. */
    private BigDecimal ordenInt;

    /** The localAccount. */
    private LocalAccount localAccount;

    /** The iban. */
    private String iban;

    /** The currency. */
    private String currency;

    /** The startDate. */
    private String startDate;

    /** The availableBalance. */
    private AvailableBalance availableBalance;

    /** The currentBalance. */
    private CurrentBalance currentBalance;

    /** The holdBalance. */
    private HoldBalance holdBalance;

    /** The accountDescription. */
    private String accountDescription;

    /**
     * getContract.
     *
     * @return the Contract.
     */
    public Contract getContract() {
        return new Contract(contract);
    }

    /**
     * getNewContract.
     *
     * @return the NewContract.
     */
    public Contract getNewContract() {
        return  new Contract(newContract);
    }

    /**
     * getSubproduct.
     *
     * @return the Subproduct.
     */
    public SubproductClass getSubproduct() {
        return new SubproductClass(subproduct);
    }

    /**
     * getLocalAccount.
     *
     * @return the LocalAccount.
     */
    public LocalAccount getLocalAccount() {
        return new LocalAccount(localAccount);
    }

    /**
     * getAvailableBalance.
     *
     * @return the AvailableBalance.
     */
    public AvailableBalance getAvailableBalance() {
        return (AvailableBalance) availableBalance.copy();
    }

    /**
     * getCurrentBalance.
     *
     * @return the CurrentBalance.
     */
    public CurrentBalance getCurrentBalance() {
        return (CurrentBalance) currentBalance.copy();
    }

    /**
     * getHoldBalance.
     *
     * @return the HoldBalance.
     */
    public HoldBalance getHoldBalance() {
        return (HoldBalance) holdBalance.copy();
    }

    public void setContract(Contract contract) {
        this.contract = new Contract(contract);
    }

    public void setNewContract(Contract newContract) {
        this.newContract = new Contract(newContract);
    }

    public void setSubproduct(SubproductClass subproduct) {
        this.subproduct = new SubproductClass(subproduct);
    }

    public void setOrdenInt(BigDecimal ordenInt) {
        this.ordenInt = new BigDecimal(String.valueOf(ordenInt));
    }

    public void setLocalAccount(LocalAccount localAccount) {
        this.localAccount = new LocalAccount(localAccount);
    }

    public void setIban(String iban) {
        this.iban = String.valueOf(iban);
    }

    public void setCurrency(String currency) {
        this.currency = String.valueOf(currency);
    }

    public void setStartDate(String startDate) {
        this.startDate = String.valueOf(startDate);
    }

    public void setAvailableBalance(AvailableBalance availableBalance) {
        this.availableBalance = new AvailableBalance(availableBalance);
    }

    public void setCurrentBalance(CurrentBalance currentBalance) {
        this.currentBalance = new CurrentBalance(currentBalance);
    }

    public void setHoldBalance(HoldBalance holdBalance) {
        this.holdBalance = new HoldBalance(holdBalance);
    }

    public void setAccountDescription(String accountDescription) {
        this.accountDescription = String.valueOf(accountDescription);
    }

}
