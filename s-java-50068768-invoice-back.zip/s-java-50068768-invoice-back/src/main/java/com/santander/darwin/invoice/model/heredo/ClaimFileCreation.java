package com.santander.darwin.invoice.model.heredo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Gets the intervening list.
 *
 * @return the intervening list
 */
@Getter

/**
 * Sets the intervening list.
 *
 * @param interveningList the new intervening list
 */
@Setter
public class ClaimFileCreation {
	
	/** The file external id. */
	private String fileExternalId;
	
	/** The document list. */
	private List<DocumentList> documentList;
	
	/** The intervening list. */
	private List<Intervening> interveningList;
}