package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OutputDisplayPdfMailbox.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class OutputDisplayPdfMailbox {

	// Variables retorno
	// Para swagger
	@Schema(example = "<xml></xml>", description = "Data of document")
	private String xml;
	// Para swagger
	@Schema(example = "http://invoice.com", description = "URL of document")
	private String url;

}
