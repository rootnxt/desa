/**
 * 
 */
package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

/**
 * A1REO4RequestDTO
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class A1REO4RequestDTO {

	//Datos bloque 1
	private String a1oculto;
	private String a1text1;
	//Datos asteri 1 al 5 
	private String asteri01;
	private String asteri02;
	private String asteri03;
	private String asteri04;
	private String asteri05;
	//Datos asteri 6 al 10
	private String asteri06;
	private String asteri07;
	private String asteri08;
	private String asteri09;
	private String asteri10;
	//Datos asteri 11 al 14
	private String asteri11;
	private String asteri12;
	private String asteri13;
	private String asteri14;
	private String atext750;
	//Datos descri
	private String descri14;
	private String descri5a;
	private String elevarsn;
	//Datos de indice
	private String indaviso;
	private String indcerte;
	private String indgaran;
	//Datos de otros indices
	private String indinter;
	private String indmen;
	private String indreest;

}
