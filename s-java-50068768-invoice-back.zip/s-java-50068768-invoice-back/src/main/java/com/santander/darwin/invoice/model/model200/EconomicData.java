package com.santander.darwin.invoice.model.model200;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * EconomicData.java
 *
 * @author igndom
 *
 */
public class EconomicData {

	@NotNull
	@Size(min = 16, max = 16)
	private String csv;

	/**
	 * @return the csv
	 */
	public String getCsv() {
		return csv;
	}

	/**
	 * @param csv the csv to set
	 */
	public void setCsv(String csv) {
		this.csv = csv;
	}

}
