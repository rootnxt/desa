package es.santander.darwin.financiaciondigital.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PropuestaRgoEntity.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the propuesta rgo dto
 */
@Builder

/**
 * Instantiates a new propuesta rgo dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new propuesta rgo dto.
 *
 * @param cotestad the cotestad
 * @param indproce the indproce
 */
@AllArgsConstructor
public class PropuestaRgoDto {

    /** The cotestad. */
    private String cotestad;
    
    /** The indproce. */
    private String indproce;

}
