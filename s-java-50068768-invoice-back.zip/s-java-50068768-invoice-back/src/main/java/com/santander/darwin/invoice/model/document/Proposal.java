/**
 * 
 */
package com.santander.darwin.invoice.model.document;

import java.math.BigDecimal;

/**
 * Proposal
 * 
 * @author josdon
 *
 */
public class Proposal {

	private String centerId;
	private String companyId;
	private BigDecimal proposalNumber;
	private String proposalYear;

	/**
	 * @return the centerId
	 */
	public String getCenterId() {
		return centerId;
	}

	/**
	 * @param centerId the centerId to set
	 */
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the proposalNumber
	 */
	public BigDecimal getProposalNumber() {
		return proposalNumber;
	}

	/**
	 * @param proposalNumber the proposalNumber to set
	 */
	public void setProposalNumber(BigDecimal proposalNumber) {
		this.proposalNumber = proposalNumber;
	}

	/**
	 * @return the proposalYear
	 */
	public String getProposalYear() {
		return proposalYear;
	}

	/**
	 * @param proposalYear the proposalYear to set
	 */
	public void setProposalYear(String proposalYear) {
		this.proposalYear = proposalYear;
	}

}
