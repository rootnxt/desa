package com.santander.darwin.invoice.model.common;

/**
 * InputSend.java
 *
 * @author igndom
 *
 */
public class InputSend {

	private String codeSms;
	private String codeMail;
	private String mobile;
	private String mail;

	/**
	 * @return the codeSms
	 */
	public String getCodeSms() {
		return codeSms;
	}

	/**
	 * @param codeSms the codeSms to set
	 */
	public void setCodeSms(String codeSms) {
		this.codeSms = codeSms;
	}

	/**
	 * @return the codeMail
	 */
	public String getCodeMail() {
		return codeMail;
	}

	/**
	 * @param codeMail the codeMail to set
	 */
	public void setCodeMail(String codeMail) {
		this.codeMail = codeMail;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

}
