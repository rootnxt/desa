package com.santander.darwin.invoice.model.psd2;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the source variables.
 *
 * @return the source variables
 */
@Getter

/**
 * Sets the source variables.
 *
 * @param sourceVariables
 *            the new source variables
 */
@Setter

/**
 * Instantiates a new find variable output.
 */
@NoArgsConstructor

/**
 * Instantiates a new find variable output.
 *
 * @param intervention
 *            the intervention
 * @param sourceVariables
 *            the source variables
 */
@AllArgsConstructor
public class FindVariableOutput {

    /** The intervention. */
    private String intervention;

    /** The source variables. */
    private List<SourceVariable> sourceVariables;

}
