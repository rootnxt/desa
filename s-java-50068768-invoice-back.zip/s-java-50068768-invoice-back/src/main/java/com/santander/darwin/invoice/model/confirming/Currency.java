package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Currency.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Currency {
	// Datos de Currency
	private String code;
}