package com.santander.darwin.invoice.model.common;

import com.santander.darwin.invoice.model.CommonInformation;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CommonCsv
 * @author josdon
 *
 */
@Getter
@Setter
public class CommonCsv {

	// Codigo del modelo aeat
    private String code;
    // Numero de años
    private List<CommonInformation> years;
	
    // Descripción del modelo 
    private String desc;
}
