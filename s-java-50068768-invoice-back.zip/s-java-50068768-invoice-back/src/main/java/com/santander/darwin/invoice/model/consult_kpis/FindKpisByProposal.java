package com.santander.darwin.invoice.model.consult_kpis;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class FindKpisByProposalOutput.
 */
@Getter
@Setter
public class FindKpisByProposal {

    /** The monthly. */
    private InputVariables inputVariables;
    
    /** The score. */
    private AgileVariables agileVariables;
    
}
