/**
 * 
 */
package com.santander.darwin.invoice.model.be;

import lombok.Getter;
import lombok.Setter;

/**
 * Mapeo de la respuesta llamada banca electronica users
 * @author josdon
 *
 */
@Getter
@Setter
public class UsersOutput {
	
	// Alias
	private String userAlias;
	private String userCode;
	
	// Code Services
	private boolean serviceCodeY9;
	private boolean serviceCodeRC;
	private boolean serviceCode1;
	private boolean serviceCode2;
	private boolean serviceCode3;

}
