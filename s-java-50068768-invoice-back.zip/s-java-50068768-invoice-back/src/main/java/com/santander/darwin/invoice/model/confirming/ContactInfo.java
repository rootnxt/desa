package com.santander.darwin.invoice.model.confirming;

import com.santander.darwin.invoice.model.model200.PersonalData;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * ContactInfo.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ContactInfo {

	// Variables

	// Nombre de contacto
	@NotNull
	@NotEmpty
	private String name;
	// Apellidos de contacto
	@NotNull
	@NotEmpty
	private String surnames;
	// Datos de contacto
	@Valid
	private PersonalData personalData;

}
