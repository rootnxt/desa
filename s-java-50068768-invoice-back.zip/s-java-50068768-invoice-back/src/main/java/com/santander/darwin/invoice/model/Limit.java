package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * InvoiceLimit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
public class Limit {

	private BigDecimal min;
	private BigDecimal max;
	@JsonProperty("limit")
	private BigDecimal limitAmount;

	/**
	 * @return the min
	 */
	public BigDecimal getMin() {
		return min;
	}

	/**
	 * @param min the min to set
	 */
	public void setMin(BigDecimal min) {
		this.min = min;
	}

	/**
	 * @return the max
	 */
	public BigDecimal getMax() {
		return max;
	}

	/**
	 * @param max the max to set
	 */
	public void setMax(BigDecimal max) {
		this.max = max;
	}

	/**
	 * @return the limitAmount
	 */
	public BigDecimal getLimitAmount() {
		return limitAmount;
	}

	/**
	 * @param limitAmount the limitAmount to set
	 */
	public void setLimitAmount(BigDecimal limitAmount) {
		this.limitAmount = limitAmount;
	}

}
