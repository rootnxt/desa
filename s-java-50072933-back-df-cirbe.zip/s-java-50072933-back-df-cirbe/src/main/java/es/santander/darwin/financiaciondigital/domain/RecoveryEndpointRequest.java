package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RecoveryEndpointRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RecoveryEndpointRequest {

	/** The person type. */
	private String personType;

	/** The person code. */
	private Integer personCode;

	/** The bde code. */
	private String bdeCode;

	/** The bde description. */
	private String bdeDescription;

	/** The decision. */
	private String decision;

	/** The company id. */
	private String companyId;

	/** The center id. */
	private String centerId;

	/** The proposal year. */
	private Integer proposalYear;

	/** The proposal number. */
	private Integer proposalNumber;

	/** The titulares. */
	private List<TitularesEndpointRequest> titulares;

	/** The return value. */
	private String returnValue;

	/** The desc error. */
	private String descError;

}
