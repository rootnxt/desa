package es.santander.darwin.financiaciondigital.web;

import static es.santander.darwin.financiaciondigital.constant.HttpConstants.BAD_REQUEST_CODE;
import static es.santander.darwin.financiaciondigital.constant.HttpConstants.BAD_REQUEST_DESC;

import java.math.BigDecimal;
import java.util.concurrent.ExecutionException;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.santander.darwin.financiaciondigital.constant.PersonType;
import es.santander.darwin.financiaciondigital.constant.SwaggerConstants;
import es.santander.darwin.financiaciondigital.constant.Urls;
import es.santander.darwin.financiaciondigital.domain.PetitionsTreatmentProcessResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolDto;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolMotorDTO;
import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.service.CirbeSasnaService;
import es.santander.darwin.financiaciondigital.service.CirbeService;
import es.santander.darwin.financiaciondigital.util.converters.BigDecimalCustomEditor;
import es.santander.darwin.financiaciondigital.util.converters.PersonTypeCustomEditor;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class CirbeController.
 */
@RestController
@Validated
public class CirbeController {

    /** The cirbe service. */
    @Autowired
    private CirbeService cirbeService;

    /** The cirbe sasna service. */
    @Autowired
    private CirbeSasnaService cirbeSasnaService;

    /**
     * Data binding.
     *
     * @param binder the binder
     */
    @InitBinder
    public void dataBinding(WebDataBinder binder) {
        binder.registerCustomEditor(PersonType.class, new PersonTypeCustomEditor());
        binder.registerCustomEditor(BigDecimal.class, new BigDecimalCustomEditor());
    }

    /**
     * Call sasna.
     *
     * @param personType the person type
     * @param personCode the person code
     * @param companyId the company id
     * @param sourceType the source type
     * @return the sasna response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @ApiOperation(value = SwaggerConstants.MSG_API_OPERATION_VALUE)
    @ApiImplicitParams({
            @ApiImplicitParam(name = SwaggerConstants.AUTH, required = true,
                    dataType = SwaggerConstants.DATA_TYPE_STRING, paramType = SwaggerConstants.PARAM_TYPE_HEADER,
                    value = SwaggerConstants.TOKEN_HEADER_DESC),
            @ApiImplicitParam(name = SwaggerConstants.PERSON_TYPE_PARAM_NAME, required = true,
                    dataType = SwaggerConstants.DATA_TYPE_PERSON_TYPE, paramType = SwaggerConstants.PARAM_TYPE_PATH,
                    value = SwaggerConstants.PERSON_TYPE_PARAM_VALUE,
                    allowableValues = SwaggerConstants.PERSON_TYPE_PARAM_ALLOWABLES_VALUES) })
    @ApiResponses(value = { @ApiResponse(code = BAD_REQUEST_CODE, message = BAD_REQUEST_DESC) })
    @PostMapping(path = Urls.URL_SASNA, produces = MediaType.APPLICATION_JSON_VALUE)
    public SasnaResponse callSasna(@PathVariable(required = true) PersonType personType,
            @PathVariable(required = true) BigDecimal personCode,
            @RequestParam(required = true) @Size(min = 4, max = 4) String companyId,
            @RequestParam(required = true) @Size(min = 5, max = 5) String sourceType)
            throws DigitalConsumptionServiceException {

        SasnaResponse response = cirbeSasnaService.callSasna(companyId, personType.getValue(), personCode, sourceType);

        return response;
    }

    /**
     * Call cirbe.
     *
     * @param proposal the proposal
     * @return the sencol response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws InterruptedException the interrupted exception
     * @throws ExecutionException the execution exception
     */
    @ApiOperation(value = SwaggerConstants.MSG_API_OPERATION_VALUE)
    @ApiImplicitParams({
            @ApiImplicitParam(name = SwaggerConstants.AUTH, required = true,
                    dataType = SwaggerConstants.DATA_TYPE_STRING, paramType = SwaggerConstants.PARAM_TYPE_HEADER,
                    value = SwaggerConstants.TOKEN_HEADER_DESC) })
    @ApiResponses(value = { @ApiResponse(code = BAD_REQUEST_CODE, message = BAD_REQUEST_DESC) })
    @PostMapping(path = Urls.URL_SENCOL, produces = MediaType.APPLICATION_JSON_VALUE)
    public SencolResponse callCirbe(@RequestBody @Valid ProposalRequestsSencolDto proposal)
            throws DigitalConsumptionServiceException, InterruptedException, ExecutionException {

        return cirbeService.callSencol(proposal);
    }

    /**
     * Call petitions treatment process.
     *
     * @param proposal the proposal
     * @return the petitions treatment process response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    @ApiOperation(value = SwaggerConstants.MSG_API_OPERATION_VALUE)
    @ApiImplicitParams({ @ApiImplicitParam(name = SwaggerConstants.AUTH, required = true,
            dataType = SwaggerConstants.DATA_TYPE_STRING, paramType = SwaggerConstants.PARAM_TYPE_HEADER,
            value = SwaggerConstants.TOKEN_HEADER_DESC) })
    @ApiResponses(value = { @ApiResponse(code = BAD_REQUEST_CODE, message = BAD_REQUEST_DESC) })
    @PostMapping(path = Urls.URL_SENCOL_MOTOR, produces = MediaType.APPLICATION_JSON_VALUE)
    public PetitionsTreatmentProcessResponse callPetitionsTreatmentProcess(
            @RequestBody @Valid ProposalRequestsSencolMotorDTO proposal) throws DigitalConsumptionServiceException {
        PetitionsTreatmentProcessResponse response = new PetitionsTreatmentProcessResponse();
        response = cirbeService.callTreatmentProcess(proposal);
        return response;
    }
}
