package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientResponseException;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.constant.PersonType;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataRequestVO;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsultaConsolidadoCirbeResponseVO;
import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.lib.model.PersonRequests;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.CirbeSasnaService;
import es.santander.darwin.financiaciondigital.service.CiriteService;
import es.santander.darwin.financiaciondigital.service.ConsolidadoCirbeService;
import es.santander.darwin.financiaciondigital.service.DFLibConnectorService;
import es.santander.darwin.financiaciondigital.soap.DataPerson;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifResponse;
import es.santander.darwin.financiaciondigital.soap.repositories.PersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.ProposalPersonRequestsRepository;
import es.santander.darwin.financiaciondigital.soap.repositories.PropuestaRgoJpaRepository;

/**
 * The Class CirbeSasnaServiceImplTest.
 */
public class CirbeSasnaServiceImplTest {

    /** The cirbe service. */
    @Spy
    @InjectMocks
    private CirbeServiceImpl cirbeService = new CirbeServiceImpl();

    /** The cirbe sasna service. */
    @Spy
    @InjectMocks
    private CirbeSasnaServiceImpl cirbeSasnaService = new CirbeSasnaServiceImpl();

    /** The lib connector svc. */
    @Mock
    private DFLibConnectorService libConnectorSvc;

    /** The consolidado cirbe service. */
    @Mock
    private ConsolidadoCirbeService consolidadoCirbeService;

    /** The rest consumer service. */
    @Mock
    private RestConsumerService restConsumerService;

    /** The person requests repository. */
    @Mock
    private PersonRequestsRepository personRequestsRepository;

    /** The person request. */
    @Mock
    private List<PersonRequests> personRequest;

    /** The person. */
    @Mock
    private DataPerson person;

    /** The cirite service. */
    @Mock
    private CiriteService ciriteService;

    /** The propuesta rgo jpa repository. */
    @Mock
    private PropuestaRgoJpaRepository propuestaRgoJpaRepository;

    /** The proposal person requests repository. */
    @Mock
    private ProposalPersonRequestsRepository proposalPersonRequestsRepository;

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
        personRequest = new ArrayList<>();
        person = new DataPerson();
    }

    /**
     * Call sasna test OK 1.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK1() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue().toString();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201901";
        boolean nuevoAcreditado = false;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaSistema, fechaCliente);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NOACREDITADO_CIRBEACTUALIZADA));
    }

    /**
     * Call sasna test OK 2.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK2() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        boolean nuevoAcreditado = false;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaSistema, fechaCliente);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        personRequests.setSourceState("");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(
                result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA));
    }

    /**
     * Call sasna test OK 3.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK3() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSetCutParam = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSetCutParam.setAccessible(true);
        fieldToSetCutParam.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        // mockAlta
        Field fieldToSetMockAlta = serviceReflectClass.getDeclaredField("mockAlta");
        fieldToSetMockAlta.setAccessible(true);
        fieldToSetMockAlta.set(cirbeSasnaService, "S");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        // String fechaSistema = "201801";
        // String fechaCliente = "201701";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        // ConsultaConsolidadoCirbeResponseVO responseConsolidado = new ConsultaConsolidadoCirbeResponseVO(fechaSistema,
        // fechaCliente);
        PersonRequests personRequests = new PersonRequests();
        AltModifResponse altModifResponse = new AltModifResponse();
        altModifResponse.setCodigoRespuesta("1");
        AltModifCiriteRequestResponse responseAltaCirite = new AltModifCiriteRequestResponse();
        responseAltaCirite.setAltModifCiriteRequestResult(altModifResponse);
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        doReturn(responseAltaCirite).when(ciriteService).callAltaCirite(any(BasicPersonDataResponseVO.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA));
    }

    /**
     * Call sasna test OK 4.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK4() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSetCutParam = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSetCutParam.setAccessible(true);
        fieldToSetCutParam.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        // String fechaSistema = "201801";
        // String fechaCliente = "201701";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        // ConsultaConsolidadoCirbeResponseVO responseConsolidado = new ConsultaConsolidadoCirbeResponseVO(fechaSistema,
        // fechaCliente);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA));
    }

    /**
     * Call sasna test OK 5.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK5() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSetCutParam = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSetCutParam.setAccessible(true);
        fieldToSetCutParam.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        // mockAlta
        Field fieldToSetMockAlta = serviceReflectClass.getDeclaredField("mockAlta");
        fieldToSetMockAlta.setAccessible(true);
        fieldToSetMockAlta.set(cirbeSasnaService, "S");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        // String fechaSistema = "201801";
        // String fechaCliente = "201701";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        // ConsultaConsolidadoCirbeResponseVO responseConsolidado = new ConsultaConsolidadoCirbeResponseVO(fechaSistema,
        // fechaCliente);
        PersonRequests personRequests = new PersonRequests();
        AltModifResponse altModifResponse = new AltModifResponse();
        altModifResponse.setCodigoRespuesta("1");
        AltModifCiriteRequestResponse responseAltaCirite = new AltModifCiriteRequestResponse();
        responseAltaCirite.setAltModifCiriteRequestResult(altModifResponse);
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        doReturn(responseAltaCirite).when(ciriteService).callAltaCirite(any(BasicPersonDataResponseVO.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA));
    }

    /**
     * Call sasna test OK 6.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test
    public void callSasnaTest_OK6() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 0);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        boolean nuevoAcreditado = true;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaCliente, fechaSistema);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_PETICION_MAXIMA));
    }

    @Test
    public void callSasnaTest_OK7() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 4);
        // resAlta
        Field fieldToSetResAlta = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSetResAlta.setAccessible(true);
        fieldToSetResAlta.set(cirbeSasnaService, "1");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        boolean nuevoAcreditado = true;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "EN";// ES y EN
        String codPaisN = "";
        Date dateNac = new Date();
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaCliente, fechaSistema);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).updatePersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NO_RESIDENTE));
    }

    @Test
    public void callSasnaTest_OK8() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 10);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue().toString();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        boolean nuevoAcreditado = false;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        ReflectionTestUtils.setField(cirbeSasnaService, "mockAlta", "N");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaSistema, fechaCliente);
        AltModifResponse altModifResponse = new AltModifResponse();
        altModifResponse.setCodigoRespuesta("1");
        AltModifCiriteRequestResponse responseAltaCirite = new AltModifCiriteRequestResponse();
        responseAltaCirite.setAltModifCiriteRequestResult(altModifResponse);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(responseAltaCirite).when(ciriteService).callAltaCirite(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).insertPersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_ACREDITADO_CIRBENOACTUALIZADA));
    }

    @Test
    public void callSasnaTest_OK9() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 10);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 10);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue().toString();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        boolean nuevoAcreditado = false;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "EN";
        String codPaisN = "";
        Date dateNac = new Date();
        ReflectionTestUtils.setField(cirbeSasnaService, "mockAlta", "N");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaSistema, fechaCliente);
        AltModifResponse altModifResponse = new AltModifResponse();
        altModifResponse.setCodigoRespuesta("1");
        AltModifCiriteRequestResponse responseAltaCirite = new AltModifCiriteRequestResponse();
        responseAltaCirite.setAltModifCiriteRequestResult(altModifResponse);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(responseAltaCirite).when(ciriteService).callAltaCirite(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).insertPersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_NO_RESIDENTE));
    }

    @Test
    public void callSasnaTest_OK10() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 10);
        // limitePeticiones
        Field fieldToSetPetitionLimit = serviceReflectClass.getDeclaredField("limitePeticiones");
        fieldToSetPetitionLimit.setAccessible(true);
        fieldToSetPetitionLimit.set(cirbeSasnaService, 0);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue().toString();
        String user = "user";
        String fechaSistema = "201801";
        String fechaCliente = "201701";
        boolean nuevoAcreditado = false;
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        ReflectionTestUtils.setField(cirbeSasnaService, "mockAlta", "N");
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        ConsultaConsolidadoCirbeResponseVO responseConsolidado =
                new ConsultaConsolidadoCirbeResponseVO(nuevoAcreditado, fechaSistema, fechaCliente);
        AltModifResponse altModifResponse = new AltModifResponse();
        altModifResponse.setCodigoRespuesta("1");
        AltModifCiriteRequestResponse responseAltaCirite = new AltModifCiriteRequestResponse();
        responseAltaCirite.setAltModifCiriteRequestResult(altModifResponse);
        PersonRequests personRequests = new PersonRequests();
        personRequests.setPetitionsNumber(8);
        personRequests.setNewAccreditedIndicator("S");
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(responseConsolidado).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doReturn(responseAltaCirite).when(ciriteService).callAltaCirite(any(BasicPersonDataResponseVO.class));
        doReturn(personRequests).when(restConsumerService).getPersonRequests(any(String.class), any(),
                any(BigDecimal.class), any(String.class));
        doReturn(personRequests).when(restConsumerService).insertPersonRequests(any(PersonRequests.class));
        SasnaResponse result = cirbeSasnaService.callSasna(companyId, personType, personCode, user);
        assertTrue(result.getMessage().equalsIgnoreCase(Constants.MESSAGE_PETICION_MAXIMA));
    }

    /**
     * Call sasna test NOK 1.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callSasnaTest_NOK1() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.getValue().toString();
        String user = "user";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "";
        String codPaisN = "";
        Date dateNac = new Date();
        DigitalConsumptionServiceException dcse =
                new DigitalConsumptionServiceException(HttpStatus.BAD_REQUEST, "Mensaje de error",
                        "Codigo de Error SOAP", "Traza de error", new NullPointerException(),
                        "args");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doThrow(dcse).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        cirbeSasnaService.callSasna(companyId, personType, personCode, user);
    }

    /**
     * Call sasna test NOK 2.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callSasnaTest_NOK2() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        Field fieldToSet2 = serviceReflectClass.getDeclaredField("resAlta");
        fieldToSet2.setAccessible(true);
        fieldToSet2.set(cirbeSasnaService, "1");
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        Date dateNac = new Date();
        RestClientResponseException rcre =
                new RestClientResponseException("Error Message", 400, "not found", null, null, null);
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doThrow(rcre).when(restConsumerService).getPersonRequests(any(String.class), any(), any(BigDecimal.class),
                any(String.class));
        cirbeSasnaService.callSasna(companyId, personType, personCode, user);
    }

    /**
     * Call sasna test NOK 3.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callSasnaTest_NOK3() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        AltModifResponse altaRes = new AltModifResponse();
        altaRes.setCodigoRespuesta("cod");
        altaRes.setDescripcionRespuesta("des");
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        RestClientResponseException rcre =
                new RestClientResponseException("", 400, "not found", null, null, null);
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doThrow(rcre).when(restConsumerService).getPersonRequests(any(String.class), any(), any(BigDecimal.class),
                any(String.class));
        cirbeSasnaService.callSasna(companyId, personType, personCode, user);
    }

    /**
     * Call sasna test NOK 4.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callSasnaTest_NOK4() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        ReflectionTestUtils.setField(cirbeSasnaService, "sourceType", "uwu");
        DigitalConsumptionInternalException dcie =
                new DigitalConsumptionInternalException("Message", "detail", new NullPointerException(), "args");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doThrow(dcie).when(restConsumerService).getPersonRequests(any(String.class), any(), any(BigDecimal.class),
                any(String.class));
        cirbeSasnaService.callSasna(companyId, personType, personCode, user);
    }

    /**
     * Call sasna test NOK 5.
     *
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws NoSuchFieldException the no such field exception
     * @throws SecurityException the security exception
     * @throws IllegalArgumentException the illegal argument exception
     * @throws IllegalAccessException the illegal access exception
     */
    @Test(expected = NullPointerException.class)
    public void callSasnaTest_NOK5() throws DigitalConsumptionServiceException, NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        CirbeSasnaService cirbeServiceInstance = new CirbeSasnaServiceImpl();
        Class<?> serviceReflectClass = cirbeServiceInstance.getClass();
        Field fieldToSet = serviceReflectClass.getDeclaredField("parametroCorte");
        fieldToSet.setAccessible(true);
        fieldToSet.set(cirbeSasnaService, 2);
        BigDecimal personCode = BigDecimal.valueOf(145.0);
        String companyId = "49";
        String personType = PersonType.PHYSICAL.ordinal() + "";
        String user = "user";
        String documentCod = "";
        String documentType = "";
        String fullName = "Testing Everis";
        String codPaisR = "ES";
        String codPaisN = "";
        Date dateNac = new Date();
        DigitalConsumptionInternalException dcie =
                new DigitalConsumptionInternalException("Message", "detail",
                        new HttpClientErrorException(HttpStatus.NOT_FOUND), "args");
        BasicPersonDataResponseVO basicPersonDataRes = new BasicPersonDataResponseVO(documentCod, documentType,
                fullName, codPaisR, codPaisN, dateNac, personCode, personType, companyId);
        doReturn(basicPersonDataRes).when(libConnectorSvc).getBasicPersonData(any(BasicPersonDataRequestVO.class));
        doReturn(null).when(consolidadoCirbeService).callConsolidadoCirbe(any(BasicPersonDataResponseVO.class));
        doThrow(dcie).when(restConsumerService).getPersonRequests(any(String.class), any(), any(BigDecimal.class),
                any(String.class));
        cirbeSasnaService.callSasna(companyId, personType, personCode, user);
    }

}
