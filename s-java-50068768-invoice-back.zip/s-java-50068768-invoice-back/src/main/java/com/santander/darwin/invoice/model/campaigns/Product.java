package com.santander.darwin.invoice.model.campaigns;

import lombok.Getter;
import lombok.Setter;

/**
 * Product.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Product {

	// Atributos de la clase
	private String productType;
	private String subProduct;
	private String reference;
	
	// Codigo campaña
	private String campaignCode;
	private String triadFamily;
	private String channel;

}
