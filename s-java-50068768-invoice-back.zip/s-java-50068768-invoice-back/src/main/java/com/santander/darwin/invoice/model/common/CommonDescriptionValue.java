package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.Setter;

/**
 * CommonDescriptionValue.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CommonDescriptionValue {

	// Atributos de la clase
	private String value;
	private String description;
}
