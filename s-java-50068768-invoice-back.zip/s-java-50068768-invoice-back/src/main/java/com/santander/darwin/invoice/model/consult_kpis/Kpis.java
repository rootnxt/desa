package com.santander.darwin.invoice.model.consult_kpis;

import com.santander.darwin.invoice.model.CommonInformationValue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The Class Kpis.
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class Kpis {
	
	/** The  credit */
	private List<CommonInformationValue> credit;
	
	/** The  transactional */
	private List<CommonInformationValue> transactional;

	/** The  tipoPers */
	private String tipoPers;

	/** The  codPers */
	private int codPers;

}
