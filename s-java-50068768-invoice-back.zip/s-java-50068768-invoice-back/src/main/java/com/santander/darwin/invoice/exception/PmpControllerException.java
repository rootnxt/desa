package com.santander.darwin.invoice.exception;

/**
 * The PmpControllerException Class.
 *
 * @author luis.lopez
 *
 */
public class PmpControllerException extends GlobalException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new PmpControllerException.
     * @param message the message
     */

    public PmpControllerException(String message) {
        super(message);
    }

    /**
     * Instantiates a new PmpControllerException.
     * @param code          the code
     * @param lang          the lang
     * @param errorAppType  the errorAppType
     */
    public PmpControllerException(String code, String lang, String errorAppType) {
    	super(code, lang, errorAppType);
    }

}
