package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;


/**
 * InputTransactionA270.java
 * 
 *
 */
public class InputTransactionA270 {

	private BigDecimal aaa;
	private BigDecimal ccentro;
	private BigDecimal cempresa;
	private String cencuen;
	private BigDecimal cnumeric;
	private String descri25;
	private BigDecimal diafijo;
    private String indiarev;
	private String indtabco;
	private String nomapes1;
	/**
	 * @return the aaa
	 */
	public BigDecimal getAaa() {
		return aaa;
	}
	/**
	 * @param aaa the aaa to set
	 */
	public void setAaa(BigDecimal aaa) {
		this.aaa = aaa;
	}
	/**
	 * @return the ccentro
	 */
	public BigDecimal getCcentro() {
		return ccentro;
	}
	/**
	 * @param ccentro the ccentro to set
	 */
	public void setCcentro(BigDecimal ccentro) {
		this.ccentro = ccentro;
	}
	/**
	 * @return the cempresa
	 */
	public BigDecimal getCempresa() {
		return cempresa;
	}
	/**
	 * @param cempresa the cempresa to set
	 */
	public void setCempresa(BigDecimal cempresa) {
		this.cempresa = cempresa;
	}
	/**
	 * @return the cencuen
	 */
	public String getCencuen() {
		return cencuen;
	}
	/**
	 * @param cencuen the cencuen to set
	 */
	public void setCencuen(String cencuen) {
		this.cencuen = cencuen;
	}
	/**
	 * @return the cnumeric
	 */
	public BigDecimal getCnumeric() {
		return cnumeric;
	}
	/**
	 * @param cnumeric the cnumeric to set
	 */
	public void setCnumeric(BigDecimal cnumeric) {
		this.cnumeric = cnumeric;
	}
	/**
	 * @return the descri25
	 */
	public String getDescri25() {
		return descri25;
	}
	/**
	 * @param descri25 the descri25 to set
	 */
	public void setDescri25(String descri25) {
		this.descri25 = descri25;
	}
	/**
	 * @return the diafijo
	 */
	public BigDecimal getDiafijo() {
		return diafijo;
	}
	/**
	 * @param diafijo the diafijo to set
	 */
	public void setDiafijo(BigDecimal diafijo) {
		this.diafijo = diafijo;
	}
	/**
	 * @return the indiarev
	 */
	public String getIndiarev() {
		return indiarev;
	}
	/**
	 * @param indiarev the indiarev to set
	 */
	public void setIndiarev(String indiarev) {
		this.indiarev = indiarev;
	}
	/**
	 * @return the indtabco
	 */
	public String getIndtabco() {
		return indtabco;
	}
	/**
	 * @param indtabco the indtabco to set
	 */
	public void setIndtabco(String indtabco) {
		this.indtabco = indtabco;
	}
	/**
	 * @return the nomapes1
	 */
	public String getNomapes1() {
		return nomapes1;
	}
	/**
	 * @param nomapes1 the nomapes1 to set
	 */
	public void setNomapes1(String nomapes1) {
		this.nomapes1 = nomapes1;
	}

	
	
}
