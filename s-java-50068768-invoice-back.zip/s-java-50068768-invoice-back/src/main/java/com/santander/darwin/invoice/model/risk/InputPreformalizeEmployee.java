/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InputPreformalizeEmployee.class
 * 
 * @author x574726
 *
 */

@Getter
@Setter
public class InputPreformalizeEmployee {

	/**
	* Número de empleado del grupo.
	* Partenon alphanumeric (A) - Length (6)
	*/
	private String bsnumemp;

	/**
	* Codigo de centro.
	* Partenon alphanumeric (A) - Length (4)
	*/
	private String idcent;

	/** Identificador de empresa Partenon alphanumeric (A) - Length (4). */
	private String idempr;
	
	/** Año de la propuesta Partenon alphanumeric (A) - Length (4). */
	private String anoprop;

	/** Id del estado de ejecucion glp Partenon alphanumeric (A) - Length (2). */
	//private String estadoe;

	/**
	 * Nro.de secuencia de la propuesta Partenon unsigned numeric (N) - Length (5,0)
	 */
	private BigDecimal numprop;

	/** Usuario ultima modificacion Partenon alphanumeric (A) - Length (8). */
	private String usumod;

}
