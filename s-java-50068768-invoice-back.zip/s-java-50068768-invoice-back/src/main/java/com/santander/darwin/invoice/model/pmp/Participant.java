/**
 * 
 */
package com.santander.darwin.invoice.model.pmp;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Participant
 * 
 * @author josdon
 *
 */
@Data
public class Participant {

	/** The customerId. */
	private String customerId;

	/** The participantType. */
	private String participantType;

	/** The participantOrder. */
	private BigDecimal participantOrder;

	/** The participantForm. */
	private String participantForm;

	/** The descParticipantForm. */
	private String descParticipantForm;

	/** The participationPercentage. */
	private BigDecimal participationPercentage;

	/** The name. */
	private String name;

	
}
