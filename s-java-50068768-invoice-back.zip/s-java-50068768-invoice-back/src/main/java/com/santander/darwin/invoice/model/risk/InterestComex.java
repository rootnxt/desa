package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * The Class InterestComex.
 */
@Getter
@Setter
public class InterestComex {

    /** Cogemos primera ocurrencia del campo PLAZOCLQ – SAT 2634 **/
    private BigDecimal plazo;
    /** Cogemos primera ocurrencia del campo IDTASA – SAT 2634 **/
    private BigDecimal tasa;
    /** Cogemos primera ocurrencia del campo IDIFEREN – SAT 2634 **/
    private BigDecimal diferencial;
    /** Cogemos primera ocurrencia del campo IMPMIN4 – SAT 2634 **/
    private BigDecimal minimo;

}
