package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputSat002506.java
 *
 * @author igndom
 *
 */
public class InputSat002506 {

	private List<String> sxvalue;
	private List<String> anoprop;
	private List<String> idcent;
	private List<String> idempr;
	private List<BigDecimal> numprop;

	/**
	 * @return the sxvalue
	 */
	public List<String> getSxvalue() {
		return sxvalue;
	}

	/**
	 * @param sxvalue the sxvalue to set
	 */
	public void setSxvalue(List<String> sxvalue) {
		this.sxvalue = sxvalue;
	}

	/**
	 * @return the anoprop
	 */
	public List<String> getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(List<String> anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the idcent
	 */
	public List<String> getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(List<String> idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public List<String> getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(List<String> idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the numprop
	 */
	public List<BigDecimal> getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(List<BigDecimal> numprop) {
		this.numprop = numprop;
	}

}
