package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FormalizationOutput.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class FormalizationOutput {
	// Datos de FormalizationInput
    private Contract contract;
    private ConfirmingOperationOutput confirmingOperation;
}