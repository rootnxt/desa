package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.errors.InvoiceErrorValidation;
import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import com.santander.darwin.invoice.model.refinancing_contracts.Guarantor;
import com.santander.darwin.invoice.model.simulation.ProductExtend;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * InvoiceFinancingExtends.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceFinancingExtends extends InvoiceFinancingConfirming {
	// Errores de prevalidacion
	private InvoiceErrorValidation errorValidation;
	// Datos de auditoria
	private DataAudit dataAudit;
	// Finalidad seleccionada
	private CommonFinality finality;
	// Productos seleccionado
	private ProductExtend product;
	// Nombre de producto devuelto en el servicio de limites
	private String internalName;
	// Propuesta de riesgos
	private Proposal proposal;
	// Contrato
	private Contract contract;
	private String documentType;
	private String documentNumber;
	// Flags
	private boolean formalized;
	private String errorFormalized;
	// Cancelacion automatica en refinanciaciones
	private boolean canceled;
	private boolean associatedContracts;
	private boolean generateCsv;
	private BigDecimal amountQuota;
	// Identificador de operacion en buzon
	private String operationBuzonId;
	// Listado de avalistas
	private List<Guarantor> guarantors;
	// Resultado de la firma
	private String signatureResult;
	// flag para comprobar si se ha ejecutado correctamente los servicios de
	// formalizacion de banca electronica
	private String beResult;
	// Control flag
	private boolean pymes;

	// Productos auxiliares carga de combo
	private List<String> productsAux;
	
	//Meses auxiliares
	private int monthAux;
	
	// Due date
	private MongoLocalDateTime dueDate;
	// Preformalized date
	private MongoLocalDateTime preformalizedDate;
    // Pay day
	private int payDay;
	
	// Tipo firma 01-Buzón;02-Digital;03-Manuscrita 
	private String typeSign;
	
	private MongoLocalDateTime feconfor;
	private MongoLocalDateTime dateLastUpdate;

}