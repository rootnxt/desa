package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The InputHeader model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class InputHeader implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The operationId. */
    private String operationId;

    /** The typeCustomer. */
    private String typeCustomer;

    /** The codeCustomer. */
    private BigDecimal codeCustomer;

}
