package com.santander.darwin.invoice.model.common;

/**
 * ProposalCommon.java
 *
 * @author igndom
 *
 */
public class ProposalCommon {

	private String codpers;
	private String  idcent;
	private String idempr;

	/**
	 * @return the codpers
	 */
	public String getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(String codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

}
