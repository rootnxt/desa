package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * AuxParam
 * 
 * @author igndom
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class AuxParam {

	// Atributos de la clase
	private String lang;
	private String device;
	private String langStandard;
	private String codeDeepLink;
	private boolean limitsOne;
	private boolean pymes;
	private BigDecimal financeLimits;
	private BigDecimal maxSlider;
	private BigDecimal minSlider;
	private boolean oriented;
	//Productos auxiliares carga de combo
	private List<String> productsAux;
	// Currency
	private String currency;
	// Months
	private int months;
	// internalName
	private String internalName;
	/**
	 * Constructor de la clase
	 * 
	 * @param lang String
	 */
	public AuxParam(String lang) {
		super();
		this.lang = lang;
	}

	/**
	 * Constructor de la clase
	 * 
	 * @param lang         String
	 * @param device       String
	 * @param langStandard String
	 * @param codeDeepLink String
	 * @param limitsOne    boolean
	 */
	public AuxParam(String lang, String device, String langStandard, String codeDeepLink, boolean limitsOne) {
		super();
		this.lang = lang;
		this.device = device;
		this.langStandard = langStandard;
		this.codeDeepLink = codeDeepLink;
		this.limitsOne = limitsOne;
	}

}
