package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputSat002415.java
 *
 * @author igndom
 *
 */
public class InputSat002415 {

	private List<String> sxvalue;
	private List<String> anoprop;
	private List<String> a1codseg;
	private List<String> idcent;
	private List<String> idempr;
	private List<BigDecimal> numprop;
	private List<String> a1estado;
	private List<BigDecimal> clocaliz;
	private List<String> codcesta;
	private List<String> cpmoneda;
	private List<BigDecimal> csituaci;
	private List<String> idprod;
	private List<String> idstipro;
	private List<String> timestam;
	private List<String> a8estref;

	/**
	 * @return the sxvalue
	 */
	public List<String> getSxvalue() {
		return sxvalue;
	}

	/**
	 * @param sxvalue the sxvalue to set
	 */
	public void setSxvalue(List<String> sxvalue) {
		this.sxvalue = sxvalue;
	}

	/**
	 * @return the anoprop
	 */
	public List<String> getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(List<String> anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the a1codseg
	 */
	public List<String> getA1codseg() {
		return a1codseg;
	}

	/**
	 * @param a1codseg the a1codseg to set
	 */
	public void setA1codseg(List<String> a1codseg) {
		this.a1codseg = a1codseg;
	}

	/**
	 * @return the idcent
	 */
	public List<String> getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(List<String> idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public List<String> getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(List<String> idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the numprop
	 */
	public List<BigDecimal> getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(List<BigDecimal> numprop) {
		this.numprop = numprop;
	}

	/**
	 * @return the a1estado
	 */
	public List<String> getA1estado() {
		return a1estado;
	}

	/**
	 * @param a1estado the a1estado to set
	 */
	public void setA1estado(List<String> a1estado) {
		this.a1estado = a1estado;
	}

	/**
	 * @return the clocaliz
	 */
	public List<BigDecimal> getClocaliz() {
		return clocaliz;
	}

	/**
	 * @param clocaliz the clocaliz to set
	 */
	public void setClocaliz(List<BigDecimal> clocaliz) {
		this.clocaliz = clocaliz;
	}

	/**
	 * @return the codcesta
	 */
	public List<String> getCodcesta() {
		return codcesta;
	}

	/**
	 * @param codcesta the codcesta to set
	 */
	public void setCodcesta(List<String> codcesta) {
		this.codcesta = codcesta;
	}

	/**
	 * @return the cpmoneda
	 */
	public List<String> getCpmoneda() {
		return cpmoneda;
	}

	/**
	 * @param cpmoneda the cpmoneda to set
	 */
	public void setCpmoneda(List<String> cpmoneda) {
		this.cpmoneda = cpmoneda;
	}

	/**
	 * @return the csituaci
	 */
	public List<BigDecimal> getCsituaci() {
		return csituaci;
	}

	/**
	 * @param csituaci the csituaci to set
	 */
	public void setCsituaci(List<BigDecimal> csituaci) {
		this.csituaci = csituaci;
	}

	/**
	 * @return the idprod
	 */
	public List<String> getIdprod() {
		return idprod;
	}

	/**
	 * @param idprod the idprod to set
	 */
	public void setIdprod(List<String> idprod) {
		this.idprod = idprod;
	}

	/**
	 * @return the idstipro
	 */
	public List<String> getIdstipro() {
		return idstipro;
	}

	/**
	 * @param idstipro the idstipro to set
	 */
	public void setIdstipro(List<String> idstipro) {
		this.idstipro = idstipro;
	}

	/**
	 * @return the timestam
	 */
	public List<String> getTimestam() {
		return timestam;
	}

	/**
	 * @param timestam the timestam to set
	 */
	public void setTimestam(List<String> timestam) {
		this.timestam = timestam;
	}

	/**
	 * @return the a8estref
	 */
	public List<String> getA8estref() {
		return a8estref;
	}

	/**
	 * @param a8estref the a8estref to set
	 */
	public void setA8estref(List<String> a8estref) {
		this.a8estref = a8estref;
	}

}
