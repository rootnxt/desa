package es.santander.darwin.financiaciondigital.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLA;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLAResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;

/**
 * The Class DatosUsuarioLAClient.
 */
public class DatosUsuarioLAClient extends WebServiceGatewaySupport {

    /** The soap action. */
    @Value("${darwin.webservices.datosusuario.resources.methods.soapAction:"
            + "http://www.isban.es/webservices/CWPOLA/Cwpdatosusuario_la/F_cwpola_cwpdatosusuario_la/internet/"
            + "ACCWPOLACWPDatosUsuario/v1/datosUsuario_LA}")
    private String soapAction;

    /**
     * Execute soap request.
     *
     * @param endpoint the endpoint
     * @param request the request
     * @return the datos usuario LA response
     */
    public DatosUsuarioLAResponse executeSoapRequest(String endpoint, DatosUsuarioLA request) {
        WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
        DatosUsuarioLAResponse response = new DatosUsuarioLAResponse();
        response = (DatosUsuarioLAResponse) webServiceTemplate.marshalSendAndReceive(endpoint, request,
                new SoapActionCallback(soapAction));

        return response;
    }

    /**
     * Handle error.
     *
     * @return Nothing
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    public void handleError() throws DigitalConsumptionServiceException {
        throw new DigitalConsumptionServiceException(HttpStatus.REQUEST_TIMEOUT,
                ErrorMessagesConstants.ERROR_TIMEOUT_WEBSERVICETEMPLATE, ExceptionsErrorConstants.ERROR_CODE_TEMPORAL,
                ErrorMessagesConstants.ERROR_WEBSERVICE_TEMPLATE,
                new Throwable(ErrorMessagesConstants.TIMEOUT_EXCEPTION));
    }

}
