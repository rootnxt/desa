package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

/**
 * InvoiceProposalState.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceProposalState {

	//Identificador en mongo
	@Id
	private String id;
	
	// Codigo de estado de propuesta
	private String code;
	
	// Descripcion estado de propuesta
	private String desc;
	
	// Indicador si se muestra el estado en informe de kpis
	private boolean show;
	
	// statesFront
	private String statesFront;
	
	// stateDefault
	private String stateDefault;

}
