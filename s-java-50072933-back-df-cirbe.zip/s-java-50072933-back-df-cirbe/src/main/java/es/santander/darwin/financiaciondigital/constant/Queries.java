package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class Queries.
 */
public class Queries {

    /** The Constant INTERV_BY_FILTER. */
    public static final String INTERV_BY_FILTER =
            "SELECT pp.PNE_TIPINTER, pp.PNE_ORDINTC, pp.PNE_TIPOPERS, pp.PNE_CODPERS"
                    + "FROM PERSO_PROPUESTA pp"
                    + "WHERE pp.PNE_TIPINTER IN ('01','40','41','44', '30','33','36', '10','43','95')"
                    + "AND pp.PNE_IDEMPR = :idEmpresa"
                    + "AND pp.PNE_IDCENT = :idCentro"
                    + "AND pp.PNE_ANOPROP = :annoProp"
                    + "AND pp.PNE_NUMPROP = :numPropuesta";

    /** The Constant PROPOSAL_PERSON_REQUEST_FOR_PETITIONS. */
    public static final String PROPOSAL_PERSON_REQUEST_FOR_PETITIONS = "{ "
            + "'requestPersonIdentifier.companyId' : '?0', "
            + "'requestPersonIdentifier.centerId' : '?1', "
            + "'requestPersonIdentifier.proposalYear' : ?2, "
            + "'requestPersonIdentifier.proposalNumber' : ?3 "
            + "}";
    
    
    /** The Constant PROPOSAL_PERSON_REQUEST_BY_IDENTIFIER. */
    public static final String PROPOSAL_PERSON_REQUEST_BY_IDENTIFIER = "{ "
            + "'requestPersonIdentifier.companyId' : '?0', "
            + "'requestPersonIdentifier.centerId' : '?1', "
            + "'requestPersonIdentifier.proposalYear' : ?2, "
            + "'requestPersonIdentifier.proposalNumber' : ?3, "
            + "'requestPersonIdentifier.personType' : '?4', "
            + "'requestPersonIdentifier.personCode' : ?5, "
            + "'requestPersonIdentifier.sourceType' : '?6' "
            + "}";

    /** The Constant PERSON_REQUESTS_FOR_PETITIONNS. */
    public static final String PERSON_REQUESTS_BY_IDENTIFIER = "{'personRequestIdentifier' : { "
            + "'companyId' : ?0, "
            + "'personType' : ?1, "
            + "'personCode' : ?2, "
            + "'sourceType' : ?3 } }";

    /** The Constant PERSON_REQUESTS_FOR_PETITIONNS2. */
    public static final String PERSON_REQUESTS_FOR_PETITIONNS2 = "{"
            + "'personRequestIdentifier.companyId' : ?0, "
            + "'personRequestIdentifier.personType' : ?1, "
            + "'personRequestIdentifier.personCode' : ?2 } }";

    /** The Constant TITULARES_POR_PROPUESTA. */
    public static final String TITULARES_POR_PROPUESTA =
            "SELECT pp3 "
                    + "FROM    PersoPropuestaEntity pp3 "
                    + "WHERE   pp3.id.companyId =   :company "
                    + "AND     pp3.id.centerId  =   :center "
                    + "AND     pp3.id.proposalYear =   :proposalYear "
                    + "AND     pp3.id.proposalNumber =   :proposalNumber "
                    + "AND     pp3.id.intervType IN ('01','40','41','44') "
                    + "ORDER BY pp3.id.companyId, pp3.id.centerId, pp3.id.proposalYear, pp3.id.proposalNumber, pp3.id.intervType,"
                    + "         pp3.id.ordintc, pp3.id.personType, pp3.id.personCode, pp3.formint";

    /** The Constant AVALISTAS_POR_PROPUESTA. */
    public static final String AVALISTAS_POR_PROPUESTA =
            "SELECT pp3 "
                    + "FROM    PersoPropuestaEntity pp3 "
                    + "WHERE   pp3.id.companyId =   :company "
                    + "AND     pp3.id.centerId =   :center "
                    + "AND     pp3.id.proposalYear =   :proposalYear "
                    + "AND     pp3.id.proposalNumber =   :proposalNumber "
                    + "AND     pp3.id.intervType IN ('30','33','36','10','43','95')  "
                    + "ORDER BY pp3.id.companyId, pp3.id.centerId, pp3.id.proposalYear, pp3.id.proposalNumber, pp3.id.intervType,"
                    + "         pp3.id.ordintc, pp3.id.personType, pp3.id.personCode, pp3.formint ";

    /**
     * Instantiates a new queries.
     */
    private Queries() {
        super();
    }
}
