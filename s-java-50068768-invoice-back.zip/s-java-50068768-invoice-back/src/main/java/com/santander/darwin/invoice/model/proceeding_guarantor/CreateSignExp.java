package com.santander.darwin.invoice.model.proceeding_guarantor;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CreateSignExp.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CreateSignExp {

	//Datos basicos
	private String typeReference;
	private String reference;
	private String statusExp;
	//Datos box
	private String typeBox;
	private String catBox;
	private String typeExp;
	//Datos de empresa
	private String company;
	private String centre;
	private String descExp;
	//Contrato y canl
	private String contract;
	private String channelExp;
	//Datos de indicadores
	private String indBE;
	private String indBP;
	//Datos de documentos
	private List<Docs> docs;
	//Datos del producto
	private String productDetail;
	private String productDesc;
	//Notificaciones
	private Notifications notifications;
	//Proceso de negocio
	private String processNeg;
	private List<SignChannel> signChannel;
	//Listado de facultades
	private List<String> listFaculties;

}
