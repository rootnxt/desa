/**
 * 
 */
package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * A1REOFRequestDTO
 * @author josdon
 *
 */
public class A1REOFRequestDTO {
	
	private String elevarsn;

	/**
	 * @return the elevarsn
	 */
	public String getElevarsn() {
		return elevarsn;
	}

	/**
	 * @param elevarsn the elevarsn to set
	 */
	public void setElevarsn(String elevarsn) {
		this.elevarsn = elevarsn;
	}
	
	

}
