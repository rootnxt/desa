package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Interveners.
 */

/**
 * Checks if is selected.
 *
 * @return true, if is selected
 */
@Getter

/**
 * Sets the selected.
 *
 * @param selected the new selected
 */
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Interveners {

	/** The id. */
	private int id;
	
	/** The name. */
	private String name;
	
	/** The selected. */
	private boolean selected;

	/** The personCode. */
	private String personCode;

	/** The personType. */
	private String personType;

	/** The document. */
	private String document;

	/** The fType. */
	private String fType;

}
