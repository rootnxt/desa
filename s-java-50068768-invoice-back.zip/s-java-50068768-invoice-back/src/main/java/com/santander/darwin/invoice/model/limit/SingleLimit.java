package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the url.
 *
 * @return the url
 */
@Getter

/**
 * Sets the url.
 *
 * @param url the new url
 */
@Setter

/**
 * Instantiates a new single limit.
 */
@NoArgsConstructor
public class SingleLimit {

    /** The label. */
    private String label;
    
    /** The family. */
    private String family;
    
    /** The campana. */
    private String campana;
    
    /** The product. */
    private String product;
    
    /** The amount 1. */
    private Integer amount1;
    
    /** The amount 2. */
    private Integer amount2;
    
    /** The amount 3. */
    private Integer amount3;
    
    /** The amount 4. */
    private Integer amount4;
    
    /** The asterisk. */
    private Integer asterisk;
    
    /** The url. */
    private String url;

}
