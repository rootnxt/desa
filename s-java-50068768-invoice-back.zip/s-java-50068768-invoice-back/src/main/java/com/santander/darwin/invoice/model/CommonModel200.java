package com.santander.darwin.invoice.model;

/**
 * Model for confidential values
 * 
 * @author icozar
 *
 */
public class CommonModel200 {

	// Id for object
	private String nif;
	// Name of the object
	private String name;

	/**
	 * Constructor
	 */
	public CommonModel200() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param nif  String
	 * @param name String
	 */
	public CommonModel200(String nif, String name) {
		this.nif = nif;
		this.name = name;
	}

	/**
	 * @return the nif
	 */
	public String getNif() {
		return nif;
	}

	/**
	 * @param nif the nif to set
	 */
	public void setNif(String nif) {
		this.nif = nif;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
