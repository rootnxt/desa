/**
 * 
 */
package com.santander.darwin.invoice.model;

/**
 * Modelo para las querys de bastanteo
 * 
 * @author josdon
 *
 */
public class ReglaExp {
	
	private Integer regla;
	private Integer exp;
	
	/**
	 * Constructor
	 */
	public ReglaExp() {
		super();
	}
	/**
	 * Constructor
	 * @param regla Integer
	 * @param exp Integer
	 */
	public ReglaExp(Integer regla, Integer exp) {
		super();
		this.regla = regla;
		this.exp = exp;
	}
	/**
	 * @return the regla
	 */
	public Integer getRegla() {
		return regla;
	}
	/**
	 * @param regla the regla to set
	 */
	public void setRegla(Integer regla) {
		this.regla = regla;
	}
	/**
	 * @return the exp
	 */
	public Integer getExp() {
		return exp;
	}
	/**
	 * @param exp the exp to set
	 */
	public void setExp(Integer exp) {
		this.exp = exp;
	}
	
	
	

}
