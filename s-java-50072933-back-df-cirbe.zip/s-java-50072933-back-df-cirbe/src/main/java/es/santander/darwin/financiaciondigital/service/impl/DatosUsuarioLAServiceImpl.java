package es.santander.darwin.financiaciondigital.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ws.soap.client.SoapFaultClientException;

import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.cwpola.ComBanestoAlCwpolaCwpdatosusuarioLaFCbCabeceraLAKType;
import es.santander.darwin.financiaciondigital.cwpola.ComBanestoAlCwpolaCwpdatosusuarioLaFCbConexionLAKType;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLA;
import es.santander.darwin.financiaciondigital.cwpola.DatosUsuarioLAResponse;
import es.santander.darwin.financiaciondigital.cwpola.IDIOMACORPORATIVOType;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAClient;
import es.santander.darwin.financiaciondigital.service.DatosUsuarioLAService;
import es.santander.darwin.security.authentication.converter.TokenConverter;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class DatosUsuarioLAServiceImpl.
 */

/** The Constant log. */

/** The Constant log. */
@Slf4j
@Service
public class DatosUsuarioLAServiceImpl implements DatosUsuarioLAService {

    /** The datos usuario LA client. */
    @Autowired
    private DatosUsuarioLAClient datosUsuarioLAClient;

    /** The facade. */
    @Value("${darwin.webservices.datosusuario.constants.datosusuarioFacade}")
    private String facade;

    /** The endpoint. */
    @Value("${darwin.webservices.datosusuario.resources.defaultEndpoint}")
    private String endpoint;

    /** The token converter. */
    @Autowired
    private TokenConverter tokenConverter;

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.DatosUsuarioLAService#getUserName(java.lang.String)
     */
    @Override
    public String getUserName(String companyId) throws DigitalConsumptionServiceException {
        log.info("getUserName method: " + companyId);
        try {
            DatosUsuarioLA soapRequest = this.setRequestParams(companyId);
            return this.mapResponse(datosUsuarioLAClient.executeSoapRequest(endpoint, soapRequest));
        } catch (SoapFaultClientException sfce) {
            log.info("Error CMC SoapFaultClientException: " + sfce.getCause());
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ExceptionsErrorConstants.ERROR_DETAIL_UNEXPECTED, sfce, sfce.getCause());

        } catch (Exception e) {
            log.info("Error CMC Exception: " + e.getCause());
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ExceptionsErrorConstants.ERROR_DETAIL_UNEXPECTED, e, e.getCause());
        }
    }

    /**
     * Sets the request params.
     *
     * @param companyId the company id
     * @return the datos usuario LA
     */
    private DatosUsuarioLA setRequestParams(String companyId) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String corporateToken = (String) auth.getCredentials();
        corporateToken = tokenConverter.getCorpToken();

        DatosUsuarioLA soapRequest = new DatosUsuarioLA();

        ComBanestoAlCwpolaCwpdatosusuarioLaFCbConexionLAKType datosConexion =
                new ComBanestoAlCwpolaCwpdatosusuarioLaFCbConexionLAKType();

        datosConexion.setCanalMarco(Constants.CANAL_MARCO);
        datosConexion.setTokenSeguridad(corporateToken);

        ComBanestoAlCwpolaCwpdatosusuarioLaFCbCabeceraLAKType datosCabecera =
                new ComBanestoAlCwpolaCwpdatosusuarioLaFCbCabeceraLAKType();

        IDIOMACORPORATIVOType idioma = new IDIOMACORPORATIVOType();
        idioma.setIDIOMAISO(Constants.IDIOMA_ISO);
        idioma.setDIALECTOISO(Constants.DIALECTO_ISO);
        datosCabecera.setIdioma(idioma);
        datosCabecera.setEmpresaAsociada(companyId);

        soapRequest.setFacade(facade);
        soapRequest.setDatosCabecera(datosCabecera);
        soapRequest.setDatosConexion(datosConexion);

        return soapRequest;

    }

    /**
     * Map response.
     *
     * @param soapResponse the soap response
     * @return the datos usuario response
     */
    private String mapResponse(DatosUsuarioLAResponse soapResponse) {
        String response = null;
        log.info("soapResponse: ");
        if (null != soapResponse && null != soapResponse.getMethodResult()
                && StringUtils.isNotBlank(soapResponse.getMethodResult().getNombreUsuario())) {
            response = soapResponse.getMethodResult().getNombreUsuario().trim();
        }
        return response;
    }

}
