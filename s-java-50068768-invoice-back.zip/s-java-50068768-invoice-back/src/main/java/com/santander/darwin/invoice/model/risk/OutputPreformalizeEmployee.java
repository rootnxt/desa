/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

/**
 * OutputPreformalizeEmployee.class
 * 
 * @author x574726
 *
 */

@Getter
@Setter
public class OutputPreformalizeEmployee {

	/**
	 * Indicador aplicacion(n=nominal/g=gastos) 
	 * 		Partenon alphanumeric (A) - Length(1).
	 */
	private String indapl;

}
