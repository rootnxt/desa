package com.santander.darwin.invoice.model;

import lombok.Data;

/**
 * Instantiates a new links.
 */
@Data
public class Links {
	
	/** The first. */
	private Link first;
	
	/** The self. */
	private Link self;
	
	/** The prev. */
	private Link prev;
	
	/** The next. */
	private Link next;
	
	/** The last. */
	private Link last;

}
