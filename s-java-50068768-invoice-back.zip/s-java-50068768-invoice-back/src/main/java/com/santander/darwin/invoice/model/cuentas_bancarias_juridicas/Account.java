package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import com.santander.darwin.invoice.model.common.AccountCommon;

/**
 * Account
 * 
 * @author igndom
 *
 */
public class Account extends AccountCommon {

	private String id;
	private String iban;
	private String controlDigit;
	private String accountNumber;
	private String accountNumberWithControlDigit;
	private String ccc;
	private String productTypeCode;
	private String bankCode;
	private String branchCode;
	private String contractCode;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the iban
	 */
	public String getIban() {
		return iban;
	}

	/**
	 * @param iban the iban to set
	 */
	public void setIban(String iban) {
		this.iban = iban;
	}

	/**
	 * @return the controlDigit
	 */
	public String getControlDigit() {
		return controlDigit;
	}

	/**
	 * @param controlDigit the controlDigit to set
	 */
	public void setControlDigit(String controlDigit) {
		this.controlDigit = controlDigit;
	}

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the accountNumberWithControlDigit
	 */
	public String getAccountNumberWithControlDigit() {
		return accountNumberWithControlDigit;
	}

	/**
	 * @param accountNumberWithControlDigit the accountNumberWithControlDigit to set
	 */
	public void setAccountNumberWithControlDigit(String accountNumberWithControlDigit) {
		this.accountNumberWithControlDigit = accountNumberWithControlDigit;
	}

	/**
	 * @return the ccc
	 */
	public String getCcc() {
		return ccc;
	}

	/**
	 * @param ccc the ccc to set
	 */
	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

	/**
	 * @return the productTypeCode
	 */
	public String getProductTypeCode() {
		return productTypeCode;
	}

	/**
	 * @param productTypeCode the productTypeCode to set
	 */
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return the contractCode
	 */
	public String getContractCode() {
		return contractCode;
	}

	/**
	 * @param contractCode the contractCode to set
	 */
	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}
}
