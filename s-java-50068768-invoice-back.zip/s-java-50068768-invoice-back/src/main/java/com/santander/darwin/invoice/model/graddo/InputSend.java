package com.santander.darwin.invoice.model.graddo;


import lombok.Getter;
import lombok.Setter;

/**
 * The InputSend model class.
 *
 * @Autor luis.lopez
 */
@Setter
@Getter
public class InputSend {

    /** The name. */
    private String name;

    /** The nomPlantilla. */
    private String nomPlantilla;

    /** The tipoDocumento. */
    private String tipoDocumento;

    /** The empresa. */
    private String empresa;

    /** The centro. */
    private String centro;

    /** The codigoContrato. */
    private String codigoContrato;

    /** The tipoCliente. */
    private String tipoCliente;

    /** The codigoCliente. */
    private String codigoCliente;

    /** The anio. */
    private String anio;

    /** The propuesta. */
    private String propuesta;

    /** The producto. */
    private String producto;

    /** The subtipo. */
    private String subtipo;

    /** The estandar. */
    private String estandar;

    /** The usuario. */
    private String usuario;

}
