package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Invoice.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Invoice {

	// Variables

	// Para swagger
	@Schema(example = "221,fs7.;th", description = "Id of invoice")
	@NotEmpty(message = "IVID")
	private String invoiceId;

	// Para swagger
	@Schema(example = "2019-345/790", description = "Serial and number of invoice")
	@NotEmpty(message = "IVSERIALNUMBER")
	private String invoiceSerialAndNumber;

	// Para swagger
	@Schema(example = "2021-05-30 14:15:00", description = "Date of creation")
	@NotEmpty(message = "IVCREATIONDATE")
	private String invoiceCreationDate;

	// Para swagger
	@Schema(example = "2021-05-30", description = "Date of invoice")
	@NotEmpty(message = "IVDATE")
	private String invoiceDate;

	// Para swagger
	@Schema(example = "2021-08-30", description = "Expiration date of invoice")
	@NotEmpty(message = "IVEXPIRATIONDATE")
	private String invoiceExpirationDate;

	// Para swagger
	@Schema(example = "2021-08-30", description = "Payment date of invoice")
	@NotEmpty(message = "IVPAYMENTDATE")
	private String invoicePaymentDate;

	// Para swagger
	@Schema(example = "50000", description = "Total of invoice")
	@NotNull(message = "IVTOTAL")
	private BigDecimal invoiceTotal;

	// Para swagger
	@Schema(example = "Talleres del sur S.L", description = "Name of invoice")
	@NotEmpty(message = "IVNAME")
	private String invoiceName;

	// Para swagger
	@Schema(example = "C58118753", description = "Document of invoice")
	@NotEmpty(message = "IVDOCUMENT")
	private String invoiceDocument;

	// Para swagger
	@Schema(example = "EUR", description = "Currency of invoice")
	@NotEmpty(message = "IVCURRENCY")
	private String invoiceCurrency;
}
