package es.santander.darwin.financiaciondigital.constant;

import java.util.Locale;

import org.springframework.context.i18n.LocaleContextHolder;

/**
 * The Class ErrorConstants.
 */
public class ErrorConstants {

    /** The Constant MESSAGE_BAD_REQUEST. */
    public static final String MESSAGE_BAD_REQUEST = "error.400.message";

    /** The Constant MESSAGE_UNAUTHORIZED. */
    public static final String MESSAGE_UNAUTHORIZED = "error.401.message";

    /** The Constant MESSAGE_FORBIDDEN. */
    public static final String MESSAGE_FORBIDDEN = "error.403.message";

    /** The Constant MESSAGE_INT_SERVER_ERROR. */
    public static final String MESSAGE_INT_SERVER_ERROR = "error.500.message";

    /** The Constant DEFAULT_MESSAGE. */
    public static final String DEFAULT_ERROR_MESSAGE = "Error Desconocido";

    /** The Constant DEFAULT_REQUEST_PARAM. */
    public static final String DEFAULT_REQUEST_PARAM = "unknown";

    /** The Constant DEFAULT_ERROR_CODE. */
    public static final String DEFAULT_ERROR_CODE = "UNKNOWN";

    /** The Constant LOCALE. */
    public static final Locale LOCALE = LocaleContextHolder.getLocale();

    /** The Constant COMMA_DELIMETER. */
    public static final String COMMA_DELIMETER = ", ";

    /** The Constant PATTERN_REGEX_FORMATTER_MESSAGE_1. */
    public static final String PATTERN_REGEX_FORMATTER_MESSAGE_1 = "Resolution Text:";

    /** The Constant PATTERN_REGEX_FORMATTER_MESSAGE_2. */
    public static final String PATTERN_REGEX_FORMATTER_MESSAGE_2 = "cannonicalNameException";

    /** The Constant MESSAGE_FIELD_ERROR. */
    public static final String MESSAGE_FIELD_REQUIRED = "Los siguiente campos son requeridos: ";

    /** The Constant MESSAGE_FIELD_NOT_EMPTY. */
    public static final String MESSAGE_FIELD_NOT_EMPTY = "Los siguiente campos no pueden estar vacios: ";

    /** The Constant MESSAGE_FIELD. */
    public static final String MESSAGE_FIELD = "El campo ";

    /** The Constant MESSAGE_REQUIRED. */
    public static final String MESSAGE_REQUIRED = " es requerido.";

    /** The Constant MESSAGE_INVALID_VALUE. */
    public static final String MESSAGE_INVALID_VALUE = "Valor invalido";

    /** The Constant MESSAGE_INVALID_PERSON_TYPE. */
    public static final String MESSAGE_INVALID_PERSON_TYPE = "El valor de tipo de persona solo puede ser F o J";

    /** The Constant MESSAGE_INVALID_BIGDECIMAL. */
    public static final String MESSAGE_INVALID_BIGDECIMAL = "El valor no es numerico";

    /** The Constant LENGTH_ERROR. */
    public static final String LENGTH_ERROR = "No cumple con el tamaño del campo requerido";

    /** The Constant LENGTH_ERROR_GENERIC. */
    public static final String LENGTH_ERROR_GENERIC = "Alguno de los campos cumple con el tamaño requerido";

    /** The Constant ERROR_LENGTH_ERROR. */
    public static final String ERROR_LENGTH_ERROR = "Los siguiente campos no cumplen el tamaño requerido: ";

    /** The Constant ERROR_DETAILS_PERSON_REQUESTS. */
    public static final String ERROR_DETAILS_PERSON_REQUESTS = "Se ha producido un error en el servicio SOAP, por favor ponte en contacto con tu oficina para continuar con el proceso";

    /** The Constant ERROR_NULL_CONSULTA. */
    public static final String ERROR_NULL_REQUEST = "No se encontraron petiones en la consulta";
    
    public static final String ERROR_CODE_NULL_REQUEST = "100";
    
    /** The Constant ERROR_NULL_COMPANYID. */
    public static final String MESSAGE_COMPANYID = "companyID";
    
    /** The Constant ERROR_NULL_PERSONTYPE. */
    public static final String MESSAGE_PERSONTYPE = "personType";
    
    /** The Constant ERROR_NULL_PERSONCODE. */
    public static final String MESSAGE_PERSONCODE = "personCode";
    
    /** The Constant MESSAGE_ERROR. */
    public static final String MESSAGE_ERROR = "ERROR";
    
    /** The Constant COD_ERROR_ESTADO_PROPUESTA. */
    public static final String COD_ERROR_ESTADO_PROPUESTA = "10";
    
    /** The Constant COD_ERROR_SASNA_CALL. */
    public static final String COD_ERROR_SASNA_CALL = "20";
    
    /** The Constant COD_ERROR_LLAMADO_RESOLUCION. */
    public static final String COD_ERROR_RECUPERAR_ESTADO_PROPUESTA = "30";
    
    /** The Constant COD_ERROR_RECUPERAR_PETICION_PERSONA. */
    public static final String COD_ERROR_RECUPERAR_PETICION_PERSONA = "40";
    
    /** The Constant COD_ERROR_RECUPERAR_PET_PERS_PROP. */
    public static final String COD_ERROR_ACCESO_PET_PERS_PROP = "50";
    
    /** The Constant COD_ERROR_SIN_PERSONA_ASOCIADA_PROPUESTA. */
    public static final String COD_ERROR_SIN_PERSONA_ASOCIADA_PROPUESTA = "60";
    
    /** The Constant ERROR_LENGTH_OR_NULL. */
    public static final String ERROR_LENGTH_OR_NULL = "Campos nulos o vacíos en request: ";
    
    /** The Constant ERROR_PERSONA_ASOCIADA. */
    public static final String ERROR_PERSONA_ASOCIADA = "No se encontraron datos de persona asociada a la propuesta";
    
    /** The Constant MESSAGE_ERROR_ACCESO_PET_PERS_PROP. */
    public static final String MESSAGE_ERROR_ACCESO_PET_PERS_PROP = "Error al intentar acceder a entidad peticion persona propuesta";
    
    /** The Constant MESSAGE_ERROR_CALL_SASNA. */
    public static final String MESSAGE_ERROR_CALL_SASNA = "Error al llamar al servicio de alta de nuevos acreditados";
        
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_10 = "10";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_20 = "20";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_30 = "30";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_40 = "40";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_50 = "50";
    
    /** The Constant ERROR_CODE_SENCOL_100. */
    public static final String ERROR_CODE_SENCOL_100 = "100";

    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_DETAIL_SENCOL_SASNA = "la respuesta de SASNA"; 
    
    /** The Constant ERROR_DETAIL_SENCOL_MOTOR. */
    public static final String ERROR_DETAIL_SENCOL_MOTOR = "la respuesta de MOTOR";
    
    /** The Constant ERROR_DETAIL_SENCOL_PERSON_REQUESTS. */
    public static final String ERROR_DETAIL_SENCOL_PERSON_REQUESTS = "la peticion persona";
 
    /** The Constant ERROR_DETAIL_SENCOL_PROPOSAL_STATE. */
    public static final String ERROR_DETAIL_SENCOL_PROPOSAL_STATE = "el estado de la propuesta";

    /** The Constant ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS. */
    public static final String ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS =
            "la(s) peticion(es) persona propuesta";
    
	/** The Constant ERROR_MESSAGE_SENCOL. */
	public static final String ERROR_MESSAGE_SENCOL = "Se ha producido un error al obtener {0}, por favor ponte en contacto con tu oficina para continuar con el proceso";

	/** The Constant ERROR_MESSAGE_SENCOL_GENERIC. */
	public static final String ERROR_MESSAGE_SENCOL_GENERIC = "Ha ocurrido un error, intentelo mas tarde.";
	
	/** The Constant ERROR_EMAIL_BANESCASH. */
    public static final String ERROR_EMAIL_BANESCASH = "BE_0289";

	
    /**
     * Instantiates a new error constants.
     */
    private ErrorConstants() {
    }

}
