/**
 * 
 */
package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.common.CommonType;

/**
 * CommonCommissionSummary
 * 
 * @author josdon
 *
 */
public class CommonCommissionSummary extends CommonType {

	private Object value;

	/**
	 * Constructor
	 */
	public CommonCommissionSummary() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param description String
	 * @param value       Object
	 */
	public CommonCommissionSummary(String description, Object value) {
		super(description);
		this.value = value;
	}

	/**
	 * Constructor
	 * 
	 * @param type        String
	 * @param description String
	 * @param value       Object
	 */
	public CommonCommissionSummary(String type, String description, Object value) {
		super(type, description);
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}

}
