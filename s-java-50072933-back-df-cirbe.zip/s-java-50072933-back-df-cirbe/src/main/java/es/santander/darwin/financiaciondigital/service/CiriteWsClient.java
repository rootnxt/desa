package es.santander.darwin.financiaciondigital.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class CiriteWsClient.
 */
@Slf4j
public class CiriteWsClient extends WebServiceGatewaySupport {

    /** The soap action. */
    @Value("${darwin.webservices.cirite.resources.methods.soapAction}")
    private String soapAction;

    /**
     * Execute soap request.
     *
     * @param endpoint the endpoint
     * @param request the request
     * @return the alt modif cirite request response
     */
    public AltModifCiriteRequestResponse executeSoapRequest(String endpoint, AltModifCiriteRequest request) {
        log.info("soapAction:" + soapAction);
        WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
        return (AltModifCiriteRequestResponse) webServiceTemplate.marshalSendAndReceive(endpoint, request,
                new SoapActionCallback(soapAction));
    }

}