package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * ProceedingInput.java
 *
 * @author igndom
 *
 */
public class ProceedingInput {

	private CreateSignExp createSignExp;

	/**
	 * @return the createSignExp
	 */
	public CreateSignExp getCreateSignExp() {
		return createSignExp;
	}

	/**
	 * @param createSignExp the createSignExp to set
	 */
	public void setCreateSignExp(CreateSignExp createSignExp) {
		this.createSignExp = createSignExp;
	}

}
