package es.santander.darwin.financiaciondigital.service.impl;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientResponseException;

import es.santander.darwin.common.security.auth.DarwinUserDetails;
import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataRequestVO;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsultaConsolidadoCirbeResponseVO;
import es.santander.darwin.financiaciondigital.domain.SasnaDto;
import es.santander.darwin.financiaciondigital.domain.SasnaResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.lib.constant.PersonType;
import es.santander.darwin.financiaciondigital.lib.model.PersonRequests;
import es.santander.darwin.financiaciondigital.lib.model.bean.PersonRequestIdentifier;
import es.santander.darwin.financiaciondigital.lib.service.RestConsumerService;
import es.santander.darwin.financiaciondigital.service.CirbeSasnaService;
import es.santander.darwin.financiaciondigital.service.CiriteService;
import es.santander.darwin.financiaciondigital.service.ConsolidadoCirbeService;
import es.santander.darwin.financiaciondigital.service.DFLibConnectorService;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifResponse;
import es.santander.darwin.financiaciondigital.util.TimeUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class CirbeSasnaServiceImpl.
 */

/** The Constant log. */
@Slf4j
@Service
public class CirbeSasnaServiceImpl implements CirbeSasnaService {

    /** The rest consumer service. */
    @Autowired
    private RestConsumerService restConsumerService;
    
    /** The cirite service. */
    @Autowired
    private CiriteService ciriteService;

    /** The consolidado cirbe service. */
    @Autowired
    private ConsolidadoCirbeService consolidadoCirbeService;
    
    /** The lib connector svc. */
    @Autowired
    private DFLibConnectorService libConnectorSvc;
    
    /** The parametro corte. */
    @Value("${cirbe.consolidado.parametro-corte}")
    private Integer parametroCorte;

    /** The limite peticiones. */
    @Value("${cirbe.limite-peticiones}")
    private Integer limitePeticiones;
    
    /** The mock alta. */
    @Value("${cirbe.mockAlta}")
    private String mockAlta;

    /** The res alta. */
    @Value("${cirbe.resAlta}")
    private String resAlta;
    
    /** The source type. */
    @Value("${cirbe.sourceType}")
    private String sourceType;

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.SasnaService#callSasna(java.lang.String, java.lang.String,
     * java.math.BigDecimal, java.lang.String)
     */
    @Override
    public SasnaResponse callSasna(String companyId, String personType, BigDecimal personCode, String petitionUser)
            throws DigitalConsumptionServiceException {

        boolean cirbeActualizada;

        SasnaResponse response = new SasnaResponse();

        SasnaDto sasnaDto = SasnaDto.builder().companyId(companyId).personCode(personCode).personType(personType)
                .requestUser(petitionUser).build();

        BasicPersonDataRequestVO basicPersonDataReq =
                BasicPersonDataRequestVO.builder().codpers(personCode).idempr(companyId).tipopers(personType).build();
        BasicPersonDataResponseVO basicPersonDataRes = libConnectorSvc.getBasicPersonData(basicPersonDataReq);
        log.info(basicPersonDataRes.toString());

        log.info("call callCirbe ");
        try {
            ConsultaConsolidadoCirbeResponseVO consolidado = existeEnConsolidado(basicPersonDataRes);

            boolean residente = validaResidente(basicPersonDataRes);
            boolean numPeticiones = validaNumeroDePeticiones(sasnaDto);

            if (null != consolidado && !consolidado.isNuevoAcreditado()) {
                cirbeActualizada = validaActualizado(consolidado);
                if (cirbeActualizada) {
                    procesoPeticionesPersona(basicPersonDataRes, consolidado, Constants.VALUE_02, Constants.VALUE_N,
                            null, StringUtils.EMPTY,
                            StringUtils.EMPTY);

                    response.setCode(Constants.CODE_NOACREDITADO_CIRBEACTUALIZADA);
                    response.setMessage(Constants.MESSAGE_NOACREDITADO_CIRBEACTUALIZADA);

                } else {

                    response = updateSasnaResponseWhenResidenteAndPeticiones(residente, numPeticiones,
                            basicPersonDataRes, consolidado, response);
                }
            } else {
                if (residente && numPeticiones) {
                    AltModifResponse altModifResponse = altaCirite(basicPersonDataRes, consolidado);
                    String estadoSolicitud = getEstadoSolicitud(altModifResponse.getCodigoRespuesta());
                    procesoPeticionesPersona(basicPersonDataRes, consolidado, estadoSolicitud, Constants.VALUE_S, 1,
                            StringUtils.EMPTY, StringUtils.EMPTY);
                    response.setCode(Constants.CODE_NOACREDITADO_CIRBENOACTUALIZADA);
                    response.setMessage(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA);
                } else {
                    if (!residente) {
                        response.setCode(Constants.CODE_NO_RESIDENTE);
                        response.setMessage(Constants.MESSAGE_NO_RESIDENTE);
                    }
                    if (!numPeticiones) {
                        restConsumerService.updateSourceState(personType, personCode.toString(), companyId, Constants.SOURCE_STATE_04);
                        response.setCode(Constants.CODE_PETICION_MAXIMA);
                        response.setMessage(Constants.MESSAGE_PETICION_MAXIMA);
                    }
                }
            }

        } catch (DigitalConsumptionServiceException e) {
            log.error("callCirbe : " + e.getMessage());
            throw e;
        }
        log.info(response.getMessage() + response.getCode());
        return response;

    }

    /**
     * Update sasna response when residente and peticiones.
     *
     * @param residente the residente
     * @param numPeticiones the num peticiones
     * @param basicPersonDataRes the basic person data res
     * @param consolidado the consolidado
     * @param response the response
     * @return the sasna response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private SasnaResponse updateSasnaResponseWhenResidenteAndPeticiones(boolean residente, boolean numPeticiones,
            BasicPersonDataResponseVO basicPersonDataRes, ConsultaConsolidadoCirbeResponseVO consolidado,
            SasnaResponse response) throws DigitalConsumptionServiceException {
        if (residente && numPeticiones) {
            AltModifResponse altModifResponse = altaCirite(basicPersonDataRes, consolidado);
            String estadoSolicitud = getEstadoSolicitud(altModifResponse.getCodigoRespuesta());
            PersonRequests personRequests = procesoPeticionesPersona(basicPersonDataRes, consolidado,
                    estadoSolicitud, null, 1, StringUtils.EMPTY, StringUtils.EMPTY);
            if (personRequests.getNewAccreditedIndicator().equals(Constants.VALUE_S)) {
                response.setCode(Constants.CODE_ACREDITADO_CIRBENOACTUALIZADA);
                response.setMessage(Constants.MESSAGE_ACREDITADO_CIRBENOACTUALIZADA);
            } else {
                response.setCode(Constants.CODE_NOACREDITADO_CIRBENOACTUALIZADA);
                response.setMessage(Constants.MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA);
            }
        } else if (!residente) {
            response.setCode(Constants.CODE_NO_RESIDENTE);
            response.setMessage(Constants.MESSAGE_NO_RESIDENTE);
        } else if (!numPeticiones) {
            response.setCode(Constants.CODE_PETICION_MAXIMA);
            response.setMessage(Constants.MESSAGE_PETICION_MAXIMA);
        }
        return response;
    }

    /**
     * Gets the estado solicitud.
     *
     * @param codigoRespuesta the codigo respuesta
     * @return the estado solicitud
     */
    private String getEstadoSolicitud(String codigoRespuesta) {
        Integer codCirite = Integer.parseInt(codigoRespuesta.trim());
        if (codCirite <= -4) {
            return Constants.VALUE_03;
        } else if (codCirite >= -3) {
            return Constants.VALUE_01;
        }
        return null;
    }

    /**
     * Valida residente.
     *
     * @param basicPersonDataRes the basic person data res
     * @return true, if successful
     */
    private boolean validaResidente(BasicPersonDataResponseVO basicPersonDataRes) {
        if (basicPersonDataRes.getCodPaisR().equals(Constants.COD_PAIS_ES)) {
            return true;
        }
        return false;
    }

    /**
     * Valida numero de peticiones.
     *
     * @param sasnaDto the sasna dto
     * @return true, if successful
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private boolean validaNumeroDePeticiones(SasnaDto sasnaDto)
            throws DigitalConsumptionServiceException {
        PersonRequestIdentifier personRequestIdentifier = PersonRequestIdentifier.builder()
                .companyId(sasnaDto.getCompanyId())
                .personType(sasnaDto.getPersonType())
                .personCode(sasnaDto.getPersonCode().intValue())
                .sourceType(sourceType).build();

        PersonRequests personRequests = getPeticionesPersonas(personRequestIdentifier);

        boolean response = false;
        if (null == personRequests) {
            response = true;
        } else {
            response = personRequests.getPetitionsNumber().compareTo(limitePeticiones) < 0;
        }
        return response;
    }

    /**
     * Alta cirite.
     *
     * @param basicPersonDataRes the basic person data res
     * @param consolidado the consolidado
     * @return the alt modif response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private AltModifResponse altaCirite(BasicPersonDataResponseVO basicPersonDataRes,
            ConsultaConsolidadoCirbeResponseVO consolidado) throws DigitalConsumptionServiceException {
        AltModifResponse response = new AltModifResponse();
        if (Constants.VALUE_N.equals(mockAlta)) {
            response = ciriteService.callAltaCirite(basicPersonDataRes).getAltModifCiriteRequestResult();
        } else {
            response.setCodigoRespuesta(resAlta);
        }
        return response;
    }

    /**
     * Valida actualizado.
     *
     * @param consolidado the consolidado
     * @return true, if successful
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private boolean validaActualizado(ConsultaConsolidadoCirbeResponseVO consolidado)
            throws DigitalConsumptionServiceException {

        YearMonth fechaSistema = TimeUtil.stringToDateYYYYMM(consolidado.getFechaSistema());
        YearMonth fechaCorte = fechaSistema.minusMonths(parametroCorte);

        YearMonth fechaCliente = TimeUtil.stringToDateYYYYMM(consolidado.getFechaCliente());
        int vigente = fechaCliente.compareTo(fechaCorte);
        return vigente >= 0;
    }

    /**
     * Existe en consolidado.
     *
     * @param sasnaDto the sasna dto
     * @return the consulta consolidado cirbe response VO
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private ConsultaConsolidadoCirbeResponseVO existeEnConsolidado(BasicPersonDataResponseVO basicPersonDataRes)
            throws DigitalConsumptionServiceException {
        try {
            
            ConsultaConsolidadoCirbeResponseVO response = consolidadoCirbeService.callConsolidadoCirbe(basicPersonDataRes);
            return response;
        } catch (DigitalConsumptionServiceException e) {
            if (StringUtils.isNotBlank(e.getCode())) {
                throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                        ErrorMessagesConstants.CODE_DETAILS_CIRBE_CONSOLIDADO,
                        ErrorMessagesConstants.ERROR_DETAILS_CIRBE_CONSOLIDADO, e, e.getCode());
            }
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.CODE_DETAILS_CIRBE_CONSOLIDADO,
                    ErrorMessagesConstants.ERROR_DETAILS_CIRBE_CONSOLIDADO, e);
        }

    }
    
    /**
     * Proceso peticiones persona.
     *
     * @param basicPersonDataRes the basic person data res
     * @param consolidado the consolidado
     * @param estadoSolicitud the estado solicitud
     * @param nuevoAcreditado the nuevo acreditado
     * @param peticiones the peticiones
     * @param codBdE the cod bd E
     * @param descBdE the desc bd E
     * @return the person requests
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private PersonRequests procesoPeticionesPersona(BasicPersonDataResponseVO basicPersonDataRes,
            ConsultaConsolidadoCirbeResponseVO consolidado, String estadoSolicitud, String nuevoAcreditado,
            Integer peticiones, String codBdE, String descBdE) throws DigitalConsumptionServiceException {
        PersonRequestIdentifier personRequestIdentifier = PersonRequestIdentifier.builder()
                .companyId(basicPersonDataRes.getIdEmpr()).personType(basicPersonDataRes.getTipoPers())
                .personCode(basicPersonDataRes.getCodPers().intValue()).sourceType(sourceType).build();
        PersonRequests personRequests = getPeticionesPersonas(personRequestIdentifier);

        Date now = new Date();
        if (personRequests == null) {
            nuevoAcreditado = nuevoAcreditado == null ? Constants.VALUE_S : nuevoAcreditado;
            personRequests = getUpdatedPersonRequests(new PersonRequests(), estadoSolicitud, nuevoAcreditado, null,
                    codBdE, descBdE);
            personRequests.setAdmissionDate(now);
            personRequests.setPersonRequestIdentifier(personRequestIdentifier);
            return insertPeticionesPersona(personRequests);
        } else {
            nuevoAcreditado = nuevoAcreditado == null ? Constants.VALUE_N : nuevoAcreditado;
            return updatePeticionesPersona(getUpdatedPersonRequests(personRequests, estadoSolicitud, nuevoAcreditado,
                    peticiones, codBdE, descBdE));
        }

    }
    


    /**
     * Gets the updated person requests.
     *
     * @param personRequests the person requests
     * @param sourceState the source state
     * @param nuevoAcreditado the nuevo acreditado
     * @param peticiones the peticiones
     * @param codBdE the cod bd E
     * @param descBdE the desc bd E
     * @return the updated person requests
     */
    private PersonRequests getUpdatedPersonRequests(PersonRequests personRequests, String sourceState,
            String nuevoAcreditado, Integer peticiones, String codBdE, String descBdE) {
        Date now = new Date();
        peticiones = peticiones == null ? 1 : Integer.sum(personRequests.getPetitionsNumber(), peticiones);
        personRequests.setSourceState(sourceState);
        personRequests.setNewAccreditedIndicator(nuevoAcreditado);
        personRequests.setPetitionsNumber(peticiones);
        personRequests.setRespExtCode(codBdE);
        personRequests.setRespExtDescCode(descBdE);
        personRequests.setModificationDate(now);
        personRequests.setModificationUser(getUser());
        return personRequests;
    }

    /**
     * Gets the peticiones personas.
     *
     * @param request the request
     * @return the peticiones personas
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    private PersonRequests getPeticionesPersonas(PersonRequestIdentifier request)
            throws DigitalConsumptionServiceException {
        PersonRequests personRequests = null;
        try {
            personRequests = restConsumerService.getPersonRequests(request.getCompanyId(),
                    PersonType.JURIDICAL.getValue().equalsIgnoreCase(request.getPersonType()) ? PersonType.JURIDICAL
                            : PersonType.PHYSICAL,
                    BigDecimal.valueOf(request.getPersonCode()), request.getSourceType());
        } catch (RestClientResponseException e) {
            if (StringUtils.isNotBlank(e.getMessage())) {
                throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                        ErrorMessagesConstants.CODE_DETAILS_PERSONA, ErrorMessagesConstants.ERROR_DETAILS_PERSONA, e,
                        e.getMessage());
            }
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.CODE_DETAILS_PERSONA,
                    ErrorMessagesConstants.ERROR_DETAILS_PERSONA, e);
        } catch (DigitalConsumptionInternalException e) {
            if (e.getCause() instanceof HttpClientErrorException
                    && ((HttpClientErrorException) e.getCause()).getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                return null;
            }

            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.CODE_DETAILS_PERSONA,
                    ErrorMessagesConstants.ERROR_DETAILS_PERSONA, e);
        }
        return personRequests;
    }

    /**
     * Update peticiones persona.
     *
     * @param personRequests the person requests
     * @return the person requests
     */
    private PersonRequests updatePeticionesPersona(PersonRequests personRequests) {
        return restConsumerService.updatePersonRequests(personRequests);
    }

    /**
     * Insert peticiones persona.
     *
     * @param personRequests the person requests
     * @return the person requests
     */
    private PersonRequests insertPeticionesPersona(PersonRequests personRequests) {
        return restConsumerService.insertPersonRequests(personRequests);
    }
    
    /**
     * Obtiene el usuario conectado.
     *
     * @return the user
     */
    private String getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = StringUtils.EMPTY;
        if (auth != null && auth.getPrincipal() instanceof DarwinUserDetails) {
            DarwinUserDetails santanderUD = (DarwinUserDetails) auth.getPrincipal();
            userId = santanderUD.getUsername();
        }

        return userId;
    }


}
