package com.santander.darwin.invoice.model.mongo;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * MongoLocalDateTime
 * 
 * @author igndom
 *
 */
public class MongoLocalDateTime implements Comparable<MongoLocalDateTime>, Serializable {

	public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

	private static final long serialVersionUID = -6027857356525364682L;
	private static final int PRIME = 31;
	private transient LocalDateTime localDateTime;

	private MongoLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

	/**
	 * @return the localDateTime
	 */
	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	/**
	 * Create MongoLocalDateTime of LocalDateTime
	 * 
	 * @param localDateTime LocalDateTime
	 * @return MongoLocalDateTime
	 */
	public static MongoLocalDateTime of(LocalDateTime localDateTime) {
		return new MongoLocalDateTime(localDateTime);
	}

	/**
	 * Create MongoLocalDateTime of year, month, day, hour, minute, second
	 * 
	 * @param year       int
	 * @param month      int
	 * @param dayOfMonth int
	 * @param hour       int
	 * @param minute     int
	 * @param second     int
	 * @return MongoLocalDateTime
	 */
	public static MongoLocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second) {
		return new MongoLocalDateTime(LocalDateTime.of(year, month, dayOfMonth, hour, minute, second));
	}

	/**
	 * getYear
	 * 
	 * @return int
	 */
	public int getYear() {
		return this.localDateTime.getYear();
	}

	/**
	 * getMonth
	 * 
	 * @return Month
	 */
	public Month getMonth() {
		return this.localDateTime.getMonth();
	}

	/**
	 * getDayOfMonth
	 * 
	 * @return int
	 */
	public int getDayOfMonth() {
		return this.localDateTime.getDayOfMonth();
	}

	/**
	 * getHour
	 * 
	 * @return int
	 */
	public int getHour() {
		return this.localDateTime.getHour();
	}

	/**
	 * getMinute
	 * 
	 * @return int
	 */
	public int getMinute() {
		return this.localDateTime.getMinute();
	}

	/**
	 * getSecond
	 * 
	 * @return int
	 */
	public int getSecond() {
		return this.localDateTime.getSecond();
	}

	/**
	 * toLocalDateTime
	 * 
	 * @return LocalDateTime
	 */
	public LocalDateTime toLocalDateTime() {
		return this.localDateTime;
	}

	/**
	 * plus
	 * 
	 * @param time long
	 * @param unit ChronoUnit
	 * @return MongoLocalDateTime
	 */
	public MongoLocalDateTime plus(long time, ChronoUnit unit) {
		return new MongoLocalDateTime(this.localDateTime.plus(time, unit));
	}

	/**
	 * plusDays
	 * 
	 * @param days long
	 * @return MongoLocalDateTime
	 */
	public MongoLocalDateTime plusDays(long days) {
		return new MongoLocalDateTime(this.localDateTime.plusDays(days));
	}

	/**
	 * isBefore
	 * 
	 * @param localDateTime LocalDateTime
	 * @return boolean
	 */
	public boolean isBefore(LocalDateTime localDateTime) {
		return this.localDateTime.isBefore(localDateTime);
	}

	/**
	 * isAfter
	 * 
	 * @param localDateTime LocalDateTime
	 * @return boolean
	 */
	public boolean isAfter(LocalDateTime localDateTime) {
		return this.localDateTime.isAfter(localDateTime);
	}

	@Override
	public int hashCode() {
		int result = 1;
		result = PRIME * result + ((localDateTime == null) ? 0 : localDateTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		MongoLocalDateTime other = (MongoLocalDateTime) obj;
		return (localDateTime == null && other.localDateTime != null)
				|| (localDateTime == null || !localDateTime.equals(other.localDateTime));
	}

	@Override
	public int compareTo(MongoLocalDateTime other) {
		return this.localDateTime.compareTo(other.localDateTime);
	}

	@Override
	public String toString() {
		return this.localDateTime.toString();
	}
}
