package com.santander.darwin.invoice.model.pmp;

import com.santander.darwin.invoice.model.common.CommonUrlDescription;
import com.santander.darwin.invoice.model.simulation.Disposition;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * The Class FindAdnOutput.
 */

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FindAdnOutput {


	/** The id. */
	private BigDecimal id;

	/** The name. */
	private String name;

	/** The description. */
	private String description;

	/** The tag. */
	private String tag;

	/** The fType. */
	private String fType;

	/** The tType. */
	private String tType;

	/** The financing. */
	private Financing financing;

	/** The productMonths. */
	private ProductMonths productMonths;
	
	/** The contactable. */
	private boolean contractable;

	/** The type. */
	private String type;

	/** The subType. */
	private String subType;

	/** The reference. */
	private String reference;
	
	/** The Disposition. */
    private Disposition disposition;
    
    /** The product sheet. */
	private CommonUrlDescription productSheet;

}
