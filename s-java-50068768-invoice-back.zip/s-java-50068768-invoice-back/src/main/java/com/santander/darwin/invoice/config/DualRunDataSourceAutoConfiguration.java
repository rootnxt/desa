package com.santander.darwin.invoice.config;

import com.gruposantander.enablers.dualrun.DualrunDataSource;
import com.zaxxer.hikari.HikariConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Creates the necessary datasource beans to be used by the repositories in
 * order to be able to use the mds library
 * 
 * @author Santander Technology / /* Dual run datasource automatic configuration
 *         via configuration properties.
 * @author Architecture
 */

/**
 * @author x574726
 *
 * GRAVITY DualRunDataSourceAutoConfiguration
 *
 */
@Configuration
public class DualRunDataSourceAutoConfiguration {
	/**
	 * The dual run datasource that will be created automatically.
	 * 
	 * @param mainframeConfig Mainframe datasource configuration
	 * @param gravityConfig   Gravity datasource configuration
	 * @return The dual run datasource with the combination of both
	 */

	@Bean
	public DualrunDataSource dualRunDataSource(HikariConfig mainframeConfig, HikariConfig gravityConfig) {
		return new DualrunDataSource(mainframeConfig, gravityConfig);
	}

	/**
	 * The mainframe configuration.
	 * 
	 * @return The configuration for mainframe
	 */

	@Bean
	@ConfigurationProperties(prefix = "app.datasource.mainframe")
	public HikariConfig mainframeConfig() {
		return new HikariConfig();
	}

	/**
	 * The gravity configuration.
	 * 
	 * @return The configuration for gravity
	 */
	@Bean
	@ConfigurationProperties(prefix = "app.datasource.gravity")
	public HikariConfig gravityConfig() {
		return new HikariConfig();
	}
	
}
