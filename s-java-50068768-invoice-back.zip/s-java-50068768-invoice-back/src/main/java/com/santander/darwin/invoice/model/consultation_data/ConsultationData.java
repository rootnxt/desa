package com.santander.darwin.invoice.model.consultation_data;

import com.santander.darwin.invoice.model.Account;
import com.santander.darwin.invoice.model.CommonData;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * ConsutationData
 * 
 * Consultation data class
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ConsultationData extends CommonData{
	// Cuentas
	private Account account;
	
	//Financiación 
	//OJO!! No estaria en el objeto InvoiceFinancing
	private BigDecimal finance;
	
	//registry user
	private String registryUser;
	
	//registration date
	private String registrationDate;
	
	//description
	private String description;
	
	//preformalizedDate
	private String preformalizedDate;
	
	//dueDate
	private String dueDate;
	
	//payDay
	private int payDay;
	
	// last user 
	private String lastUser;
	
	//last update date
	private String lastUpdate;
	
	
	//state Proposal
	private String stateProposal;
	
	//state ProposalCode
	private String stateProposalCode;
	
	//show preformalization data
	private boolean showPreformalizationData;
	
	// subtipology
	private String subtypology;
	
}

