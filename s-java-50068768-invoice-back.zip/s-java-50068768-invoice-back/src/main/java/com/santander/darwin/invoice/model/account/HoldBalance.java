
package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The CurrentBalance model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor
public class HoldBalance extends Balance {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new HoldBalance object.
     *
     * @param balance the balance.
     */
    public HoldBalance (Balance balance) {
        super(balance);
    }

    /**
     * copy.
     *
     * @return the Balance.
     */
    @Override
    public Balance copy() {
        return new HoldBalance(this);
    }

}
