
package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * The LocalAccount model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor

public class LocalAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The type. */
    private String type;

    /** The account. */
    private String account;

    /**
     * Instantiates a new LocalAccount object.
     *
     * @param localAccount the balance.
     */
    public LocalAccount (LocalAccount localAccount) {
        this.type = localAccount.type;
        this.account = localAccount.account;
    }

}
