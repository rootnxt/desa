package com.santander.darwin.invoice.model.fioc;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Sets the segmentacion.
 *
 * @param segmentacion the new segmentacion
 */
@Setter

/**
 * Gets the segmentacion.
 *
 * @return the segmentacion
 */
@Getter

/**
 * Instantiates a new output fioc.
 */
@NoArgsConstructor
public class OutputFioc{

	/** The existe FIOC. */
	private String existeFIOC;
	
	/** The cod estado FIOC. */
	private String codEstadoFIOC;
	
	/** The desc estado FIOC. */
	private String descEstadoFIOC;
	
	/** The fecha fin vigencia FIOC. */
	private String fechaFinVigenciaFIOC;
	
	/** The fec ult act segmentacion. */
	private String fecUltActSegmentacion;
	
	/** The segmentacion. */
	private String segmentacion;

}