package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import java.math.BigDecimal;

/**
 * AccountList
 * 
 * @author igndom
 *
 */
public class AccountList {

	private Account account;
	private String alias;
	private String accountType;
	private BigDecimal amount;
	private BigDecimal confirmedBalance;
	private BigDecimal variationBalance;
	private String currency;
	private String holderName;

	/**
	 * @return the account
	 */
	public Account getAccount() {
		return account;
	}

	/**
	 * @param account the account to set
	 */
	public void setAccount(Account account) {
		this.account = account;
	}

	/**
	 * @return the alias
	 */
	public String getAlias() {
		return alias;
	}

	/**
	 * @param alias the alias to set
	 */
	public void setAlias(String alias) {
		this.alias = alias;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the confirmedBalance
	 */
	public BigDecimal getConfirmedBalance() {
		return confirmedBalance;
	}

	/**
	 * @param confirmedBalance the confirmedBalance to set
	 */
	public void setConfirmedBalance(BigDecimal confirmedBalance) {
		this.confirmedBalance = confirmedBalance;
	}

	/**
	 * @return the variationBalance
	 */
	public BigDecimal getVariationBalance() {
		return variationBalance;
	}

	/**
	 * @param variationBalance the variationBalance to set
	 */
	public void setVariationBalance(BigDecimal variationBalance) {
		this.variationBalance = variationBalance;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the holderName
	 */
	public String getHolderName() {
		return holderName;
	}

	/**
	 * @param holderName the holderName to set
	 */
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

}
