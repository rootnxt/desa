package es.santander.darwin.financiaciondigital.lib.model.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RequestIdentifier.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the request person identifier
 */
@Builder

/**
 * Instantiates a new request person identifier.
 */
@NoArgsConstructor

/**
 * Instantiates a new request person identifier.
 *
 * @param companyId the company id
 * @param centerId the center id
 * @param proposalYear the proposal year
 * @param proposalNumber the proposal number
 * @param personType the person type
 * @param personCode the person code
 * @param sourceType the source type
 */
@AllArgsConstructor
public class RequestPersonIdentifier {

    /** The company id. */
    private String companyId;

    /** The center id. */
    private String centerId;

    /** The proposal year. */
    private Integer proposalYear;

    /** The proposal number. */
    private Integer proposalNumber;

    /** The person type. */
    private String personType;

    /** The person code. */
    private Integer personCode;

    /** The source type. */
    private String sourceType;
}
