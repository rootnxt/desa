package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * BastanteoSignerList.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class BastanteoSignerList {
	
	//Atributos de la clase
	private List<BastanteoSigner> blocks;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;
	
	//summary
	private Summary summary;
	
	//Account
	private Account account;
	
	//TypeSign
    private String typeSign;
}
