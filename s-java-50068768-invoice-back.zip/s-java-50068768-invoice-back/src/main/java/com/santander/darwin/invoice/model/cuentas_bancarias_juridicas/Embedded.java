package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Embedded
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Embedded {
	// List AccountResponse
	private  List<AccountResponseList> accountResponseList;
}
