package com.santander.darwin.invoice.exception;

import java.util.UUID;

/**
 * PageUrlException.java
 *
 * @author igndom
 *
 */
public class PageUrlException extends GlobalException {

	private static final long serialVersionUID = -8332782870266238978L;

	private final String type;
	private final String operationId;
	private final String app;
	private final String url;


	/**
	 * Constructor
	 *
	 * @param code        String
	 * @param lang        String
	 * @param operationId String
	 * @param app         String
	 * @param url         String
	 */
	public PageUrlException(String code, String lang, String operationId, String app, String url) {
		super(UUID.randomUUID(), System.currentTimeMillis(), code, lang);
		this.type = null;
		this.operationId = operationId;
		this.app = app;
		this.url = url;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return the operationId
	 */
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @return the app
	 */
	public String getApp() {
		return app;
	}
	
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

}
