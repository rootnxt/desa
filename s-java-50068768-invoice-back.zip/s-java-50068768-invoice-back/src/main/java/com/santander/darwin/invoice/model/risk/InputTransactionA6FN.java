package com.santander.darwin.invoice.model.risk;

import java.util.List;

/**
 * InputTransactionA6FN.java
 *
 * @author igndom
 *
 */
public class InputTransactionA6FN {

	private List<String> codpers;
	private List<String> tipopers;

	/**
	 * @return the codpers
	 */
	public List<String> getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(List<String> codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the tipopers
	 */
	public List<String> getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(List<String> tipopers) {
		this.tipopers = tipopers;
	}

}
