package com.santander.darwin.invoice.model.model200;

/**
 * UrlParams.java
 *
 * @author igndom
 *
 */
public class UrlParams {

	//Datos de sistema
	private String sispet;
	
	//Datos de la persona
	private String nif;
	private String tipoDoc;
	private String idempr;
	private String codPer;
	private String tipPer;
	private String canal;
	//Datos de idioma
	private String idioma;
	private String dialecto;
	/**
	 * @return the sispet
	 */
	public String getSispet() {
		return sispet;
	}
	/**
	 * @param sispet the sispet to set
	 */
	public void setSispet(String sispet) {
		this.sispet = sispet;
	}
	/**
	 * @return the nif
	 */
	public String getNif() {
		return nif;
	}
	/**
	 * @param nif the nif to set
	 */
	public void setNif(String nif) {
		this.nif = nif;
	}
	/**
	 * @return the tipoDoc
	 */
	public String getTipoDoc() {
		return tipoDoc;
	}
	/**
	 * @param tipoDoc the tipoDoc to set
	 */
	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}
	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}
	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}
	/**
	 * @return the codPer
	 */
	public String getCodPer() {
		return codPer;
	}
	/**
	 * @param codPer the codPer to set
	 */
	public void setCodPer(String codPer) {
		this.codPer = codPer;
	}
	/**
	 * @return the tipPer
	 */
	public String getTipPer() {
		return tipPer;
	}
	/**
	 * @param tipPer the tipPer to set
	 */
	public void setTipPer(String tipPer) {
		this.tipPer = tipPer;
	}
	/**
	 * @return the canal
	 */
	public String getCanal() {
		return canal;
	}
	/**
	 * @param canal the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}
	/**
	 * @return the idioma
	 */
	public String getIdioma() {
		return idioma;
	}
	/**
	 * @param idioma the idioma to set
	 */
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	/**
	 * @return the dialecto
	 */
	public String getDialecto() {
		return dialecto;
	}
	/**
	 * @param dialecto the dialecto to set
	 */
	public void setDialecto(String dialecto) {
		this.dialecto = dialecto;
	}

	
}
