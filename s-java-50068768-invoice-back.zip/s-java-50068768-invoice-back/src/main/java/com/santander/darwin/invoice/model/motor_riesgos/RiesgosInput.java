package com.santander.darwin.invoice.model.motor_riesgos;

/**
 * RiesgosInput
 * 
 * @author igndom
 *
 */
public class RiesgosInput {

	private String companyId;
	private String centerId;
	private String proposalYear;
	private int proposalNumber;
	private String operationType;
	private String processId;
	private String carIndicator;

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the centerId
	 */
	public String getCenterId() {
		return centerId;
	}

	/**
	 * @param centerId the centerId to set
	 */
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	/**
	 * @return the proposalYear
	 */
	public String getProposalYear() {
		return proposalYear;
	}

	/**
	 * @param proposalYear the proposalYear to set
	 */
	public void setProposalYear(String proposalYear) {
		this.proposalYear = proposalYear;
	}

	/**
	 * @return the proposalNumber
	 */
	public int getProposalNumber() {
		return proposalNumber;
	}

	/**
	 * @param proposalNumber the proposalNumber to set
	 */
	public void setProposalNumber(int proposalNumber) {
		this.proposalNumber = proposalNumber;
	}

	/**
	 * @return the operationType
	 */
	public String getOperationType() {
		return operationType;
	}

	/**
	 * @param operationType the operationType to set
	 */
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}

	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}

	/**
	 * @return the carIndicator
	 */
	public String getCarIndicator() {
		return carIndicator;
	}

	/**
	 * @param carIndicator the carIndicator to set
	 */
	public void setCarIndicator(String carIndicator) {
		this.carIndicator = carIndicator;
	}
}
