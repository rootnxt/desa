package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * TermStrech.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class TermStrech {
	// Datos de TermStrech
	private int termStrechFrom;
	private int termStrechUntil;
	private String priceTypeCode;
	private String priceTypeDescription;
	// Datos de TermStrech
	private String rateIndicatorCode;
	private String rateIndicatorDescription;
	private Tax tax;
	// Datos de amount
	private AmountPrix minAmount;
	private AmountPrix maxAmount;
}
