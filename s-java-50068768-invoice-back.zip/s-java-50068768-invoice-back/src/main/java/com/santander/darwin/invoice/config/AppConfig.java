package com.santander.darwin.invoice.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.santander.darwin.core.annotation.DarwinQualifier;
import com.santander.darwin.invoice.utils.interceptor.ManageRequestInterceptor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * AppConfig
 * 
 * @author igndom
 *
 */
@EnableScheduling
@Configuration
public class AppConfig implements WebMvcConfigurer {

	/** Mail **/
	@Value("${app.mail.config.server}")
	private String mailHost;
	@Value("${app.mail.config.port}")
	private String mailPort;
	@Value("${app.mail.from.user}")
	private String mailUser;
	@Value("${app.mail.from.pass}")
	private String mailPass;

	@Value("${spring.data.mongodb.idleTime:60000}")
	private Integer idleTime;

	@Value("${darwin.core.rest-template.read-timeout:10000}")
	private Integer readTimeout;

	@Value("${darwin.core.rest-template.connect-timeout:10000}")
	private Integer connectTimeout;

	/**
	 * Use the standard Mongo driver API to create a com.mongodb.client.MongoClient instance.
	 * 
	 * @return MongoClient
	 */
	public @Bean MongoClient mongoClient() {
		return MongoClients.create(MongoClientSettings.builder().applyToConnectionPoolSettings(
				builder -> builder.maxConnectionIdleTime(idleTime, TimeUnit.MILLISECONDS)).build());
	}
	
	/**
	 * restTemplate
	 * 
	 * @param builder      RestTemplateBuilder
	 * @param restTemplate RestTemplate
	 * @return RestTemplate
	 */
	@Primary
	@Bean
	@Qualifier("restTemplate")
	public RestTemplate restTemplate(RestTemplateBuilder builder, @DarwinQualifier RestTemplate restTemplate) {
		restTemplate.getMessageConverters().stream().filter(AbstractHttpMessageConverter.class::isInstance)
				.map(AbstractHttpMessageConverter.class::cast)
				.forEach(c -> c.setDefaultCharset(StandardCharsets.UTF_8));

		// Se cogen todos los interceptores
		List<ClientHttpRequestInterceptor> interceptors = restTemplate.getInterceptors();
		// Añadimos un interceptor para manegar las peticiones
		interceptors.add(new ManageRequestInterceptor());

		return builder.setConnectTimeout(Duration.ofMillis(connectTimeout))
				.setReadTimeout(Duration.ofMillis(readTimeout))
				.requestFactory(() -> new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()))
				.messageConverters(restTemplate.getMessageConverters()).interceptors(interceptors).build();
	}

	/**
	 * disableSSLValidation
	 * 
	 * @return boolean
	 * @throws NoSuchAlgorithmException NoSuchAlgorithmException
	 * @throws KeyManagementException   KeyManagementException
	 */
	@Bean
	public boolean disableSSLValidation() throws NoSuchAlgorithmException, KeyManagementException {

		// Creamos el contexto
		final SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
		// Lo inicializamos
		sslContext.init(null, null, null);

		// Cambiamos el docket por defecto
		HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
		// Cambiamos la verificacion por defecto del host
		HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> !hostname.isEmpty());

		return true;
	}

	/**
	 * setObjectMapper
	 * 
	 * @return ObjectMapper
	 */
	@Primary
	@Bean
	@Qualifier("customObjectMapper")
	public ObjectMapper setObjectMapper() {
		// Creamos el object mapper
		ObjectMapper mapper = new ObjectMapper();
		// Lo configuramos
		mapper.setConfig(mapper.getDeserializationConfig().with(JsonParser.Feature.STRICT_DUPLICATE_DETECTION)
				.with(JsonReadFeature.ALLOW_LEADING_ZEROS_FOR_NUMBERS)
				.with(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
				.with(DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY));
		return mapper;
	}

	/**
	 * getMailSender
	 * 
	 * @return JavaMailSender
	 */
	@Bean
	public JavaMailSender getMailSender() {
		// Creamos el mailSender
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		// Lo configuramos
		mailSender.setHost(mailHost);
		mailSender.setPort(25);
		mailSender.setUsername(mailUser);

		// Le cambiamos las propiedades
		Properties javaMailProperties = new Properties();
		javaMailProperties.put("mail.smtp.starttls.enable", "true");
		javaMailProperties.put("mail.smtp.auth", "false");
		javaMailProperties.put("mail.transport.protocol", "smtp");
		javaMailProperties.put("mail.debug", "false");
		javaMailProperties.put("mail.smtp.host", mailHost);
		javaMailProperties.put("mail.mime.charset", "utf-8");

		mailSender.setJavaMailProperties(javaMailProperties);

		return mailSender;
	}

}
