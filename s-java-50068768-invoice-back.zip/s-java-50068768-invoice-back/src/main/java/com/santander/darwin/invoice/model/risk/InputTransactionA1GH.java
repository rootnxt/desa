package com.santander.darwin.invoice.model.risk;

/**
 * InputTransactionA1GH.java
 *
 * @author igndom
 *
 */
public class InputTransactionA1GH extends GenericTransactionA1G {

	private String acodcamp;
	private String cfamilia;

	/**
	 * @return the acodcamp
	 */
	public String getAcodcamp() {
		return acodcamp;
	}

	/**
	 * @param acodcamp the acodcamp to set
	 */
	public void setAcodcamp(String acodcamp) {
		this.acodcamp = acodcamp;
	}

	/**
	 * @return the cfamilia
	 */
	public String getCfamilia() {
		return cfamilia;
	}

	/**
	 * @param cfamilia the cfamilia to set
	 */
	public void setCfamilia(String cfamilia) {
		this.cfamilia = cfamilia;
	}

}
