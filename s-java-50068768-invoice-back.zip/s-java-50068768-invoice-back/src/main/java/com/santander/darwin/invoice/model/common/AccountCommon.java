package com.santander.darwin.invoice.model.common;

/**
 * AccountCommon.java
 *
 * @author igndom
 *
 */
public class AccountCommon {

	private String number;
	private String company;
	private String center;
	private String product;

	/**
	 * Constructor
	 *
	 */
	public AccountCommon() {
		super();
	}

	/**
	 * Constructor
	 *
	 * @param number  String
	 * @param company String
	 * @param center  String
	 * @param product String
	 */
	public AccountCommon(String number, String company, String center, String product) {
		this.number = number;
		this.company = company;
		this.center = center;
		this.product = product;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * @return the center
	 */
	public String getCenter() {
		return center;
	}

	/**
	 * @param center the center to set
	 */
	public void setCenter(String center) {
		this.center = center;
	}

	/**
	 * @return the product
	 */
	public String getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(String product) {
		this.product = product;
	}

}
