/**
 * 
 */
package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * OutContractableProducts.java
 * 
 *
 */
@Getter
@Setter
public class OutContractableProducts {
	
	// Atributos de la clase
	// Id Familia
	private String productFamilyId;
	 
	// Lista de productGroup
	private List<ProductGroup> productGroup;
	 
}
