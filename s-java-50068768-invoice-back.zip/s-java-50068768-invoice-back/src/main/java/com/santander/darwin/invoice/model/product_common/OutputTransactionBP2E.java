package com.santander.darwin.invoice.model.product_common;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * OutputTransactionBP2E
 * 
 * @author igndom
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class OutputTransactionBP2E {
	// OUTPUT DATA

	// Partenon alphanumeric (A) - Length (6)
	private String codmsg;

	// Partenon alphanumeric (A) - Length (3)
	private List<String> codprod;

	// Partenon alphanumeric (A) - Length (3)
	private String codprodr;

	// Partenon alphanumeric (A) - Length (3)
	private List<String> codsprod;

	// Partenon alphanumeric (A) - Length (3)
	private String codspror;

	// Partenon alphanumeric (A) - Length (7)
	private List<String> coestref;

	// Partenon alphanumeric (A) - Length (7)
	private String coestrer;

	// Partenon alphanumeric (A) - Length (50)
	private List<String> desestan;

	// Partenon date (D1) - Length (8)
	private List<Date> fecomval;

	// Partenon date (D1) - Length (8)
	private Date fecomvar;

	// Partenon date (D1) - Length (8)
	private List<Date> fefinval;

	// Partenon alphanumeric (A) - Length (4)
	private List<String> idempr;

	// Partenon alphanumeric (A) - Length (4)
	private String idemprr;

	// Partenon alphanumeric (A) - Length (50)
	private String nomcesta;

	// Partenon alphanumeric (A) - Length (50)
	private List<String> nomsprod;
	
	

	/**
	 * @return the fecomvar
	 */
	public Date getFecomvar() {
		return Optional.ofNullable(fecomvar).map(Date::getTime).map(Date::new).orElse(null);
	}

	/**
	 * @param fecomvar the fecomvar to set
	 */
	public void setFecomvar(Date fecomvar) {
		this.fecomvar = Optional.ofNullable(fecomvar).map(Date::getTime).map(Date::new).orElse(null);
	}
}
