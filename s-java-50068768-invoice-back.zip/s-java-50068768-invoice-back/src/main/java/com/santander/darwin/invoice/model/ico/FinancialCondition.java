package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class FinancialCondition.
 */

/**
 * Sets the interest rate.
 *
 * @param interestRate the new interest rate
 */
@Setter

/**
 * Gets the interest rate.
 *
 * @return the interest rate
 */
@Getter

/**
 * Instantiates a new financial condition.
 */
@NoArgsConstructor
public class FinancialCondition {
	
	/** The validity period. */
	private ValidityPeriod validityPeriod;
	
	/** The interest rate. */
	private InterestRate interestRate;
}
