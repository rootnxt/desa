package com.santander.darwin.invoice.model.lanzadera;

/**
 * Lanzadera.java
 *
 * @author igndom
 *
 */
public class Lanzadera {

	private InvoiceDataLanzadera person;
	private String invoices;
	private String mode;

	/**
	 * @return the person
	 */
	public InvoiceDataLanzadera getPerson() {
		return person;
	}

	/**
	 * @param person the person to set
	 */
	public void setPerson(InvoiceDataLanzadera person) {
		this.person = person;
	}

	/**
	 * @return the invoices
	 */
	public String getInvoices() {
		return invoices;
	}

	/**
	 * @param invoices the invoices to set
	 */
	public void setInvoices(String invoices) {
		this.invoices = invoices;
	}

	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}

	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}

}
