package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * FormalizeConfirming.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class FormalizationInput {
	// Datos de FormalizationInput
	private List<Participant> participants;
	private List<ProposalPrice> proposalPrice;
	// Datos de ProposalRisk
	private ProposalRisk proposalRisk;
}