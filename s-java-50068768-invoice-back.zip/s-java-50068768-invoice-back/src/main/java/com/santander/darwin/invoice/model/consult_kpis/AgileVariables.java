/*
 * 
 */
package com.santander.darwin.invoice.model.consult_kpis;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


/**
 * The Class InputVariables.
 */

/**
 * Gets the a0531t1.
 *
 * @return the a0531t1
 */
@Getter

/**
 * Sets the a0960.
 *
 * @param a0960 the new a0960
 */
@Setter
public class AgileVariables {
	
    /** The a 0531 T 1. */
    @JsonProperty("A0531T1") 
    public String a0531T1;
    
}
