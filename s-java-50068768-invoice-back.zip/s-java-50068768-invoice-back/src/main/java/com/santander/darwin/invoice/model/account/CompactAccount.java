package com.santander.darwin.invoice.model.account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * The CompactAccount model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompactAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The type. */
    private String type;

    /** The alias. */
    private String alias;

    /** The contract. */
    private String contract;

    /** The balance. */
    private String balance;

    /** The currency. */
    private String currency;

    /** The number. */
    private String number;

    /** The company. */
    private String company;

    /** The center. */
    private String center;

    /** The product. */
    private String product;

}
