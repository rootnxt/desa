package com.santander.darwin.invoice.model.lynx;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * The MetaDataLynx class.
 *
 */
@Getter
@Setter
public class MetadataLynx extends MetaDataLynxExtends{

	/** The online flag. */
	@JsonProperty("ONLINE_FLAG")
	private String onlineFlag;
	
	/** The response required flag. */
	@JsonProperty("RESPONSE_REQUIRED_FLAG")
	private String responseRequiredFlag;
	
	/** The message type. */
	@JsonProperty("MESSAGE_TYPE")
	private String messageType;
	
	/** The host id. */
	@JsonProperty("HOST_ID")
	private String hostId;
	
	/** The cod empresa. */
	@JsonProperty("COD_EMPRESA")
	private String codEmpresa;
	
	/** The marco channel. */
	@JsonProperty("MARCO_CHANNEL")
	private String marcoChannel;
	
	/** The operative channel. */
	@JsonProperty("OPERATIVE_CHANNEL")
	private String operativeChannel;
	
	/** The country. */
	@JsonProperty("COUNTRY")
	private String country;
	
	/** The customer type. */
	@JsonProperty("CUSTOMER_TYPE")
	private String customerType;
	
	/** The customer number. */
	@JsonProperty("CUSTOMER_NUMBER")
	private String customerNumber;
	
	/** The mcc customer type. */
	@JsonProperty("MCC_CUSTOMER_TYPE")
	private String mccCustomerType;
	
	/** The mcc customer number. */
	@JsonProperty("MCC_CUSTOMER_NUMBER")
	private String mccCustomerNumber;
	
	/** The autn method. */
	@JsonProperty("AUTN_METHOD")
	private String autnMethod;
	
	/** The account. */
	@JsonProperty("ACCOUNT")
	private String account;
	
	/** The transaction unique id. */
	@JsonProperty("TRANSACTION_UNIQUE_ID")
	private String transactionUniqueId;
	
	/** The future payment date. */
	@JsonProperty("FUTURE_PAYMENT_DATE")
	private String futurePaymentDate;
	
	/** The payment end date. */
	@JsonProperty("PAYMENT_END_DATE")
	private String paymentEndDate;
	
	/** The iban destino. */
	@JsonProperty("IBAN_DESTINO")
	private String ibanDestino;
	
	/** The iban prestamo. */
	@JsonProperty("IBAN")
	private String iban;

	/** The debit credit nonmon flag. */
	@JsonProperty("DEBIT_CREDIT_NONMON_FLAG")
	private String debitCreditNonmonFlag;
	
	/** The ip address. */
	@JsonProperty("IP_ADDRESS")
	private String ipAddress;
	
	/** The response code. */
	@JsonProperty("RESPONSE_CODE")
	private String responseCode;
	
	/** The date time. */
	@JsonProperty("DATE_TIME")
	private String dateTime;
	
	/** The amount. */
	@JsonProperty("AMOUNT")
	private String amount;
	
	/** The currency. */
	@JsonProperty("CURRENCY")
	private String currency;
	
	/** The transaction code. */
	@JsonProperty("TRANSACTION_CODE")
	private String transactionCode;
	
	/** The ioc uid. */
	@JsonProperty("IOC_UID")
	private String iocUid;
	
	/** The process flag. */
	@JsonProperty("PROCESS_FLAG")
	private String processFlag;
	
	/** The beneficiary alias. */
	@JsonProperty("BENEFICIARY_NAME")
	private String beneficiaryAlias;
	
	/** The original payment amount. */
	@JsonProperty("ORIGINAL_PAYMENT_AMOUNT")
	private String originalPaymentAmount;
	
}

