package com.santander.darwin.invoice.model.refinancing_contracts;

import com.santander.darwin.invoice.model.common.ProposalCommon;

/**
 * CommonData.java
 *
 * @author igndom
 *
 */
public class CommonData extends ProposalCommon {

	private String sxvalue;
	private String a1codseg;
	private String anoprop;
	private String tipopers;
	private int numprop;
	private String podinter;
	private String pormint;
	private String a1tipint;
	private String a1forint;
	private float porparti;
	private float a1porpar;
	private int relainte;
	private int ordintc;

	/**
	 * @return the sxvalue
	 */
	public String getSxvalue() {
		return sxvalue;
	}

	/**
	 * @param sxvalue the sxvalue to set
	 */
	public void setSxvalue(String sxvalue) {
		this.sxvalue = sxvalue;
	}

	/**
	 * @return the a1codseg
	 */
	public String getA1codseg() {
		return a1codseg;
	}

	/**
	 * @param a1codseg the a1codseg to set
	 */
	public void setA1codseg(String a1codseg) {
		this.a1codseg = a1codseg;
	}

	/**
	 * @return the anoprop
	 */
	public String getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(String anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTippers(String tipopers) {
		this.tipopers = tipopers;
	}

	/**
	 * @return the numprop
	 */
	public int getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(int numprop) {
		this.numprop = numprop;
	}

	/**
	 * @return the podinter
	 */
	public String getPodinter() {
		return podinter;
	}

	/**
	 * @param podinter the podinter to set
	 */
	public void setPodinter(String podinter) {
		this.podinter = podinter;
	}

	/**
	 * @return the pormint
	 */
	public String getPormint() {
		return pormint;
	}

	/**
	 * @param pormint the pormint to set
	 */
	public void setPormint(String pormint) {
		this.pormint = pormint;
	}

	/**
	 * @return the a1tipint
	 */
	public String getA1tipint() {
		return a1tipint;
	}

	/**
	 * @param a1tipint the a1tipint to set
	 */
	public void setA1tipint(String a1tipint) {
		this.a1tipint = a1tipint;
	}

	/**
	 * @return the a1forint
	 */
	public String getA1forint() {
		return a1forint;
	}

	/**
	 * @param a1forint the a1forint to set
	 */
	public void setA1forint(String a1forint) {
		this.a1forint = a1forint;
	}

	/**
	 * @return the porparti
	 */
	public float getPorparti() {
		return porparti;
	}

	/**
	 * @param porparti the porparti to set
	 */
	public void setPorparti(float porparti) {
		this.porparti = porparti;
	}

	/**
	 * @return the a1porpar
	 */
	public float getA1porpar() {
		return a1porpar;
	}

	/**
	 * @param a1porpar the a1porpar to set
	 */
	public void setA1porpar(float a1porpar) {
		this.a1porpar = a1porpar;
	}

	/**
	 * @return the relainte
	 */
	public int getRelainte() {
		return relainte;
	}

	/**
	 * @param relainte the relainte to set
	 */
	public void setRelainte(int relainte) {
		this.relainte = relainte;
	}

	/**
	 * @return the ordintc
	 */
	public int getOrdintc() {
		return ordintc;
	}

	/**
	 * @param ordintc the ordintc to set
	 */
	public void setOrdintc(int ordintc) {
		this.ordintc = ordintc;
	}
}