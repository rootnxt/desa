package com.santander.darwin.invoice.model.end;

import lombok.Getter;
import lombok.Setter;

/**
 * End.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class DataText {

	// Atributos de la clase
	private String title;
	private String body;
	private String body1;
	private String body2;


}
