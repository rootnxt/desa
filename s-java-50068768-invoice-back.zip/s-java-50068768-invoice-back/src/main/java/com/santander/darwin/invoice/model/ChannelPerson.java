package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * 
 * ChannelPerson
 * 
 * @author X281418
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ChannelPerson {
	
	// Tipo de persona
	private String tipoPers;
	
	// Codigo de persona
	private int codPers;
	
	// Canal
	private String channel;


}
