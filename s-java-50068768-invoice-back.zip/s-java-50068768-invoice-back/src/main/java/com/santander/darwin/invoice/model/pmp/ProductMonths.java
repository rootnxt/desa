package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * ProductMonths model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductMonths {
    /** min */
    private int min;
    /** max */
    private int max;
    /** range */
    private List<Integer> range;
    /** select */
    private int select;
    /** type */
    private String type;
    /** maxContract */
    private String maxContract;
    /** maxDraft */
    private String maxDraft;
}
