/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * DataComexOutput.class
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class DataComexOutput {
	
	// Atributos de la clase
	
	/** Cogemos el campo TASA01 que corresponda al número de ocurrencia COCONCL2 212 – TRX A8CRL  **/
	private BigDecimal porcentajeApertura;
	/** Cogemos el campo DESCODRE que corresponda al número de ocurrencia COCONCL2 212 – TRX A8CRL  **/
	private String minimoComisApert;
	/** Cogemos el campo TASA01 que corresponda al número de ocurrencia COCONCL2 214 – TRX A8CRL  **/
	private BigDecimal comisionCanAnt;
	
	
	/** Cogemos el campo TASA01 que corresponda al número de ocurrencia COCONCL2 BF0 – TRX A8CRL **/
	private BigDecimal comisionCambio;
	
	/** Cogemos el campo DESCODRE que corresponda al número de ocurrencia COCONCL2 BF0 – TRX A8CRL **/
	private String minComisionCambio;
	
	/** Cogemos el campo TASA01 que corresponda al número de ocurrencia COCONCL2 B67 – TRX A8CRL **/
	private BigDecimal comisionModCondiciones;
	
	/** Cogemos el campo DESCODRE que corresponda al número de ocurrencia COCONCL2 B67 – TRX A8CRL **/
	private String minComisionModCondiciones;
	
	/** Listado de intereses SAT 2634  **/
    private List<InterestComex> intereses;
	
	/** Cogemos primera ocurrencia del campo IDIFEREN para COCONCL2 118– SAT 2634 **/
	private BigDecimal interesDemora;
}
