package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * AsociateGuarantorsInput.java
 *
 * @author igndom
 *
 */
public class AsociateGuarantorsInput {

	private CommonData commonData;
	private Sat2406RequestDTO sat2406RequestDto;
	private Trxa1meRequestDTO trxA1MERequestDto;

	/**
	 * @return the commonData
	 */
	public CommonData getCommonData() {
		return commonData;
	}

	/**
	 * @param commonData the commonData to set
	 */
	public void setCommonData(CommonData commonData) {
		this.commonData = commonData;
	}

	/**
	 * @return the sat2406RequestDto
	 */
	public Sat2406RequestDTO getSat2406RequestDto() {
		return sat2406RequestDto;
	}

	/**
	 * @param sat2406RequestDto the sat2406RequestDto to set
	 */
	public void setSat2406RequestDto(Sat2406RequestDTO sat2406RequestDto) {
		this.sat2406RequestDto = sat2406RequestDto;
	}

	/**
	 * @return the trxA1MERequestDto
	 */
	public Trxa1meRequestDTO getTrxA1MERequestDto() {
		return trxA1MERequestDto;
	}

	/**
	 * @param trxA1MERequestDto the trxA1MERequestDto to set
	 */
	public void setTrxA1MERequestDto(Trxa1meRequestDTO trxA1MERequestDto) {
		this.trxA1MERequestDto = trxA1MERequestDto;
	}

}
