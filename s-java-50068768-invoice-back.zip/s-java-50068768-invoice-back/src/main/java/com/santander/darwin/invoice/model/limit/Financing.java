package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Gets the financing data.
 *
 * @return the data
 */
@Getter

/**
 * Sets the financing data.
 *
 * @param data the new data
 */
@Setter

/**
 * Instantiates a new financing data.
 */
@NoArgsConstructor
public class Financing {

	// Min
	private BigDecimal min;
	
	// Maximo
	private BigDecimal max;
	
	// Seleccionado
	private BigDecimal finance;

}
