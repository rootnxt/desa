package com.santander.darwin.invoice.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 *
 * InvoiceDto model class.
 *
 * @author luis.lopez
 *
 */
@Setter
@Getter
@Builder
public class InvoiceDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The registryUser */
    private String registryUser;

    /** The lastChannel */
    private String lastChannel;

    /** The lastEmployed */
    private String selectedEmployeeNumber;
}
