package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * InvoiceAppPMP model class.
 * 
 * @author luis.lopez
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceAppPMP {

	/** The id. */
	@Id
	private String id;

	/** The description List. */
	private List<CommonLangDesc> description;

	/** The group. */
	private String group;

	/** The tags. */
	private String tags;

	/** The type. */
	private String type;

	/** The subType. */
	private String subType;

	/** The reference. */
	private String reference;

	/** The channel. */
	private String channel;

	/** The tInter. */
	private String tInter;

	/** The fInter. */
	private String fInter;
	
	/** The riskConsumptionIndicator. */
	private String riskConsumptionIndicator;
	
	/** The contractable. */
	private boolean contractable;
	
	/** The gtype. */
	private String gtype;

	/** The gsubType. */
	private String gsubType;

	/** The greference. */
	private String greference;

}
