package es.santander.darwin.financiaciondigital.service;

import es.santander.darwin.financiaciondigital.domain.ConsolidadoResponse;
import es.santander.darwin.financiaciondigital.domain.ListaResumenRequest;

/**
 * The Interface RestConsolidadoService.
 */
public interface RestConsolidadoService {
    

   /**
    * Call consolidado.
    *
    * @param request the request
    * @return the consolidado response
    */
   ConsolidadoResponse callConsolidado(ListaResumenRequest request);

}
