package es.santander.darwin.financiaciondigital.jpa.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;

import es.santander.darwin.financiaciondigital.constant.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the perso propuesta entity
 */
@Builder
@Entity

/**
 * Instantiates a new perso propuesta entity.
 */
@NoArgsConstructor

/**
 * Instantiates a new perso propuesta entity.
 *
 * @param id the id
 * @param formint the formint
 * @param porParti the por parti
 * @param modifierUser the modifier user
 * @param modifyDate the modify date
 * @param regMatri the reg matri
 * @param indrai the indrai
 * @param indProju the ind proju
 * @param imporAct the impor act
 */
@AllArgsConstructor
@Table(name = Constants.PERSOPROP_03)
public class PersoPropuestaEntity {

    /** The id. */
    @EmbeddedId
    private PersoPropuestaEntityPK id;

    /** The formint. */
    @Column(name = "PNE_FORMINT")
    private String formint;

    /** The por parti. */
    @Column(name = "PNE_PORPARTI")
    private BigDecimal porParti;

    /** The modifier user. */
    @Column(name = "PNE_USUMOD")
    private String modifierUser;
    
    /** The modify date. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNE_FECMOD")
    private LocalDate modifyDate;

    /** The reg matri. */
    @Column(name = "PNE_REGMATRI")
    private String regMatri;

    /** The indrai. */
    @Column(name = "PNE_INDRAI")
    private String indrai;

    /** The ind proju. */
    @Column(name = "PNE_INDPROJU")
    private String indProju;

    /** The impor act. */
    @Column(name = "PNE_IMPORACT")
    private BigDecimal imporAct;
}
