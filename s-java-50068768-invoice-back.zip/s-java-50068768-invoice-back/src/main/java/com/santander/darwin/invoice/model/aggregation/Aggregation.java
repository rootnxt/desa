package com.santander.darwin.invoice.model.aggregation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.santander.darwin.invoice.model.CommonData;
import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Aggregation
 * 
 * @author igndom
 *
 */

@NoArgsConstructor
@Getter
@Setter
public class Aggregation extends CommonData {
	
	//urlAggregator
	private String urlAggregator;

	// Notificaciones
	private boolean notifyAggregation;
	private boolean online;
	//Fecha notificación
	@JsonIgnore
	private MongoLocalDateTime dateNotifyAggregation;
	
	//Resultado de la notificacion
	private String state;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;
}