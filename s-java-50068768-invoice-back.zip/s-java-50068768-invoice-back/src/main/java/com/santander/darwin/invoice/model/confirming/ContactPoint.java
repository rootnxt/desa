package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * ContactPoint.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ContactPoint {
	// Datos de ContactPoint
	private List<ElectronicAddress> electronicAddresses;
	private Object postalAddress;
	// Datos de ContactPoint
	private Object electronicAddress;
	private PhoneAddress phoneAddress;
}