/**
 * 
 */
package com.santander.darwin.invoice.model.refinancing_contracts;

import com.santander.darwin.invoice.model.common.ProposalCommon;

import java.math.BigDecimal;

/**
 * CommonDataDTO
 * 
 * @author josdon
 *
 */
public class CommonDataDTO extends ProposalCommon {

	private String tipopers;
	private BigDecimal anoprop;
	private BigDecimal numprop;

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}

	/**
	 * @return the anoprop
	 */
	public BigDecimal getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(BigDecimal anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the numprop
	 */
	public BigDecimal getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(BigDecimal numprop) {
		this.numprop = numprop;
	}

}
