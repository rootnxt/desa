package es.santander.darwin.financiaciondigital.soap.repositories;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import es.santander.darwin.financiaciondigital.constant.Queries;
import es.santander.darwin.financiaciondigital.jpa.model.PersoPropuestaEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PersoPropuestaEntityPK;

/**
 * The Interface PersonProposalOraRepository.
 */
@Repository
public interface PersonProposalJpaRepository
        extends PagingAndSortingRepository<PersoPropuestaEntity, PersoPropuestaEntityPK>,
        JpaSpecificationExecutor<PersoPropuestaEntity> {

    /**
     * Gets the lista titulares.
     *
     * @param company the company
     * @param center the center
     * @param year the year
     * @param numProp the num prop
     * @return the lista titulares
     */
    @Query(Queries.TITULARES_POR_PROPUESTA)
    public List<PersoPropuestaEntity> getListaTitulares(@Param("company") String company,
            @Param("center") String center, @Param("proposalYear") String year,
            @Param("proposalNumber") BigDecimal numProp);

    /**
     * Gets the lista avalistas.
     *
     * @param company the company
     * @param center the center
     * @param year the year
     * @param numProp the num prop
     * @return the lista avalistas
     */
    @Query(Queries.AVALISTAS_POR_PROPUESTA)
    public List<PersoPropuestaEntity> getListaAvalistas(@Param("company") String company,
            @Param("center") String center, @Param("proposalYear") String year,
            @Param("proposalNumber") BigDecimal numProp);
}
