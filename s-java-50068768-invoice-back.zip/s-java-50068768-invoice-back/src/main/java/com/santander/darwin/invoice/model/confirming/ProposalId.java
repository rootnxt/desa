package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * ProposalId.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProposalId {
	// Datos de ProposalId
	private String entity;
	private String center;
	private String year;
	// Datos de ProposalId
	private BigDecimal applicationNumber;
}