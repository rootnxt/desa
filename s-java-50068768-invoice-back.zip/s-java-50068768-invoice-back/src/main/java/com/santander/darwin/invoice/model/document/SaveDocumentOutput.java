/**
 * 
 */
package com.santander.darwin.invoice.model.document;

/**
 * SaveDocumentOutput
 * 
 * @author josdon
 *
 */
public class SaveDocumentOutput {

	private String gniD;

	/**
	 * @return the gniD
	 */
	public String getGniD() {
		return gniD;
	}

	/**
	 * @param gniD the gniD to set
	 */
	public void setGniD(String gniD) {
		this.gniD = gniD;
	}

}
