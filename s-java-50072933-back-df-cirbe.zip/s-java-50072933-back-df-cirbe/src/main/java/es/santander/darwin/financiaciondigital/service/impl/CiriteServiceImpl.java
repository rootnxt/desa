package es.santander.darwin.financiaciondigital.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.service.CiriteService;
import es.santander.darwin.financiaciondigital.service.CiriteWsClient;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.DomicilioNoResidente;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.Gestion;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.Identificador;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.NoResidente;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class DocumentServiceImpl.
 */

/** The Constant log. */

/** The Constant log. */
@Slf4j
@Service
public class CiriteServiceImpl implements CiriteService {

    /** The document client. */
    @Autowired
    private CiriteWsClient ciriteClient;

    /** The end point. */
    @Value("${darwin.webservices.cirite.resources.defaultEndpoint}")
    private String endPoint;

    /** The centro persona. */
    @Value("${cirite.centroPersona}")
    private String centroPersona;

    /** The person management. */
    @Value("${cirite.personManagement}")
    private String personManagement;

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.nuar.consumodigital.service.CiriteService#callCirite(es.santander.nuar.consumodigital.bean.
     * CiriteRequest)
     */
    @Override
    public AltModifCiriteRequestResponse callAltaCirite(BasicPersonDataResponseVO persona)
            throws DigitalConsumptionServiceException {
        AltModifRequest consultRequest = new AltModifRequest();
        Identificador identificador = new Identificador();
        Gestion gestion = new Gestion();
        NoResidente noResidente = new NoResidente();
        DomicilioNoResidente domicilioNoResidente = new DomicilioNoResidente();

        identificador.setIdEntidadPropietaria(Integer.parseInt(persona.getIdEmpr()));
        identificador
                .setIdPersona(persona.getTipoPers() + StringUtils.leftPad(persona.getCodPers().toString(), 9, "0"));
        identificador.setTipoPersona(persona.getTipoPers());
        identificador.setPaisResidencia(persona.getCodPaisR());
        identificador.setNIF(persona.getDocumentCod());
        identificador.setNIE("");
        identificador.setCNR("");
        identificador.setPaisNacionalidad(persona.getCodPaisN());
        identificador.setApellidosORazonSocial(persona.getFullName());
        identificador.setNombre("");

        gestion.setCiriteGestion("");
        gestion.setCentroPersona(centroPersona);
        gestion.setGestorPersona(personManagement);

        noResidente.setCodigoIdentificacionFiscalPaisResidencia("");
        noResidente.setNumeroPasaporte("");
        noResidente.setNumeroDocumentoIdentificacionPaisOrigen("");
        noResidente.setSector("");
        noResidente.setSexo("");
        noResidente.setPaisNacimiento("");
        noResidente.setFechaNacimientoConstitucion("");
        noResidente.setFormaSocialAbreviatura("");
        noResidente.setCodigoIsin("");
        noResidente.setCodigoSwift("");
        noResidente.setInformacionCualitativa("");
        noResidente.setCodigoLEI("");
        noResidente.setIdentificadorNacional("");
        noResidente.setTipoIdentificadorNacional("");
        noResidente.setFormaJuridicaNoResidente("");

        domicilioNoResidente.setTipoVia("");
        domicilioNoResidente.setNombreVia("");
        domicilioNoResidente.setNumeroVia("");
        domicilioNoResidente.setBloqueOPortal("");
        domicilioNoResidente.setPlanta("");
        domicilioNoResidente.setPuerta("");
        domicilioNoResidente.setMunicipio("");
        domicilioNoResidente.setPoblacion("");
        domicilioNoResidente.setCodigoPostal("");
        domicilioNoResidente.setPais("");
        domicilioNoResidente.setDomicilioPersonalSocialNUT("");

        noResidente.setDomicilio(domicilioNoResidente);

        consultRequest.setIdentificador(identificador);
        consultRequest.setGestion(gestion);
        consultRequest.setNoResidente(noResidente);

        log.info(consultRequest.toString());

        AltModifCiriteRequest soapCiriteRequest = new AltModifCiriteRequest();
        soapCiriteRequest.setRequest(consultRequest);

        log.info("Verificacion Centro Persona: "+soapCiriteRequest.getRequest().getGestion().getCentroPersona());
        log.info("Verificacion Gestor Persona: "+soapCiriteRequest.getRequest().getGestion().getGestorPersona());
        
        AltModifCiriteRequestResponse response;
        try {
            response = ciriteClient.executeSoapRequest(endPoint, soapCiriteRequest);
        } catch (Exception e) {
            log.info("ERROR al ejecutar llamada WS Cirite");
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.CODE_DETAILS_CIRBE_ALTA, ErrorMessagesConstants.ERROR_DETAILS_CIRBE_ALTA,
                    e);
        }

        if (response != null && response.getAltModifCiriteRequestResult() != null) {
            log.info("La respuesta de cirite es:\n Codigo respuesta: "
                    + response.getAltModifCiriteRequestResult().getCodigoRespuesta() + "\n Descripcion respuesta: "
                    + response.getAltModifCiriteRequestResult().getDescripcionRespuesta());
        }

        return response;
    }

}
