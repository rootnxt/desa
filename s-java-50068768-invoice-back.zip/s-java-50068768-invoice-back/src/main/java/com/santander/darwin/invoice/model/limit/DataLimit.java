package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the subs.
 *
 * @return the subs
 */
@Getter

/**
 * Sets the subs.
 *
 * @param subs the new subs
 */
@Setter

/**
 * Instantiates a new data limit.
 */
@NoArgsConstructor
public class DataLimit {

    /** The data. */
    private SingleLimit data;
    
    /** The subs. */
    private List<SingleLimit> subs;

}
