package es.santander.darwin.financiaciondigital.CirbeEndPointTest;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import es.santander.darwin.financiaciondigital.endpoint.CirbeEndPoint;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.handler.DigitalConsumptionServiceExceptionHandler;
import es.santander.darwin.financiaciondigital.service.CirbeService;
import es.santander.darwin.financiaciondigital.soap.GetPersonRequest;
import es.santander.darwin.financiaciondigital.soap.GetPersonResponse;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalResponse;
import es.santander.darwin.financiaciondigital.soap.exceptions.ServiceFaultException;

public class CirbeEndPointTest {

    @InjectMocks
    private CirbeEndPoint cirbeEndPoint;

    @Mock
    private CirbeService cirbeService;

    @Mock
    private GetPersonResponse getPersonResponse;

    private MockMvc mockMvc;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders
                .standaloneSetup(cirbeEndPoint)
                .setControllerAdvice(new DigitalConsumptionServiceExceptionHandler())
                .build();
    }

    @Test
    public void personRequestTestOK() throws Exception {
        GetPersonRequest body = new GetPersonRequest();
        body.setCompanyID("0049");
        body.setPersonCode(new BigDecimal(320));
        body.setPersonType("J");
        doReturn(getPersonResponse).when(cirbeService).getPersonRequest(body);
        cirbeEndPoint.getPersonRequest(body);
    }

    @Test(expected = NullPointerException.class)
    public void personRequestTestNOK() throws Exception {
        when(cirbeService.getPersonRequest(any(GetPersonRequest.class))).thenThrow(new NullPointerException());
        cirbeEndPoint.getPersonRequest(new GetPersonRequest());
    }

    @Test
    public void getPetitionsOfPersonAndProposalsTestOk()
            throws DatatypeConfigurationException, DigitalConsumptionServiceException {
        PetitionsOfPersonAndProposalResponse petitionsOfPersAndPropsResponseMock =
                new PetitionsOfPersonAndProposalResponse();
        petitionsOfPersAndPropsResponseMock.setProcessIndicator("11");

        when(cirbeService.getPetitionsOfPersonAndProposalsResponse(any(PetitionsOfPersonAndProposalRequest.class)))
                .thenReturn(petitionsOfPersAndPropsResponseMock);
        assertNotNull(cirbeEndPoint.getPetitionsOfPersonAndProposals(new PetitionsOfPersonAndProposalRequest()));
    }

    @Test(expected = ServiceFaultException.class)
    public void getPetitionsOfPersonAndProposalsTestKO()
            throws DatatypeConfigurationException, DigitalConsumptionServiceException {

        when(cirbeService.getPetitionsOfPersonAndProposalsResponse(any(PetitionsOfPersonAndProposalRequest.class)))
                .thenThrow(new ServiceFaultException("Message", new RuntimeException(), null));
        cirbeEndPoint.getPetitionsOfPersonAndProposals(new PetitionsOfPersonAndProposalRequest());
    }

}
