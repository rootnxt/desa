package es.santander.darwin.financiaciondigital.service;

import java.util.concurrent.ExecutionException;

import javax.xml.datatype.DatatypeConfigurationException;

import es.santander.darwin.financiaciondigital.domain.PetitionsTreatmentProcessResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolDto;
import es.santander.darwin.financiaciondigital.domain.ProposalRequestsSencolMotorDTO;
import es.santander.darwin.financiaciondigital.domain.SencolResponse;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.soap.GetPersonRequest;
import es.santander.darwin.financiaciondigital.soap.GetPersonResponse;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalRequest;
import es.santander.darwin.financiaciondigital.soap.PetitionsOfPersonAndProposalResponse;

/**
 * The Interface SasnaService.
 */
public interface CirbeService {

    /**
     * Call sencol.
     *
     * @param body the body
     * @return the sencol response
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     * @throws ExecutionException
     * @throws InterruptedException
     */
    SencolResponse callSencol(ProposalRequestsSencolDto body)
            throws DigitalConsumptionServiceException, InterruptedException, ExecutionException;

    /**
     * Gets the person request.
     *
     * @param request the request
     * @return the person request
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    GetPersonResponse getPersonRequest(GetPersonRequest request) throws DigitalConsumptionServiceException;

    /**
     * Gets the petitions of person and proposals response.
     *
     * @param request the request
     * @return the petitions of person and proposals response
     * @throws DatatypeConfigurationException the datatype configuration exception
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    public PetitionsOfPersonAndProposalResponse getPetitionsOfPersonAndProposalsResponse(
            PetitionsOfPersonAndProposalRequest request)
            throws DatatypeConfigurationException, DigitalConsumptionServiceException;

    /**
     * Call treatment process.
     *
     * @param proposalRequest the proposal request
     * @param petitionUser the petition user
     * @return the petitions treatment process response
     */
    public PetitionsTreatmentProcessResponse callTreatmentProcess(ProposalRequestsSencolMotorDTO proposalRequest)
            throws DigitalConsumptionServiceException;
}
