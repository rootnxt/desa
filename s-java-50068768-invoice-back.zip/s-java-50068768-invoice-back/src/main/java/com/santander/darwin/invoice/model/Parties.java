package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Parties
 * 
 * @author x232031
 *
 */

@Getter
@Setter
public class Parties {

	/** The clientId. */
	private String clientId;

	/** The name. */
	private String name;

	/** The participantType. */
	private String participantType;

	/** The participantOrder. */
	private BigDecimal participantOrder;

	/** The participant. */
	private String participant;

	/** The participantForm. */
	private String participantForm;

	/** The expirationDate. */
	private String expirationDate;

}
