/**
 * 
 */
package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * ProductGroup.java
 * 
 *
 */
@Getter
@Setter
public class ProductGroup {
	
	// Atributos de la clase
	// productGroupId
	private String productGroupId;
	// products listaProductos
	private List<ProductClass> products;
	 
}
