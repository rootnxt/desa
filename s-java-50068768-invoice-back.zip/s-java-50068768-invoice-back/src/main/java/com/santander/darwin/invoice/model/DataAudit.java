
package com.santander.darwin.invoice.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * DataAudit
 * 
 * @author igndom
 *
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "registryUser", "personCodeUser", "userName", "typeUserNif", "userNif", "personCodeNoCustomers",
		"endUserPersonCode", "userEmail", "contractHolderName", "documentContractHolder", "registryDate",
		"dateLastUpdate", "lastUser", "dateDelete", "deleteUser", "dateEnd" })
public class DataAudit implements Serializable {
	private static final long serialVersionUID = -5008275655840979030L;

	/** The registryUser */
	@JsonProperty("registryUser")
	private String registryUser;

	// Codigo de persona juridica logada
	/** The personCodeUser */
	@JsonProperty("personCodeUser")
	private int personCodeUser;

	// Nombre persona fisica logada
	/** The userName */
	@JsonProperty("userName")
    private transient String userName;

	// Tipo NIF persona fisica logada
	/** The typeUserNif */
	@JsonProperty("typeUserNif")
    private transient String typeUserNif;

	// NIF persona fisica logada
	/** The userNif */
	@JsonProperty("userNif")
    private transient String userNif;

	// Codigos de persona fisica cliente / no cliente
	/** The personCodeNoCustomers */
	@JsonProperty("personCodeNoCustomers")
	private int personCodeNoCustomers;

	/** The endUserPersonCode */
	@JsonProperty("endUserPersonCode")
	private int endUserPersonCode;

	// Mail de la persona fisica logada
	/** The userEmail */
	@JsonProperty("userEmail")
    private transient String userEmail;

	// Nombre de la empresa logada
	/** The contractHolderName */
	@JsonProperty("contractHolderName")
	private String contractHolderName;

	// CIF de la empresa logada
	/** The documentContractHolder */
	@JsonProperty("documentContractHolder")
	private String documentContractHolder;

	// Fechas y usuarios de auditoria, creacion, modificacion y baja

	/** The registryDate */
	@JsonProperty("registryDate")
	private transient MongoLocalDateTime registryDate;

	/** The dateLastUpdate */
	@JsonProperty("dateLastUpdate")
	private transient MongoLocalDateTime dateLastUpdate;

	/** The lastUser */
	@JsonProperty("lastUser")
	private String lastUser;

	/** The dateDelete */
	@JsonProperty("dateDelete")
	private transient MongoLocalDateTime dateDelete;

	/** The deleteUser */
	@JsonProperty("deleteUser")
	private String deleteUser;

	/** The dateEnd */
	@JsonProperty("dateEnd")
	private transient MongoLocalDateTime dateEnd;

	/** The channel */
	@JsonProperty("channel")
	private String channel;

	/** The lastChannel */
	@JsonProperty("lastChannel")
	private String lastChannel;

	/** The registryEmployee */
	@JsonProperty("registryEmployee")
	private String registryEmployee;

	/** The selectedEmployee */
	@JsonProperty("selectedEmployee")
	private String selectedEmployee;
	
	/** The origin */
	@JsonProperty("origin")
	private String origin;

	/**
	 * Constructor Default
	 */
	public DataAudit() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param registryUser String
	 * @param registryDate LocalDateTime
	 */
	public DataAudit(String registryUser, MongoLocalDateTime registryDate) {
		super();
		this.registryUser = registryUser;
		this.registryDate = registryDate;
	}

}
