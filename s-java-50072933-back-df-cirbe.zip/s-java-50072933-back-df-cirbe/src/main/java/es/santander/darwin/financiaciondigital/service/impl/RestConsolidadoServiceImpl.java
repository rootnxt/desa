package es.santander.darwin.financiaciondigital.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.santander.darwin.common.annotation.DarwinQualifier;
import es.santander.darwin.financiaciondigital.domain.ConsolidadoResponse;
import es.santander.darwin.financiaciondigital.domain.ListaResumenRequest;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.service.RestConsolidadoService;
import lombok.extern.slf4j.Slf4j;

/** The Constant log. */
@Slf4j
@Service
public class RestConsolidadoServiceImpl implements RestConsolidadoService  {
    
    /** The rest template. */
    @Autowired
    @DarwinQualifier
    private RestTemplate restTemplate;

    /** The json mapper. */
    @Autowired
    private ObjectMapper jsonMapper;
    
    /** The consolidado url. */
    @Value("${restConsolidado.consolidado}")
    private String consolidadoUrl;


    @Override
    public ConsolidadoResponse callConsolidado(ListaResumenRequest request) {
        return callRest(ConsolidadoResponse.class, HttpMethod.POST, consolidadoUrl, request);
    }
    
    /**
     * Call rest.
     *
     * @param <T> the generic type
     * @param responseType the response type
     * @param method the method
     * @param url the url
     * @param request the request
     * @return the t
     */
    private <T> T callRest(Class<T> responseType, HttpMethod method, String url, Object request) {
        log.info("Invoking rest service [" + method + "]: " + url);
        if (null != request) {
            try {
                log.info("cuerpo de solicitud [" + method + " (" + url + ")] : "
                        + jsonMapper.writeValueAsString(request));
            } catch (JsonProcessingException e1) {
                throw new DigitalConsumptionInternalException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                        ExceptionsErrorConstants.ERROR_DETAIL_UNEXPECTED, e1, e1.getMessage());
            }
        }
        HttpHeaders headersAux = new HttpHeaders();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
        headersAux.setContentType(MediaType.APPLICATION_JSON);
        if (null != request) {
            headersAux.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        }
        headersAux.forEach((k, v) -> headers.put(k, v));
        HttpEntity<Object> entity;
        if (null != request) {
            entity = new HttpEntity<>(request, headers);
        } else {
            entity = new HttpEntity<>(headers);
        }

        log.info("Entity " + entity);
        try {
            ResponseEntity<T> response = restTemplate.exchange(url, method, entity, responseType);

            log.info("Response: " + response.getBody());
            return response.getBody();
        } catch (RestClientResponseException e) {
            throw new DigitalConsumptionInternalException(e, "Error restTemplate - RestClientResponseException");

        } catch (Exception ex) {
            log.info("Error conectividad desconocido en " + url);
            throw new DigitalConsumptionInternalException(ex, "Error en llamada Rest");
        }
    }

}
