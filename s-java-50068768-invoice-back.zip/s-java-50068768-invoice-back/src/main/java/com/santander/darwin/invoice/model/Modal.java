package com.santander.darwin.invoice.model;

/**
 * Modal.java
 *
 * @author igndom
 *
 */
public class Modal {

	private String title;
	private String message;
	private String type;

	/**
	 * Constructor
	 */
	public Modal() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param title   String
	 * @param message String
	 * @param type    String
	 */
	public Modal(String title, String message, String type) {
		super();
		this.title = title;
		this.message = message;
		this.type = type;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

}
