package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * PersonInterveners model
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonIntervener {
	
	/** The tipInter. PNE_TIPINTER. */
    private String tipInter;
    
    /** The tipoPers. PNE_TIPOPERS. */
    private String tipoPers;
    
    /** The codPers. PNE_CODPERS. */
    private String codPers;
	
}
