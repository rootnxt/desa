package es.santander.darwin.financiaciondigital.soap.repositories;

public class ProposalRepository {

}
