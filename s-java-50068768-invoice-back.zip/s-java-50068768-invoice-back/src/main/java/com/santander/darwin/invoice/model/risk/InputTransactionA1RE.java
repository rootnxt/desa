package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputTransactionA1RE.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputTransactionA1RE {

	private String anoprop;
	private List<String> asocia;
	private BigDecimal codpers;
	private String idcent;
	private String idempr;
	private String indaviso;
	private String indicada;
	private String indicadb;
	private String indicadc;
	private String indicadd;
	private String indicade;
	private String indicadf;
	private String indicadg;
	private String indicadh;
	private String indreest;
	private BigDecimal numprop;
	private String tipopers;

}
