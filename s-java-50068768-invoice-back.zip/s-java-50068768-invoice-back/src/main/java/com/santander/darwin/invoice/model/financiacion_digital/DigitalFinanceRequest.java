package com.santander.darwin.invoice.model.financiacion_digital;

import java.math.BigDecimal;

/**
 * DigitalFinanceRequest
 * 
 * @author igndom
 *
 */
public class DigitalFinanceRequest {

	private String center;
	private String company;
	private String modificationUser;
	private BigDecimal proposalNumber;
	private int year;
	private String subApplication;

	/**
	 * @return the center
	 */
	public String getCenter() {
		return center;
	}

	/**
	 * @param center the center to set
	 */
	public void setCenter(String center) {
		this.center = center;
	}

	/**
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * @return the modificationUser
	 */
	public String getModificationUser() {
		return modificationUser;
	}

	/**
	 * @param modificationUser the modificationUser to set
	 */
	public void setModificationUser(String modificationUser) {
		this.modificationUser = modificationUser;
	}

	/**
	 * @return the proposalNumber
	 */
	public BigDecimal getProposalNumber() {
		return proposalNumber;
	}

	/**
	 * @param proposalNumber the proposalNumber to set
	 */
	public void setProposalNumber(BigDecimal proposalNumber) {
		this.proposalNumber = proposalNumber;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * @return the subApplication
	 */
	public String getSubApplication() {
		return subApplication;
	}

	/**
	 * @param subApplication the subApplication to set
	 */
	public void setSubApplication(String subApplication) {
		this.subApplication = subApplication;
	}

}
