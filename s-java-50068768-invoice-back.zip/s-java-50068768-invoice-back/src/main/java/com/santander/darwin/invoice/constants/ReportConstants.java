/**
 * 
 */
package com.santander.darwin.invoice.constants;

import lombok.Getter;

/**
 * ReportConstants
 * 
 * @author josdon
 *
 */
public class ReportConstants {

	// Constantes configuracion informe
	public static final String TITLE_SUBJECT = "Informe KPI Financia&Go %s";
	public static final String TITLE_EXCEL = "INFORME FINANCIA&GO %s";
	public static final String NAME_FILE = "report_";
	public static final String EXTENSION_FILE = ".xlsx";
	public static final String SYSTEM_PROPERTY = "user.dir";

	// Titulos de las tablas
	public static final String BY_WEB = "POR %s - WEB";
	public static final String BY_APP = "POR %s - APP";

	// Columna total
	public static final String COLUMN_TOTAL = "TOTAL %s";
	public static final String TYPE_WEB = "WEB";
	public static final String TYPE_APP = "APP";

	// Paginas que contiene el excel
	public static final String PAGE_STATE_PROPOSAL = "ESTADO PROPUESTA";
	public static final String PAGE_STATE = "ESTADO";
	public static final String PAGE_PRODUCT = "PRODUCTO";
	public static final String PAGE_ERROR = "ERROR";

	// Subtitulos de cada app
	public static final String TITLE_PRECONCEDIDO = "Precon";
	public static final String TITLE_ORIENTADO = "Orientado";
	public static final String TITLE_PYMES = "Pymes";

	//Producto por defecto
	public static final String DEFAULT_PRODUCT_NAME = "Sin producto";

	//Columnas definidas
	public static final int NUM_COLUMNS = 3;
	public static final int NUM_COLUMN_NO_PRODUCT = 1;
	public static final int NUM_COLUMN_PRODUCT = 2;
	
	// Commons
	public static final int COMMON_ZERO = 0;
	public static final int COMMON_ONE = 1;
	public static final int COMMON_TWO = 2;
	public static final int COMMON_THREE = 3;

	//Fila en la que se comienza
	public static final int NUM_ROW_INIT_WEB = 6;
	
	// Tipo de device
	public static final String DEVICE_DESKTOP = "desktop";
	public static final String DEVICE_MOBILE = "mobile";
	public static final String DEVICE_TABLET = "tablet";
		
		
	// Producto Refinanciación por defecto
	public static final String PRODUCT_REFIS ="143 152 0000044";
	
	// Listado de estilos 
	 /**
     *  STYLECELLS
     *
     * @return enum
     */
    @Getter
	public enum STYLECELLS {
		HEADER(0), TITLE(1), APP(2), BOTTOM(3), LEFT(4), BOTTOM_RIGHT(5), BOTTOM_LEFT(6), 
		BOLD_BOTTOM(7), TOTAL(8), TOTAL_BOTTOM(9), RIGHT(10);

		private int index;
		// Estilos
		STYLECELLS(int index) {
			this.index = index;
		}
	}
	
	private ReportConstants() {
		throw new IllegalStateException("Utility class");
	}

}
