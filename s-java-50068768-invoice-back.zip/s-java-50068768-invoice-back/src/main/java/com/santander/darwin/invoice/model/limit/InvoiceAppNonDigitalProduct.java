/**
 * 
 */
package com.santander.darwin.invoice.model.limit;

import com.santander.darwin.invoice.model.CommonLangText;
import com.santander.darwin.invoice.model.Product;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;
import java.util.List;

/**
 * The class InvoiceAppNonDigitalProduct
 * @author josdon
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceAppNonDigitalProduct extends Product {

	@Id
	private String id;

	// Descripciones por idiomas
	private List<CommonLangText> description;
	
	// Plazo
	private String range;

	// tags
	private String tags;

	// importe minimo slider
	private BigDecimal min;
	
	private BigDecimal percentManager;
	
	//Typology
	private String typology;
	
	// date last update
	private String dateLastUpdate;

}
