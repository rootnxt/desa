package com.santander.darwin.invoice.model;

/**
 * Model for common text values
 * 
 * @author josdon
 *
 */
public class CommonLangText extends CommonLang {

	// Info text
	private String infoText;
	
	

	/**
	 * Constructor
	 */
	public CommonLangText() {
		super();
	}

	/**
	 * Constructor 
	 * 
	 * @param lang String
	 * @param name String
	 */
	public CommonLangText(String lang, String name) {
		super(lang, name);
	}
	
	/**
	 * Constructor
	 * 
	 * @param lang String
	 * @param name String
	 * @param infoText String
	 */
	public CommonLangText(String lang, String name,String infoText) {
		super(lang, name);
		this.infoText = infoText;
	}

	/**
	 * @return the infoText
	 */
	public String getInfoText() {
		return infoText;
	}

	/**
	 * @param infoText the infoText to set
	 */
	public void setInfoText(String infoText) {
		this.infoText = infoText;
	}
	
	

}
