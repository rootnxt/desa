package com.santander.darwin.invoice.model.pmp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.darwin.invoice.model.Proposal;
import com.santander.darwin.invoice.model.simulation.Disposition;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The Class InputNext.
 */

/**
 * Gets the digital limit.
 *
 * @return the digital limit
 */

/**
 * Gets the interveners.
 *
 * @return the interveners
 */
@Getter

/**
 * Sets the digital limit.
 *
 * @param digitalLimit the new digital limit
 */

/**
 * Sets the interveners.
 *
 * @param interveners the new interveners
 */
@Setter
public class InputNextPmp {
	
    /** The id. */
	private int id;
	
    /** The name. */
    private String name;
    
    /** The description. */
    private String description;
    
    /** The product months. */
    private ProductMonths productMonths;
    
    /** The financing. */
    private Financing financing;
    
    /** The center. */
    private OutputCentro center;
    
    /** The interveners. */
    private List<Interveners> interveners;
    
	/** The fType. */
    @JsonProperty("fType")
    private String fType;

	/** The tType. */
    @JsonProperty("tType")
	private String tType;
	
	/** The tag. */
	private String tag;
	
	/** The proposal pmp. */
	private Proposal proposalPmp;
	
	/** The contractable */
	private boolean contractable;
	
	/** The Disposition. */
    private Disposition disposition;
    
    /** The group. */
	private String group;

}
