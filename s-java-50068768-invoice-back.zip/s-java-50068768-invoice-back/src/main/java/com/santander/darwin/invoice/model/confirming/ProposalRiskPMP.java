package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProposalRisk.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProposalRiskPMP extends ProposalRisk {

	// Version de PRE
	 private ProposalId proposalIdPmp;
}