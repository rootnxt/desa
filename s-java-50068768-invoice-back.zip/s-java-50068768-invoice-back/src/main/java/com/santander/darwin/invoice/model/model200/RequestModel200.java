package com.santander.darwin.invoice.model.model200;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * RequestModel200.java
 *
 * @author igndom
 *
 */
/**
 * @author josdon
 *
 */
public class RequestModel200 {

	//Variable cvs de entrada
	private String cvs;
	//Otros datos de entrada
	private String idEmp;
	private String idMod;
	private String idVer;
	private String idSistPet;
	//Parametros de entrada
	@JsonProperty("urlParams")
	private UrlParams urlParamsObject;
	
	/**
	 * @return the cvs
	 */
	public String getCvs() {
		return cvs;
	}
	/**
	 * @param cvs the cvs to set
	 */
	public void setCvs(String cvs) {
		this.cvs = cvs;
	}
	/**
	 * @return the idEmp
	 */
	public String getIdEmp() {
		return idEmp;
	}
	/**
	 * @param idEmp the idEmp to set
	 */
	public void setIdEmp(String idEmp) {
		this.idEmp = idEmp;
	}
	/**
	 * @return the idMod
	 */
	public String getIdMod() {
		return idMod;
	}
	/**
	 * @param idMod the idMod to set
	 */
	public void setIdMod(String idMod) {
		this.idMod = idMod;
	}
	/**
	 * @return the idVer
	 */
	public String getIdVer() {
		return idVer;
	}
	/**
	 * @param idVer the idVer to set
	 */
	public void setIdVer(String idVer) {
		this.idVer = idVer;
	}
	/**
	 * @return the idSistPet
	 */
	public String getIdSistPet() {
		return idSistPet;
	}
	/**
	 * @param idSistPet the idSistPet to set
	 */
	public void setIdSistPet(String idSistPet) {
		this.idSistPet = idSistPet;
	}
	/**
	 * @return the urlParamsObject
	 */
	public UrlParams getUrlParamsObject() {
		return urlParamsObject;
	}
	/**
	 * @param urlParamsObject the urlParamsObject to set
	 */
	public void setUrlParamsObject(UrlParams urlParamsObject) {
		this.urlParamsObject = urlParamsObject;
	}

}
