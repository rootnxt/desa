package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class HttpConstants.
 *
 * @author everis
 */
public class HttpConstants {

    /** The Constant NOT_FOUND_CODE. */
    public static final int NOT_FOUND_CODE = 404;

    /** The Constant NOT_FOUND_DESC. */
    public static final String NOT_FOUND_DESC = "Recurso no encontrado.";

    /** The Constant BAD_REQUEST_CODE. */
    public static final int BAD_REQUEST_CODE = 400;

    /** The Constant BAD_REQUEST_DESC. */
    public static final String BAD_REQUEST_DESC = "Error en la llamada.";

    /**
     * Instantiates a new http constants.
     */
    private HttpConstants() {
        super();
    }

}
