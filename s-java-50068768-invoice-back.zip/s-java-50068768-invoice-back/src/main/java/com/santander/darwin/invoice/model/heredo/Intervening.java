package com.santander.darwin.invoice.model.heredo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Intervening.
 * 
 * Intervening class.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Intervening {
	
	/** The intervening person type. */
	private String interveningPersonType;
	
	/** The intervening person code. */
	private String interveningPersonCode;
}