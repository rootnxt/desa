package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * GroupsRepresentativesMembersDTO.java
 *
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GroupsRepresentativesMembersDTO {
	
	// personType
	private String personType;
	// personCode
	private String personCode;
	// documentType
	private String documentType;
	// documentCode
	private String documentCode;
	// fullName
	private String fullName;
	// group
	private Integer group;

}
