package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.simulation.ProductExtend;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * InvoiceAppFinality.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceAppFinality {

	@Id
	private String id;
	// Codigo
	private String code;
	// order
	private int order;
	// resaltar
	private boolean highlight;
	// Descripcion
	private List<CommonLangText> des;
	// Id de app
	private String app;
	// Rango
	private String range;
	// Rango proveedor
	private String rangeProvider;
	private List<ProductExtend> product;
	// boolean 
	private boolean activeSmartPricing;
	//Canal
	private String canal;

}
