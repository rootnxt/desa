package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PersonDto.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the person dto request
 */
@Builder

/**
 * Instantiates a new person dto request.
 */
@NoArgsConstructor

/**
 * Instantiates a new person dto request.
 *
 * @param personType the person type
 * @param personCode the person code
 * @param bdeCode the bde code
 * @param bdeDescription the bde description
 */
@AllArgsConstructor
public class PersonDtoRequest {

    /** The person type. */
    private String personType;

    /** The person code. */
    @Size(min = 4, max = 4)
    @NotNull
    /** The person code. */
    private BigDecimal personCode;

    /** The bde code. */
    private String bdeCode;

    /** The bde description. */
    private String bdeDescription;
}
