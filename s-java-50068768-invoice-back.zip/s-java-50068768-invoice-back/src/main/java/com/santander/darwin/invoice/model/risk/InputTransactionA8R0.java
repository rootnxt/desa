package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * InputTransactionA8R0.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputTransactionA8R0 extends TransactionA8R0 {

	private String a1z003;
	private String a6centro;
	private String a8codmon;
	private String a8emploc;
	private String a8estref;
	private Date a8fealta;
	private Date a8fevenc;
	private String a8idcenc;
	private String a8idcent;
	private BigDecimal a8idconc;
	private String a8idempc;
	private String a8idempr;
	private String a8idproc;
	private String a8idprod;
	private String a8idsegm;
	private String a8idstip;
	private BigDecimal a8impapr;
	private String a8locali;
	private BigDecimal a8numpro;
	private String a8sitpre;
	private String a8timest;
	private BigDecimal idcontr8;
	private String indfconv;
	private String opcil;
	private String subgrup;

}
