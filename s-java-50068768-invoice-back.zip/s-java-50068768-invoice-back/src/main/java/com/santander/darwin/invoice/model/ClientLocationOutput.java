package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Devuelve el codigo de persona
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class ClientLocationOutput {
	
	// CodPers
	private List<Integer> codpers = new ArrayList<>();

	// TipoPers
	private List<String> tipopers = new ArrayList<>();

	// Nomper
	private List<String> nomper73 = new ArrayList<>();

	// idemp
	private List<String> idemprpp = new ArrayList<>();
	
}