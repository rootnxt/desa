package com.santander.darwin.invoice.model.be;

/**
 * AltaBEInput
 * 
 * @author josdon
 *
 */
public class AltaBEInput {

    /** The contract. */
    private ContractBE contract;
    
    /** The user. */
    private String user;
    
    /** The services codes. */
    private String[] servicesCodes;

	/**
	 * @return the contract
	 */
	public ContractBE getContract() {
		return contract;
	}

	/**
	 * @param contract the contract to set
	 */
	public void setContract(ContractBE contract) {
		this.contract = contract;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the servicesCodes
	 */
	public String[] getServicesCodes() {
		return servicesCodes.clone();
	}

	/**
	 * @param servicesCodes the servicesCodes to set
	 */
	public void setServicesCodes(String[] servicesCodes) {
		this.servicesCodes = servicesCodes.clone();
	}
    
    

}
