package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * InputTransactionBPBV.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputTransactionBPBV {

	private String ate01;
	private String ate02;
	private String ate03;
	private String ate04;
	private String ate05;
	private String ate06;
	private String ate07;
	private String ate08;
	private String ate09;
	private String ate10;
	private String codco01;
	private String codco02;
	private String codco03;
	private String codco04;
	private String codco05;
	private String codco06;
	private String codco07;
	private String codco08;
	private String codco09;
	private String codco10;
	private String codco11;
	private String codco12;
	private String codco13;
	private String codco14;
	private String codco15;
	private String codco16;
	private String codco17;
	private String codco18;
	private String codco19;
	private String codco20;
	private BigDecimal codpers;
	private String codproa;
	private String codprod;
	private String codsproa;
	private String codsprod;
	private String codvar1;
	private String codvar2;
	private String codvar3;
	private String codvar4;
	private String codvar5;
	private String codvar6;
	private String codvar7;
	private String codvar8;
	private String codvar9;
	private String codvar99;
	private String coestref;
	private String coestre1;
	private String datosva;
	private BigDecimal desdepla;
	private Date fecha;
	private String idemp;
	private String idempr;
	private BigDecimal imporh;
	private String opc;
	private String peticion;
	private String tipopers;

}
