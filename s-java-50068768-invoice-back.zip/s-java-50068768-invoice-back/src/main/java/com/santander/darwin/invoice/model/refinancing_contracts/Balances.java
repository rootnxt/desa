package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Balances.java
 *
 * @author igndom
 *
 */
public class Balances {

	private Capital balance;

	/**
	 * @return the balance
	 */
	public Capital getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(Capital balance) {
		this.balance = balance;
	}
}
