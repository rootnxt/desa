package com.santander.darwin.invoice.model.limit;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the limites.
 *
 * @return the limites
 */
@Getter

/**
 * Sets the limites.
 *
 * @param limites
 *            the new limites
 */
@Setter

/**
 * Instantiates a new resume.
 */
@NoArgsConstructor
@AllArgsConstructor
public class Resume {

    /** The headers. */
    private String[] headers;
    
    /** The limites. */
    private List<ResumeLimit> limites;

    /**
     * Gets the headers.
     *
     * @return the headers
     */
    public String[] getHeaders() {
        return headers.clone();
    }

    /**
     * Sets the headers.
     *
     * @param headers
     *            the new headers
     */
    public void setHeaders(String[] headers) {
        this.headers = headers.clone();
    }

}
