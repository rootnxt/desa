package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FormalizedResponse.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class FormalizedResponse {

	// Variables de retorno
	// Para swagger
	@Schema(example = "00", description = "Code of the return")
	private String codRetorno;
	// Para swagger
	@Schema(example = "S", description = "Indicator of the relaunch")
	private String relanzable;
	// Para swagger
	@Schema(example = "http://invoice.com", description = "URL of document")
	private String url;
	// Para swagger
	@Schema(example = "00", description = "Id of contact")
	private String contractId;

}
