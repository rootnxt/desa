package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.santander.darwin.financiaciondigital.domain.ConsolidadoDto;
import es.santander.darwin.financiaciondigital.domain.ConsolidadoResponse;
import es.santander.darwin.financiaciondigital.domain.ListaRequest;
import es.santander.darwin.financiaciondigital.domain.ListaResumenRequest;
import es.santander.darwin.financiaciondigital.domain.ListaResumenResponse;
import es.santander.darwin.financiaciondigital.domain.Persona;
import es.santander.darwin.financiaciondigital.domain.SummaryImports;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.service.RestConsolidadoService;
import es.santander.darwin.financiaciondigital.util.TestDataUtil;

/**
 * The Class RestConsolidadoServiceImplTest.
 */
public class RestConsolidadoServiceImplTest {

    /** The rest template. */
    @Mock
    private RestTemplate restTemplate;

    /** The json mapper. */
    @Mock
    private ObjectMapper jsonMapper;

    /** The Rest consolidado service. */
    @InjectMocks
    private RestConsolidadoService RestConsolidadoService = new RestConsolidadoServiceImpl();

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Call consolidado test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callConsolidadoTestOK() throws Exception {

        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ListaRequest listaRequest = new ListaRequest();
        listaRequest.setCodigoIdentificacionPers("uwu");
        listaRequest.setFechaDesde("");
        listaRequest.setFechaHasta("");
        listaRequest.setGrupo("");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        listaRequest.setPersona(persona);
        listaResumen.add(listaRequest);
        request.setListaResumen(listaResumen);
        
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("100");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona2 = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona2);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        
        ResponseEntity<?> response = new ResponseEntity<>(consolidadoResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        ReflectionTestUtils.setField(RestConsolidadoService, "consolidadoUrl", "uwu");

        ConsolidadoResponse result = RestConsolidadoService.callConsolidado(request);
        assertNotNull(result);

    }
    
    /**
     * Call consolidado test NOK.
     *
     * @throws Exception the exception
     */
    @Test(expected = Exception.class)
    public void callConsolidadoTestNOK() throws Exception {

        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ListaRequest listaRequest = new ListaRequest();
        listaRequest.setCodigoIdentificacionPers("uwu");
        listaRequest.setFechaDesde("");
        listaRequest.setFechaHasta("");
        listaRequest.setGrupo("");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        listaRequest.setPersona(persona);
        listaResumen.add(listaRequest);
        request.setListaResumen(listaResumen);
        
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("100");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona2 = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona2);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        
        ResponseEntity<?> response = new ResponseEntity<>(consolidadoResponse, HttpStatus.OK);

        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        ReflectionTestUtils.setField(RestConsolidadoService, "consolidadoUrl", "uwu");

        ConsolidadoResponse result = RestConsolidadoService.callConsolidado(any(ListaResumenRequest.class));
        assertNotNull(result);

    }
    
    /**
     * Call consolidado test NOK 2.
     *
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionInternalException.class)
    public void callConsolidadoTestNOK2() throws Exception {

        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ListaRequest listaRequest = new ListaRequest();
        listaRequest.setCodigoIdentificacionPers("uwu");
        listaRequest.setFechaDesde("");
        listaRequest.setFechaHasta("");
        listaRequest.setGrupo("");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        listaRequest.setPersona(persona);
        listaResumen.add(listaRequest);
        request.setListaResumen(listaResumen);
        
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("100");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona2 = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona2);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        
        RestClientResponseException e = new RestClientResponseException("uwu", 01, "uwu01", null, null, null);
        
        doThrow(e).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));

        ReflectionTestUtils.setField(RestConsolidadoService, "consolidadoUrl", "uwu");

        ConsolidadoResponse result = RestConsolidadoService.callConsolidado(request);
        assertNotNull(result);

    }
    
    /**
     * Call consolidado test NOK 3.
     *
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionInternalException.class)
    public void callConsolidadoTestNOK3() throws Exception {

        ListaResumenRequest request = new ListaResumenRequest();
        List<ListaRequest> listaResumen = new ArrayList<>();
        ListaRequest listaRequest = new ListaRequest();
        listaRequest.setCodigoIdentificacionPers("uwu");
        listaRequest.setFechaDesde("");
        listaRequest.setFechaHasta("");
        listaRequest.setGrupo("");
        Persona persona = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        listaRequest.setPersona(persona);
        listaResumen.add(listaRequest);
        request.setListaResumen(listaResumen);
        
        ConsolidadoResponse consolidadoResponse = new ConsolidadoResponse();
        List<ConsolidadoDto> methodResult = new ArrayList<>();
        ConsolidadoDto consolidadoDto = new ConsolidadoDto();
        ArrayList<ListaResumenResponse> listaResumenResponseList = new ArrayList<>();
        ListaResumenResponse listaResumenResponse = new ListaResumenResponse();
        SummaryImports summary = TestDataUtil.fillDummyObject(new SummaryImports());
        listaResumenResponse.setFecha("09-06-2019");
        listaResumenResponse.setIndicadorNuevoAcredit("uwu");
        listaResumenResponse.setCuota(summary);
        listaResumenResponse.setGarantiasFormalesTotal(summary);
        listaResumenResponse.setGarantiasRealesTotal(summary);
        listaResumenResponse.setMorosidadTotal(summary);
        listaResumenResponse.setOtrasEntidades(summary);
        listaResumenResponse.setRestoGrupo(summary);
        listaResumenResponse.setRiesgoIndirectoTotal(summary);
        listaResumenResponse.setSantander(summary);
        listaResumenResponse.setTotal(summary);
        listaResumenResponseList.add(listaResumenResponse);
        consolidadoDto.setListaResumen(listaResumenResponseList);
        consolidadoDto.setCodError("100");
        consolidadoDto.setCodigoIdentificacionPers("123");
        consolidadoDto.setGrupo("grupo");
        consolidadoDto.setMensajeError("uwu");
        Persona persona2 = new Persona();
        persona.setCodigoDePersona("1234");
        persona.setTipoDePersona("J");
        consolidadoDto.setPersona(persona2);
        consolidadoDto.setUltimaFecha("09-06-2019");
        methodResult.add(consolidadoDto);
        consolidadoResponse.setMethodResult(methodResult);
        
        ResponseEntity<?> response = new ResponseEntity<>(consolidadoResponse, HttpStatus.OK);
        
        doReturn(response).when(restTemplate).exchange(any(String.class), any(HttpMethod.class), any(),
                (Class<?>) any(Object.class));
        
        doThrow(JsonParseException.class).when(jsonMapper).writeValueAsString(any(Object.class));

        ReflectionTestUtils.setField(RestConsolidadoService, "consolidadoUrl", "uwu");

        ConsolidadoResponse result = RestConsolidadoService.callConsolidado(request);
        assertNotNull(result);

    }

}
