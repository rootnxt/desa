package com.santander.darwin.invoice.exception.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * AbstractGlobalErrorBean
 * 
 * @author igndom
 *
 */
@Getter
@Setter
public abstract class AbstractGlobalErrorBean implements Serializable {

	// Serial version
	private static final long serialVersionUID = 8528574299613767884L;

	// Para swagger
	@Schema(example = "500", description = "Status of error")
	// Status
	private String status;
	// Para swagger
	@Schema(example = "IVFNGENERICERROR", description = "Code of error")
	// Code
	private String code;
	// Para swagger
	@Schema(example = "184745839292", description = "Timestamp")
	// Timestamp
	private long timestamp;

}
