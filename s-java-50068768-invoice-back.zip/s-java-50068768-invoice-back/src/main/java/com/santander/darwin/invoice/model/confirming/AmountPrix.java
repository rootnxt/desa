package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * AmountPrix.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class AmountPrix {
	// Datos de amount
	private BigDecimal amount;
	private String currency;
}