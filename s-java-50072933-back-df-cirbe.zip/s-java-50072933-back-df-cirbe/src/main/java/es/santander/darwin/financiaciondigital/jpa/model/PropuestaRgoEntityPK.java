package es.santander.darwin.financiaciondigital.jpa.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * The Class PropuestaRgoEntityPK.
 * 
 * 
 */

/**
 * Sets the numprop.
 *
 * @param numprop the new numprop
 */
@Data

/**
 * Builds the.
 *
 * @return the propuesta rgo entity PK
 */
@Builder
@Embeddable

/**
 * Instantiates a new propuesta rgo entity PK.
 */
@NoArgsConstructor

/**
 * Instantiates a new propuesta rgo entity PK.
 *
 * @param idempr the idempr
 * @param idcent the idcent
 * @param anoprop the anoprop
 * @param numprop the numprop
 */
@AllArgsConstructor

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@EqualsAndHashCode(callSuper = false)
public class PropuestaRgoEntityPK extends SerializableParent {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4213520841219852760L;

    /** The idempr. */
    @Column(name = "PNA_IDEMPR")
    private String idempr;

    /** The idcent. */
    @Column(name = "PNA_IDCENT")
    private String idcent;

    /** The anoprop. */
    @Column(name = "PNA_ANOPROP")
    private String anoprop;

    /** The numprop. */
    @Column(name = "PNA_NUMPROP")
    private BigDecimal numprop;

}
