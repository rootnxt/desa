package es.santander.darwin.financiaciondigital.domain;

/**
 * The Class SencolMotorProposalResponse.
 */
public class SencolMotorProposalResponse {

}
