package es.santander.darwin.financiaciondigital.service;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;

/**
 * The Interface CiriteService.
 */
public interface CiriteService {

    /**
     * Call Alta Cirite.
     *
     * @param basicPersonDataRes the request
     * @return the alt modif cirite request response
     * @throws DigitalConsumptionServiceException
     */
    AltModifCiriteRequestResponse callAltaCirite(BasicPersonDataResponseVO basicPersonDataReq)
            throws DigitalConsumptionServiceException;

}