package com.santander.darwin.invoice.model.model200;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Stockholders.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Stockholders {

	// Id for object
	@Schema(example = "77722194L", description = "Number identifier of stockholder")
	private String nif;
	// Name of the object
	@Schema(example = "LUCAS MARTINEZ ALFREDO", description = "Name of stockholder")
	private String stockholderName;
	@Schema(example = "100", description = "Percentage of participation")
	private String participationPercentage;

}
