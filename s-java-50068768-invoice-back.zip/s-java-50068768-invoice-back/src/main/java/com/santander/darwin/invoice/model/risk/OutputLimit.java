package com.santander.darwin.invoice.model.risk;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * OutputLimit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class OutputLimit {

	// Variables

	// Para swagger
	@Schema(example = "S", description = "Ind of campaign")
	@NotNull(message = "INDCAMPAIGN")
	private String indCampaign;

	// Para swagger
	@Schema(example = "OCD001", description = "Code of campaign")
	@NotNull(message = "CODCAMPAIGN")
	private String codCampaign;

	// Para swagger
	@Schema(example = "EUR", description = "Currency of amount")
	@NotNull(message = "CURRENCY")
	private String currency;

	// Para swagger
	@Schema(example = "T05", description = "Triad of fam")
	@NotNull(message = "FAMTRIAD")
	private String famTriad;

	// Para swagger
	@Schema(example = "999999", description = "Max of amount")
	@NotNull(message = "MAXAMOUNT")
	private BigDecimal maxAmount;

	// Para swagger
	@Schema(example = "1", description = "Min of amount")
	@NotNull(message = "MINAMOUNT")
	private BigDecimal minAmount;

	// Para swagger
	@Schema(example = "999999", description = "Limit of amount")
	@NotNull(message = "LIMIT")
	private BigDecimal limit;

	// Para swagger
	@Schema(example = "2", description = "Term of limit")
	@NotNull(message = "TERM")
	private BigDecimal term;

	@Schema( description = "List of oriented")
	private List<Orientado> oriented;

}
