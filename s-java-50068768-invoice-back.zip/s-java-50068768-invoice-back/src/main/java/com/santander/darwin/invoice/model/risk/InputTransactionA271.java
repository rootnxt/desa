package com.santander.darwin.invoice.model.risk;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class InputTransactionA271 {

    //INPUT DATA
    /**
     * Año
     * Partenon unsigned numeric (N) - Length (4,0)
     */
    public BigDecimal aaa;

    /**
     * Codigo centro
     * Partenon unsigned numeric (N) - Length (4,0)
     */
    public BigDecimal ccentro;

    /**
     * Codigo empresa
     * Partenon unsigned numeric (N) - Length (4,0)
     */
    public BigDecimal cempresa;

    /**
     * Codigo numerico
     * Partenon unsigned numeric (N) - Length (5,0)
     */
    public BigDecimal cnumeric;

    /**
     * Descripcion del codigo de moneda
     * Partenon alphanumeric (A) - Length (30)
     */
    public String dcodmone;

    /**
     * Fecha fin
     * Partenon date (D1) - Length (8)
     */
    public Date fechafi;

    /**
     * Indicador de pignoracion
     * Partenon alphanumeric (A) - Length (1)
     */
    public String indpig;

    /**
     * Indicador de la tabla de contratos asociada a este producto
     * Partenon alphanumeric (A) - Length (1)
     */
    public String indtabco;

    /**
     * Oficina de la tarjeta
     * Partenon alphanumeric (A) - Length (4)
     */
    public String oficinat;

    /**
     * Promun
     * Partenon alphanumeric (A) - Length (5)
     */
    public String promun;

    /**
     * Fecha oculta
     * Partenon date (D1) - Length (8)
     */
    public Date zfecha;


}