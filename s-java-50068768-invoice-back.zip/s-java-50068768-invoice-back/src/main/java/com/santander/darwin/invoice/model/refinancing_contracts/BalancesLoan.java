package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * BalancesLoan.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class BalancesLoan {

	//Atributos de capital
	private Capital initialCapital;
	private Capital outstandingCapital;
	//Atributos unpaid
	private Capital unpaidInstallments;
	private Capital totalUnpaidAmount;
	private Capital grpd;
	//Atributos delay
	private Capital delayBalanceUnpaidInstallmentsCurrentYear;
	private Capital delayBalanceUnpaidInstallmentsPreviousYear;
	private Capital postage;
	private Capital dubiousSystemExpenses;

}
