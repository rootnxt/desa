package com.santander.darwin.invoice.model.impresion;


import lombok.Getter;
import lombok.Setter;

/**
 * The language.
 * 
 *
 */
@Getter
@Setter
public class LanguageBean {
    
	/** The language. */
    private String language;
  
    /** The dialect. */
    private String dialect;
}
