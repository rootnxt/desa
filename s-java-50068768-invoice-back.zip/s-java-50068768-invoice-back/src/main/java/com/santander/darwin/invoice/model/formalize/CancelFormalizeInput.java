package com.santander.darwin.invoice.model.formalize;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * CancelFormalizeInput class
 * 
 *
 */
@Getter
@Setter
@Builder
public class CancelFormalizeInput implements Serializable {

	/**serial version uid*/
    private static final long serialVersionUID = 1L;

    /** The proposal */
    private Proposal proposal;

    /** The indTipoFirma */
    private String indTipoFirma;



}
