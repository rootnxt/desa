package com.santander.darwin.invoice.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.santander.darwin.invoice.converter.DateToMongoLocalDateTimeConverter;
import com.santander.darwin.invoice.converter.MongoLocalDateTimeToStringConverter;
import com.santander.darwin.invoice.converter.StringToMongoLocalDateTimeConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;

import java.util.ArrayList;
import java.util.List;

/**
 * MongoConfiguration
 * 
 * @author igndom
 *
 */
@Configuration
public class MongoConfiguration extends AbstractMongoClientConfiguration {

	@Value("${spring.data.mongodb.uri}")
	private String uri;
	@Value("${spring.data.mongodb.database}")
	private String database;

	@Override
	public MongoClient mongoClient() {
		// Creamos el cliente con la uri
		return MongoClients.create(uri);
	}

	@Override
	protected String getDatabaseName() {
		// Retornamos el nombre de la base de datos
		return database;
	}

	@Override
	public MongoCustomConversions customConversions() {
		// Creamos una lista de convertidores
		List<Converter<?, ?>> converters = new ArrayList<>();
		// Añadimos de date a mongo
		converters.add(new DateToMongoLocalDateTimeConverter());
		// Añadimos de mongo a string
		converters.add(new MongoLocalDateTimeToStringConverter());
		// Añadimos de string a mongo
		converters.add(new StringToMongoLocalDateTimeConverter());
		// Retornamos los convertidores custom
		return new MongoCustomConversions(converters);
	}

}
