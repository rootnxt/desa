package com.santander.darwin.invoice.model.crisol;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * End.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CrisolPricesInput extends CrisolPricesInputBase{ 
	
	// Tipo de operacion
	private String operationType; 
	private String referenceRate; 
	private String paybackPeriodCode; 
	private String amortizationTypeCode; 
	// Fecha de formalizacion
	private String formalizationDate; 
	
	// Otros datos fijos
	private String multiproductInd; 
	private BigDecimal averageRemittanceTerm;
	private String currencyCode; 
	
	// Mas valores
	private String factoringAssignmentInd; 
	private String debtRestructuring; 
	private String renewalFormalizationDate; 
	private String interestGracePeriod; 
	private String renewalIndicator;
	private BigDecimal factoringMinimumAssignmentCommission;
	private BigDecimal averageLevelUse;
	// Importe de la transaccion
	private BigDecimal transactionAmount;
	
	// Plazo de la transacciones
	private BigDecimal transactionTerm;
	private BigDecimal renewalOperationAmount;	
	private String renewalOperationTerm; 

}
