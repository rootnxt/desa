package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.aggregation.Aggregation;
import com.santander.darwin.invoice.model.confirming.MnemoContracts;
import com.santander.darwin.invoice.model.modelaeat.ModelAeat;
import com.santander.darwin.invoice.model.pmp.IntervenersPMPSelected;
import com.santander.darwin.invoice.model.refinancing_contracts.InvoiceRefinancingContracts;
import com.santander.darwin.invoice.model.simulation.Financing;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * InvoiceFinancingConfirming.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class InvoiceFinancingConfirming extends Financing {

	// Contratos refinanciacion version 3
	private InvoiceRefinancingContracts contracts;
	// Listado de apoderados
	private List<Person> representatives;
	// Documento buzon empresas
	private String gnIdEmpresas;
	// Documento buzon particulares
	private String gnIdParticulares;
	// Tipo de dispositivo
	private String device;
	// Confirming
	private Confirming confirming;
	// Combinacion de firmantes
	private BastanteoSigner signers;
	// Mnemos y contratos Confirming
	private MnemoContracts mnemosContracts;
	// PSD2 Agregador
	private Aggregation aggregation;
    // Datos del modelo 303, 347 y 390.
    private ModelAeat modelAeat;
    // Codigo segmentacion
    private String codseg;
    private String dessegas;
    // flag de transfertooffice
    private boolean transferToOffice;
	// Propuesta padre
	private Proposal proposalParent;
	// Intervinientes seleccionados
	private List<IntervenersPMPSelected> interveners;
	// boolean contractable - PMP MVP2 -> true
	private boolean contractable;
	// indicador PMP. Se usa de entrada para la generacion de documentos. Para
	// validaciones se usa el contractable
	private String indicadorPMP;
	/** The maxContract. */
    private String maxContract;
    /** The maxDraft. */
    private String maxDraft;
    /** The centerSelected. */
    private String centerSelected;
    /** The group. */
    private String group;
	private String app;
	//Idioma Dialecto
	private String langStandard;
	// Mensaje error funcionamiento app
	private String msgBackNavigation;

	// Mock para redirigir.
	private String systemDecision;
	private String groupDecision;
	private String stateFindVariable;
    // Plazo Maximo
	private Integer pmg;
}