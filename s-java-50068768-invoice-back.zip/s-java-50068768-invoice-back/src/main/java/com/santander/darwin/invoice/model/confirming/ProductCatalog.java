package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProductCatalog.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProductCatalog {
	// Datos de ProductCatalog
	private String productType;
	private String subProductType;
	private String standardOfReference;
}