package es.santander.darwin.financiaciondigital.lib.model;

import java.util.List;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class ProposalPersonRequests.
 */

/**
 * Sets the modification user.
 *
 * @param modificationUser the new modification user
 */
@Data

/**
 * Builds the.
 *
 * @return the proposal person requests
 */
@Builder

/**
 * Instantiates a new proposal person requests.
 */
@NoArgsConstructor

/**
 * Instantiates a new proposal person requests.
 *
 * @param Id                      the id
 * @param requestPersonIdentifier the request person identifier
 * @param sourceState             the source state
 * @param criticalityData         the criticality data
 * @param processIndicator        the process indicator
 * @param interventionType        the intervention type
 * @param admissionDate           the admission date
 * @param modificationDate        the modification date
 * @param modificationUser        the modification user
 */
@AllArgsConstructor

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@EqualsAndHashCode(callSuper = false)
public class Application {

	/** The Id. */
	@Id
	private String Id;

	private List<String> safeDomainList;

}
