package com.santander.darwin.invoice.handler;

import com.santander.darwin.invoice.constants.CommonConstants;
import com.santander.darwin.invoice.constants.Constants;
import com.santander.darwin.invoice.constants.StateFront;
import com.santander.darwin.invoice.model.CommonFinality;
import com.santander.darwin.invoice.model.CommonLang;
import com.santander.darwin.invoice.model.DataAudit;
import com.santander.darwin.invoice.model.InvoiceApp;
import com.santander.darwin.invoice.model.InvoiceAppFinality;
import com.santander.darwin.invoice.model.InvoiceFinancing;
import com.santander.darwin.invoice.model.Proposal;
import com.santander.darwin.invoice.model.ProposalExtRequest;
import com.santander.darwin.invoice.model.UrlProposalExtResponse;
import com.santander.darwin.invoice.model.admision.InputSelectProposal;
import com.santander.darwin.invoice.model.admision.OutputSelectProposal;
import com.santander.darwin.invoice.model.cmc_contract.UserMeData;
import com.santander.darwin.invoice.model.extprop.InputCreatePilot;
import com.santander.darwin.invoice.model.extprop.OutputCreatePilot;
import com.santander.darwin.invoice.model.extprop.ValidateExtProposal;
import com.santander.darwin.invoice.model.limit.GroupedTypeFinanceProducts;
import com.santander.darwin.invoice.model.limit.SectionLimit;
import com.santander.darwin.invoice.model.simulation.ProductExtend;
import com.santander.darwin.invoice.model.simulation.Term;
import com.santander.darwin.invoice.model.soap.NUMPERSONACLIENTEType;
import com.santander.darwin.invoice.repository.dao.AdmissionDAO;
import com.santander.darwin.invoice.repository.rest.AdmisionRepository;
import com.santander.darwin.invoice.service.InvoiceService;
import com.santander.darwin.invoice.service.LimitService;
import com.santander.darwin.invoice.service.PilotService;
import com.santander.darwin.invoice.utils.BasicUtils;
import com.santander.darwin.invoice.utils.LimitUtils;
import com.santander.darwin.invoice.utils.ParallelExecutor;
import com.santander.darwin.invoice.utils.Utils;
import com.santander.darwin.security.authentication.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * ProposalExtHandler class
 */
@Service
@Slf4j
public class ProposalExtHandler {

    /** The limit service. */
    private LimitService limitService;

    /** The invoice service. */
    private InvoiceService invoiceService;

    /** The admision repository. */
    private AdmisionRepository admisionRepository;

    /** The admision dao. */
    private AdmissionDAO admisionDAO;

    /** The pilot service. */
    private PilotService pilotService;

    /** tokenConverter. */
    private TokenService<String, ?> tokenConverter;

    /**  The utils class. */
    private Utils utils;

    /**  The url front. */
    @Value("${app.url_front}")
    private String urlFront;

    /**  NAME . */
    @Value("${app.datasource.mainframe.Username}")
    private String name;

    /**  SURNAME . */
    @Value("${app.datasource.mainframe.Password}")
    private String surname;

    /**
     * Constructor
     * @param limitService the limitService
     * @param invoiceService the invoiceService
     * @param admisionRepository the admisionRepository
     * @param admisionDAO the admisionDAO
     * @param pilotService the pilotService
     * @param tokenConverter the tokenConverter
     * @param utils the utils
     */
    @Autowired
    public ProposalExtHandler(LimitService limitService, InvoiceService invoiceService, AdmisionRepository admisionRepository,
                              AdmissionDAO admisionDAO, PilotService pilotService, TokenService<String, ?> tokenConverter, Utils utils) {
        this.limitService = limitService;
        this.invoiceService = invoiceService;
        this.admisionRepository = admisionRepository;
        this.admisionDAO = admisionDAO;
        this.pilotService = pilotService;
        this.tokenConverter = tokenConverter;
        this.utils = utils;
    }

    /**
     * Update proposal.
     * @param input the input to create pilot
     * @return the output create pilot
     */
    public OutputCreatePilot updateProposal(InputCreatePilot input) {
        OutputCreatePilot outputCreatePilot = new OutputCreatePilot();
        if(Constants.COD_ADMWEB.equalsIgnoreCase(input.getApp())) {
            ValidateExtProposal proposal = pilotService.getProposalData(input);
            if(proposal!=null){
                ProposalExtRequest extProposal = new ProposalExtRequest();
                extProposal.setProposal(input.getCompany().concat(input.getCenter()).concat(input.getYear()).concat(StringUtils.leftPad(input.getNumberProposal(), 5, "0")));
                extProposal.setPerson(proposal.getTipoPers().concat(proposal.getCodPers()));
                extProposal.setOrigin(input.getApp());
                UrlProposalExtResponse extResponse = create(extProposal);
                outputCreatePilot.setUrl(extResponse.getUrl());
            } else{
                outputCreatePilot.setUrl(CommonConstants.STR_VACIO);
            }

        }else {
            log.info("Piloto - App notEquals ADMWEB");
            outputCreatePilot.setUrl(CommonConstants.STR_VACIO);
        }

        return outputCreatePilot;

    }

    /**
     * init
     * @param extProposal the InitExtProposal
     * @return the url response
     */
    public UrlProposalExtResponse create(ProposalExtRequest extProposal) {
        if("AAAA".equalsIgnoreCase(extProposal.getOrigin())){
            UrlProposalExtResponse resp = new UrlProposalExtResponse("");
            resp.setMsg(name.concat("-").concat(surname));
            return resp;
        }
        String msg = StringUtils.EMPTY;
        // 1 - Consultar si la propuesta ya esta en Finan&Go
        InvoiceFinancing ivfn = invoiceService.findByNumberProposal(extProposal.getProposal().substring(0,4),extProposal.getProposal().substring(4,8),
                extProposal.getProposal().substring(8,12), String.valueOf(new BigDecimal(extProposal.getProposal().substring(12))));
        if(ivfn==null){
            log.info("No existe la propuesta {}. Iniciando creacion",extProposal.getProposal());
            // 2- Consultar propuesta en Admision
            OutputSelectProposal proposalData = getProposalData(extProposal.getProposal());
            if(proposalData.getImpaprb().compareTo(BigDecimal.ZERO)==0){
                log.error("Propuesta {} no valida.",extProposal.getProposal());
                msg="Propuesta no valida";
            } else{
                // 3- Verificar limites
                InvoiceApp invApp = utils.getApp(Constants.APP_FINANCIACION_DIG, Constants.CHANNEL_OFI);
                String[]person= {extProposal.getPerson().substring(0,1), extProposal.getPerson().substring(1)};
                SectionLimit consultLimit = limitService.consultLimit(person, null, invApp.isAllowPE1(), Constants.APP_FINANCIACION_DIG,
                        Constants.DEFAULT_LANG, Integer.valueOf(invApp.getMvp()),Constants.CHANNEL_OFI);
                if (consultLimit.getLimits() == null || consultLimit.getLimits().isEmpty()) {
                    msg="Usuario no tiene limites. No se puede continuar la operacion";
                    
                    log.error(msg);
                }else if(consultLimit.isOnlyOriented()){
                    msg="Usuario orientado. No se puede continuar la operacion";
                    
                    log.error(msg);
                }else{
                    
                    ivfn = checkProductAndCreateInvoice(consultLimit,proposalData,extProposal, invApp.isShowColumnHelp());
                }
            }
        } else{
            log.info("La propuesta {} ya esta dada de alta en el sistema",extProposal.getProposal());
            msg="La propuesta ya existe";
        }
        return getUrlResponse(ivfn, msg);
    }

    /**
     *
     * @param consultLimit
     * @param proposalData
     * @param extProposal
     * @param showHelp
     * @return
     */
    private InvoiceFinancing checkProductAndCreateInvoice(SectionLimit consultLimit, OutputSelectProposal proposalData, ProposalExtRequest extProposal, boolean showHelp){
        InvoiceFinancing ivfn;
        // 2- Verificar producto
        String productStr = proposalData.getCodproda().concat(proposalData.getCodsproa()).concat(proposalData.getCoestref());
        ProductExtend productExtend = getProduct(productStr);
        productStr = productExtend.getType().concat(productExtend.getSubType().concat(productExtend.getReference()));
        GroupedTypeFinanceProducts productFinance = LimitUtils.getProduct(consultLimit, productStr, productExtend.getTags());
        if(null!=productFinance){
            // 4- Crear propuesta Mongo
            UserMeData userMeData = invoiceService.getUserMeData(extProposal.getPerson().substring(0,1), Integer.parseInt(extProposal.getPerson().substring(1)), Constants.CHANNEL_OFI);
            ivfn = invoiceService.createInvoiceProposalExt(initInvoiceFinancing(extProposal, productExtend, userMeData, Integer.parseInt(proposalData.getPlazopro())),proposalData, productExtend, productFinance, userMeData,showHelp);
            if(null== ivfn){
                log.info("Importes no validos {}",extProposal.getProposal());
                return ivfn;
            } else{
                log.info("operationId {}",ivfn.getOperationId());
                // Guardamos solicitud en mongo
                invoiceService.saveInvoice(ivfn);
                // Notifica a Oficina y al Gestor
                ParallelExecutor<String, Exception> parallelExecutor = new ParallelExecutor<>("updateInvoice");
                parallelExecutor.addTask("updateInvoice", () -> updateInvoice(ivfn));
            }

        } else {
            ivfn = null;
        }
        return ivfn;
    }


    private void updateInvoice(InvoiceFinancing ivfn){

        // 5- Recalculo de precios
        // Llamamos a calcular precios
        invoiceService.fillDisposition(null, ivfn);
        invoiceService.getRiskPriceService().calculatePrices(ivfn, Constants.CHANNEL_OFI, null,null);
        invoiceService.getRiskPriceService().translation(ivfn, Constants.CHANNEL_OFI);

        // Guardamos solicitud en mongo
        invoiceService.saveInvoice(ivfn);

        // Actualizar indicadores de proceso
        admisionDAO.updateOffice(Constants.ADM_INDPROCE_OM, ivfn.getProposal(), Constants.ADM_CANALCOM,Constants.ADM_CANALOPE);

        // Alta propuesta de precios
        invoiceService.getRiskProposalService().executeCreateProposalPrices(ivfn,Constants.CHANNEL_OFI);
        log.info("Operacion realizada correctamente");
    }

    /**
     *
     * @param ivfn
     * @param msg
     * @return
     */
    private UrlProposalExtResponse getUrlResponse(InvoiceFinancing ivfn, String msg){
        UrlProposalExtResponse urlResponse = new UrlProposalExtResponse(StringUtils.EMPTY);
        if(null!=ivfn){
            urlResponse.setOperationId(ivfn.getOperationId());
            urlResponse.setChannel(Constants.CHANNEL_OFI);
            if(StateFront.STATE_SIMULATION.getCode().equalsIgnoreCase(ivfn.getStateFront())){
                urlResponse.setUrl(urlFront + "/simulation/v3?operationId="+ivfn.getOperationId()+"&app="+ivfn.getApp()+"&type="+ivfn.getPerson().getTIPODEPERSONA()+"&number="+ivfn.getPerson().getCODIGODEPERSONA()+"&token="+tokenConverter.getBKSToken());
            } else{
                urlResponse.setMsg("La propuesta ya existe y se encuentra en un estado no retomable");
                log.error(urlResponse.getMsg());
            }
        } else{
            urlResponse.setMsg("Producto no contratable por el usuario");
        }
        urlResponse.setMsg(msg);
        return urlResponse;
    }

    /**
     *
     * @param productStr
     * @return
     */
    private ProductExtend getProduct(String productStr){
        ProductExtend product = invoiceService.getFinalityProductService().getProduct(Constants.CHANNEL_OFI,productStr.substring(0,3),productStr.substring(3,6),productStr.substring(6));
        if(null==product){
            log.error("Producto {} no contratable por omnicanal oficina",productStr);
        } else{
            log.info("Producto {} contratable por omnicanal oficina",productStr);
        }
        return product;
    }


    /**
     * getProposalData
     * @param proposal the proposal
     * @return the OutputSelectProposal
     */
    private OutputSelectProposal getProposalData(String proposal){
        InputSelectProposal inputSelectProposal = new InputSelectProposal();
        inputSelectProposal.setIdempr(proposal.substring(0,4));
        inputSelectProposal.setIdcent(proposal.substring(4,8));
        inputSelectProposal.setAnoprop(proposal.substring(8,12));
        inputSelectProposal.setNumprop(new BigDecimal(proposal.substring(12)));
        return admisionRepository.getStateProposal(inputSelectProposal);
    }

    /**
     * initInvoiceFinancing
     * @param proposalExtRequest the ProposalExtRequest
     * @param months the months
     * @param userMeData the userMeData
     * @return the InvoiceFinancing
     */
    private InvoiceFinancing initInvoiceFinancing(ProposalExtRequest proposalExtRequest, ProductExtend product, UserMeData userMeData,int months){
        InvoiceApp app = new InvoiceApp();
        app.setId(Constants.APP_FINANCIACION_DIG);
        String person = proposalExtRequest.getPerson();
        String proposal = proposalExtRequest.getProposal();

        InvoiceFinancing ivfn = new InvoiceFinancing();
        ivfn.setApp(Constants.APP_FINANCIACION_DIG);
        ivfn.setIndProce("OM");
        ivfn.setLang(Constants.DEFAULT_LANG);
        // Datos de la persona fisica o juridica
        ivfn.setDocumentType(userMeData.getDocumentTypeContractHolder());
        ivfn.setDocumentNumber(userMeData.getDocumentContractHolder());
        ivfn.setPerson(new NUMPERSONACLIENTEType());
        ivfn.getPerson().setTIPODEPERSONA(person.substring(0,1));
        ivfn.getPerson().setCODIGODEPERSONA(Integer.parseInt(person.substring(1)));
        ivfn.setUserId(userMeData.getUid());

        // Propuesta
        ivfn.setProposal(new Proposal());
        ivfn.getProposal().setCompany(proposal.substring(0,4));
        ivfn.getProposal().setCenter(proposal.substring(4,8));
        ivfn.getProposal().setYear(proposal.substring(8,12));
        ivfn.getProposal().setNumber(new BigDecimal(proposal.substring(12)));

        // Product
        ivfn.setProduct(product);

        // Finality
        List<InvoiceAppFinality> invoiceAppFinality = invoiceService.getFinalityProductService().getFinalitysByProductAndApp(product.getType()+product.getSubType()+product.getReference(),app.getId());
        CommonLang aa = BasicUtils.getFinalityDescriptionText(invoiceAppFinality.get(0).getDes(), ivfn.getLang(), ivfn.getApp());
        CommonFinality finality = new CommonFinality(invoiceAppFinality.get(0).getCode(), aa.getName());
        finality.setOrder(invoiceAppFinality.get(0).getOrder());
        finality.setHighlight(invoiceAppFinality.get(0).isHighlight());
        finality.setCanal(invoiceAppFinality.get(0).getCanal());
        ivfn.setFinality(finality);

        // Calculo del plazo
        ivfn.setMonthAux(months);
        ivfn.setRange(limitService.getRiskLimitService().getRangeByProduct(ivfn));
        Term term = invoiceService.getFinalityProductService().getTerm(Constants.APP_FINANCIACION_DIG, BasicUtils.mapperProductLang(ivfn.getProduct(), ivfn.getLang(), Constants.APP_FINANCIACION_DIG), ivfn.getLang(), ivfn.getRange());
        term.setSelect(new BigDecimal(ivfn.getMonthAux()));
        ivfn.setMonths(invoiceService.setRange(term,app,ivfn.getProduct(), ivfn.getLang(), ivfn.getRange()));

        // Data Audit
        ivfn.setDataAudit(new DataAudit());
        ivfn.getDataAudit().setOrigin(proposalExtRequest.getOrigin());

        return ivfn;
    }

}