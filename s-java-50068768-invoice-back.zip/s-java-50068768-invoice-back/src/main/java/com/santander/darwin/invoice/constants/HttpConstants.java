package com.santander.darwin.invoice.constants;

/**
 * The Class HttpConstants.
 *
 */
public class HttpConstants {
	
	/** Cabecera X-ClientId */
	 public static final String HEADER_XCLIENTID = "X-ClientId";
	 
	 public static final String HEADER_XCLIENTID_DESC = "finfact";
	
	/** The Constant NOT_FOUND_CODE. */
    public static final String OK = "200";
    
    public static final String OK_DESC = "OK";
    
    /** The Constant UNAUTHORIZED_CODE. */
    public static final String UNAUTHORIZED_CODE = "401";

    /** The Constant UNAUTHORIZED_DESC. */
    public static final String UNAUTHORIZED_DESC = "Unauthorized";

    /** The Constant NOT_FOUND_CODE. */
    public static final String NOT_FOUND_CODE = "404";

    /** The Constant NOT_FOUND_DESC. */
    public static final String NOT_FOUND_DESC = "Resource not found";

    /** The Constant BAD_REQUEST_CODE. */
    public static final String BAD_REQUEST_CODE = "400";

    /** The Constant BAD_REQUEST_DESC. */
    public static final String BAD_REQUEST_DESC = "Bad Request";
    
    /** The Constant INTERNAL_SERVER_CODE. */
    public static final String INTERNAL_SERVER_CODE = "500";

    /** The Constant INTERNAL_SERVER_DESC. */
    public static final String INTERNAL_SERVER_DESC = "Internal Server Error";

    /** The Constant NO_CONTENT_CODE. */
    public static final String NO_CONTENT_CODE = "204";

    /** The Constant NO_CONTENT_DESC. */
    public static final String NO_CONTENT_DESC = "No Content";

    /**
     * Instantiates a new http constants.
     */
    private HttpConstants() {
    	throw new IllegalStateException("Utility class");
    }

}
