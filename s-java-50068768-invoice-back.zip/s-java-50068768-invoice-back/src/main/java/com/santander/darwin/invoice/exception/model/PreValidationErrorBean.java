package com.santander.darwin.invoice.exception.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PreValidationErrorBean.java
 *
 * @author igndom
 *
 */
public class PreValidationErrorBean extends AbstractGlobalErrorBean {

	private static final long serialVersionUID = 5023507378050474072L;

	private String shortMessage;
	@JsonProperty("DetailedMessage")
	private String detailedMessage;

	/**
	 * @return the shortMessage
	 */
	public String getShortMessage() {
		return shortMessage;
	}

	/**
	 * @param shortMessage the shortMessage to set
	 */
	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}

	/**
	 * @return the detailedMessage
	 */
	public String getDetailedMessage() {
		return detailedMessage;
	}

	/**
	 * @param detailedMessage the detailedMessage to set
	 */
	public void setDetailedMessage(String detailedMessage) {
		this.detailedMessage = detailedMessage;
	}

}
