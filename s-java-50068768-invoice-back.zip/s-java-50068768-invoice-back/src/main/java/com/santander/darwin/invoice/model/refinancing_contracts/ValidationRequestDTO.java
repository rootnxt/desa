/**
 * 
 */
package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * ValidationRequestDTO
 * @author josdon
 *
 */
public class ValidationRequestDTO {
	
	private A1REO4RequestDTO a1REO4RequestDto;
	private A1REOFRequestDTO a1REOFRequestDto;
	private CommonDataDTO commonData;
	/**
	 * @return the a1REO4RequestDto
	 */
	public A1REO4RequestDTO getA1REO4RequestDto() {
		return a1REO4RequestDto;
	}
	/**
	 * @param a1reo4RequestDto the a1REO4RequestDto to set
	 */
	public void setA1REO4RequestDto(A1REO4RequestDTO a1reo4RequestDto) {
		a1REO4RequestDto = a1reo4RequestDto;
	}
	/**
	 * @return the a1REOFRequestDto
	 */
	public A1REOFRequestDTO getA1REOFRequestDto() {
		return a1REOFRequestDto;
	}
	/**
	 * @param a1reofRequestDto the a1REOFRequestDto to set
	 */
	public void setA1REOFRequestDto(A1REOFRequestDTO a1reofRequestDto) {
		a1REOFRequestDto = a1reofRequestDto;
	}
	/**
	 * @return the commonData
	 */
	public CommonDataDTO getCommonData() {
		return commonData;
	}
	/**
	 * @param commonData the commonData to set
	 */
	public void setCommonData(CommonDataDTO commonData) {
		this.commonData = commonData;
	}
	
	

}
