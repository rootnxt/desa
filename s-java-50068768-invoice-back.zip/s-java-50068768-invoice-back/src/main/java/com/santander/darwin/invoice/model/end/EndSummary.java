package com.santander.darwin.invoice.model.end;

import com.santander.darwin.invoice.model.pmp.DatosCentro;
import com.santander.darwin.invoice.model.pmp.FindAdnOutput;
import com.santander.darwin.invoice.model.pmp.IntervenersPMPSelected;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * End.java
 *
 * @author igndom
 *
 */

/**
 * Gets the center.
 *
 * @return the center
 */
@Getter

/**
 * Sets the center.
 *
 * @param center the new center
 */
@Setter
public class EndSummary{

   /** The product. */
   private FindAdnOutput product;
    
	/** The interveners. */
	private List<IntervenersPMPSelected> interveners;
	
	/** The center. */
	private DatosCentro center;
}
