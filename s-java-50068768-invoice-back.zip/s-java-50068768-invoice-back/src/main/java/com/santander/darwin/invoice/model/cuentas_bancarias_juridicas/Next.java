package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

/**
 * Next
 * 
 * @author igndom
 *
 */
public class Next {

	private String href;

	/**
	 * @return the href
	 */
	public String getHref() {
		return href;
	}

	/**
	 * @param href the href to set
	 */
	public void setHref(String href) {
		this.href = href;
	}

}
