package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * OutputTransactionA1GG.java
 *
 * @author igndom
 *
 */
public class OutputTransactionA1GG {

	private List<String> cfamilia;
	private String codcampf;
	private List<String> codcam4p;
	private List<String> descamp;
	private List<String> empresal;
	private String empresar;
	private String fmts;
	private List<BigDecimal> implimi3;
	private List<BigDecimal> jfactor1;
	private List<String> moneda;
	private List<String> tipcamp;

	/**
	 * @return the cfamilia
	 */
	public List<String> getCfamilia() {
		return cfamilia;
	}

	/**
	 * @param cfamilia the cfamilia to set
	 */
	public void setCfamilia(List<String> cfamilia) {
		this.cfamilia = cfamilia;
	}

	/**
	 * @return the codcampf
	 */
	public String getCodcampf() {
		return codcampf;
	}

	/**
	 * @param codcampf the codcampf to set
	 */
	public void setCodcampf(String codcampf) {
		this.codcampf = codcampf;
	}

	/**
	 * @return the codcam4p
	 */
	public List<String> getCodcam4p() {
		return codcam4p;
	}

	/**
	 * @param codcam4p the codcam4p to set
	 */
	public void setCodcam4p(List<String> codcam4p) {
		this.codcam4p = codcam4p;
	}

	/**
	 * @return the descamp
	 */
	public List<String> getDescamp() {
		return descamp;
	}

	/**
	 * @param descamp the descamp to set
	 */
	public void setDescamp(List<String> descamp) {
		this.descamp = descamp;
	}

	/**
	 * @return the empresal
	 */
	public List<String> getEmpresal() {
		return empresal;
	}

	/**
	 * @param empresal the empresal to set
	 */
	public void setEmpresal(List<String> empresal) {
		this.empresal = empresal;
	}

	/**
	 * @return the empresar
	 */
	public String getEmpresar() {
		return empresar;
	}

	/**
	 * @param empresar the empresar to set
	 */
	public void setEmpresar(String empresar) {
		this.empresar = empresar;
	}

	/**
	 * @return the fmts
	 */
	public String getFmts() {
		return fmts;
	}

	/**
	 * @param fmts the fmts to set
	 */
	public void setFmts(String fmts) {
		this.fmts = fmts;
	}

	/**
	 * @return the implimi3
	 */
	public List<BigDecimal> getImplimi3() {
		return implimi3;
	}

	/**
	 * @param implimi3 the implimi3 to set
	 */
	public void setImplimi3(List<BigDecimal> implimi3) {
		this.implimi3 = implimi3;
	}

	/**
	 * @return the jfactor1
	 */
	public List<BigDecimal> getJfactor1() {
		return jfactor1;
	}

	/**
	 * @param jfactor1 the jfactor1 to set
	 */
	public void setJfactor1(List<BigDecimal> jfactor1) {
		this.jfactor1 = jfactor1;
	}

	/**
	 * @return the moneda
	 */
	public List<String> getMoneda() {
		return moneda;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(List<String> moneda) {
		this.moneda = moneda;
	}

	/**
	 * @return the tipcamp
	 */
	public List<String> getTipcamp() {
		return tipcamp;
	}

	/**
	 * @param tipcamp the tipcamp to set
	 */
	public void setTipcamp(List<String> tipcamp) {
		this.tipcamp = tipcamp;
	}

}