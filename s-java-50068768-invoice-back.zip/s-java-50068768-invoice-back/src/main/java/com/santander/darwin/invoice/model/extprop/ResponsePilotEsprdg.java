package com.santander.darwin.invoice.model.extprop;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * InputConsultProposal.
 *
 * @author seresc
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
//Schema clase
// Comentarios
// Example
// Evitar sonar
public class ResponsePilotEsprdg {

    /** The center. */
    private Boolean response;

    
}
