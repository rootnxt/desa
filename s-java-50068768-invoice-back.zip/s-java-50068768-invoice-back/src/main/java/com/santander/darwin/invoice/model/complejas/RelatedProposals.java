package com.santander.darwin.invoice.model.complejas;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Gets the level.
 *
 * @return the level
 */

/**
 * Gets the proposals status S.
 *
 * @return the proposals status S
 */
@Getter

/**
 * Sets the level.
 *
 * @param level the new level
 */

/**
 * Sets the proposals status S.
 *
 * @param proposalsStatusS the new proposals status S
 */
@Setter
public class RelatedProposals {
    
    /** The proposalRoot. */
    private OutputDataPmp proposalRoot;
    
    /** The proposalsStatusS. */
    private List<OutputDataPmp> proposalsStatusS;
}
