package com.santander.darwin.invoice.model.risk;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * InputLimit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
@Builder
@AllArgsConstructor
public class InputLimit {

	// Variables

	// Para swagger
	@Schema(example = "J", description = "Type of person")
	@NotNull(message = "PERSONTYPE")
	private String personType;

	// Para swagger
	@Schema(example = "120", description = "Number of person")
	@NotNull(message = "PERSONNUMBER")
	private String personNumber;

	// Para swagger
	@Schema(example = "143", description = "Type of product")
	@NotNull(message = "TYPE")
	private String type;

	// Para swagger
	@Schema(example = "152", description = "Subtype of product")
	@NotNull(message = "SUBTYPE")
	private String subType;

	// Para swagger
	@Schema(example = "000007", description = "Reference of product")
	@NotNull(message = "REFERENCESTANDARD")
	private String referenceStandard;

	// Para swagger
	@Schema(example = "0049", description = "Company of product")
	@NotNull(message = "COMPANY")
	private String company;

	// Para swagger
	@Schema(example = "OCD001", description = "Campaign of product")
	private String campaign;

	// Para swagger
	@Schema(example = "T05", description = "Family of product")
	private String family;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}
