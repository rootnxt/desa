package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * BalancesCredit.java
 *
 * @author igndom
 *
 */
public class BalancesCredit {

	private Capital balance;
	private Capital limit;
	private Capital drawnBalance;
	private Capital exceededAmount;

	/**
	 * @return the balance
	 */
	public Capital getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(Capital balance) {
		this.balance = balance;
	}

	/**
	 * @return the limit
	 */
	public Capital getLimit() {
		return limit;
	}

	/**
	 * @param limit the limit to set
	 */
	public void setLimit(Capital limit) {
		this.limit = limit;
	}

	/**
	 * @return the drawnBalance
	 */
	public Capital getDrawnBalance() {
		return drawnBalance;
	}

	/**
	 * @param drawnBalance the drawnBalance to set
	 */
	public void setDrawnBalance(Capital drawnBalance) {
		this.drawnBalance = drawnBalance;
	}

	/**
	 * @return the exceededAmount
	 */
	public Capital getExceededAmount() {
		return exceededAmount;
	}

	/**
	 * @param exceededAmount the exceededAmount to set
	 */
	public void setExceededAmount(Capital exceededAmount) {
		this.exceededAmount = exceededAmount;
	}

}
