package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the lista request
 */
@Builder

/**
 * Instantiates a new lista request.
 */
@NoArgsConstructor

/**
 * Instantiates a new lista request.
 *
 * @param codigoIdentificacionPers the codigo identificacion pers
 * @param fechaDesde the fecha desde
 * @param fechaHasta the fecha hasta
 * @param grupo the grupo
 * @param persona the persona
 */
@AllArgsConstructor
public class ListaRequest {
    
    /** The codigo identificacion pers. */
    private String codigoIdentificacionPers;
    
    /** The fecha desde. */
    private String fechaDesde;
    
    /** The fecha hasta. */
    private String fechaHasta;
    
    /** The grupo. */
    private String grupo;
    
    /** The person. */
    private Persona persona;

}
