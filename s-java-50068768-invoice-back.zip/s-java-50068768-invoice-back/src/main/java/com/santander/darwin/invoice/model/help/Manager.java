package com.santander.darwin.invoice.model.help;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Manager.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Manager {

	// Variables
	private boolean show;
	// Para swagger
	@Schema(example = "Titulo", description = "Title of manager")
	private String title;
	// Para swagger
	@Schema(example = "Santander", description = "Name of manager")
	private String name;
	// Para swagger
	@Schema(example = "666777888", description = "Mobile of manager")
	private String mobile;
	// Para swagger
	@Schema(example = "santander@santander.com", description = "Email of manager")
	private String email;

}
