package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RecoveryPhoneAndMailResponse.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the recovery phone and mail response
 */
@Builder

/**
 * Instantiates a new recovery phone and mail response.
 */
@NoArgsConstructor

/**
 * Instantiates a new recovery phone and mail response.
 *
 * @param phoneNumber the phone number
 * @param email the email
 * @param internationalPrefix the international prefix
 */
@AllArgsConstructor
public class RecoveryPhoneAndMailResponse {

    /** The phone number. */
    private String phoneNumber;

    /** The email. */
    private String email;

    /** The international prefix. */
    private String internationalPrefix;

}
