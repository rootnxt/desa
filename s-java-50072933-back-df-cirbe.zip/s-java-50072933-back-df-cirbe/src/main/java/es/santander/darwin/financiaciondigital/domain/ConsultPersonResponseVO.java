package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ConsultPersonResponseVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the consult person response VO
 */
@Builder

/**
 * Instantiates a new consult person response VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new consult person response VO.
 *
 * @param personList the person list
 */
@AllArgsConstructor
public class ConsultPersonResponseVO {

    /** The person list. */
    private List<PersonVO> personList;
}
