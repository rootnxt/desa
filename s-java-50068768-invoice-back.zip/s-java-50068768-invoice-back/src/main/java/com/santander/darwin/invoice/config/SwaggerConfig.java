package com.santander.darwin.invoice.config;

import com.santander.darwin.invoice.constants.HttpConstants;
import com.santander.darwin.invoice.constants.RestConstants;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.IntegerSchema;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.ObjectSchema;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.GroupedOpenApi;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * Creates the necessary objects to configure Springdoc OpenAPI. OpenAPI
 * automates the generation of API documentation using spring boot projects This
 * class only will be loaded with Non production profile.
 *
 * @author Santander Technology
 */
@Configuration
public class SwaggerConfig {

	/**
     * Creates Springdoc object where the API Documentation is grouped by
     * package and path pattern.
     *
     * @return GroupedOpenApi
     */
	@Bean
	public GroupedOpenApi api() {
        return GroupedOpenApi.builder().group("api-web").packagesToScan("com.santander.darwin.invoice.web")
				.addOpenApiCustomiser(this.customerGlobalHeaderOpenApiCustomiser()).build();
	}

	/**
	 * Creates Springdoc object where it is defined or described the API definition.
	 *
	 * @return OpenAPI
	 */
	@Bean
	public OpenAPI apiInfo() {
		return new OpenAPI()
				.info(new Info().title("Financian&Go")
                        .description(
                                "Banco Santander DARWIN Application - Microservice of the Financian&Go application")
                        .version("1.0.0-SNAPSHOT"))
				.components(new Components().addSecuritySchemes("BearerAuth",
						new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
				.addSecurityItem(new SecurityRequirement().addList("BearerAuth"));
	}

    /**
     * Creates the schema error.
     *
     * @param httpStatusError
     *            the http status error
     * @param exampleMessage
     *            the example message
     * @return the object schema
     */
    public ObjectSchema createSchemaError(String httpStatusError, String exampleMessage) {
    	// Default error response
        return (ObjectSchema) new ObjectSchema()
        		.addProperty("code", new StringSchema().example("IVFNGENERICERROR"))
        		.addProperty("message", new StringSchema().example(exampleMessage))
        		.addProperty("nameApp", new StringSchema().example("Financiación digital"))
        		.addProperty("presentation", new StringSchema().example("WEB"))
        		.addProperty("status", new StringSchema().example(httpStatusError))
        		.addProperty("style", new StringSchema().example("string"))
        		.addProperty("timestamp", new IntegerSchema().example(System.currentTimeMillis()))
        		.addProperty("type", new StringSchema().example("PAGE"))
        		.addProperty("url", new StringSchema().example("/error"))
                ;
    }

	/**
     * Add all default architecture headers.
     *
     * @return OpenApiCustomizer
     */
	public OpenApiCustomiser customerGlobalHeaderOpenApiCustomiser() {
		// Arq headers. Explain in
		// https://confluence.ci.gsnet.corp/pages/viewpage.action?pageId=213326163
		return this::openApiConfig;
	}

    /**
     * Open api config.
     *
     * @param openApi
     *            the open api
     */
	private void openApiConfig(OpenAPI openApi) {
		openApi.components(openApi.getComponents().addParameters(HttpConstants.HEADER_XCLIENTID, new HeaderParameter()
				.required(Boolean.FALSE).name(HttpConstants.HEADER_XCLIENTID)
				.description("\t\n" + "Identify the calling application.\n" + "\n"
						+ "It originates from the client that calls an API, either a presentation component or a microservice.")
				.schema(new StringSchema()).example(HttpConstants.HEADER_XCLIENTID_DESC)));

		if (openApi.getPaths() != null) {
	        // Respuestas error globales
	        openApi.getPaths().values().forEach(pathItem -> pathItem.readOperations().forEach((Operation operation) -> {
	            var apiResponses = operation.getResponses();
	            // apiResponseBadRequest
	            var apiResponseBadRequest = new ApiResponse().description(HttpConstants.BAD_REQUEST_DESC)
	                    .content(new Content().addMediaType(org.springframework.http.MediaType.APPLICATION_JSON_VALUE,
	                            new MediaType().schema(createSchemaError(
	                            		HttpConstants.BAD_REQUEST_CODE, RestConstants.BAD_REQUEST_DESCRIPTION))));
	
	            apiResponses.addApiResponse(HttpConstants.BAD_REQUEST_CODE, apiResponseBadRequest);
	
	            // apiResponseUnauthorized
	            var apiResponseUnauthorized = new ApiResponse().description(HttpConstants.UNAUTHORIZED_DESC)
	                    .content(new Content().addMediaType(org.springframework.http.MediaType.APPLICATION_JSON_VALUE,
	                            new MediaType().schema(createSchemaError(HttpConstants.UNAUTHORIZED_CODE,
	                            		RestConstants.UNAUTHORIZED_DESCRIPTION))));
	            apiResponses.addApiResponse(HttpConstants.UNAUTHORIZED_CODE, apiResponseUnauthorized);
	            // apiResponseNotFoundCode
	            var apiResponseNotFoundCode = new ApiResponse().description(HttpConstants.NOT_FOUND_DESC)
	                    .content(new Content().addMediaType(org.springframework.http.MediaType.APPLICATION_JSON_VALUE,
	                            new MediaType().schema(createSchemaError(
	                            		HttpConstants.NOT_FOUND_CODE, RestConstants.NOT_FOUND_DESCRIPTION))));
	            apiResponses.addApiResponse(HttpConstants.NOT_FOUND_CODE, apiResponseNotFoundCode);
	
	            // apiResponseInternalServerError
	            var apiResponseInternalServerError = new ApiResponse()
	                    .description(HttpConstants.INTERNAL_SERVER_DESC)
	                    .content(new Content().addMediaType(org.springframework.http.MediaType.APPLICATION_JSON_VALUE,
	                            new MediaType().schema(createSchemaError(HttpConstants.INTERNAL_SERVER_CODE,
	                            		RestConstants.INTERNAL_SERVER_DESCRIPTION))));
	            apiResponses.addApiResponse(HttpConstants.INTERNAL_SERVER_CODE, apiResponseInternalServerError);
	        }));

			openApi.getPaths().values().stream().flatMap(pathItem -> pathItem.readOperations().stream())
					.forEach(operation -> operation.addParametersItem(new HeaderParameter()
							.$ref("#/components/parameters/".concat(HttpConstants.HEADER_XCLIENTID))));
		}
	}

}
