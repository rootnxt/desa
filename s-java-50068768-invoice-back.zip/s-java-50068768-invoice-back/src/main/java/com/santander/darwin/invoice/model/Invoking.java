package com.santander.darwin.invoice.model;

/**
 * Invoking.java
 *
 * @author igndom
 *
 */
public class Invoking {

	private String invokingId;
	private String term;

	/**
	 * @return the invokingId
	 */
	public String getInvokingId() {
		return invokingId;
	}

	/**
	 * @param invokingId the invokingId to set
	 */
	public void setInvokingId(String invokingId) {
		this.invokingId = invokingId;
	}

	/**
	 * @return the term
	 */
	public String getTerm() {
		return term;
	}

	/**
	 * @param term the term to set
	 */
	public void setTerm(String term) {
		this.term = term;
	}

}
