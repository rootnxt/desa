package es.santander.darwin.financiaciondigital.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity.IgnoredRequestConfigurer;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.stereotype.Component;

import es.santander.darwin.financiaciondigital.config.bean.CustomSecurityConfigProperties;

/**
 * The Class CustomSecurityConfig.
 */
@Component
@Configuration
@EnableWebSecurity
@Order(SecurityProperties.BASIC_AUTH_ORDER)
public class CustomSecurityConfig extends WebSecurityConfigurerAdapter {

    /** The csc properties. */
    @Autowired
    CustomSecurityConfigProperties cscProperties;

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.security.config.annotation.web.configuration.
     * WebSecurityConfigurerAdapter#configure(org.springframework.security. config.annotation.web.builders.WebSecurity)
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        IgnoredRequestConfigurer w = web.ignoring();
        for (String str : cscProperties.getListWeb()) {
            w = w.antMatchers(str);
        }
    }

}
