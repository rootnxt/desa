package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * InputConsultProposal.
 *
 * @author seresc
 */

@Getter
@Setter
public class ProposalExtRequest {
	// Atributos de la clase
	
	/** PROPOSAL. */
	@Schema(example = "004900075202405504", description = "The proposal")
	@NotNull(message = "PROPOSALNULL")
	@NotEmpty(message = "PROPOSALEMPTY")
	@Size(message = "PROPOSALSIZE", min = 17, max = 17)
	private String proposal;

    /** PNE_TIPOPERS. */
	@Schema(example = "J101724800", description = "The person")
	@NotNull(message = "PERSONNULL")
	@NotEmpty(message = "PERSONEMPTY")
    private String person;

	/** origin **/
	@Schema(example = "ADMWEB", description = "The origin")
	@NotNull(message = "ORIGINNULL")
	@NotEmpty(message = "ORIGINEMPTY")
	private String origin;
}