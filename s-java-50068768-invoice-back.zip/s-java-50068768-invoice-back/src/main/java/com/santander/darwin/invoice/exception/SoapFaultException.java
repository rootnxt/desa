package com.santander.darwin.invoice.exception;

import com.santander.darwin.invoice.constants.Constants;
import com.santander.darwin.invoice.model.soap.FaultData;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * SoapFaultException.java
 *
 * @author igndom
 *
 */
public class SoapFaultException extends GlobalException {

	private static final long serialVersionUID = 6722182163890181109L;

	private final FaultData faultData;
	private final List<String> codes;
	private final List<String> messages;

	/**
	 * Constructor
	 *
	 * @param faultData FaultData
	 * @param errors    List<String>
	 * @param messages  List<String>
	 */
	public SoapFaultException(FaultData faultData, List<String> errors, List<String> messages) {
		super(UUID.randomUUID(), System.currentTimeMillis(), Constants.LANG_ES);
		this.faultData = faultData;
		this.codes = Collections.unmodifiableList(errors);
		this.messages = Collections.unmodifiableList(messages);
	}

	/**
	 * Constructor
	 *
	 * @param faultData FaultData
	 * @param errors    List<String>
	 * @param messages  List<String>
	 * @param lang      String
	 */
	public SoapFaultException(FaultData faultData, List<String> errors, List<String> messages, String lang) {
		super(UUID.randomUUID(), System.currentTimeMillis(), lang);
		this.faultData = faultData;
		this.codes = Collections.unmodifiableList(errors);
		this.messages = Collections.unmodifiableList(messages);
	}

	/**
	 * @return the faultData
	 */
	public FaultData getFaultData() {
		return faultData;
	}

	/**
	 * @return the codes
	 */
	public List<String> getCodes() {
		return Collections.unmodifiableList(codes);
	}

	/**
	 * @return the messages
	 */
	public List<String> getMessages() {
		return Collections.unmodifiableList(messages);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SoapFaultException [faultData=" + faultData + ", codes=" + codes + ", messages=" + messages
				+ ", toString()=" + super.toString() + "]";
	}

}
