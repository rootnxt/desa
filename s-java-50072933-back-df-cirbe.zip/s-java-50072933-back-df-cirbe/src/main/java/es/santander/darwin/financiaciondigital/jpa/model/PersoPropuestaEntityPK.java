package es.santander.darwin.financiaciondigital.jpa.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class PersoPropuestaEntityPK.
 */

/**
 * Sets the person code.
 *
 * @param personCode the new person code
 */
@Data

/**
 * Builds the.
 *
 * @return the perso propuesta entity PK
 */
@Builder
@Embeddable

/**
 * Instantiates a new perso propuesta entity PK.
 */
@NoArgsConstructor

/**
 * Instantiates a new perso propuesta entity PK.
 *
 * @param companyId the company id
 * @param centerId the center id
 * @param proposalYear the proposal year
 * @param proposalNumber the proposal number
 * @param intervType the interv type
 * @param ordintc the ordintc
 * @param personType the person type
 * @param personCode the person code
 */
@AllArgsConstructor

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@EqualsAndHashCode(callSuper = false)
public class PersoPropuestaEntityPK extends SerializableParent {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1530867738225783110L;

    /** The company id. */
    @Column(name = "PNE_IDEMPR")
    private String companyId;

    /** The center id. */
    @Column(name = "PNE_IDCENT")
    private String centerId;

    /** The proposal year. */
    @Column(name = "PNE_ANOPROP")
    private String proposalYear;

    /** The proposal number. */
    @Column(name = "PNE_NUMPROP")
    private BigDecimal proposalNumber;

    /** The interv type. */
    @Column(name = "PNE_TIPINTER")
    private String intervType;

    /** The ordintc. */
    @Column(name = "PNE_ORDINTC")
    private Integer ordintc;

    /** The person type. */
    @Column(name = "PNE_TIPOPERS")
    private String personType;

    /** The person code. */
    @Column(name = "PNE_CODPERS")
    private BigDecimal personCode;

}
