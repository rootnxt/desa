package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;


/**
 * The Contract model class.
 *
 * @Autor luis.lopez
 */
@Setter
@Getter
@NoArgsConstructor
public class Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The entity. */
	private String entity;

    /** The center. */
    private String center;

    /** The product. */
    private String product;

    /** The number. */
    private String number;

    /**
     * Instantiates a new Contract object.
     *
     * @param contract the contract.
     */
    public Contract (Contract contract) {
        this.entity = contract.entity;
        this.center = contract.center;
        this.product = contract.product;
        this.number = contract.number;
    }

}
