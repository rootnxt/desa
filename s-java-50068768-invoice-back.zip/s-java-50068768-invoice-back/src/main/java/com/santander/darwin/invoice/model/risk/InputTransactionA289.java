package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * InputTransactionA289.java
 *
 * @author igndom
 *
 */
public class InputTransactionA289 {

	private String anoprop;
	private BigDecimal codpers;
	private String idcent;
	private String idempr;
	private BigDecimal numprop;
	private BigDecimal porcepar;
	private String tipopers;

	/**
	 * @return the anoprop
	 */
	public String getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(String anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the codpers
	 */
	public BigDecimal getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(BigDecimal codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the numprop
	 */
	public BigDecimal getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(BigDecimal numprop) {
		this.numprop = numprop;
	}

	/**
	 * @return the porcepar
	 */
	public BigDecimal getPorcepar() {
		return porcepar;
	}

	/**
	 * @param porcepar the porcepar to set
	 */
	public void setPorcepar(BigDecimal porcepar) {
		this.porcepar = porcepar;
	}

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}
}
