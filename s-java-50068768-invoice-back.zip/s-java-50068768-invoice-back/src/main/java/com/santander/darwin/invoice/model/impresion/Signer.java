package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

/**
 * The Signer class. 
 *
 *
 */
@Getter
@Setter
public class Signer {
    /** The typPerson. */
    private String typPerson;
    
    /** The codPerson. */
    private Integer codPerson;
}
