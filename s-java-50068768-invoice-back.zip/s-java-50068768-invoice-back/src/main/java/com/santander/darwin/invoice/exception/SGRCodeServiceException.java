package com.santander.darwin.invoice.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * SGRCodeServiceException.java
 *
 */
@Getter
@Setter
public class SGRCodeServiceException extends GlobalException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -376531965402024557L;

    /** The usuario. */
    private final String usuario;

    /** The entidad. */
    private final String entidad;

    /** The oficina. */
    private final String oficina;

    /** The app. */
    private final String app;

    /** The channel. */
    private final String channel;

    /** The invoice code. */
    private final String invoiceCode;


    /**
     * Instantiates a new SGR code service exception.
     *
     * @param lang the lang
     * @param app the app
     * @param code the code
     * @param usuario the usuario
     * @param entidad the entidad
     * @param oficina the oficina
     * @param channel the channel
     * @param invoiceCode the invoiceCode
     */
    public SGRCodeServiceException(String lang, String app, String code, String usuario, String entidad, String oficina,
                                   String channel, String invoiceCode) {
        super(code, lang, null);
        this.app = app;
        this.usuario = usuario;
        this.entidad = entidad;
        this.oficina = oficina;
        this.channel = channel;
        this.invoiceCode = invoiceCode;
    }
    
}
