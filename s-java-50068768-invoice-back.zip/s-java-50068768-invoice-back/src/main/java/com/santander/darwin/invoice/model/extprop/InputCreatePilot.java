package com.santander.darwin.invoice.model.extprop;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * InputConsultProposal.
 *
 * @author seresc
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
//Schema clase
// Comentarios
// Example
// Evitar sonar
public class InputCreatePilot {

    /** The center. */
    @NotBlank
    @Size(min = 1, max = 4)
    @Schema(example = "0075", description = "Center of proposal")
    private String center;

    /** The company. */
    @NotBlank
    @Size(min = 1, max = 4)
    @Schema(example = "0049", description = "Company of proposal")
    private String company;

    /** The year. */
    @NotBlank
    @Size(min = 1, max = 4)
    @Schema(example = "2022", description = "Year of proposal")
    private String year;
    
    /** The numberProposal. */
    @NotBlank
    @Size(min = 1, max = 5)
    @Schema(example = "01671", description = "Number of proposal")
    private String numberProposal;

    /** The number. */
    @NotBlank
    @Schema(example = "ADMWEB", description = "Number of app")
    private String app;
    
}
