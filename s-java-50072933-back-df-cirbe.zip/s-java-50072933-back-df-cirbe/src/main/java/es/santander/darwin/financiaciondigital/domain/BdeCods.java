package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the bde cods
 */
@Builder

/**
 * Instantiates a new bde cods.
 */
@NoArgsConstructor

/**
 * Instantiates a new bde cods.
 *
 * @param bdeCodsList the bde cods list
 */
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "bdecods")
public class BdeCods {
    
    /** The bde cods list. */
    private List<BdeInfo> bdeCodsList;

}
