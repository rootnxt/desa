package com.santander.darwin.invoice.model.end;

import lombok.Getter;
import lombok.Setter;

/**
 * Opinator.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Opinator {

	//Se declaran las variables
	private String dataOpi;
	private String product;
	private String subProduct;
	private String operative;

}
