package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ConfirmingOperationOutput.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ConfirmingOperationOutput {
	// Datos de ConfirmingOperationOutput
	
	/** confirmingOperationId */
	private String confirmingOperationId;
	
	/** mnemonicCode */
	private String mnemonicCode;
	
	/** paymentTypeCode */
	private String paymentTypeCode;
	
	/** account */
	private Account account;
	
}