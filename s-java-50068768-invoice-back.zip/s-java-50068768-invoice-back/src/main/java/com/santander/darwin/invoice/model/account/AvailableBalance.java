
package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The AvailableBalance model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor
public class AvailableBalance extends Balance {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new AvailableBalance object.
     *
     * @param balance the balance.
     */
    public AvailableBalance (Balance balance) {
        super(balance);
    }

    /**
     * copy.
     *
     * @return the Balance.
     */
    @Override
    public Balance copy() {
        return new AvailableBalance(this);
    }


}
