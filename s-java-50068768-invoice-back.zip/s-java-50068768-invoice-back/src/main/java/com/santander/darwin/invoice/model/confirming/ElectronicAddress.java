package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ElectronicAddress.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ElectronicAddress {
	// Datos de ElectronicAddress
	private String emailAddress;

	
	/**
	 * Constructor
	 * @param emailAddress String
	 */
	public ElectronicAddress(String emailAddress) {
		super();
		this.emailAddress = emailAddress;
	}
	
	
}