package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PetitionsTreatmentProcessResponse.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the petitions treatment process response
 */
@Builder

/**
 * Instantiates a new petitions treatment process response.
 */
@NoArgsConstructor

/**
 * Instantiates a new petitions treatment process response.
 *
 * @param responseMessage the response message
 * @param errorCode the error code
 * @param errorMessage the error message
 */
@AllArgsConstructor
public class PetitionsTreatmentProcessResponse {

    /** The response message. */
    private String responseMessage;
    
    /** The error code. */
    private String errorCode;
    
    /** The error message. */
    private String errorMessage;
}
