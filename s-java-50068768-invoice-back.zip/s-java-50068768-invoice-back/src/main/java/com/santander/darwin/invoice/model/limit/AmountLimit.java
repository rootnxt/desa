package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the url.
 *
 * @return the url
 */
@Getter

/**
 * Sets the url.
 *
 * @param url the new url
 */
@Setter
@NoArgsConstructor

/**
 * Instantiates a new amount limit.
 */
public class AmountLimit {
    
    /** The amount 1. */
    private Integer amount1;
    
    /** The amount 3. */
    private Integer amount3;
    
    /** The allowProduct. */
    private boolean allowProduct;

	/**
	 * Constructor
	 * 
	 * @param amount1 Integer
	 * @param amount3 Integer
	 */
	public AmountLimit(Integer amount1, Integer amount3) {
		super();
		this.amount1 = amount1;
		this.amount3 = amount3;
	}
}
