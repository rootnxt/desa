package com.santander.darwin.invoice.model.mtdl_url;

import org.springframework.data.annotation.Id;

/**
 * InvoiceMtdlUrl
 * 
 * @author igndom
 *
 */
public class InvoiceMtdlUrl {

	@Id
	private String id;
	private String stateFront;
	private String url;
	private String desc;
	private Integer order;
	private boolean show;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the stateFront
	 */
	public String getStateFront() {
		return stateFront;
	}

	/**
	 * @param stateFront the stateFront to set
	 */
	public void setStateFront(String stateFront) {
		this.stateFront = stateFront;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	/**
	 * @return the show
	 */
	public boolean isShow() {
		return show;
	}

	/**
	 * @param show the show to set
	 */
	public void setShow(boolean show) {
		this.show = show;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	

}
