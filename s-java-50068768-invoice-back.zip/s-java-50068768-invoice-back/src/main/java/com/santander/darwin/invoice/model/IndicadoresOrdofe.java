package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * IndicadoresOrdofe.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class IndicadoresOrdofe {

	// Datos
	// Para swagger
	@Schema(example = "00", description = "Indicator of Fin")
	private String indFin;
	// Para swagger
	@Schema(example = "00", description = "Result of indicator")
	private String indResult;

}
