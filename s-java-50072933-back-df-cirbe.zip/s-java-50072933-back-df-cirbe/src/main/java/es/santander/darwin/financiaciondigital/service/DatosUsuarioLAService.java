package es.santander.darwin.financiaciondigital.service;

import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;

/**
 * The Interface DatosUsuarioLAService.
 */
public interface DatosUsuarioLAService {

  
    /**
     * Gets the user name.
     *
     * @param companyId the company id
     * @return the user name
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    String getUserName(String companyId) throws DigitalConsumptionServiceException;

}
