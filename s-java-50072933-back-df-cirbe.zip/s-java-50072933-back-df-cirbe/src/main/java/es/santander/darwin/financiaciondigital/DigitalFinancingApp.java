package es.santander.darwin.financiaciondigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * The Class Application.
 */
@SpringBootApplication
@EnableCaching
public class DigitalFinancingApp {

    public static void main(String[] args) {
        SpringApplication.run(DigitalFinancingApp.class, args);
    }
}
