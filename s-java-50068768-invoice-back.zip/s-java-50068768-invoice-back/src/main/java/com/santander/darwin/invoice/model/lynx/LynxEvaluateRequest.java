package com.santander.darwin.invoice.model.lynx;

import lombok.Getter;
import lombok.Setter;


/**
 * The Class LynxEvaluateRequest.
 */

/**
 * Gets the meta data.
 *
 * @return the meta data
 */

/**
 * Gets the meta data.
 *
 * @return the meta data
 */
@Getter

/**
 * Sets the meta data.
 *
 * @param metaData the new meta data
 */

/**
 * Sets the meta data.
 *
 * @param metaData the new meta data
 */

/**
 * Sets the meta data.
 *
 * @param metaData the new meta data
 */
@Setter
public class LynxEvaluateRequest {
	
	/** The fraud id. */
	private String fraudId;
	
	/** The reference id. */
	private String referenceId;
	
	/** The customer id. */
	private String customerId;
	
	/** The operation type. */
	private String operationType;
	
	/** The operation subtype. */
	private String operationSubtype;
	
	/** The call type. */
	private String callType;
	
	/** The meta data. */
	private String metaData;

}