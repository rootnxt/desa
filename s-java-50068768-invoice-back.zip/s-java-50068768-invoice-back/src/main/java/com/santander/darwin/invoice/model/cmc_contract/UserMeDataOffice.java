package com.santander.darwin.invoice.model.cmc_contract;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * UserMeDataOffice
 * 
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class UserMeDataOffice {

	// uid
	private String uid;
	
	//Resto de atributos
	private Attributes attributes;

}
