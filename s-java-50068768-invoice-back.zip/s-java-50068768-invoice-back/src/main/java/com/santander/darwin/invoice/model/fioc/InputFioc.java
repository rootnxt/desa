package com.santander.darwin.invoice.model.fioc;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Sets the canal.
 *
 * @param canal the new canal
 */
@Setter

/**
 * Gets the canal.
 *
 * @return the canal
 */
@Getter

/**
 * Instantiates a new input fioc.
 */
@NoArgsConstructor
public class InputFioc{

	/** The persona. */
	private PersonFioc persona;
	
	/** The empresa. */
	private String empresa;
	
	/** The canal. */
	private String canal;

}