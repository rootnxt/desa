package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class CheckImpresionInput.
 */

@Getter
@Setter
public class CheckImpresionInput {

    /** The empresa. */
    private String empresa;
    
    /** The centro. */
    private String centro;
    
    /** The anio. */
    private String anio;
    
    /** The propuesta. */
    private int propuesta;
    
    /** The tipintervencion. */
    private String tipintervencion;
    
    /** The formintervencion. */
    private String formintervencion;
    
    /** The ordintervencion. */
    private int ordintervencion;
    
    /** The objeto. */
    private String objeto;
    
    /** The indimpresion. */
    private String indimpresion;
    
    /** The gn id. */
    private String gnId;
}
