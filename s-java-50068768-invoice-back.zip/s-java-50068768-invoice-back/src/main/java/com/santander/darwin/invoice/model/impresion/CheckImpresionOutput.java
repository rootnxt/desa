package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class CheckImpresionOutput.
 */

@Getter
@Setter
public class CheckImpresionOutput {

	/** The codigo. */
	private String codigo;
	
}
