package com.santander.darwin.invoice.model.hiring;

import com.santander.darwin.invoice.model.Account;
import com.santander.darwin.invoice.model.CommonData;
import com.santander.darwin.invoice.model.Document;
import com.santander.darwin.invoice.model.confirming.ContactInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Hiring.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Hiring extends CommonData {

	// Cuentas
	private List<Account> accounts;
	// Informacion contacto confirming
	private ContactInfo contactInfo;
	// Documentos
	private List<Document> documents;
	// Permite boton firmar
	private boolean allowSign;
	// Permite boton firmar luego
	private boolean allowSignLater;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;
	
	// Número de empleado
	private String employed;

	// Informacion contacto confirming
	private PreformalizationInfo preformalizationInfo;

	// Tipo firma 01-Buzón;02-Digital;03-Manuscrita 
	private String typeSign;

	//Flag admite firma buzon
	private Boolean allowBuzon;

	//Flag admite firma wacom
	private Boolean allowWacom;

	/** The errorFormalized */
	private String errorFormalized;

	/** The show preformalization data flag */
	private boolean showPreformalizationData;
	
}
