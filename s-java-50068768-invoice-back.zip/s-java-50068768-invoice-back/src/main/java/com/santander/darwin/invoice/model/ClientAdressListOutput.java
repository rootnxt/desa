package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Devuelve el codigo de persona
 * 
 * @author josdon
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ClientAdressListOutput {
	
	// Detalle del domicio
	private List<String> domdesc = new ArrayList<>();
	// Tipo de domicilio
	private List<String> tipodo = new ArrayList<>();
	
}
