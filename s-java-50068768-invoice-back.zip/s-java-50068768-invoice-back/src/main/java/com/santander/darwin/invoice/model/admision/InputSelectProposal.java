/**
 * 
 */
package com.santander.darwin.invoice.model.admision;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Clase de entrada para las llamadas rest
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class InputSelectProposal {
	
	// Atributos de la propuesta
	private String anoprop;
	private String idcent;
	private String idempr;
	private BigDecimal numprop; 
	
}
