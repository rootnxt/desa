package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BasicPersonDataResponseVO.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the consulta consolidado cirbe response VO
 */
@Builder

/**
 * Instantiates a new consulta consolidado cirbe response VO.
 */
@NoArgsConstructor

/**
 * Instantiates a new consulta consolidado cirbe response VO.
 *
 * @param nuevoAcreditado the nuevo acreditado
 * @param fechaSistema the fecha sistema
 * @param fechaCliente the fecha cliente
 */
@AllArgsConstructor
public class ConsultaConsolidadoCirbeResponseVO {
    
    /** The nuevo acreditado. */
    private boolean nuevoAcreditado;

    /** The fechaSistema. */
    private String fechaSistema;
    
    /** The fechaSistema. */
    private String fechaCliente;


}