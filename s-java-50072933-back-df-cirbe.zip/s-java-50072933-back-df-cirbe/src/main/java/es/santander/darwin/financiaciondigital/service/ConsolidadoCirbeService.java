package es.santander.darwin.financiaciondigital.service;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.domain.ConsultaConsolidadoCirbeResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;

/**
 * The Interface CiriteService.
 */
public interface ConsolidadoCirbeService {

    
    /**
     * Call consolidado cirbe.
     *
     * @param basicPersonDataRes the basic person data res
     * @return the consulta consolidado cirbe response VO
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    ConsultaConsolidadoCirbeResponseVO callConsolidadoCirbe(BasicPersonDataResponseVO basicPersonDataRes) throws DigitalConsumptionServiceException;

}