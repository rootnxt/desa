/**
 * 
 */
package com.santander.darwin.invoice.model.common;

/**
 * CommonValue
 * 
 * @author josdon
 *
 */
public class CommonValue {
	
	private int progress;
	
	
	/**
	 * Constructor
	 */
	public CommonValue() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Constructor con parametro
	 * @param progress int
	 */
	public CommonValue(int progress) {
		super();
		this.progress = progress;
	}

	/**
	 * @return the progress
	 */
	public int getProgress() {
		return progress;
	}

	/**
	 * @param progress the progress to set
	 */
	public void setProgress(int progress) {
		this.progress = progress;
	}

	
}
