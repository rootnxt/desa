package com.santander.darwin.invoice.model.confirming;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * CustomerRepresentative.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class CustomerRepresentative {
	// Datos de Customer
	private Person person;
	private ContactPoint contactPoint;
	// Datos de Customer
	private Organization organization;
}