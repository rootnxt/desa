package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CommonRefinancing.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CommonRefinancing {

	// contractId
	private String contractId;
	private String ccc;
	private String iban;
	private String productName;
	
	// completeProductName
	private String completeProductName;
	
	// participants
	private List<Participants> participants;
}
