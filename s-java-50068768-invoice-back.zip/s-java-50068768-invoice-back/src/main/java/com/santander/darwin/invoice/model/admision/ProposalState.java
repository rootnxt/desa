package com.santander.darwin.invoice.model.admision;

import lombok.Getter;
import lombok.Setter;

/**
 * Clase de entrada para las llamadas rest
 *
 * @author josdon
 *
 */
@Getter
@Setter
public class ProposalState {
    // Estado de la propuesta en admision
    private String cotestad;
    // Usuario modificador 
    private String usumod;
    //timestamp
    private String timeProp;
}