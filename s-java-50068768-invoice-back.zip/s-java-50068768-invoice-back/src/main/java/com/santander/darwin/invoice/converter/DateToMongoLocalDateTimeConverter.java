package com.santander.darwin.invoice.converter;

import com.santander.darwin.invoice.model.mongo.MongoLocalDateTime;
import org.springframework.core.convert.converter.Converter;

import java.time.ZoneId;
import java.util.Date;

/**
 * DateToMongoLocalDateTimeConverter
 * 
 * @author igndom
 *
 */
public class DateToMongoLocalDateTimeConverter implements Converter<Date, MongoLocalDateTime> {

	@Override
	public MongoLocalDateTime convert(Date source) {
		// Convertidor custom date to mongo
		return MongoLocalDateTime.of(source.toInstant().atZone(ZoneId.of("GMT")).toLocalDateTime());
	}
}
