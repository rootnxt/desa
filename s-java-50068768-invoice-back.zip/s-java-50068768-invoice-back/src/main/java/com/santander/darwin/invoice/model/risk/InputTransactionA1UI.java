/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * InputTransactionA1UI 
 * 
 *
 */
@Getter
@Setter
public class InputTransactionA1UI {
	
	//INPUT DATA

		/**
		 * Año de la propuesta
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String anoprop;

		/**
		 * Año de la 2a. propuesta
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String anoprop2;

		/**
		 * Codigo de moneda swift del contrato en la formalizacion
		 * Partenon alphanumeric (A) - Length (3)
		 */
		public String codmocto;

		/**
		 * Codigo de moneda
		 * Partenon alphanumeric (A) - Length (3)
		 */
		public String codmonsw;

		/**
		 * Codigo de persona
		 * Partenon unsigned numeric (N) - Length (9,0)
		 */
		public BigDecimal codpers;

		/**
		 * Código del tipo de operación de crédito
		 * Partenon alphanumeric (A) - Length (3)
		 */
		public String codprod;

		/**
		 * Subtipo de producto
		 * Partenon alphanumeric (A) - Length (3)
		 */
		public String codsprod;

		/**
		 * Codigo de estandar de referencia
		 * Partenon alphanumeric (A) - Length (7)
		 */
		public String coestref;

		/**
		 * Fecha de vencimiento propuesta
		 * Partenon date (D1) - Length (8)
		 */
		public Date fechvtoc;

		/**
		 * Codigo de centro.
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idcent;

		/**
		 * Codigo de centro contable
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idcentc;

		/**
		 * Codigo de centro para cta. personal
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idcent2;

		/**
		 * Numero de contrato
		 * Partenon alphanumeric (A) - Length (7)
		 */
		public String idcontr;

		/**
		 * Identificador de empresa
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idempr;

		/**
		 * Empresa destinataria
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idemprc;

		/**
		 * Codigo de empresa para cta.personal
		 * Partenon alphanumeric (A) - Length (4)
		 */
		public String idempr2;

		/**
		 * Codigo de producto del contrato
		 * Partenon alphanumeric (A) - Length (3)
		 */
		public String idprod;

		/**
		 * Importe comisiones ultimo mes
		 * Partenon signed numeric (L) - Length (16,2)
		 */
		public BigDecimal imporcom;

		/**
		 * Importe de la relacion contrato-propuesta en la moneda del contrato
		 * Partenon signed numeric (L) - Length (16,2)
		 */
		public BigDecimal imporcto;

		/**
		 * Nro.de secuencia de la propuesta
		 * Partenon unsigned numeric (N) - Length (5,0)
		 */
		public BigDecimal numprop;

		/**
		 * Numero de orden 2a. propuesta
		 * Partenon unsigned numeric (N) - Length (5,0)
		 */
		public BigDecimal numprop2;

		/**
		 * Altamira - conversacion de contabilidad
		 * Partenon alphanumeric (A) - Length (2)
		 */
		public String opcion;

		/**
		 * Tipo de persona (f=fisica, j=juridica)
		 * Partenon alphanumeric (A) - Length (1)
		 */
		public String tipopers;

}
