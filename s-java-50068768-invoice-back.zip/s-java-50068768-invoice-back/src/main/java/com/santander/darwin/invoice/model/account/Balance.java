
package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The LocalAccount model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor
public class Balance implements Serializable {

    public static final long serialVersionUID = 1L;

    /** The amount. */
    private BigDecimal amount;

    /** The currency. */
    private String currency;

    /**
     * Instantiates a new Balance object.
     *
     * @param balance the balance.
     */
    public Balance (Balance balance) {
        this.amount = balance.amount;
        this.currency = balance.currency;
    }

    /**
     * copy.
     *
     * @return the Balance.
     */
    public Balance copy() {
        return new Balance(this);
    }

}
