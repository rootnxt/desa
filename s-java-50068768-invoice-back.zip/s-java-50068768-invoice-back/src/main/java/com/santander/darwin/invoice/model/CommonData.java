package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.simulation.Condition;

/**
 * CommonData
 * 
 * @author igndom
 *
 */
public class CommonData {

	private Summary summary;
	
	// Summary Conditions comex
	private Condition conditions;
	private Account account;
	private boolean showGuarantors;
	/**
	 * @return the summary
	 */
	public Summary getSummary() {
		return summary;
	}
	/**
	 * @param summary the summary to set
	 */
	public void setSummary(Summary summary) {
		this.summary = summary;
	}
	/**
	 * @return the conditions
	 */
	public Condition getConditions() {
		return conditions;
	}
	/**
	 * @param conditions the conditions to set
	 */
	public void setConditions(Condition conditions) {
		this.conditions = conditions;
	}
	/**
	 * @return the account
	 */
	public Account getAccount() {
		return account;
	}
	/**
	 * @param account the account to set
	 */
	public void setAccount(Account account) {
		this.account = account;
	}
	/**
	 * @return the showGuarantors
	 */
	public boolean isShowGuarantors() {
		return showGuarantors;
	}
	/**
	 * @param showGuarantors the showGuarantors to set
	 */
	public void setShowGuarantors(boolean showGuarantors) {
		this.showGuarantors = showGuarantors;
	}

	
}
