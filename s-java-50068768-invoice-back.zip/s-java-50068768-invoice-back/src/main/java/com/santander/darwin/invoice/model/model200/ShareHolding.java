package com.santander.darwin.invoice.model.model200;

import com.santander.darwin.invoice.model.CommonModel200;

import java.math.BigDecimal;

/**
 * ShareHolding.java
 *
 * @author igndom
 *
 */
public class ShareHolding extends CommonModel200 {

	private BigDecimal share;

	/**
	 * @return the share
	 */
	public BigDecimal getShare() {
		return share;
	}

	/**
	 * @param share the share to set
	 */
	public void setShare(BigDecimal share) {
		this.share = share;
	}

}
