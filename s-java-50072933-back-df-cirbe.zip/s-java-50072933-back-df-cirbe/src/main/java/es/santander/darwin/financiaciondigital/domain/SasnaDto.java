package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the sasna dto
 */
@Builder

/**
 * Instantiates a new sasna dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new sasna dto.
 *
 * @param companyId the company id
 * @param personType the person type
 * @param personCode the person code
 * @param requestUser the request user
 */
@AllArgsConstructor
public class SasnaDto {

    /** The company id. */
    private String companyId;

    /** The person type. */
    private String personType;

    /** The person code. */
    private BigDecimal personCode;

    /** The request user. */
    private String requestUser;
    
}
