package com.santander.darwin.invoice.model;

/**
 * AccountPtn
 * 
 * @author x232031
 *
 */

public class AccountPtn{

	/**
	 * bankCode
	 */
	private String bankCode;
	/**
	 * branchCode
	 */
	private String branchCode;
	/**
	 * productTypeCode
	 */
	private String productTypeCode;
	// contractCode
	private String contractCode;
	// id
	private String id;
	
	/**
	 * Constructor
	 */
	public AccountPtn() {
		super();
	}
	
	/**
	 * Constructor fields
	 * 
	 * @param bankCode String
	 * @param branchCode String
	 * @param productTypeCode String
	 * @param contractCode String
	 * @param id String
	 */
	public AccountPtn(String bankCode, String branchCode, String productTypeCode, String contractCode, String id) {
		super();
		this.bankCode = bankCode;
		this.branchCode = branchCode;
		this.productTypeCode = productTypeCode;
		this.contractCode = contractCode;
		this.id = id;
	}
	
	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}
	
	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	
	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}
	
	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	/**
	 * @return the productTypeCode
	 */
	public String getProductTypeCode() {
		return productTypeCode;
	}
	
	/**
	 * @param productTypeCode the productTypeCode to set
	 */
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}
	
	/**
	 * @return the contractCode
	 */
	public String getContractCode() {
		return contractCode;
	}
	
	/**
	 * @param contractCode the contractCode to set
	 */
	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	
	
}
