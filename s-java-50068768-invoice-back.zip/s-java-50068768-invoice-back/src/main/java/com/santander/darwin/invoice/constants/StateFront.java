package com.santander.darwin.invoice.constants;

/**
 * StateFront.java
 *
 * @author igndom
 *
 */
public enum StateFront {

	// PRESIMULACION
	STATE_NOT_INIT("00"),
	
	// LIMITES P2
	STATE_PYMES_LIMITS("51"),
	
	// Combo de cuentas-contratacion
	STATE_PYMES_LIMITS_HIRING_FORM("52"),

	// SIMULACION
	STATE_SIMULATION("01"),

	// Listado de facturas
	STATE_BILLIN_LIST("02"),
	
	// Listado de avalistas
    STATE_GUARANTORS("12"),

	// Cirbe
	STATE_DATA("20"),
	
	// Addtional model aeat
	STATE_MODEL_AEAT("22"),
	
	// Agregador
	STATE_AGGREGATOR("40"),
	
	//Noitificacion agregacion pendiente
	STATE_AGGREGATOR_PENDING_NOTIFY("41"),
	
	// Kpis
	STATE_KPIS("50"),

	// Combo de cuentas-contratacion
	STATE_HIRING("03"),

	// Solicitud listado de apoderados firmantes
	STATE_CONFIRMING_SIGNER("30"),

	// Firma criptocalculadora
	STATE_SIGNING_POSITIONS_OR_CRYPTO("04"),
	
	//Firma avalista
	STATE_SIGNING_POSITIONS_OR_CRYPTO_GUARANTOR("24"),

	// Firma otp
	STATE_SIGNING_OTP("05"),
	
	// Firma otp avalista
	STATE_SIGNING_OTP_GUARANTOR("25"),

	// Seleccion de apoderados.
	STATE_REPRESENTATIVES("06"),

	// Resultado correcto //Pantallas final
	STATE_END_SUCCESS("07"),

	// Resultado email //Pantallas final
	STATE_END_EMAIL("08"),

	// Resultado proxies //Pantallas final
	STATE_END_PROXIES("09"),

	// Resultado proxies //Pantallas final
	STATE_INFO_SCREEN("10"),

	// Resultado firma v4 //Pantallas final
	STATE_END_SIGNATURE("11"),
	
	// Elevacion de la propuesta /Pantalla final
	STATE_END_PROPOSAL_SUBMITTED("13"),
	
	// Activacion de servicios /Pantalla final
	STATE_END_SERVICES_ACTIVATION("14"),

	// State Wacom Signature
	STATE_WACOM_SIGNATURE("15"),
	
	// url de error no limites en P2
	STATE_PYMES_END_ERROR_NO_LIMITS("95"),
	
	// url de error ko1
    STATE_PYMES_END_ERROR_KO1("94"),
    
    // url de error ko2
    STATE_PYMES_END_ERROR_KO2("93"),
	
	// url end success pymes
	STATE_PYMES_END("103"),
	
	// traspaso a oficina
	STATE_END_OFFICE("104"),

	// Cancelada JOB
	STATE_END_CANCEL("96"),

	// Denegada por el motor
	STATE_END_DENIED("98"),

	// Error en formalizacion
	STATE_END_ERROR("99"),

	// Solicitud borrada
	STATE_END_DELETE("100"),

	// Solo se utiliza en el informe
	STATE_END_DELETE_ERROR("100E"),

	// Solicitud finalizada
	STATE_END("101"),

	// Formalizada desde Buzon
	STATE_END_BOX("102"),
	
	// Cancelada propuesta oficina
	STATE_END_CANCEL_PROPOSAL("105"),

	// UrlExternas. Url de encuesta de satisfaccion
	EXT_URL_SURVEY("80"),

	// UrlExternas. Url de buzon de supernet particulares
	EXT_URL_SUPERNET_PHYSICAL("81"),

	// UrlExternas. Url de buzon de supernet empresas
	EXT_URL_SUPERNET_JURIDIC("82"),

	// LISTADO DE SOLICITUDES
	STATE_REQUESTS("83"),

	// MockLanzadera en consola
	MOCK_LANZADERA("97"),

	// UrlExternas. Url de buzon de supernet empresas
    EXT_URL_SIGN_GUARANTOR("84"),
	
	// Standalone KPIS
    URL_STANDALONE_KPIS("85"),
	
	// Url de pago next comex
	EXT_URL_PAGO_NEXT("86");
	
    
	private String code;

	/**
	 * Instantiate a new state front.
	 *
	 * @param code the code
	 */
	StateFront(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Get state from code.
	 *
	 * @param code the code
	 * @return StateFront
	 */
	public static StateFront getStateFromCode(String code) {
		for (StateFront stateFrontType : StateFront.values()) {
			if (stateFrontType.getCode().equals(code)) {
				return stateFrontType;
			}
		}
		return null;
	}
}
