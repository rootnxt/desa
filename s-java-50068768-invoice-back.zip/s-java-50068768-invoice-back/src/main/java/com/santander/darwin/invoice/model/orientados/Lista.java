package com.santander.darwin.invoice.model.orientados;

import java.math.BigDecimal;

/**
 * Lista.java
 *
 * @author igndom
 *
 */
public class Lista {

	private String acodcamp;
	private String implimit;
	private String impmincn;
	private String impmaxcn;
	private String canalpre;
	private String cfamilia;
	private String jfactor;
	private BigDecimal cnopcanl;
	private String triadrec;
	private BigDecimal nmaxcanl;
	private BigDecimal impacu1;
	private String triadlim;
	private String feinivig;
	private String fefinvig;
	private String fcubiert;

	/**
	 * @return the acodcamp
	 */
	public String getAcodcamp() {
		return acodcamp;
	}

	/**
	 * @param acodcamp the acodcamp to set
	 */
	public void setAcodcamp(String acodcamp) {
		this.acodcamp = acodcamp;
	}

	/**
	 * @return the implimit
	 */
	public String getImplimit() {
		return implimit;
	}

	/**
	 * @param implimit the implimit to set
	 */
	public void setImplimit(String implimit) {
		this.implimit = implimit;
	}

	/**
	 * @return the impmincn
	 */
	public String getImpmincn() {
		return impmincn;
	}

	/**
	 * @param impmincn the impmincn to set
	 */
	public void setImpmincn(String impmincn) {
		this.impmincn = impmincn;
	}

	/**
	 * @return the impmaxcn
	 */
	public String getImpmaxcn() {
		return impmaxcn;
	}

	/**
	 * @param impmaxcn the impmaxcn to set
	 */
	public void setImpmaxcn(String impmaxcn) {
		this.impmaxcn = impmaxcn;
	}

	/**
	 * @return the canalpre
	 */
	public String getCanalpre() {
		return canalpre;
	}

	/**
	 * @param canalpre the canalpre to set
	 */
	public void setCanalpre(String canalpre) {
		this.canalpre = canalpre;
	}

	/**
	 * @return the cfamilia
	 */
	public String getCfamilia() {
		return cfamilia;
	}

	/**
	 * @param cfamilia the cfamilia to set
	 */
	public void setCfamilia(String cfamilia) {
		this.cfamilia = cfamilia;
	}

	/**
	 * @return the jfactor
	 */
	public String getJfactor() {
		return jfactor;
	}

	/**
	 * @param jfactor the jfactor to set
	 */
	public void setJfactor(String jfactor) {
		this.jfactor = jfactor;
	}

	/**
	 * @return the cnopcanl
	 */
	public BigDecimal getCnopcanl() {
		return cnopcanl;
	}

	/**
	 * @param cnopcanl the cnopcanl to set
	 */
	public void setCnopcanl(BigDecimal cnopcanl) {
		this.cnopcanl = cnopcanl;
	}

	/**
	 * @return the triadrec
	 */
	public String getTriadrec() {
		return triadrec;
	}

	/**
	 * @param triadrec the triadrec to set
	 */
	public void setTriadrec(String triadrec) {
		this.triadrec = triadrec;
	}

	/**
	 * @return the nmaxcanl
	 */
	public BigDecimal getNmaxcanl() {
		return nmaxcanl;
	}

	/**
	 * @param nmaxcanl the nmaxcanl to set
	 */
	public void setNmaxcanl(BigDecimal nmaxcanl) {
		this.nmaxcanl = nmaxcanl;
	}

	/**
	 * @return the impacu1
	 */
	public BigDecimal getImpacu1() {
		return impacu1;
	}

	/**
	 * @param impacu1 the impacu1 to set
	 */
	public void setImpacu1(BigDecimal impacu1) {
		this.impacu1 = impacu1;
	}

	/**
	 * @return the triadlim
	 */
	public String getTriadlim() {
		return triadlim;
	}

	/**
	 * @param triadlim the triadlim to set
	 */
	public void setTriadlim(String triadlim) {
		this.triadlim = triadlim;
	}

	/**
	 * @return the feinivig
	 */
	public String getFeinivig() {
		return feinivig;
	}

	/**
	 * @param feinivig the feinivig to set
	 */
	public void setFeinivig(String feinivig) {
		this.feinivig = feinivig;
	}

	/**
	 * @return the fefinvig
	 */
	public String getFefinvig() {
		return fefinvig;
	}

	/**
	 * @param fefinvig the fefinvig to set
	 */
	public void setFefinvig(String fefinvig) {
		this.fefinvig = fefinvig;
	}

	/**
	 * @return the fcubiert
	 */
	public String getFcubiert() {
		return fcubiert;
	}

	/**
	 * @param fcubiert the fcubiert to set
	 */
	public void setFcubiert(String fcubiert) {
		this.fcubiert = fcubiert;
	}
}
