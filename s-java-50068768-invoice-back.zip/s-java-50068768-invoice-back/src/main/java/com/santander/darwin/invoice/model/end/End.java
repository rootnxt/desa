package com.santander.darwin.invoice.model.end;

import com.santander.darwin.invoice.model.CommonData;
import lombok.Getter;
import lombok.Setter;

/**
 * End.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class End extends CommonData {

	//Atributos de la clase
	private String supernetUrl;
	private String surveyUrl;
    private String typeSurvey;
	//Datos de firma
	private String sign;
	private String signatureState;
	private String signatureUrl;
	private Opinator opinator;
	private String proposedDuration;
	
	//Datos de confirming
	private String mNemoNational;
	private String mNemoInternational;
	
	// Resultado de banca electronica
	private String beResult;
	
	// Pago next url
	private String pagoNextUrl;
	
	// Texto parametrizable en pantallas finales
	private TextEnd texts;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;
	
	// Tipo firma 01-Buzón;02-Digital;03-Manuscrita 
	private String typeSign;
	
	// Texto para la pantalla final de financiacion de importacion
	private String messageEndComex;

	// Texto para la pantalla final de Pago Agil - Confirming
	private String messageEndConfirming;

}