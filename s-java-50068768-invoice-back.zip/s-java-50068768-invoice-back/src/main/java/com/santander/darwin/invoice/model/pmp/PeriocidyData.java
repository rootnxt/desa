package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
/**
 * The PeriocidyData class.
 * @author Santander Technology
 *
 */
@Getter
@EqualsAndHashCode
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PeriocidyData {
	    /** The periodicity code. **/
	    private String periodicityCode;
	    /** The description code. **/
	    private String description;
	    /** The period units. **/
	    private String periodUnits;
	    /** The periodicity type code. **/
	    private String periodicityTypeCode;
	    /** The max number. **/
	    private String maxNumber;
}
