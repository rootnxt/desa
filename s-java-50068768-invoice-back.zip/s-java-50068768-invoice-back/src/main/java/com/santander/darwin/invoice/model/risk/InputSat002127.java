package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputSat002127.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class InputSat002127 {

	private List<String> anoprop;
	private List<String> codcesta;
	private List<String> codmonsw;
	private List<String> codprod;
	private List<String> codsprod;
	private List<String> coestref;
	private List<String> idcent;
	private List<String> idempr;
	private List<BigDecimal> numprop;
	private List<BigDecimal> pnplazo;
	private List<BigDecimal> lmpprop;
	private List<String> indplazo;
	private List<String> a1tipcir;
	private List<String> tipsoli;
	private List<String> idemsol;
	private List<String> censoli;
	private List<String> anosolic;
	private List<BigDecimal> nsolici;
	private List<String> indfipin;
	private List<String> anroempe;
	private List<String> idemprc;
	private List<String> convcent;
	private List<String> convprod;
	private List<String> idcontv;
	private List<String> jcesta;
	private List<String> jfechaco;
	private List<String> gwidcent;
	private List<String> gwidcont;
	private List<String> gwidempr;
	private List<String> gwproduc;
	private List<String> indagent;

}
