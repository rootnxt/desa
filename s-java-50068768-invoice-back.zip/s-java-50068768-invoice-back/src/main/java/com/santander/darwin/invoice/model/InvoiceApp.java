package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * InvoiceApp
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class InvoiceApp {

	//Atributos de la clase

	@Id
	private String id;
	//Descripcion de la aplicacion
	private List<CommonLangText> description;
	//Se integra o no con arm
	private boolean arm;
	private String disclaimer;
	private String presentation;
	private boolean showNew;
	private boolean showWow;
	private boolean showColumnHelp;
	private List<ShowHelpChannel> showColumnHelpChannel;
	// Texto WOW
	private List<CommonLang> textWow;
	private String type;
	// Autenticación
	private String auth;
	//Permite a los PE1 ir por limites
	private boolean allowPE1;
	// mock para permitir pasar sin las claves de firma
	private boolean mockSign;

	//elimimar a futuro
	private boolean newConfirming;
	
	// mvp
	private int mvp;

}