package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * Signers.java
 *
 * @author igndom
 *
 */
public class Signers {

	private Signer signer;
	private String locationSign;
	private String order;
	private String signed;

	/**
	 * @return the signer
	 */
	public Signer getSigner() {
		return signer;
	}

	/**
	 * @param signer the signer to set
	 */
	public void setSigner(Signer signer) {
		this.signer = signer;
	}

	/**
	 * @return the locationSign
	 */
	public String getLocationSign() {
		return locationSign;
	}

	/**
	 * @param locationSign the locationSign to set
	 */
	public void setLocationSign(String locationSign) {
		this.locationSign = locationSign;
	}

	/**
	 * @return the order
	 */
	public String getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(String order) {
		this.order = order;
	}

	/**
	 * @return the signed
	 */
	public String getSigned() {
		return signed;
	}

	/**
	 * @param signed the signed to set
	 */
	public void setSigned(String signed) {
		this.signed = signed;
	}

}
