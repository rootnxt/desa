/**
 * 
 */
package com.santander.darwin.invoice.model.limit;

import com.santander.darwin.invoice.model.CommonLangText;
import com.santander.darwin.invoice.model.ProductGen;
import com.santander.darwin.invoice.model.simulation.Term;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * The class ProductData
 * @author josdon
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductData extends ProductGen {

	// Atributos de la clase
	private BigDecimal min;
	private BigDecimal percentManager;
	// Plazo
	private Term months;
	// Descripciones por idiomas
	private List<CommonLangText> description;

	// Descripciones por idiomas
	private String canal;

	// Tipologia
	private String typology;
	private String subtypology;
	
	//
	private BigDecimal limit;
	private boolean digital;

}

