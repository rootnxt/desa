package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.common.CommonType;

import java.math.BigDecimal;

/**
 * CommonCommission
 * 
 * @author igndom
 *
 */
public class CommonCommission extends CommonType {

	private BigDecimal value;

	/**
	 * Constructor
	 */
	public CommonCommission() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param description String
	 * @param value       BigDecimal
	 */
	public CommonCommission(String description, BigDecimal value) {
		super(description);
		this.value = value;
	}

	/**
	 * Constructor
	 * 
	 * @param type        String
	 * @param description String
	 * @param value       BigDecimal
	 */
	public CommonCommission(String type, String description, BigDecimal value) {
		super(type, description);
		this.value = value;
	}

	/**
	 * Constructor
	 * 
	 * @param type        String
	 * @param description String
	 * @param value       BigDecimal
	 * @param refer       String
	 */
	public CommonCommission(String type, String description, BigDecimal value, String refer) {
		super(type, description, refer);
		this.value = value;
	}
	
	/**
	 * Constructor
	 * 
	 * @param type        String
	 * @param description String
	 * @param value       BigDecimal
	 * @param refer       String
	 * @param codRefer    String
	 */
	public CommonCommission(String type, String description, BigDecimal value, String refer, String codRefer) {
		super(type, description, refer, codRefer);
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public BigDecimal getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(BigDecimal value) {
		this.value = value;
	}

}
