package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.account.MnemoInformation;
import com.santander.darwin.invoice.model.common.AccountCommon;

import java.math.BigDecimal;

/**
 * Account
 * 
 * @author igndom
 *
 */

public class Account extends AccountCommon {

	private String type;
	private String alias;
	private String contract;
	private BigDecimal balance;
	private boolean selected;
	private String currency;
	private AccountPtn accountPtn;
	private MnemoInformation mnemoInformation;

	/**
	 * Constructor
	 */
	public Account() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param type    String
	 * @param alias   String
	 * @param number  String
	 * @param company String
	 * @param center  String
	 * @param product String
	 */
	public Account(String type, String alias, String number, String company, String center, String product) {
		super(number, company, center, product);
		this.type = type;
		this.alias = alias;
	}
	
	/**
	 * Constructor
	 * 
	 * @param type    String
	 * @param alias   String
	 * @param number  String
	 * @param company String
	 * @param center  String
	 * @param product String
	 * @param accountPtn AccountPtn
	 */
	public Account(String type, String alias, String number, String company, 
			String center, String product, AccountPtn accountPtn) {
		super(number, company, center, product);
		this.type = type;
		this.alias = alias;
		this.accountPtn = accountPtn;
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the alias
	 */
	public String getAlias() {
		return alias;
	}

	/**
	 * @param alias the alias to set
	 */
	public void setAlias(String alias) {
		this.alias = alias;
	}

	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}

	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}

	/**
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}

	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	/**
	 * @return the accountPtn
	 */
	public AccountPtn getAccountPtn() {
		return accountPtn;
	}

	/**
	 * @param accountPtn the accountPtn to set
	 */
	public void setAccountPtn(AccountPtn accountPtn) {
		this.accountPtn = accountPtn;
	}
	
	/**
	 * @return the accountPtn
	 */
	public MnemoInformation getMnemoInformation() {
		return mnemoInformation;
	}

	/**
	 * @param accountPtn the accountPtn to set
	 */
	public void setMnemoInformation(MnemoInformation mnemoInformation) {
		this.mnemoInformation = mnemoInformation;
	}
	
}
