package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * OutputSat002506.java
 *
 * @author laujim
 *
 */
@Getter
@Setter
public class OutputSat001610 {
	//OUTPUT DATA

	// String(4)
	private List<String> idcent;

	// String(4)
	private List<String> idempr;

	// String(4)
	private List<String> usulargo;

	// String(4)
	private List<String> usua;

}