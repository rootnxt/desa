package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * The OutputHeader model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class OutputHeader implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The data. */
    private Data data;

    /** The channel. */
    private String channel;

}
