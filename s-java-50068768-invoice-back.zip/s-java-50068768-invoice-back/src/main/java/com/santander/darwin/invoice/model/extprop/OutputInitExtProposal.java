package com.santander.darwin.invoice.model.extprop;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class OutputInitExtProposal.
 */
@Getter
@Setter
public class OutputInitExtProposal {
	
	/** The limit output. */
	private String url;
}
