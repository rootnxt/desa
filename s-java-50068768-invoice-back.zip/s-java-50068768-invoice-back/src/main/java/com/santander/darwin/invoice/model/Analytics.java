package com.santander.darwin.invoice.model;

import java.math.BigDecimal;

/**
 * Analytics
 * 
 * @author igndom
 *
 */
public class Analytics {

	/* The user Id.*/
	private String userId;
	
	/* The user Id.*/
	private String personCode;
	
	/* The person Type. */
	private String personType;
	
	/* The product. */
	private String product;
	
	/* The product Ref. */
	private String productRef;
	
	/* The state. */
	private String state;
	
	/* The total. */
	private BigDecimal total;
	
	/* The tipology.*/
	private String typology;
	
	/* The tin. */
	private String tin;
	
	/* The tae. */
	private String tae;
	
	/* The amount. */
	private String amount;
	
	/* The term. */
	private int term;

	/**
	 * Get Tin.
	 * 
	 * @return String
	 */
	public String getTin() {
		return tin;
	}

	/**
	 * Set Tin.
	 * 
	 * @param tin String
	 */
	public void setTin(String tin) {
		this.tin = tin;
	}

	/**
	 * Get tae. 
	 * 
	 * @return tae String
	 */
	public String getTae() {
		return tae;
	}

	/**
	 * Set tae.
	 * 
	 * @param tae String
	 */
	public void setTae(String tae) {
		this.tae = tae;
	}

	/**
	 * Get amount. 
	 * @return amount String
	 */
	
	public String getAmount() {
		return amount;
	}

	/**
	 * Set amount.
	 * @param amount String
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the personCode
	 */
	public String getPersonCode() {
		return personCode;
	}
	/**
	 * @param personCode the personCode to set
	 */
	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}
	/**
	 * @return the personType
	 */
	public String getPersonType() {
		return personType;
	}
	/**
	 * @param personType the personType to set
	 */
	public void setPersonType(String personType) {
		this.personType = personType;
	}
	/**
	 * @return the product
	 */
	public String getProduct() {
		return product;
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(String product) {
		this.product = product;
	}
	/**
	 * @return the total
	 */
	public BigDecimal getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	/**
	 * @return the typology
	 */
	public String getTypology() {
		return typology;
	}
	/**
	 * @param typology the typology to set
	 */
	public void setTypology(String typology) {
		this.typology = typology;
	}

    /**
     * Get productRef.
     * 
     * @return productRef
     */
	public String getProductRef() {
		return productRef;
	}

	/**
	 * Set productRef
	 * @param productRef
	 */
	public void setProductRef(String productRef) {
		this.productRef = productRef;
	}

	/**
	 * Get State
	 * @return String
	 */
	public String getState() {
		return state;
	}

	/**
	 * Set state.
	 * @param state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Get term.
	 * @return int
	 */
	public int getTerm() {
		return term;
	}

	/**
	 * Set term
	 * @param term int
	 */
	public void setTerm(int term) {
		this.term = term;
	}
}
