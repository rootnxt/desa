package com.santander.darwin.invoice.model.document;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * InsertDocumentInput.java
 *
 * @author igndom
 *
 */
public class InsertDocumentInput {

	@JsonProperty("sDoc")
	private String doc;
	private String typeDoc;
	private String attrs;

	/**
	 * @return the doc
	 */
	public String getDoc() {
		return doc;
	}

	/**
	 * @param doc the doc to set
	 */
	public void setDoc(String doc) {
		this.doc = doc;
	}

	/**
	 * @return the typeDoc
	 */
	public String getTypeDoc() {
		return typeDoc;
	}

	/**
	 * @param typeDoc the typeDoc to set
	 */
	public void setTypeDoc(String typeDoc) {
		this.typeDoc = typeDoc;
	}

	/**
	 * @return the attrs
	 */
	public String getAttrs() {
		return attrs;
	}

	/**
	 * @param attrs the attrs to set
	 */
	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}

}
