package es.santander.darwin.financiaciondigital.config;

import static com.santander.serenity.banksphere.data.partenon.model.TransactionExecutionMode.CHANNEL_GENERIC_USER;
import static com.santander.serenity.banksphere.data.partenon.model.TransactionExecutionMode.TOKEN_GENERIC_USER;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.WebApplicationContext;

import com.santander.serenity.banksphere.data.partenon.autoconfigure.core.PartenonAction;
import com.santander.serenity.banksphere.data.partenon.autoconfigure.core.PartenonAction.PartenonActionBuilder;
import com.santander.serenity.banksphere.data.partenon.model.KeyRequestHeaders;
import com.santander.serenity.banksphere.data.partenon.model.PartenonHeader;
import com.santander.serenity.banksphere.data.partenon.model.TransactionExecutionMode;
import com.santander.serenity.banksphere.data.partenon.sat.model.SatExecutionMode;

import es.santander.darwin.financiaciondigital.lib.config.PartenonActionConfig;
import es.santander.darwin.financiaciondigital.lib.config.PartenonSatActionConfig;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class PartenonConfig.
 */
@Configuration
@Slf4j
public class ChannelConfig {

    /** The execution mode. */
    @Value("${partenon.execution-mode}")
    private TransactionExecutionMode executionMode;

    /** The user. */
    @Value("${partenon.user}")
    private String user;

    /** The execution mode. */
    @Value("${sat.executionMode}")
    private SatExecutionMode satExecutionMode;

    /** The entity. */
    @Value("${channel.config.entity}")
    private String entity;

    /** The center. */
    @Value("${channel.config.center}")
    private String center;

    /** The physical channel. */
    @Value("${channel.config.physicalChannel}")
    private String physicalChannel;

    /**
     * Gets the partenon action config.
     *
     * @return the partenon action config
     */
    @Bean
    @Qualifier("partenon-action")
    @Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public PartenonActionConfig getPartenonActionConfig() {
        return new PartenonActionConfig(buildPartenonAction());
    }
    
    /**
     * Gets the partenon action config thread safe.
     *
     * @return the partenon action config thread safe
     */
    @Bean
    @Qualifier("partenon-action-threadsafe")
    @Scope(scopeName = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public PartenonActionConfig getPartenonActionConfigThreadSafe() {
        return new PartenonActionConfig(buildPartenonAction());
    }
    

    /**
     * Gets the partenon sat action config.
     *
     * @return the partenon sat action config
     */
    @Bean
    @Qualifier("partenon-sat-action")
    @Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public PartenonSatActionConfig getPartenonSatActionConfig() {
        return new PartenonSatActionConfig(new PartenonAction.PartenonActionBuilder()
                .setMode(null != satExecutionMode ? satExecutionMode : CHANNEL_GENERIC_USER)
                .addInfo(getAdditionalInfo()).build());
    }

    /**
     * Builds the partenon action.
     *
     * @return the partenon action
     */
    private PartenonAction buildPartenonAction() {

        PartenonActionBuilder builder = new PartenonAction.PartenonActionBuilder();
        builder.setMode(null != executionMode ? executionMode : TOKEN_GENERIC_USER)
                .addInfo(KeyRequestHeaders.INTERNETUSER, user);

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String jwtToken = (String) auth.getCredentials();
        builder.setTokenBKS(jwtToken);
        log.info("token estructural:" + jwtToken);

        return builder.build();

    }

    /**
     * Gets the additional info.
     *
     * @return the additional info
     */
    private Map<PartenonHeader, String> getAdditionalInfo() {
        Map<PartenonHeader, String> additionalInfo = new HashMap<>();
        additionalInfo.put(KeyRequestHeaders.ENTITY, entity);
        additionalInfo.put(KeyRequestHeaders.CENTER, center);
        additionalInfo.put(KeyRequestHeaders.PHYSICALCHANNEL, physicalChannel);
        return additionalInfo;
    }

}