package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * The Class InterestRate.
 */

/**
 * Sets the audit.
 *
 * @param audit the new audit
 */
@Setter

/**
 * Gets the audit.
 *
 * @return the audit
 */
@Getter

/**
 * Instantiates a new interest rate.
 */
@NoArgsConstructor
public class InterestRate {
    
    /** The term. */
    private Term term;
    
    /** The deficiency term. */
    private Term deficiencyTerm;
    
    /** The technical deficiency date. */
    private String technicalDeficiencyDate;
    
    /** The annual percentage rate. */
    private BigDecimal annualPercentageRate;
    
    /** The maximum annual percentage rate. */
    private BigDecimal maximumAnnualPercentageRate;
    
    /** The maximum opening commission rate. */
    private BigDecimal maximumOpeningCommissionRate;
    
    /** The funding cost. */
    private BigDecimal fundingCost;
    
    /** The minimum differential rate. */
    private BigDecimal minimumDifferentialRate;
    
    /** The maximum differential rate. */
    private BigDecimal maximumDifferentialRate;
    
    /** The audit. */
    private Audit audit;
}
