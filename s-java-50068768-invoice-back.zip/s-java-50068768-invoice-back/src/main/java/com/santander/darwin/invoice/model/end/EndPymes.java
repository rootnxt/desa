package com.santander.darwin.invoice.model.end;

import lombok.Getter;
import lombok.Setter;

/**
 * EndPymes.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class EndPymes extends End {

	//Atributos de la clase
	private boolean pymes;
	
	// Texto parametrizable en pantallas finales
	private TextEnd texts;

}
