package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * RefinancedContractData.java
 *
 * @author igndom
 *
 */
public class RefinancedContractData {

	private String productType;
	private String refinancedContractAccount;
	private Double pendingCapital;
	private Double paidAmount;
	private Double tin;
	private Double unpaidFeeImport;
	private Double unpaidDelayImport;
	private Double mailExpenses;
	private Double debtorPositionsExpenses;
	private Double unpaidCapital;
	private Double unpaidComissions;
	private Double ordinaryUnpaidInterests;
	

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the refinancedContractAccount
	 */
	public String getRefinancedContractAccount() {
		return refinancedContractAccount;
	}

	/**
	 * @param refinancedContractAccount the refinancedContractAccount to set
	 */
	public void setRefinancedContractAccount(String refinancedContractAccount) {
		this.refinancedContractAccount = refinancedContractAccount;
	}

	/**
	 * @return the pendingCapital
	 */
	public Double getPendingCapital() {
		return pendingCapital;
	}

	/**
	 * @param pendingCapital the pendingCapital to set
	 */
	public void setPendingCapital(Double pendingCapital) {
		this.pendingCapital = pendingCapital;
	}

	/**
	 * @return the paidAmount
	 */
	public Double getPaidAmount() {
		return paidAmount;
	}

	/**
	 * @param paidAmount the paidAmount to set
	 */
	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}

	/**
	 * @return the tin
	 */
	public Double getTin() {
		return tin;
	}

	/**
	 * @param tin the tin to set
	 */
	public void setTin(Double tin) {
		this.tin = tin;
	}
	
	/**
	 * @return the unpaidFeeImport
	 */
	public Double getUnpaidFeeImport() {
		return unpaidFeeImport;
	}

	/**
	 * @param unpaidFeeImport the unpaidFeeImport to set
	 */
	public void setUnpaidFeeImport(Double unpaidFeeImport) {
		this.unpaidFeeImport = unpaidFeeImport;
	}
	
	/**
	 * @return the unpaidDelayImport
	 */
	public Double getUnpaidDelayImport() {
		return unpaidDelayImport;
	}

	/**
	 * @param unpaidDelayImport the unpaidDelayImport to set
	 */
	public void setUnpaidDelayImport(Double unpaidDelayImport) {
		this.unpaidDelayImport = unpaidDelayImport;
	}

	/**
	 * @return the mailExpenses
	 */
	public Double getMailExpenses() {
		return mailExpenses;
	}

	/**
	 * @param mailExpenses the mailExpenses to set
	 */
	public void setMailExpenses(Double mailExpenses) {
		this.mailExpenses = mailExpenses;
	}
	
	/**
	 * @return the debtorPositionsExpenses
	 */
	public Double getDebtorPositionsExpenses() {
		return debtorPositionsExpenses;
	}

	/**
	 * @param debtorPositionsExpenses the debtorPositionsExpenses to set
	 */
	public void setDebtorPositionsExpenses(Double debtorPositionsExpenses) {
		this.debtorPositionsExpenses = debtorPositionsExpenses;
	}
	
	/**
	 * @return the unpaidCapital
	 */
	public Double getUnpaidCapital() {
		return unpaidCapital;
	}

	/**
	 * @param unpaidCapital the unpaidCapital to set
	 */
	public void setUnpaidCapital(Double unpaidCapital) {
		this.unpaidCapital = unpaidCapital;
	}
	
	/**
	 * @return the unpaidComissions
	 */
	public Double getUnpaidComissions() {
		return unpaidComissions;
	}

	/**
	 * @param unpaidComissions the unpaidComissions to set
	 */
	public void setUnpaidComissions(Double unpaidComissions) {
		this.unpaidComissions = unpaidComissions;
	}

	/**
	 * @return the ordinaryUnpaidInterests
	 */
	public Double getOrdinaryUnpaidInterests() {
		return ordinaryUnpaidInterests;
	}

	/**
	 * @param ordinaryUnpaidInterests the ordinaryUnpaidInterests to set
	 */
	public void setOrdinaryUnpaidInterests(Double ordinaryUnpaidInterests) {
		this.ordinaryUnpaidInterests = ordinaryUnpaidInterests;
	}
}
