package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InputTransactionA293A
 * 
 * @author luis.lopez
 *
 */

@Getter
@Setter
public class InputTransactionA293A {

//INPUT DATA

	/**
	 * Codigo de divisa
	 * Partenon alphanumeric (A) - Length (3)
	 */
	public String codivisa;

	/**
	 * Codigo de persona
	 * Partenon unsigned numeric (N) - Length (9,0)
	 */
	public BigDecimal codpers;

	/**
	 * Subtipo de producto
	 * Partenon alphanumeric (A) - Length (3)
	 */
	public String codsprod;

	/**
	 * Codigo tarifa aplicar
	 * Partenon alphanumeric (A) - Length (3)
	 */
	public String codtarap;

	/**
	 * Codigo tarifa excepcion
	 * Partenon alphanumeric (A) - Length (3)
	 */
	public String codtarex;

	/**
	 * Codigo de estandar de referencia
	 * Partenon alphanumeric (A) - Length (7)
	 */
	public String coestref;

	/**
	 * Comision anualizada de operaciones en moneda nacinal
	 * Partenon unsigned numeric (N) - Length (9,6)
	 */
	public BigDecimal comises;

	/**
	 * Diferencial inicial
	 * Partenon signed numeric (L) - Length (10,6)
	 */
	public BigDecimal diferini;

	/**
	 * Diferencial
	 * Partenon signed numeric (L) - Length (10,6)
	 */
	public BigDecimal difernci;

	/**
	 * Edad actuarial
	 * Partenon unsigned numeric (N) - Length (2,0)
	 */
	public BigDecimal edadact;

	/**
	 * Codigo de centro.
	 * Partenon alphanumeric (A) - Length (4)
	 */
	public String idcent;

	/**
	 * Identificador de empresa
	 * Partenon alphanumeric (A) - Length (4)
	 */
	public String idempr;

	/**
	 * Codigo de producto del contrato
	 * Partenon alphanumeric (A) - Length (3)
	 */
	public String idprod;

	/**
	 * Importe operación
	 * Partenon signed numeric (L) - Length (16,2)
	 */
	public BigDecimal imopece;

	/**
	 * Indicador de pantalla
	 * Partenon alphanumeric (A) - Length (1)
	 */
	public String indicad1;

	/**
	 * Entidad del tipo de mensaje
	 * Partenon alphanumeric (A) - Length (4)
	 */
	public String indmen1e;

	/**
	 * Indicador seguros riesgo
	 * Partenon alphanumeric (A) - Length (1)
	 */
	public String indsegri;

	/**
	 * Plazo de liquidacion
	 * Partenon unsigned numeric (N) - Length (5,0)
	 */
	public BigDecimal plazoclq;

	/**
	 * Porcentaje de participacion
	 * Partenon signed numeric (L) - Length (10,6)
	 */
	public BigDecimal porcepar;

	/**
	 * Porcentaje sobre el saldo medio que imponeel limite superior del tramo de franqu
	 * Partenon signed numeric (L) - Length (10,6)
	 */
	public BigDecimal porimfra;

	/**
	 * Por. inc. ayuda
	 * Partenon signed numeric (L) - Length (10,6)
	 */
	public BigDecimal porincra;

	/**
	 * Tipo de concepto.
	 * Partenon alphanumeric (A) - Length (1)
	 */
	public String tipconce;

	/**
	 * Tipo de persona (f=fisica, j=juridica)
	 * Partenon alphanumeric (A) - Length (1)
	 */
	public String tipopers;

}
