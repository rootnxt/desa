package com.santander.darwin.invoice.model;

import lombok.Data;


/**
 * Instantiates a new link.
 */
@Data
public class Link {

	/** The href. */
	private String href;
}
