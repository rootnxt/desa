package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * ConfirmingOperation.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ConfirmingOperation {
	// Datos de ConfirmingOperation
	private List<AccountDetail> accountDetails;
	private Object contactPoint;
}