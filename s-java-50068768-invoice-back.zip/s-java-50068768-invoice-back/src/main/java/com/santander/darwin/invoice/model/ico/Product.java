package com.santander.darwin.invoice.model.ico;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Product.
 */

/**
 * Sets the subproduct.
 *
 * @param subproduct the new subproduct
 */
@Setter

/**
 * Gets the subproduct.
 *
 * @return the subproduct
 */
@Getter

/**
 * Instantiates a new product.
 */
@NoArgsConstructor
public class Product {
    
    /** The product id. */
    private String productId;
    
    /** The name. */
    private String name;
    
    /** The subproduct. */
    private SubProduct subproduct;
}
