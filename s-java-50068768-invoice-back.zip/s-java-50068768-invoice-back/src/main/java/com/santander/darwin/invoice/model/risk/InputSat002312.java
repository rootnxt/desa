package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.List;

/**
 * InputSat002312.java
 *
 * @author igndom
 *
 */
public class InputSat002312 {

	private List<String> anoprop;
	private List<String> idcent;
	private List<String> idempr;
	private List<BigDecimal> numprop;
	private List<String> sxvalue;
	private String codProd;
	private String codSubProd;
	private String codReferencia;
	private BigDecimal impFacturas;

	/**
	 * @return the anoprop
	 */
	public List<String> getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(List<String> anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the idcent
	 */
	public List<String> getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(List<String> idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public List<String> getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(List<String> idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the numprop
	 */
	public List<BigDecimal> getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(List<BigDecimal> numprop) {
		this.numprop = numprop;
	}

	/**
	 * @return the sxvalue
	 */
	public List<String> getSxvalue() {
		return sxvalue;
	}

	/**
	 * @param sxvalue the sxvalue to set
	 */
	public void setSxvalue(List<String> sxvalue) {
		this.sxvalue = sxvalue;
	}

	/**
	 * @return the codProd
	 */
	public String getCodProd() {
		return codProd;
	}

	/**
	 * @param codProd the codProd to set
	 */
	public void setCodProd(String codProd) {
		this.codProd = codProd;
	}

	/**
	 * @return the codSubProd
	 */
	public String getCodSubProd() {
		return codSubProd;
	}

	/**
	 * @param codSubProd the codSubProd to set
	 */
	public void setCodSubProd(String codSubProd) {
		this.codSubProd = codSubProd;
	}

	/**
	 * @return the codReferencia
	 */
	public String getCodReferencia() {
		return codReferencia;
	}

	/**
	 * @param codReferencia the codReferencia to set
	 */
	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}

	/**
	 * @return the impFacturas
	 */
	public BigDecimal getImpFacturas() {
		return impFacturas;
	}

	/**
	 * @param impFacturas the impFacturas to set
	 */
	public void setImpFacturas(BigDecimal impFacturas) {
		this.impFacturas = impFacturas;
	}

}
