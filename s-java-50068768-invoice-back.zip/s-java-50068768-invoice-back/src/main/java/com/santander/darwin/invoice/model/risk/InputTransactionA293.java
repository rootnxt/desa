package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * InputTransactionA293.java
 *
 * @author igndom
 *
 */
public class InputTransactionA293 {

	private String codivisa;
	private BigDecimal codpers;
	private String codsprod;
	private String coestref;
	private String idcent;
	private String idempr;
	private String idprod;
	private BigDecimal imopece;
	private String indproce;
	private BigDecimal plazoclq;
	private BigDecimal porcepar;
	private String tipopers;

	/**
	 * @return the codivisa
	 */
	public String getCodivisa() {
		return codivisa;
	}

	/**
	 * @param codivisa the codivisa to set
	 */
	public void setCodivisa(String codivisa) {
		this.codivisa = codivisa;
	}

	/**
	 * @return the codpers
	 */
	public BigDecimal getCodpers() {
		return codpers;
	}

	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(BigDecimal codpers) {
		this.codpers = codpers;
	}

	/**
	 * @return the codsprod
	 */
	public String getCodsprod() {
		return codsprod;
	}

	/**
	 * @param codsprod the codsprod to set
	 */
	public void setCodsprod(String codsprod) {
		this.codsprod = codsprod;
	}

	/**
	 * @return the coestref
	 */
	public String getCoestref() {
		return coestref;
	}

	/**
	 * @param coestref the coestref to set
	 */
	public void setCoestref(String coestref) {
		this.coestref = coestref;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the idprod
	 */
	public String getIdprod() {
		return idprod;
	}

	/**
	 * @param idprod the idprod to set
	 */
	public void setIdprod(String idprod) {
		this.idprod = idprod;
	}

	/**
	 * @return the imopece
	 */
	public BigDecimal getImopece() {
		return imopece;
	}

	/**
	 * @param imopece the imopece to set
	 */
	public void setImopece(BigDecimal imopece) {
		this.imopece = imopece;
	}

	/**
	 * @return the indproce
	 */
	public String getIndproce() {
		return indproce;
	}

	/**
	 * @param indproce the indproce to set
	 */
	public void setIndproce(String indproce) {
		this.indproce = indproce;
	}

	/**
	 * @return the plazoclq
	 */
	public BigDecimal getPlazoclq() {
		return plazoclq;
	}

	/**
	 * @param plazoclq the plazoclq to set
	 */
	public void setPlazoclq(BigDecimal plazoclq) {
		this.plazoclq = plazoclq;
	}

	/**
	 * @return the porcepar
	 */
	public BigDecimal getPorcepar() {
		return porcepar;
	}

	/**
	 * @param porcepar the porcepar to set
	 */
	public void setPorcepar(BigDecimal porcepar) {
		this.porcepar = porcepar;
	}

	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}

	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}

}
