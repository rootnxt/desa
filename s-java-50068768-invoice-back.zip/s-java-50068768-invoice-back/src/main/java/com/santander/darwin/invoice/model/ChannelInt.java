package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

/**
 * InvoiceApp
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class ChannelInt {

	//Atributos de la clase

	@Id
	private String id;
	
	// mvp
	private String msg;

	/**
	 * Constructor
	 * @param msg the msg
	 */
	public ChannelInt(String msg) {
		this.msg = msg;
	}
}