package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Entrada el codigo de persona
 * 
 * @author josdon
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ClientAddressListInput {
	
	//Atributos de la case
	private String canalc;

	//Listado de codigos
	private List<BigDecimal> codpers;
	
	private String idempr;
	private String indcon;
	
	//Listado de tipos
	private List<String> tipopers;
	
}
