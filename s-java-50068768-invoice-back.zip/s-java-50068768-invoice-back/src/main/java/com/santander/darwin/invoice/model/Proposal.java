package com.santander.darwin.invoice.model;

import com.santander.darwin.invoice.model.hiring.PreformalizationInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Proposal.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Proposal {

	// Primer bloque variables
	private String contract;
	private String company;
	private String center;
	// Segundo bloque variables
	private BigDecimal number;
	private String year;
	private String indGesto;
	// Tercer bloque variables
	private String coddig;
	// DAtos fechas y dia pago
	private PreformalizationInfo preformalizationInfo;
}
