package es.santander.darwin.financiaciondigital.domain;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the consolidado dto
 */
@Builder

/**
 * Instantiates a new consolidado dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new consolidado dto.
 *
 * @param ultimaFecha the ultima fecha
 * @param codigoIdentificacionPers the codigo identificacion pers
 * @param persona the persona
 * @param grupo the grupo
 * @param listaResumen the lista resumen
 * @param mensajeError the mensaje error
 * @param codError the cod error
 */
@AllArgsConstructor
public class ConsolidadoDto {
    
    /** The ultima fecha. */
    private String ultimaFecha;
    
    /** The codigo identificacion pers. */
    private String codigoIdentificacionPers;
    
    /** The persona. */
    private Persona persona;
    
    /** The grupo. */
    private String grupo;
    
    /** The lista resumen response. */
    private ArrayList<ListaResumenResponse> listaResumen;
    
    /** The mensaje error. */
    private String mensajeError;
    
    /** The cod error. */
    private String codError;

}
