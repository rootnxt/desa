package com.santander.darwin.invoice.model.arm;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Data
 * 
 * @author igndom
 *
 */
@Getter
@Setter
public class Data {

	// mode
	private String mode;
	
	// finance
	private String finance;
	
	// comision
	private String comision;
	private Integer months;
	
	// invoices
	private List<InvoiceExtendsARM> invoices;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Data [mode=" + mode + ", finance=" + finance + ", comision=" + comision + ", months=" + months
				+ ", invoices=" + invoices + "]";
	}
}
