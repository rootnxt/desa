package com.santander.darwin.invoice.model.impresion;

import lombok.Getter;
import lombok.Setter;

/**
 * The Proposal class.
 * 
 *
 */
@Getter
@Setter
public class Proposal {
 
	/** The company. */
    private String company;
    
    /** The branch. */
    private String branch;
   
    /** The year. */
    private Integer year;
    
    /** The numProposal. */
    private Integer numProposal;
}
