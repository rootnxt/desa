package com.santander.darwin.invoice.model.header;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The Proposal model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class Proposal implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The company. */
    private String company;

    /** The center. */
    private String center;

    /** The year. */
    private String year;

    /** The number. */
    private BigDecimal number;

}
