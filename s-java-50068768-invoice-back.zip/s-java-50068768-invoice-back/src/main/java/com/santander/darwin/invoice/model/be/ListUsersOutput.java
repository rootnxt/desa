/**
 * 
 */
package com.santander.darwin.invoice.model.be;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Mapeo de la respuesta llamada banca electronica users
 * @author josdon
 *
 */
@Getter
@Setter
public class ListUsersOutput {
	
	// Listado de usuarios
	private List<UsersOutput> users;
	
	// Reposicionamiento
	private String reposition;
	

}
