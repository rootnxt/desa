package com.santander.darwin.invoice.model.model200;

import com.santander.darwin.invoice.model.Modal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * Model200Input
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Model200Input {

	// Datos personales
	@NotNull(message = "PERSONALDATANULL")
	private PersonalData personalData;
	// Datos economicos
	@NotNull(message = "ECONOMICDATANULL")
	private EconomicData economicData;
	// Tasas
	private TaxSummary taxSummary;
	// Notificaciones
	private boolean notifyCirbe;
	private boolean notifyAeat200;
	// AEAT
	private Modal modalAeat200;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}
