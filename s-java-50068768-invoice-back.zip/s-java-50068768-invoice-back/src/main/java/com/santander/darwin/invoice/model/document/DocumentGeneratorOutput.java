/**
 * 
 */
package com.santander.darwin.invoice.model.document;

/**
 * DocumentGeneratorOutput
 * 
 * @author josdon
 * 
 *         "urlDocumento":
 *         "http://doc1.pru.bsch/OUT/PIOL_BKS02004911170a66a40e230900.pdf",
 *         "printXML": xml de PI "documentBase64": churro en base 64
 *
 */
public class DocumentGeneratorOutput {

	private String urlDocumento;
	private String printXML;
	private String documentBase64;

	/**
	 * @return the urlDocumento
	 */
	public String getUrlDocumento() {
		return urlDocumento;
	}

	/**
	 * @param urlDocumento the urlDocumento to set
	 */
	public void setUrlDocumento(String urlDocumento) {
		this.urlDocumento = urlDocumento;
	}

	/**
	 * @return the printXML
	 */
	public String getPrintXML() {
		return printXML;
	}

	/**
	 * @param printXML the printXML to set
	 */
	public void setPrintXML(String printXML) {
		this.printXML = printXML;
	}

	/**
	 * @return the documentBase64
	 */
	public String getDocumentBase64() {
		return documentBase64;
	}

	/**
	 * @param documentBase64 the documentBase64 to set
	 */
	public void setDocumentBase64(String documentBase64) {
		this.documentBase64 = documentBase64;
	}

}
