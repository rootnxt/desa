package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the sasna response
 */
@Builder

/**
 * Instantiates a new sasna response.
 */
@NoArgsConstructor

/**
 * Instantiates a new sasna response.
 *
 * @param code the code
 * @param message the message
 */
@AllArgsConstructor
public class SasnaResponse {
    
    /** The code. */
    private String code;
    
    /** The message. */
    private String message;
    

}
