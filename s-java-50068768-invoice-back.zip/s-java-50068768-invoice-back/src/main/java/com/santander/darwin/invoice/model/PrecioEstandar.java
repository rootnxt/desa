package com.santander.darwin.invoice.model;

/**
 * PrecioEstandar.java
 *
 * @author igndom
 *
 */
public class PrecioEstandar {

	// AAAA_COCONCLI, AAAA_COPERCON, AAAA_TASA, AAAA_IMPORMI, AAAA_IMPORMA
	private String coconcli;
	private String copercon;
	private String tasa;
	private String imporMi;
	private String imporMa;
	private String codRefer;

	/**
	 * @return the coconcli
	 */
	public String getCoconcli() {
		return coconcli;
	}

	/**
	 * @param coconcli the coconcli to set
	 */
	public void setCoconcli(String coconcli) {
		this.coconcli = coconcli;
	}

	/**
	 * @return the copercon
	 */
	public String getCopercon() {
		return copercon;
	}

	/**
	 * @param copercon the copercon to set
	 */
	public void setCopercon(String copercon) {
		this.copercon = copercon;
	}

	/**
	 * @return the tasa
	 */
	public String getTasa() {
		return tasa;
	}

	/**
	 * @param tasa the tasa to set
	 */
	public void setTasa(String tasa) {
		this.tasa = tasa;
	}

	/**
	 * @return the imporMi
	 */
	public String getImporMi() {
		return imporMi;
	}

	/**
	 * @param imporMi the imporMi to set
	 */
	public void setImporMi(String imporMi) {
		this.imporMi = imporMi;
	}

	/**
	 * @return the imporMa
	 */
	public String getImporMa() {
		return imporMa;
	}

	/**
	 * @param imporMa the imporMa to set
	 */
	public void setImporMa(String imporMa) {
		this.imporMa = imporMa;
	}
	
	/**
	 * @return the tasa
	 */
	public String getCodRefer() {
		return codRefer;
	}

	/**
	 * @param codRefer the codRefer to set
	 */
	public void setCodRefer(String codRefer) {
		this.codRefer = codRefer;
	}

}
