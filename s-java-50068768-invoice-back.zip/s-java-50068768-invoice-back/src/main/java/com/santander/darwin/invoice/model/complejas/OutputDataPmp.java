package com.santander.darwin.invoice.model.complejas;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the level.
 *
 * @return the level
 */
@Getter

/**
 * Sets the level.
 *
 * @param level the new level
 */
@Setter
public class OutputDataPmp {
    
    /** The company. */
    private String company;
    
    /** The center. */
    private String center;
    
    /** The year. */
    private String year;
    
    /** The num proposal. */
    private int numProposal;
    
    /** The second company. */
    private String secondCompany;
    
    /** The second center. */
    private String secondCenter;
    
    /** The second year. */
    private String secondYear;
    
    /** The second num proposal. */
    private int secondNumProposal;
    
    /** The status. */
    private String status;
    
    /** The date. */
    private String date;
    
    /** The level. */
    private int level;
}
