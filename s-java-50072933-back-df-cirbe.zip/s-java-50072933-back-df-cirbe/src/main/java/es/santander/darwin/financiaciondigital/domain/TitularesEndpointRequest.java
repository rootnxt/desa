package es.santander.darwin.financiaciondigital.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RecoveryEndpointRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TitularesEndpointRequest {

	/** The person code. */
	private BigDecimal personCode;

	/** The person type. */
	private String personType;

	/** The source type. */
	private String sourceType;

	/** The source state. */
	private String sourceState;

	/** The criticality data. */
	private String criticalityData;

	/** The process indicator. */
	private String processIndicator;

}
