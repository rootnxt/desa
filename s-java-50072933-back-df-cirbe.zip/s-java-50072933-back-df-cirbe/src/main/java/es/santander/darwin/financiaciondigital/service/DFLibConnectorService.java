package es.santander.darwin.financiaciondigital.service;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataRequestVO;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;

/**
 * The Interface DCLibConnectorService.
 */
public interface DFLibConnectorService {

    /**
     * Gets the basic person data.
     *
     * @param request the request
     * @return the basic person data
     * @throws DigitalConsumptionServiceException the digital consumption service exception
     */
    BasicPersonDataResponseVO getBasicPersonData(BasicPersonDataRequestVO request)
            throws DigitalConsumptionServiceException;

}
