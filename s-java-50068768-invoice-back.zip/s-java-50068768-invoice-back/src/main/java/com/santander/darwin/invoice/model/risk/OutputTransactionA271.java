package com.santander.darwin.invoice.model.risk;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class OutputTransactionA271 {

    //OUTPUT DATA

    /**
     * Año
     * Partenon unsigned numeric (N) - Length (4,0)
     */
    public BigDecimal aaa;

    /**
     * Codigo empresa
     * Partenon unsigned numeric (N) - Length (4,0)
     */
    public BigDecimal cempresa;

    /**
     * Codigo de moneda
     * Partenon alphanumeric (A) - Length (3)
     */
    public String cmoneda;

    /**
     * Descripcion del codigo de moneda
     * Partenon alphanumeric (A) - Length (30)
     */
    public String dcodmone;

    /**
     * Descripcion dia habil adelantado o atrasado en fecha revision
     * Partenon alphanumeric (A) - Length (10)
     */
    public String descrdia;

    /**
     *
     * Partenon alphanumeric (A) - Length (30)
     */
    public List<String> desmon;

    /**
     * Fecha fin
     * Partenon date (D1) - Length (8)
     */
    public Date fechafi;

    /**
     * Descripcion codigo tipo de acceso
     * Partenon date (D1) - Length (8)
     */
    public List<Date> fecha2;

    /**
     * Fecha vencimiento garantia
     * Partenon date (D1) - Length (8)
     */
    public List<Date> fechvtog;

    /**
     * Fecha contable
     * Partenon date (D1) - Length (8)
     */
    public List<Date> fecontab;

    /**
     * Fecha de otorgamiento
     * Partenon date (D1) - Length (8)
     */
    public List<Date> fotorgam;

    /**
     * Codigo de centro contable
     * Partenon alphanumeric (A) - Length (4)
     */
    public List<String> idcentc;

    /**
     * Contrato contrato nuevo
     * Partenon alphanumeric (A) - Length (7)
     */
    public List<String> idcontnu;

    /**
     * Numero de contrato
     * Partenon alphanumeric (A) - Length (7)
     */
    public List<String> idcontr;

    /**
     * Empresa destinataria
     * Partenon alphanumeric (A) - Length (4)
     */
    public List<String> idemprc;

    /**
     * Codigo de producto del contrato
     * Partenon alphanumeric (A) - Length (3)
     */
    public List<String> idprod;

    /**
     * Codigo producto del contrato
     * Partenon alphanumeric (A) - Length (3)
     */
    public List<String> idprodc;

    /**
     * Importe abonos compensacion
     * Partenon signed numeric (L) - Length (16,2)
     */
    public List<BigDecimal> impabonc;

    /**
     * Indicador de pignoracion
     * Partenon alphanumeric (A) - Length (1)
     */
    public String indpig;

    /**
     * Indicador de la tabla de contratos asociada a este producto
     * Partenon alphanumeric (A) - Length (1)
     */
    public String indtabco;

    /**
     * Oficina de la tarjeta
     * Partenon alphanumeric (A) - Length (4)
     */
    public String oficinat;

    /**
     * Promun
     * Partenon alphanumeric (A) - Length (5)
     */
    public String promun;

    /**
     * Sw si el contrato esta abriendose o no
     * Partenon alphanumeric (A) - Length (1)
     */
    public List<String> swnuevo;

    /**
     * Codigo de relacion de reposicionamiento
     * Partenon alphanumeric (A) - Length (3)
     */
    public String zcodrela;

    /**
     * Cuenta de reposicionamiento convivencias sch
     * Partenon unsigned numeric (N) - Length (11,0)
     */
    public BigDecimal zcuent2;

    /**
     * Centro del contrato-recarga-
     * Partenon alphanumeric (A) - Length (4)
     */
    public String zdcentc;

    /**
     * Identificador de contrato
     * Partenon alphanumeric (A) - Length (7)
     */
    public String zdcontr;

    /**
     * Grupo de reposicionamiento convivencias sch
     * Partenon unsigned numeric (N) - Length (3,0)
     */
    public BigDecimal zdgrup2;

    /**
     * Producto del contrato-recarga-
     * Partenon alphanumeric (A) - Length (3)
     */
    public String zdprodc;

    /**
     * Fecha oculta
     * Partenon date (D1) - Length (8)
     */
    public Date zfecha;

    /**
     * Indicador de busqueda reposicionamiento
     * Partenon alphanumeric (A) - Length (1)
     */
    public String zindbusq;

    /**
     * Sucursal de reposicionamiento convivencias sch
     * Partenon unsigned numeric (N) - Length (5,0)
     */
    public BigDecimal zsucu2;
}