package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;


/**
 * The Customer model class.
 *
 * @Autor luis.lopez
 */
@Setter
@Getter
@NoArgsConstructor
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The entity. */
	private String entity;

    /** The customerType. */
    private String customerType;

    /** The customerCode. */
    private String customerCode;

    /**
     * Instantiates a new Customer object.
     *
     * @param customer the customer.
     */
    public Customer (Customer customer) {
        this.entity = customer.entity;
        this.customerType = customer.customerType;
        this.customerCode = customer.customerCode;
    }

}
