package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class ErrorMessagesConstants.
 */
public class ErrorMessagesConstants {

    /** The Constant ERROR_CODE_NO_ACCOUNT. */
    public static final String ERROR_CODE_NO_ACCOUNT = "errors.codes.noAccount";

    /** The Constant CODE_NOACREDITADO_CIRBEACTUALIZADA. */
    public static final String CODE_NOACREDITADO_CIRBEACTUALIZADA = "errors.code.noAcreditado.cirbeActualizada";

    /** The Constant MESSAGE_NOACREDITADO_CIRBEACTUALIZADA. */
    public static final String MESSAGE_NOACREDITADO_CIRBEACTUALIZADA = "messages.noAcreditado.cirbeActualizada";

    /** The Constant CODE_NOACREDITADO_CIRBENOACTUALIZADA. */
    public static final String CODE_NOACREDITADO_CIRBENOACTUALIZADA = "errors.code.noAcreditado.cirbeNoActualizada";

    /** The Constant MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA. */
    public static final String MESSAGE_NOACREDITADO_CIRBENOACTUALIZADA = "messages.noAcreditado.cirbeNoActualizada";

    /** The Constant CODE_ACREDITADO_CIRBENOACTUALIZADA. */
    public static final String CODE_ACREDITADO_CIRBENOACTUALIZADA = "errors.code.acreditado.cirbeNoActualizada";

    /** The Constant MESSAGE_ACREDITADO_CIRBENOACTUALIZADA. */
    public static final String MESSAGE_ACREDITADO_CIRBENOACTUALIZADA = "messages.acreditado.cirbeNoActualizada";

    /** The Constant ERROR_DETAILS_INPUT. */
    public static final String ERROR_DETAILS_INPUT = "errors.details.input";

    /** The Constant CODE_DETAILS_CIRBE_CONSOLIDADO. */
    public static final String CODE_DETAILS_CIRBE_CONSOLIDADO = "errors.code.cirbe.consolidado";

    /** The Constant ERROR_DETAILS_CIRBE_CONSOLIDADO. */
    public static final String ERROR_DETAILS_CIRBE_CONSOLIDADO = "errors.details.cirbe.consolidado";
    
    /** The Constant DETAILS_CIRBE_ALTA. */
    public static final String CODE_DETAILS_CIRBE_ALTA = "errors.code.cirbe.alta";

    /** The Constant ERROR_DETAILS_CIRBE_ALTA. */
    public static final String ERROR_DETAILS_CIRBE_ALTA = "errors.details.cirbe.alta";
    
    /** The Constant CODE_DETAILS_PERSONA. */
    public static final String CODE_DETAILS_PERSONA = "errors.code.details.persona";

    /** The Constant ERROR_DETAILS_PERSONA. */
    public static final String ERROR_DETAILS_PERSONA = "errors.details.persona";

    /** The Constant ERROR_DETAILS_PERSONA. */
    public static final String ERROR_EXPECTED_PERSONA = "errors.expected.persona";

    /** The Constant ERROR_DETAILS_TRXWS. */
    public static final String ERROR_DETAILS_TRXWS = "errors.details.trxWs";
    
    /** The Constant CODE_ERROR_RESIDENTE. */
    public static final String CODE_ERROR_RESIDENTE = "errors.code.residente";
    
    /** The Constant ERROR_DETAILS_RESIDENTE. */
    public static final String ERROR_DETAILS_RESIDENTE = "errors.details.residente";
    
    /** The Constant CODE_ERROR_PETICION_MAXIMA. */
    public static final String CODE_ERROR_PETICION_MAXIMA = "errors.code.peticionMaxima";
    
    /** The Constant ERROR_DETAILS_PETICION_MAXIMA. */
    public static final String ERROR_DETAILS_PETICION_MAXIMA = "errors.details.peticionMaxima";

    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_10 = "errors.code.sencol.sasna";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_20 = "errors.code.sencol.personrequests";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_30 = "errors.code.sencol.proposalpersonrequests";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_40 = "errors.code.sencol.proposalstate";
    
    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_CODE_SENCOL_50 = "errors.code.sencol.motor";

    /** The Constant ERROR_DETAIL_SENCOL_SASNA. */
    public static final String ERROR_DETAIL_SENCOL_SASNA = "errors.details.sencol.sasna"; 
    
    /** The Constant ERROR_DETAIL_SENCOL_MOTOR. */
    public static final String ERROR_DETAIL_SENCOL_MOTOR = "errors.details.sencol.motor";
    
    /** The Constant ERROR_DETAIL_SENCOL_PERSON_REQUESTS. */
    public static final String ERROR_DETAIL_SENCOL_PERSON_REQUESTS = "errors.details.sencol.personrequests";
 
    /** The Constant ERROR_DETAIL_SENCOL_PROPOSAL_STATE. */
    public static final String ERROR_DETAIL_SENCOL_PROPOSAL_STATE = "errors.details.sencol.proposalstate";

    /** The Constant ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS. */
    public static final String ERROR_DETAIL_SENCOL_PROPOSAL_PERSON_REQUESTS =
            "errors.details.sencol.proposalpersonrequests";

    /** The Constant ERROR_TIMEOUT_WEBSERVICETEMPLATE. */
    public static final String ERROR_TIMEOUT_WEBSERVICETEMPLATE = "Tiempo de espera superado para la operación.";

    /** The Constant ERROR_WEBSERVICE_TEMPLATE. */
    public static final String ERROR_WEBSERVICE_TEMPLATE = "Error en ejecución de webServiceTemplate";
    
    /** The Constant TIMEOUT_EXCEPTION. */
    public static final String TIMEOUT_EXCEPTION = "Timeout exception";
    
    /**
     * Instantiates a new error messages constants.
     */
    private ErrorMessagesConstants() {

    }

}
