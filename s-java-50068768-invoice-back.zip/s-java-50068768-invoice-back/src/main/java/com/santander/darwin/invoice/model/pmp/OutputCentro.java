package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * The
 * OutputCentro
 * Dto
 * model
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OutputCentro implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * idtipvia
     * */
    private String idtipvia;

    /**
     * nomvia
     * */
    private String nomvia;

    /**
     * numvia
     * */
    private String numvia;

    /**
     * nomplaz
     * */
    private String nomplaz;

    /**
     * distrito
     * */
    private String distrito;

    /**
     * centerId
     * */
    private String centerId;

    /**
     * selected
     */
    private boolean selected;

}
