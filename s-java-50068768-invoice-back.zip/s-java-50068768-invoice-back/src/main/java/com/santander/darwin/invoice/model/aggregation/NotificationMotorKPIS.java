package com.santander.darwin.invoice.model.aggregation;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * NotificationMotorKPIS.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class NotificationMotorKPIS {

	// Codigo empresa
	// Para swagger
	@Schema(example = "0049", description = "Company of proposal")
	private String companyId;
	// Codigo centro
	// Para swagger
	@Schema(example = "0075", description = "Center of proposal")
	private String centerId;
	// Año
	// Para swagger
	@Schema(example = "2021", description = "Year of proposal")
	private String proposalYear;
	// Número de propuesta
	// Para swagger
	@Schema(example = "0002", description = "Number of proposal")
	private String proposalNumber;
	
	//Estado 01-OK, 02-KO
	@Schema(example = "01", description = "State of agregation")
	private String state;

	//tipoPers
	private String tipoPers;

	//codPers
	private int codPers;

}