/**
 * 
 */
package com.santander.darwin.invoice.model.document;

/**
 * GuarantorDoc
 * 
 * @author josdon
 *
 */
public class GuarantorDoc extends Agent {

	// Direccion
	private String address;

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	

}
