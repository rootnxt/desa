package com.santander.darwin.invoice.exception;

import org.springframework.http.HttpStatus;

import java.util.UUID;

/**
 * ServiceException.java
 *
 * @author igndom
 *
 */
public class ServiceException extends GlobalException {

	private static final long serialVersionUID = -7361822941285793296L;
	private final String app;

	/**
	 * Constructor
	 *
	 * @param lang  String
	 * @param app   String
	 * @param param String
	 */
	public ServiceException(String lang, String app, boolean param) {
		super(lang);
		this.app = app;
	}

	/**
	 * Constructor
	 *
	 * @param code String
	 * @param lang String
	 * @param app  String
	 */
	public ServiceException(String code, String lang, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), String.valueOf(HttpStatus.UNPROCESSABLE_ENTITY.value()),
				code, lang);
		this.app = app;
	}

	/**
	 * Constructor
	 *
	 * @param code    String
	 * @param message String
	 * @param lang    String
	 * @param app     String
	 */
	public ServiceException(String code, String message, String lang, String app) {
		super(UUID.randomUUID(), System.currentTimeMillis(), String.valueOf(HttpStatus.UNPROCESSABLE_ENTITY.value()),
				code, message, lang);
		this.app = app;
	}

	/**
	 * @return the app
	 */
	public String getApp() {
		return app;
	}

}
