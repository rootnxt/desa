package com.santander.darwin.invoice.model.crisol;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * CrisolPricesOutput
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class CrisolPricesOutput {

	//Se declaran las variables
	private List<RecommendedPriceItem> recommendedPrice;
	

}
