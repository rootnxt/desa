/**
 * 
 */
package com.santander.darwin.invoice.model.heredo;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class ClaimFileCreationResponse.
 */

@Getter
@Setter
public class ClaimFileCreationResponse {
	
	/** The file version. */
	private String fileVersion;
	
	/** The file number. */
	private String fileNumber;

}
