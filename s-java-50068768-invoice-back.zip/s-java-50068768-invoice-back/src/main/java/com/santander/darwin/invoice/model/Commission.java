package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Commission
 * 
 * @author igndom
 *
 */
@Getter
@Setter
public class Commission extends CommonCommission {

	private List<Period> periods;
	/** Minimum Amount */
	private String minimumAmount;
	/** Maximum Amount */
	private String maximumAmount;

	/**
	 * Constructor
	 */
	public Commission() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param description String
	 * @param value       BigDecimal
	 */
	public Commission(String description, BigDecimal value) {
		super(description, value);
	}

	/**
	 * Constructor
	 * 
	 * @param id          String
	 * @param description String
	 * @param value       BigDecimal
	 */
	public Commission(String id, String description, BigDecimal value) {
		super(id, description, value);
	}
	/**
	 * Constructor
	 * 
	 * @param id          String
	 * @param description String
	 * @param value       BigDecimal
	 * @param refer       String
	 */
	public Commission(String id, String description, BigDecimal value, String refer) {
		super(id, description, value, refer);
	}
	/**
	 * Constructor
	 * 
	 * @param id          String
	 * @param description String
	 * @param value       BigDecimal
	 * @param refer       String
	 * @param codRefer    String
	 */
	public Commission(String id, String description, BigDecimal value, String refer, String codRefer) {
		super(id, description, value, refer, codRefer);
	}

}
