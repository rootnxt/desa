package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * ProposalPrice.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ProposalPrice {
	// Datos de ProposalPrice
	private ProposalId proposalId;
	private String applicationStateCode;
	private String applicationStateDescription;
	// Datos de ProposalPrice
	private ProductCatalog productCatalog;
	private Currency currency;
	private List<Concept> concepts;
}