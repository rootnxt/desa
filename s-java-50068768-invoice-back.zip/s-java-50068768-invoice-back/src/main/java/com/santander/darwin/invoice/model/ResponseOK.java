package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ResponseOK.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class ResponseOK {

	// Para swagger
	@Schema(example = "OK", description = "Code of response")
	// Code
	private String code;

	// Para swagger
	@Schema(example = "Success", description = "Message of response")
	// Message
	private String message;

}
