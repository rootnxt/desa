package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The CustomerContract class.
 * 
 *
 */
@Setter
@Getter
@NoArgsConstructor
public class CustomerContract {
	/** cdcontrn. */
    private String cdcontrn;
    
    /** cdprods. */
    private String cdprods;
    
    /** cdsprod. */
    private String cdsprod;
    
    /** codbanca. */
    private String codbanca;
    
    /** codidio. */
    private String codidio;
    
    /** codsucua. */
    private String codsucua;

    /** fecbaja. */
    private String fecbaja;
    
    /** fealtcon. */
    private String fealtcon;
    
    /** fecsitu. */
    private String fecsitu;
    
    /** formaint. */
    private String formaint;
    
    /** idtipenv. */
    private String idtipenv;
    
    /** idtipsop. */
    private String idtipsop;
    
    /** inddevol. */
    private String inddevol;
    
    /** indice2. */
    private int indice2;
    
    /** indniv1. */
    private String indniv1;
    
    /** nmdomici. */
    private int nmdomici;
    
    /** obligfir. */
    private String obligfir;
    
    /** ordint. */
    private int ordint;
    
    /** porcresb. */
    private double porcresb;
    
    /** sitrelco. */
    private String sitrelco;
    
    /** tipinter. */
    private String tipinter;
}
