package es.santander.darwin.financiaciondigital.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import es.santander.darwin.financiaciondigital.service.CiriteWsClient;

/**
 * The Class CiriteConfig.
 */
@Configuration
public class CiriteConfig {

    /** The default uri. */
    @Value("${darwin.webservices.cirite.resources.defaultEndpoint}")
    private String defaultUri;

    /** The custom marshaller. */
    @Autowired
    private Jaxb2Marshaller customMarshaller;

    /**
     * Gets the WS client.
     *
     * @return the WS client
     */
    @Bean
    public CiriteWsClient getCiriteWSClient() {
        CiriteWsClient clientWS = new CiriteWsClient();
        clientWS.setDefaultUri(defaultUri);
        clientWS.setMarshaller(customMarshaller);
        clientWS.setUnmarshaller(customMarshaller);
        return clientWS;
    }

}