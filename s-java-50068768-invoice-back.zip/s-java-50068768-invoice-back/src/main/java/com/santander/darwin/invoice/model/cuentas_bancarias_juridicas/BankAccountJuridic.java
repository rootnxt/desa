package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * BankAccountJuridic
 * 
 * @author igndom
 *
 */
public class BankAccountJuridic {

	private List<AccountList> accountList;
	private String signatureType;
	@JsonProperty("_links")
	private Links links;

	/**
	 * @return the accountList
	 */
	public List<AccountList> getAccountList() {
		return new ArrayList<>(accountList);
	}

	/**
	 * @param accountList the accountList to set
	 */
	public void setAccountList(List<AccountList> accountList) {
		this.accountList = new ArrayList<>(accountList);
	}

	/**
	 * @return the signatureType
	 */
	public String getSignatureType() {
		return signatureType;
	}

	/**
	 * @param signatureType the signatureType to set
	 */
	public void setSignatureType(String signatureType) {
		this.signatureType = signatureType;
	}

	/**
	 * @return the links
	 */
	public Links getLinks() {
		return links;
	}

	/**
	 * @param links the links to set
	 */
	public void setLinks(Links links) {
		this.links = links;
	}

}
