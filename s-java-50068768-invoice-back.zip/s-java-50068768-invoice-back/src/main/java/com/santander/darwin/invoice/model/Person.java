package com.santander.darwin.invoice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Person.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Person {
	
	//Atriburos de la clase

	// Para swagger
	@Schema(example = "47909521S", description = "Document number of person")
	// Vatiables identificadores de la persona
	@NotNull(message = "IVDOCUMENTNUMBERNULL")
	@NotEmpty(message = "IVDOCUMENTNUMBEREMPTY")
	@Size(message = "IVDOCUMENTNUMBERSIZE", min = 8, max = 9)
	private String documentNumber;

	// Para swagger
	@Schema(example = "JOSE MOURAS GARCIA", description = "Name of user")
	// Variable de nombre de usuario
	@NotNull(message = "IVNOMUSUARNULL")
	@NotEmpty(message = "IVNOMUSUAREMPTY")
	@Size(message = "IVNOMUSUARSIZE", min = 1, max = 128)
	private String nomusuar;
	
	// Para swagger
	@Schema(example = "F", description = "Person Type", hidden=true)
	// Variable tipo de persona
	private String personType;

	// Para swagger
	@Schema(example = "1234567", description = "Person Code", hidden=true)
	// Variable codigo de persona
	private int personCode;

	//Datos de firma
	@Schema(example = "true", description = "Sign", hidden=true)
	private boolean sign;
	// Id de firma
	@Schema(example = "1234567", description = "SignExpId", hidden=true)
	private String signExpId;

}
