package es.santander.darwin.financiaciondigital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.util.Date;
import java.util.EmptyStackException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.service.CiriteService;
import es.santander.darwin.financiaciondigital.service.CiriteWsClient;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequest;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifCiriteRequestResponse;
import es.santander.darwin.financiaciondigital.soap.entity.cirite.AltModifResponse;

/**
 * The Class CiriteServiceImplTest.
 */
public class CiriteServiceImplTest {

    /** The cirite client. */
    @Mock
    private CiriteWsClient ciriteClient;

    /** The cirite service. */
    @InjectMocks
    private CiriteService ciriteService = new CiriteServiceImpl();

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Call alta cirite test OK.
     *
     * @throws Exception the exception
     */
    @Test
    public void callAltaCiriteTestOK() throws Exception {
        
        BasicPersonDataResponseVO persona = new BasicPersonDataResponseVO();
        persona.setCodPaisN("uwu");
        persona.setCodPaisR("uwu");
        persona.setCodPers(new BigDecimal("200"));
        persona.setDateNac(new Date());
        persona.setDocumentCod("uwu");
        persona.setDocumentType("uwu");
        persona.setFullName("uwu");
        persona.setIdEmpr("0049");
        persona.setTipoPers("J");
        
        AltModifCiriteRequestResponse response = new AltModifCiriteRequestResponse();
        AltModifResponse value = new AltModifResponse();
        value.setCodigoRespuesta("uwu");
        value.setDescripcionRespuesta("uwu");
        response.setAltModifCiriteRequestResult(value);
        
        ReflectionTestUtils.setField(ciriteService, "endPoint", "uwu");
        
        doReturn(response).when(ciriteClient).executeSoapRequest(any(String.class), any(AltModifCiriteRequest.class));
        AltModifCiriteRequestResponse result = ciriteService.callAltaCirite(persona);
        assertNotNull(result);

    }
    
    /**
     * Call alta cirite test NOK.
     *
     * @throws Exception the exception
     */
    @Test(expected = DigitalConsumptionServiceException.class)
    public void callAltaCiriteTestNOK() throws Exception {
        
        BasicPersonDataResponseVO persona = new BasicPersonDataResponseVO();
        persona.setCodPaisN("uwu");
        persona.setCodPaisR("uwu");
        persona.setCodPers(new BigDecimal("200"));
        persona.setDateNac(new Date());
        persona.setDocumentCod("uwu");
        persona.setDocumentType("uwu");
        persona.setFullName("uwu");
        persona.setIdEmpr("0049");
        persona.setTipoPers("J");
        
        AltModifCiriteRequestResponse response = new AltModifCiriteRequestResponse();
        AltModifResponse value = new AltModifResponse();
        value.setCodigoRespuesta("uwu");
        value.setDescripcionRespuesta("uwu");
        response.setAltModifCiriteRequestResult(value);
        
        ReflectionTestUtils.setField(ciriteService, "endPoint", "uwu");
        
        doThrow(new EmptyStackException()).when(ciriteClient).executeSoapRequest(any(String.class), any(AltModifCiriteRequest.class));
        AltModifCiriteRequestResponse result = ciriteService.callAltaCirite(persona);
        assertNotNull(result);

    }

}
