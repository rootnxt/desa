package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InputTransactionA8CR
 * 
 * @author ciber
 *
 */
@Getter
@Setter
public class InputTransactionA8CR {

	// INPUT DATA
	/**
	 * Año de la propuesta Partenon alphanumeric (A) - Length (4)
	 */
    private String anoprop;
	/**
	 * Codigo de moneda Partenon alphanumeric (A) - Length (3)
	 */
    private String codmonsw;
	/**
	 * Indica si se ejecuta en ese dia el listado Partenon alphanumeric (A) - Length
	 * (1)
	 */
    private String ejecutar;
	/**
	 * Estandar de referencia Partenon alphanumeric (A) - Length (7)
	 */
    private String estrefa;
	/**
	 * Codigo de centro. Partenon alphanumeric (A) - Length (4)
	 */
    private String idcent;
	/**
	 * Identificador de empresa Partenon alphanumeric (A) - Length (4)
	 */
    private String idempr;
	/**
	 * Producto de la orden asociada Partenon alphanumeric (A) - Length (3)
	 */
    private String idproda;
	/**
	 * Subtipo de producto real al que esta asociado el ficticio Partenon
	 * alphanumeric (A) - Length (3)
	 */
    private String idsproda;
	/**
	 * Indicador de pestaña evaluada Partenon alphanumeric (A) - Length (2)
	 */
    private String indpesta;
	/**
	 * Nro.de secuencia de la propuesta Partenon unsigned numeric (N) - Length (5,0)
	 */
    private BigDecimal numprop;

}
