package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.Setter;

/**
 * Document.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class DocumentData {

	/** The code. */
	private String code;

	/** The code. */
	private String codeDig;

	/** The description. */
	private String description;

	/** The documentStatus. */
	private String documentStatus;

	/** The printingUser. */
	private String printingUser;

	/** The printingDate. */
	private String printingDate;

	/** The personName. */
	private String personName;

	/** The numPerson. */
	private String numPerson;

	/** The descTipoDoc. */
	private String descTipoDoc;

	/** The tipoDoc. */
	private String tipoDoc;

	/** The gnTipoDoc. */
	private String gnTipoDoc;

	/** The gnTipoDoc. */
	private String gnTipoDocDig;

	/** The gnId. */
	private String gnId;

	/** The reasonForRejection. */
	private String reasonForRejection;

	/** The uploadedDocumentName. */
	private String uploadedDocumentName;

	/** The sent. */
	private boolean sent;

	/** The originalFilename. */
	private String originalFilename;
	

	/**
	 * Constructor
	 *
	 */
	public DocumentData() {
		super();
	}

	/**
	 * Constructor
	 *
	 * @param code        String
	 * @param description String
	 */
	public DocumentData(String code, String description) {
		super();
		this.code = code;
		this.description = description;
	}

}
