package com.santander.darwin.invoice.model.campaigns;

import lombok.Getter;
import lombok.Setter;

/**
 * Campaign.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class Campaign {

	// Atributos de la clase
	private String campaignCode;
	
	// Familia
	private String triadFamily;
	private String channel;
	private String campaignType;
	private String preGrantedType;
	private String companyCode;
	private String personType;
	private String clientCode;
	
	// Fechas
	private String startEffectiveDate;
	private String endEffectiveDate;
	
	// Importes
	private Integer minImportCN;
	private Integer maxImportCN;
	private Integer factor;
	private String triad;
	private Integer maxOperationChannel;
	private Integer numberOperationsChannel;
	private Integer importAcu1;
	
	// Limites
	private Integer limitImport;
	private Integer limitTriad;
	private String currencyCode;
	
}
