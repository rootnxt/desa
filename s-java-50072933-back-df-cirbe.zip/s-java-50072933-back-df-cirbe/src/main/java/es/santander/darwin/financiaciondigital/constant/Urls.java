package es.santander.darwin.financiaciondigital.constant;

/**
 * The Class Urls.
 */
public class Urls {

    /** The Constant API_VERSION. */
    public static final String API_VERSION = "/api/v1";

    /** The Constant URL_SASNA. */
    public static final String URL_SASNA = API_VERSION + "/sasna/{personType}/{personCode}";

    /** The Constant URL_SENCOL. */
    public static final String URL_SENCOL = API_VERSION + "/sencol";
    
    public static final String URL_SENCOL_MOTOR = API_VERSION + "/sencolMotor";

    /**
     * Instantiates a new urls.
     */
    private Urls() {
        super();
    }

}
