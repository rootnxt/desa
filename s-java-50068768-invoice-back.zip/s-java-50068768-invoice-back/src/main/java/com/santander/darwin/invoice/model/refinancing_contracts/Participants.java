package com.santander.darwin.invoice.model.refinancing_contracts;

/**
 * Participants.java
 *
 * @author igndom
 *
 */
public class Participants {

	private String customerId;
	private String participantType;
	private String participantOrder;
	private String participantForm;
	private String dueDate;

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the participantType
	 */
	public String getParticipantType() {
		return participantType;
	}

	/**
	 * @param participantType the participantType to set
	 */
	public void setParticipantType(String participantType) {
		this.participantType = participantType;
	}

	/**
	 * @return the participantOrder
	 */
	public String getParticipantOrder() {
		return participantOrder;
	}

	/**
	 * @param participantOrder the participantOrder to set
	 */
	public void setParticipantOrder(String participantOrder) {
		this.participantOrder = participantOrder;
	}

	/**
	 * @return the participantForm
	 */
	public String getParticipantForm() {
		return participantForm;
	}

	/**
	 * @param participantForm the participantForm to set
	 */
	public void setParticipantForm(String participantForm) {
		this.participantForm = participantForm;
	}

	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

}
