package com.santander.darwin.invoice.model.common;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * the OutputPerson class.
 *
 *
 */

@Setter
@Getter
@NoArgsConstructor
public class OutputPerson implements Serializable {
private static final long serialVersionUID = 1L;

	/** The tipdocps. */
	private String tipdocps;
	
	/** The coddocps. */
	private String coddocps;
	
	/** The nomper73. */
	private String nomper73;

}
