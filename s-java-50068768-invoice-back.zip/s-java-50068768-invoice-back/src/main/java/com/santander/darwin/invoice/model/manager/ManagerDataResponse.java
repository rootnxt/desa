package com.santander.darwin.invoice.model.manager;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ManagerData.
 */

/**
 * Gets the office.
 *
 * @return the office
 */
@Getter

/**
 * Sets the data.
 *
 * @param data
 *            the new data
 */
@Setter
/**
 * Instantiates a new manager data.
 */
@NoArgsConstructor
public class ManagerDataResponse {

    /** The user. */
    private String user;

    /** The code. */
    private String code;

    /** The name. */
    private String name;

    /** The surnames. */
    private String surnames;

    /** The phone. */
    private String phone;

    /** The ocu. */
    private String ocu;

    /** The ocu desc. */
    private String ocuDesc;

    /** The role. */
    private String role;

    /** The role desc. */
    private String roleDesc;

    /** The mail. */
    private String mail;

    /** The office. */
    private Office office;

}
