/**
 * 
 */
package com.santander.darwin.invoice.model.risk;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Gets the dplazocl.
 *
 * @return the dplazocl
 */
@Getter

/**
 * Sets the dplazocl.
 *
 * @param dplazocl the new dplazocl
 */
@Setter

public class OutputSat002276 {

	//OUTPUT DATA

	/** The la 1 impdo. */
	//BigDecimal(15, 2)
	private List<BigDecimal> la1impdo;

	/** The codmonsw. */
	//String(3)
	private List<String> codmonsw;

	/** The a 1 lit 13. */
	//String(13)
	private List<String> a1lit13;

	/** The a 1 lit 25. */
	//String(25)
	private List<String> a1lit25;

	/** The pnplazo. */
	//BigDecimal(3, 0)
	private List<BigDecimal> pnplazo;

	/** The indplazo. */
	//String(1)
	private List<String> indplazo;

	/** The coestref. */
	//String(7)
	private List<String> coestref;

	/** The plazodoc. */
	//BigDecimal(3, 0)
	private List<BigDecimal> plazodoc;

	/** The inplazco. */
	//String(1)
	private List<String> inplazco;

	/** The npercarc. */
	//BigDecimal(3, 0)
	private List<BigDecimal> npercarc;

	/** The npercain. */
	//BigDecimal(3, 0)
	private List<BigDecimal> npercain;

	/** The tipdesti. */
	//String(2)
	private List<String> tipdesti;

	/** The comfina 1. */
	//String(40)
	private List<String> comfina1;

	/** The comfina 2. */
	//String(40)
	private List<String> comfina2;

	/** The timestam. */
	//String(26)
	private List<String> timestam;

	/** The codcesta. */
	//String(4)
	private List<String> codcesta;

	/** The nomcesta. */
	//String(50)
	private List<String> nomcesta;

	/** The dpmoneda. */
	//String(30)
	private List<String> dpmoneda;

	/** The descri 04. */
	//String(15)
	private List<String> descri04;

	/** The desprod. */
	//String(254)
	private List<String> desprod;

	/** The accion. */
	//String(1)
	private List<String> accion;

	/** The accion 1. */
	//String(1)
	private List<String> accion1;

	/** The a 1 annopz. */
	//String(4)
	private List<String> a1annopz;

	/** The a 1 centrz. */
	//String(4)
	private List<String> a1centrz;

	/** The a 1 emprez. */
	//String(4)
	private List<String> a1emprez;

	/** The centroc. */
	//String(4)
	private List<String> centroc;

	/** The cnumeric. */
	//BigDecimal(5, 0)
	private List<BigDecimal> cnumeric;

	/** The cotperio. */
	//String(1)
	private List<String> cotperio;

	/** The cotrepro. */
	//String(2)
	private List<String> cotrepro;

	/** The cproduct. */
	//String(3)
	private List<String> cproduct;

	/** The emprma. */
	//String(4)
	private List<String> emprma;

	/** The indicad 1. */
	//String(1)
	private List<String> indicad1;

	/** The indrtpr. */
	//String(1)
	private List<String> indrtpr;

	/** The nuuniper. */
	//BigDecimal(3, 0)
	private List<BigDecimal> nuuniper;

	/** The zumprop. */
	//BigDecimal(5, 0)
	private List<BigDecimal> zumprop;

	/** The numero. */
	//BigDecimal(3, 0)
	private List<BigDecimal> numero;

	/** The a 1 zamor. */
	//String(1)
	private List<String> a1zamor;

	/** The indmulti. */
	//String(1)
	private List<String> indmulti;

	/** The intdamor. */
	//String(1)
	private List<String> intdamor;

	/** The aaaa. */
	//String(4)
	private List<String> aaaa;

	/** The codmon. */
	//String(3)
	private List<String> codmon;

	/** The impapr 15. */
	//BigDecimal(15, 2)
	private List<BigDecimal> impapr15;

	/** The plazopro. */
	//BigDecimal(3, 0)
	private List<BigDecimal> plazopro;

	/** The impant 15. */
	//BigDecimal(15, 2)
	private List<BigDecimal> impant15;

	/** The indplagi. */
	//String(1)
	private List<String> indplagi;

	/** The indlinea. */
	//String(1)
	private List<String> indlinea;

	/** The indcod. */
	//String(1)
	private List<String> indcod;

	/** The cplmaxgi. */
	//BigDecimal(5, 0)
	private List<BigDecimal> cplmaxgi;

	/** The plazocl 2. */
	//BigDecimal(5, 0)
	private List<BigDecimal> plazocl2;

	/** The extfinan. */
	//String(1)
	private List<String> extfinan;

	/** The dplazocl. */
	//BigDecimal(5, 0)
	private List<BigDecimal> dplazocl;

}
