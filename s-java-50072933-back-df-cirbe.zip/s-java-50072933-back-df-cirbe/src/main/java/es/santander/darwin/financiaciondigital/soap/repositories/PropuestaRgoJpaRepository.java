package es.santander.darwin.financiaciondigital.soap.repositories;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntity;
import es.santander.darwin.financiaciondigital.jpa.model.PropuestaRgoEntityPK;

/**
 * The Interface PropuestaRgoJpaRepository.
 */
public interface PropuestaRgoJpaRepository extends PagingAndSortingRepository<PropuestaRgoEntity, PropuestaRgoEntityPK>,
        JpaSpecificationExecutor<PropuestaRgoEntity> {

}
