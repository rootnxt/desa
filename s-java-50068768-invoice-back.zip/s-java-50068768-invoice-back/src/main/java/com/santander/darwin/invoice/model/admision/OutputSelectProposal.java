/**
 * 
 */
package com.santander.darwin.invoice.model.admision;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Clase de entrada para las llamadas rest
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class OutputSelectProposal {

	// Estado de la propuesta en admision
	private String cotestad;

	// Indicador de proceso
	private String indproce;

	// Moneda
	private String codmonsw;

	// Plazo
	private String plazopro;

	// Producto
	private String codproda;
	private String codsproa;
	private String coestref;

	// Importe
	private BigDecimal impaprb;

	// Segmento
	private String codseg;
	
}