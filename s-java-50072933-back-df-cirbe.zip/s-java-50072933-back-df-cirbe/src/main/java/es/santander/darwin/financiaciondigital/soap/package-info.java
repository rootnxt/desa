//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.24 a las 09:57:53 PM EDT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://financiaciondigital.darwin.santander.es/soap")
package es.santander.darwin.financiaciondigital.soap;
