package com.santander.darwin.invoice.model.cmc_contract;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * UserMeData
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class UserMeData {

	// Datos alias y uid
	private String alias;
	private String uid;
	// Datos de la persona
	private String personTypeContractHolder;
	private int personCodeContractHolder;
	private String personTypeUser;
	private int personCodeUser;
	// Datos de los contratos
	private String contractHolderName;
	private String documentContractHolder;
	private String documentTypeContractHolder;
	private String cmcContract;
	// Datos de firma
	private String signatureType;
	private String signagureOTP;
	private String signatureStatus;
	// Datos del segmento
	private String codeSegment;
	// Datos del documento
	private String documentUser;
	private String documentTypeUser;
	private String nameUser;
	private int personCodeNoCustomers;
	private String personTypeNoCustomers;
	// Mail usuario
	private String userEmail;
	// Datos de conexion
	private String userConnection;
	private String userConnectionType;
	private String userInternationalPhone;
	// Otros datos
	private String endUserPersonType;
	private String sanNumeroEmpleado;
	private int endUserPersonCode;
	
	private String channel;
	private String center;
}