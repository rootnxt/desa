package es.santander.darwin.financiaciondigital.service.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataRequestVO;
import es.santander.darwin.financiaciondigital.domain.BasicPersonDataResponseVO;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionLibException;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.lib.bean.TrxRequestBodyPSBMv2;
import es.santander.darwin.financiaciondigital.lib.bean.TrxResponseBodyPSBMv2;
import es.santander.darwin.financiaciondigital.lib.service.TrxLibraryService;
import es.santander.darwin.financiaciondigital.service.DFLibConnectorService;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class DFLibConnectorServiceImpl.
 */

/** The Constant log. */
@Slf4j
@Service
public class DFLibConnectorServiceImpl implements DFLibConnectorService {

    /** The transaction lib service. */
    @Autowired
    private TrxLibraryService trxLibraryService;

    /*
     * (non-Javadoc)
     * 
     * @see es.santander.darwin.financiaciondigital.service.DFLibConnectorService#
     * getBasicPersonData(es.santander.darwin.financiaciondigital.vo. BasicPersonDataRequestVO)
     */
    @Override
    public BasicPersonDataResponseVO getBasicPersonData(BasicPersonDataRequestVO request)
            throws DigitalConsumptionServiceException {
        log.info("getBasicPersonData: " + request);
        try {
            TrxRequestBodyPSBMv2 requestTrx = new TrxRequestBodyPSBMv2();

            requestTrx.setIdempr(request.getIdempr());
            requestTrx.setTipopers(Arrays.asList(request.getTipopers()));
            requestTrx.setCodpers(Arrays.asList(request.getCodpers()));

            TrxResponseBodyPSBMv2 responseTrx = trxLibraryService.trxPSBMv2(requestTrx);

            List<BasicPersonDataResponseVO> basicPersonDataList = new ArrayList<BasicPersonDataResponseVO>();
            for (int i = 0; i < responseTrx.getLit301().size(); i++) {
                BasicPersonDataResponseVO bean = BasicPersonDataResponseVO.builder()
                        .documentCod(responseTrx.getLit301().get(i)).documentType(responseTrx.getTipccx01().get(i))
                        .fullName(responseTrx.getNombr200().get(i)).codPaisR(responseTrx.getCodpaisr().get(i))
                        .codPaisN(responseTrx.getCodpaisn().get(i)).dateNac(getDate(responseTrx.getFecnac().get(i)))
                        .codPers(responseTrx.getCodpers().get(i)).tipoPers(responseTrx.getTipopers().get(i))
                        .idEmpr(responseTrx.getIdemprpp().get(i)).build();

                basicPersonDataList.add(bean);
            }
            if (basicPersonDataList.isEmpty()) {
                throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                        ErrorMessagesConstants.ERROR_EXPECTED_PERSONA, new EmptyResultDataAccessException(1));
            }
            return basicPersonDataList.get(0);
        } catch (DigitalConsumptionLibException de) {
            if (StringUtils.isNotBlank(de.getCode())) {
                throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                        ErrorMessagesConstants.ERROR_DETAILS_TRXWS, de, de.getCode());
            }
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.ERROR_DETAILS_TRXWS, de);
        }
    }

    /**
     * Gets the date.
     *
     * @param date the date
     * @return the date
     */
    private Date getDate(Object date) {
        if (date instanceof LocalDate) {
            return Date.from(((LocalDate) date).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        } else if (date instanceof Date) {
            return (Date) date;
        }
        return null;
    }

}
