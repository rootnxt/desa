package es.santander.darwin.financiaciondigital.lib.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import es.santander.darwin.financiaciondigital.lib.model.bean.RequestPersonIdentifier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class ProposalPersonRequests.
 */

/**
 * Sets the modification user.
 *
 * @param modificationUser the new modification user
 */
@Data

/**
 * Builds the.
 *
 * @return the proposal person requests
 */
@Builder

/**
 * Instantiates a new proposal person requests.
 */
@NoArgsConstructor

/**
 * Instantiates a new proposal person requests.
 *
 * @param Id                      the id
 * @param requestPersonIdentifier the request person identifier
 * @param sourceState             the source state
 * @param criticalityData         the criticality data
 * @param processIndicator        the process indicator
 * @param interventionType        the intervention type
 * @param admissionDate           the admission date
 * @param modificationDate        the modification date
 * @param modificationUser        the modification user
 * @param subApplication          the sub application
 */
@AllArgsConstructor

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@EqualsAndHashCode(callSuper = false)
@Document(collection = "proposalPersonRequests")
public class ProposalPersonRequests {

	/** The Id. */
	@Id
	private String Id;

	/** The request identifier. */
	private RequestPersonIdentifier requestPersonIdentifier;

	/** The source state. */
	private String sourceState;

	/** The criticality data. */
	private String criticalityData;

	/** The process indicator. */
	private String processIndicator;

	/** The intervention type. */
	private String interventionType;

	/** The admission date. */
	private Date admissionDate;

	/** The modification date. */
	private Date modificationDate;

	/** The modification user. */
	private String modificationUser;

	/** The sub application. */
	private String subApplication;

}
