package com.santander.darwin.invoice.model.lynx;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * The MetaDataLynx class.
 *
 */
@Getter
@Setter
public class MetaDataLynxExtends {
	
	/** The session id. */
	@JsonProperty("SESSION_ID")
	private String sessionId;
	
	/** The branch code. */
	@JsonProperty("BRANCH_CODE")
	private String branchCode;
	
	/** The account peer. */
	@JsonProperty("ACCOUNT_PEER")
	private String accountPeer;
	
	/** The partenon account peer. */
	@JsonProperty("PARTENON_ACCOUNT_PEER")
	private String partenonAccountPeer;
}
