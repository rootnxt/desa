package com.santander.darwin.invoice.model.ico;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class LoanSubsidyList.
 */

/**
 * Sets the financial condition.
 *
 * @param financialCondition the new financial condition
 */
@Setter

/**
 * Gets the financial condition.
 *
 * @return the financial condition
 */
@Getter

/**
 * Instantiates a new loan subsidy list.
 */
@NoArgsConstructor
public class LoanSubsidyList {
	
	/** The external reference. */
	private String externalReference;
	
	/** The subproduct type code. */
	private String subproductTypeCode;
	
	/** The product. */
	private Product product;
	
	/** The financial condition. */
	private FinancialCondition financialCondition;
}
