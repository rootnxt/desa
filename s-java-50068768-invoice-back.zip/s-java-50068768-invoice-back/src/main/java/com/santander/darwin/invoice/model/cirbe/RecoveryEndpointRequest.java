/**
 * 
 */
package com.santander.darwin.invoice.model.cirbe;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;


/**
 * RecoveryEndpointRequest
 * 
 * @author josdon
 *
 */
@Getter
@Setter
public class RecoveryEndpointRequest {

	// Datos de la persona
	// Para swagger
	@Schema(example = "J", description = "Type of person")
	@NotNull(message = "PERSONTYPENULL")
	@NotEmpty(message = "PERSONTYPEEMPTY")
	@Size(message = "PERSONTYPESIZE", min = 1, max = 1)
	@Pattern(regexp = "[F|J]", message = "PERSONTYPEINVALID")
	private String personType;

	// Para swagger
	@Schema(example = "120", description = "Code of person")
	@NotNull(message = "PERSONCODENULL")
	private Integer personCode;

	// Datos de la empresa
	// Para swagger
	@Schema(example = "0049", description = "Id of company")
	@NotNull(message = "COMPANYIDNULL")
	@NotEmpty(message = "COMPANYIDEMPTY")
	@Size(message = "COMPANYIDSIZE", min = 4, max = 4)
	private String companyId;

	// Datos del centro
	// Para swagger
	@Schema(example = "0075", description = "Id of center")
	@NotNull(message = "CENTERIDNULL")
	@NotEmpty(message = "CENTERIDEMPTY")
	@Size(message = "CENTERIDSIZE", min = 4, max = 4)
	private String centerId;

	// Datos de la propuesta
	// Para swagger
	@Schema(example = "2021", description = "Year of proposal")
	@NotNull(message = "PROPOSALYEARNULL")
	private Integer proposalYear;

	// Para swagger
	@Schema(example = "19765", description = "Number of proposal")
	@NotNull(message = "PROPOSALNUMBERNULL")
	private Integer proposalNumber;

	// Decision de riesgos
	// Para swagger
	@Schema(example = "AC", description = "Decision of motor")
	@NotNull(message = "DECISIONNULL")
	@NotEmpty(message = "DECISIONEMPTY")
	@Size(message = "DECISIONSIZE", min = 2, max = 2)
	private String decision;

	// Otros datos
	// Para swagger
	@Schema(example = "00", description = "Value of return")
	private String returnValue;
	// Para swagger
	@Schema(example = "none", description = "Description of error")
	private String descError;
	// Para swagger
	@Schema(example = "0", description = "Code of BDE")
	private String bdeCode;
	// Para swagger
	@Schema(example = "none", description = "Description of BDE")
	private String bdeDescription;

	// Titulares
	@JsonIgnore
	@Schema(example = "", description = "List of persons")
	private List<TitularesEndpointRequest> titulares;

}
