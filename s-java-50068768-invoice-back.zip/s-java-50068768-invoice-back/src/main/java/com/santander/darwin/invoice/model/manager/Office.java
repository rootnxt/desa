package com.santander.darwin.invoice.model.manager;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the area desc.
 *
 * @return the area desc
 */
@Getter

/**
 * Sets the data.
 *
 * @param data
 *            the new data
 */

/**
 * Sets the area desc.
 *
 * @param areaDesc
 *            the new area desc
 */
@Setter

/**
 * Instantiates a new limit.
 */

/**
 * Instantiates a new office.
 */
@NoArgsConstructor
public class Office {

    /** The center. */
    private String center;

    /** The center desc. */
    private String centerDesc;

    /** The zone. */
    private String zone;

    /** The zone desc. */
    private String zoneDesc;

    /** The territorial. */
    private String territorial;

    /** The territorial desc. */
    private String territorialDesc;

    /** The area. */
    private String area;

    /** The area desc. */
    private String areaDesc;

}
