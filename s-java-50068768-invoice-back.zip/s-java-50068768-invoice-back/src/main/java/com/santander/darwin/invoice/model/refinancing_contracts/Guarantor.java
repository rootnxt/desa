package com.santander.darwin.invoice.model.refinancing_contracts;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Guarantor.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Guarantor {

	// DNI
	private String dni;
	// Nombre
	private String name;
	// Tipo persona
	private String personType;
	// Codigo persona
	private int personCode;
	// Tipo
	private String type;
	// Participacion
	private float participation;
	// Flags
	private boolean selected;
	private boolean sign;
	private boolean associatedGuarantor;
	private boolean showRequest;
	private boolean understoodRequest;
	// Id de firma
	private String signExpId;

    @JsonProperty("isNegativeFile")
    private boolean isNegativeFile;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		result = prime * result + personCode;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Guarantor other = (Guarantor) obj;
		return personCode == other.personCode;
	}

}
