package com.santander.darwin.invoice.model.common;

/**
 * ContractCommon.java
 *
 * @author igndom
 *
 */
public class ContractCommon {
	
	private String idempr;
	private String idcent;
	private String idprod;
	private String idcont;

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idprod
	 */
	public String getIdprod() {
		return idprod;
	}

	/**
	 * @param idprod the idprod to set
	 */
	public void setIdprod(String idprod) {
		this.idprod = idprod;
	}

	/**
	 * @return the idcont
	 */
	public String getIdcont() {
		return idcont;
	}

	/**
	 * @param idcont the idcont to set
	 */
	public void setIdcont(String idcont) {
		this.idcont = idcont;
	}

}
