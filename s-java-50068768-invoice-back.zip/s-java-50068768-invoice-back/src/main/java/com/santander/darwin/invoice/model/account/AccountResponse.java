package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * The ReceivedAccount model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
public class AccountResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The code. */
    private String code;

    /** The hasMore. */
    private Boolean hasMore;

    /** The list. */
    private List<Account> list;

    /** The repDetails. */
    private RepDetails repDetails;

    /**
     * Gets the list.
     *
     * @return the list.
     */
    public List<Account> getList() {
        return Collections.unmodifiableList(list);
    }

    /**
     * Sets the list.
     *
     * @param list the new list.
     */
    public void setList(List<Account> list) {
        this.list =  Collections.unmodifiableList(list);
    }

}
