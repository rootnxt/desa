package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Gets the data.
 *
 * @return the data
 */
@Getter

/**
 * Sets the data.
 *
 * @param data the new data
 */
@Setter

/**
 * Instantiates a new limit.
 */
@NoArgsConstructor
public class Limit {

    /** The total. */
    private SingleLimit total;
    
    /** The data. */
    private List<DataLimit> data;

}
