package com.santander.darwin.invoice.model;

/**
 * Period.java
 *
 * @author igndom
 *
 */
public class Period extends CommonCommission {

	private CommonCommission euribor;
	private String fechaDesde;
	private String fechaHasta;

	/**
	 * @return the euribor
	 */
	public CommonCommission getEuribor() {
		return euribor;
	}

	/**
	 * @param euribor the euribor to set
	 */
	public void setEuribor(CommonCommission euribor) {
		this.euribor = euribor;
	}

	/**
	 * @return the fechaDesde
	 */
	public String getFechaDesde() {
		return fechaDesde;
	}

	/**
	 * @param fechaDesde the fechaDesde to set
	 */
	public void setFechaDesde(String fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	/**
	 * @return the fechaHasta
	 */
	public String getFechaHasta() {
		return fechaHasta;
	}

	/**
	 * @param fechaHasta the fechaHasta to set
	 */
	public void setFechaHasta(String fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

}
