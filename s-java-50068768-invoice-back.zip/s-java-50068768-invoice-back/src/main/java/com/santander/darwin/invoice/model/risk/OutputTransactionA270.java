package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;
import java.util.Date;

/**
 * OutputTransactionA270.java
 * 
 *
 */
public class OutputTransactionA270 {

	private BigDecimal aaa;
	private String analicli;
	private String anoprop2;
	private String a1produc;
	private String a1subtip;
	private String campo58;
	private String car0501;
	private BigDecimal ccentro;
	private String ccentro2;
	private BigDecimal cempresa;
	private String cempres2;
	private String cencuen;
	private String centante;
	private String clite023;
	private String cmoneda;
	private BigDecimal cnumeric;
	private String codcesta;
	private String codinte3;
	private String codmonsw;
	private String codpais;
	private BigDecimal codpers;
	private BigDecimal codpers2;
	private String codseg;
	private String codsenal;
	private String coestref;
	private String confante;
	private String contante;
	private String cproduct;
	private String csecbes;
	private String csubtipr;
	private BigDecimal cuenante;
	private BigDecimal cuencona;
	private String dcodmone;
	private String descri25;
	private String desmon;
	private BigDecimal diafijo;
	private BigDecimal digcon;
	private String dproduct;
	private String dsubtipr;
	private String emprante;
	private String esmibor;
	private String espago;
	private Date feconfor;
	private Date fecvenci;
	private String hayopcio;
	private String hipoteca;
	private String idcentc;
	private String idcent2;
	private String idcontr;
	private String idempr;
	private String idemprc;
	private String idempre;
	private String idprodc;
	private BigDecimal impabonc;
	private String indampli;
	private String indiarev;
	private String indrethd;
	private String indtabco;
	private String liter21;
	private String nomapes1;
	private String nomper55;
	private String nomviadm;
	private BigDecimal nrodomic;
	private BigDecimal nrofirma;
	private BigDecimal numprop2;
	private BigDecimal plazodoc;
	private BigDecimal pncopers;
	private BigDecimal pnplazo;
	private String pntipers;
	private String prodante;
	private BigDecimal prodcona;
	private BigDecimal subgante;
	private String swantece;
	private String tanteced;
	private String tconante;
	private String timeprop;
	private String tipforma;
	private String tipopers;
	private String tipoper2;
	private String tipviadm;
	private Date zfecha;
	private Date zfecvenc;
	/**
	 * @return the aaa
	 */
	public BigDecimal getAaa() {
		return aaa;
	}
	/**
	 * @param aaa the aaa to set
	 */
	public void setAaa(BigDecimal aaa) {
		this.aaa = aaa;
	}
	/**
	 * @return the analicli
	 */
	public String getAnalicli() {
		return analicli;
	}
	/**
	 * @param analicli the analicli to set
	 */
	public void setAnalicli(String analicli) {
		this.analicli = analicli;
	}
	/**
	 * @return the anoprop2
	 */
	public String getAnoprop2() {
		return anoprop2;
	}
	/**
	 * @param anoprop2 the anoprop2 to set
	 */
	public void setAnoprop2(String anoprop2) {
		this.anoprop2 = anoprop2;
	}
	/**
	 * @return the a1produc
	 */
	public String getA1produc() {
		return a1produc;
	}
	/**
	 * @param a1produc the a1produc to set
	 */
	public void setA1produc(String a1produc) {
		this.a1produc = a1produc;
	}
	/**
	 * @return the a1subtip
	 */
	public String getA1subtip() {
		return a1subtip;
	}
	/**
	 * @param a1subtip the a1subtip to set
	 */
	public void setA1subtip(String a1subtip) {
		this.a1subtip = a1subtip;
	}
	/**
	 * @return the campo58
	 */
	public String getCampo58() {
		return campo58;
	}
	/**
	 * @param campo58 the campo58 to set
	 */
	public void setCampo58(String campo58) {
		this.campo58 = campo58;
	}
	/**
	 * @return the car0501
	 */
	public String getCar0501() {
		return car0501;
	}
	/**
	 * @param car0501 the car0501 to set
	 */
	public void setCar0501(String car0501) {
		this.car0501 = car0501;
	}
	/**
	 * @return the ccentro
	 */
	public BigDecimal getCcentro() {
		return ccentro;
	}
	/**
	 * @param ccentro the ccentro to set
	 */
	public void setCcentro(BigDecimal ccentro) {
		this.ccentro = ccentro;
	}
	/**
	 * @return the ccentro2
	 */
	public String getCcentro2() {
		return ccentro2;
	}
	/**
	 * @param ccentro2 the ccentro2 to set
	 */
	public void setCcentro2(String ccentro2) {
		this.ccentro2 = ccentro2;
	}
	/**
	 * @return the cempresa
	 */
	public BigDecimal getCempresa() {
		return cempresa;
	}
	/**
	 * @param cempresa the cempresa to set
	 */
	public void setCempresa(BigDecimal cempresa) {
		this.cempresa = cempresa;
	}
	/**
	 * @return the cempres2
	 */
	public String getCempres2() {
		return cempres2;
	}
	/**
	 * @param cempres2 the cempres2 to set
	 */
	public void setCempres2(String cempres2) {
		this.cempres2 = cempres2;
	}
	/**
	 * @return the cencuen
	 */
	public String getCencuen() {
		return cencuen;
	}
	/**
	 * @param cencuen the cencuen to set
	 */
	public void setCencuen(String cencuen) {
		this.cencuen = cencuen;
	}
	/**
	 * @return the centante
	 */
	public String getCentante() {
		return centante;
	}
	/**
	 * @param centante the centante to set
	 */
	public void setCentante(String centante) {
		this.centante = centante;
	}
	/**
	 * @return the clite023
	 */
	public String getClite023() {
		return clite023;
	}
	/**
	 * @param clite023 the clite023 to set
	 */
	public void setClite023(String clite023) {
		this.clite023 = clite023;
	}
	/**
	 * @return the cmoneda
	 */
	public String getCmoneda() {
		return cmoneda;
	}
	/**
	 * @param cmoneda the cmoneda to set
	 */
	public void setCmoneda(String cmoneda) {
		this.cmoneda = cmoneda;
	}
	/**
	 * @return the cnumeric
	 */
	public BigDecimal getCnumeric() {
		return cnumeric;
	}
	/**
	 * @param cnumeric the cnumeric to set
	 */
	public void setCnumeric(BigDecimal cnumeric) {
		this.cnumeric = cnumeric;
	}
	/**
	 * @return the codcesta
	 */
	public String getCodcesta() {
		return codcesta;
	}
	/**
	 * @param codcesta the codcesta to set
	 */
	public void setCodcesta(String codcesta) {
		this.codcesta = codcesta;
	}
	/**
	 * @return the codinte3
	 */
	public String getCodinte3() {
		return codinte3;
	}
	/**
	 * @param codinte3 the codinte3 to set
	 */
	public void setCodinte3(String codinte3) {
		this.codinte3 = codinte3;
	}
	/**
	 * @return the codmonsw
	 */
	public String getCodmonsw() {
		return codmonsw;
	}
	/**
	 * @param codmonsw the codmonsw to set
	 */
	public void setCodmonsw(String codmonsw) {
		this.codmonsw = codmonsw;
	}
	/**
	 * @return the codpais
	 */
	public String getCodpais() {
		return codpais;
	}
	/**
	 * @param codpais the codpais to set
	 */
	public void setCodpais(String codpais) {
		this.codpais = codpais;
	}
	/**
	 * @return the codpers
	 */
	public BigDecimal getCodpers() {
		return codpers;
	}
	/**
	 * @param codpers the codpers to set
	 */
	public void setCodpers(BigDecimal codpers) {
		this.codpers = codpers;
	}
	/**
	 * @return the codpers2
	 */
	public BigDecimal getCodpers2() {
		return codpers2;
	}
	/**
	 * @param codpers2 the codpers2 to set
	 */
	public void setCodpers2(BigDecimal codpers2) {
		this.codpers2 = codpers2;
	}
	/**
	 * @return the codseg
	 */
	public String getCodseg() {
		return codseg;
	}
	/**
	 * @param codseg the codseg to set
	 */
	public void setCodseg(String codseg) {
		this.codseg = codseg;
	}
	/**
	 * @return the codsenal
	 */
	public String getCodsenal() {
		return codsenal;
	}
	/**
	 * @param codsenal the codsenal to set
	 */
	public void setCodsenal(String codsenal) {
		this.codsenal = codsenal;
	}
	/**
	 * @return the coestref
	 */
	public String getCoestref() {
		return coestref;
	}
	/**
	 * @param coestref the coestref to set
	 */
	public void setCoestref(String coestref) {
		this.coestref = coestref;
	}
	/**
	 * @return the confante
	 */
	public String getConfante() {
		return confante;
	}
	/**
	 * @param confante the confante to set
	 */
	public void setConfante(String confante) {
		this.confante = confante;
	}
	/**
	 * @return the contante
	 */
	public String getContante() {
		return contante;
	}
	/**
	 * @param contante the contante to set
	 */
	public void setContante(String contante) {
		this.contante = contante;
	}
	/**
	 * @return the cproduct
	 */
	public String getCproduct() {
		return cproduct;
	}
	/**
	 * @param cproduct the cproduct to set
	 */
	public void setCproduct(String cproduct) {
		this.cproduct = cproduct;
	}
	/**
	 * @return the csecbes
	 */
	public String getCsecbes() {
		return csecbes;
	}
	/**
	 * @param csecbes the csecbes to set
	 */
	public void setCsecbes(String csecbes) {
		this.csecbes = csecbes;
	}
	/**
	 * @return the csubtipr
	 */
	public String getCsubtipr() {
		return csubtipr;
	}
	/**
	 * @param csubtipr the csubtipr to set
	 */
	public void setCsubtipr(String csubtipr) {
		this.csubtipr = csubtipr;
	}
	/**
	 * @return the cuenante
	 */
	public BigDecimal getCuenante() {
		return cuenante;
	}
	/**
	 * @param cuenante the cuenante to set
	 */
	public void setCuenante(BigDecimal cuenante) {
		this.cuenante = cuenante;
	}
	/**
	 * @return the cuencona
	 */
	public BigDecimal getCuencona() {
		return cuencona;
	}
	/**
	 * @param cuencona the cuencona to set
	 */
	public void setCuencona(BigDecimal cuencona) {
		this.cuencona = cuencona;
	}
	/**
	 * @return the dcodmone
	 */
	public String getDcodmone() {
		return dcodmone;
	}
	/**
	 * @param dcodmone the dcodmone to set
	 */
	public void setDcodmone(String dcodmone) {
		this.dcodmone = dcodmone;
	}
	/**
	 * @return the descri25
	 */
	public String getDescri25() {
		return descri25;
	}
	/**
	 * @param descri25 the descri25 to set
	 */
	public void setDescri25(String descri25) {
		this.descri25 = descri25;
	}
	/**
	 * @return the desmon
	 */
	public String getDesmon() {
		return desmon;
	}
	/**
	 * @param desmon the desmon to set
	 */
	public void setDesmon(String desmon) {
		this.desmon = desmon;
	}
	/**
	 * @return the diafijo
	 */
	public BigDecimal getDiafijo() {
		return diafijo;
	}
	/**
	 * @param diafijo the diafijo to set
	 */
	public void setDiafijo(BigDecimal diafijo) {
		this.diafijo = diafijo;
	}
	/**
	 * @return the digcon
	 */
	public BigDecimal getDigcon() {
		return digcon;
	}
	/**
	 * @param digcon the digcon to set
	 */
	public void setDigcon(BigDecimal digcon) {
		this.digcon = digcon;
	}
	/**
	 * @return the dproduct
	 */
	public String getDproduct() {
		return dproduct;
	}
	/**
	 * @param dproduct the dproduct to set
	 */
	public void setDproduct(String dproduct) {
		this.dproduct = dproduct;
	}
	/**
	 * @return the dsubtipr
	 */
	public String getDsubtipr() {
		return dsubtipr;
	}
	/**
	 * @param dsubtipr the dsubtipr to set
	 */
	public void setDsubtipr(String dsubtipr) {
		this.dsubtipr = dsubtipr;
	}
	/**
	 * @return the emprante
	 */
	public String getEmprante() {
		return emprante;
	}
	/**
	 * @param emprante the emprante to set
	 */
	public void setEmprante(String emprante) {
		this.emprante = emprante;
	}
	/**
	 * @return the esmibor
	 */
	public String getEsmibor() {
		return esmibor;
	}
	/**
	 * @param esmibor the esmibor to set
	 */
	public void setEsmibor(String esmibor) {
		this.esmibor = esmibor;
	}
	/**
	 * @return the espago
	 */
	public String getEspago() {
		return espago;
	}
	/**
	 * @param espago the espago to set
	 */
	public void setEspago(String espago) {
		this.espago = espago;
	}
	/**
	 * @return the feconfor
	 */
	public Date getFeconfor() {
		return feconfor;
	}
	/**
	 * @param feconfor the feconfor to set
	 */
	public void setFeconfor(Date feconfor) {
		this.feconfor = feconfor;
	}
	/**
	 * @return the fecvenci
	 */
	public Date getFecvenci() {
		return fecvenci;
	}
	/**
	 * @param fecvenci the fecvenci to set
	 */
	public void setFecvenci(Date fecvenci) {
		this.fecvenci = fecvenci;
	}
	/**
	 * @return the hayopcio
	 */
	public String getHayopcio() {
		return hayopcio;
	}
	/**
	 * @param hayopcio the hayopcio to set
	 */
	public void setHayopcio(String hayopcio) {
		this.hayopcio = hayopcio;
	}
	/**
	 * @return the hipoteca
	 */
	public String getHipoteca() {
		return hipoteca;
	}
	/**
	 * @param hipoteca the hipoteca to set
	 */
	public void setHipoteca(String hipoteca) {
		this.hipoteca = hipoteca;
	}
	/**
	 * @return the idcentc
	 */
	public String getIdcentc() {
		return idcentc;
	}
	/**
	 * @param idcentc the idcentc to set
	 */
	public void setIdcentc(String idcentc) {
		this.idcentc = idcentc;
	}
	/**
	 * @return the idcent2
	 */
	public String getIdcent2() {
		return idcent2;
	}
	/**
	 * @param idcent2 the idcent2 to set
	 */
	public void setIdcent2(String idcent2) {
		this.idcent2 = idcent2;
	}
	/**
	 * @return the idcontr
	 */
	public String getIdcontr() {
		return idcontr;
	}
	/**
	 * @param idcontr the idcontr to set
	 */
	public void setIdcontr(String idcontr) {
		this.idcontr = idcontr;
	}
	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}
	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}
	/**
	 * @return the idemprc
	 */
	public String getIdemprc() {
		return idemprc;
	}
	/**
	 * @param idemprc the idemprc to set
	 */
	public void setIdemprc(String idemprc) {
		this.idemprc = idemprc;
	}
	/**
	 * @return the idempre
	 */
	public String getIdempre() {
		return idempre;
	}
	/**
	 * @param idempre the idempre to set
	 */
	public void setIdempre(String idempre) {
		this.idempre = idempre;
	}
	/**
	 * @return the idprodc
	 */
	public String getIdprodc() {
		return idprodc;
	}
	/**
	 * @param idprodc the idprodc to set
	 */
	public void setIdprodc(String idprodc) {
		this.idprodc = idprodc;
	}
	/**
	 * @return the impabonc
	 */
	public BigDecimal getImpabonc() {
		return impabonc;
	}
	/**
	 * @param impabonc the impabonc to set
	 */
	public void setImpabonc(BigDecimal impabonc) {
		this.impabonc = impabonc;
	}
	/**
	 * @return the indampli
	 */
	public String getIndampli() {
		return indampli;
	}
	/**
	 * @param indampli the indampli to set
	 */
	public void setIndampli(String indampli) {
		this.indampli = indampli;
	}
	/**
	 * @return the indiarev
	 */
	public String getIndiarev() {
		return indiarev;
	}
	/**
	 * @param indiarev the indiarev to set
	 */
	public void setIndiarev(String indiarev) {
		this.indiarev = indiarev;
	}
	/**
	 * @return the indrethd
	 */
	public String getIndrethd() {
		return indrethd;
	}
	/**
	 * @param indrethd the indrethd to set
	 */
	public void setIndrethd(String indrethd) {
		this.indrethd = indrethd;
	}
	/**
	 * @return the indtabco
	 */
	public String getIndtabco() {
		return indtabco;
	}
	/**
	 * @param indtabco the indtabco to set
	 */
	public void setIndtabco(String indtabco) {
		this.indtabco = indtabco;
	}
	/**
	 * @return the liter21
	 */
	public String getLiter21() {
		return liter21;
	}
	/**
	 * @param liter21 the liter21 to set
	 */
	public void setLiter21(String liter21) {
		this.liter21 = liter21;
	}
	/**
	 * @return the nomapes1
	 */
	public String getNomapes1() {
		return nomapes1;
	}
	/**
	 * @param nomapes1 the nomapes1 to set
	 */
	public void setNomapes1(String nomapes1) {
		this.nomapes1 = nomapes1;
	}
	/**
	 * @return the nomper55
	 */
	public String getNomper55() {
		return nomper55;
	}
	/**
	 * @param nomper55 the nomper55 to set
	 */
	public void setNomper55(String nomper55) {
		this.nomper55 = nomper55;
	}
	/**
	 * @return the nomviadm
	 */
	public String getNomviadm() {
		return nomviadm;
	}
	/**
	 * @param nomviadm the nomviadm to set
	 */
	public void setNomviadm(String nomviadm) {
		this.nomviadm = nomviadm;
	}
	/**
	 * @return the nrodomic
	 */
	public BigDecimal getNrodomic() {
		return nrodomic;
	}
	/**
	 * @param nrodomic the nrodomic to set
	 */
	public void setNrodomic(BigDecimal nrodomic) {
		this.nrodomic = nrodomic;
	}
	/**
	 * @return the nrofirma
	 */
	public BigDecimal getNrofirma() {
		return nrofirma;
	}
	/**
	 * @param nrofirma the nrofirma to set
	 */
	public void setNrofirma(BigDecimal nrofirma) {
		this.nrofirma = nrofirma;
	}
	/**
	 * @return the numprop2
	 */
	public BigDecimal getNumprop2() {
		return numprop2;
	}
	/**
	 * @param numprop2 the numprop2 to set
	 */
	public void setNumprop2(BigDecimal numprop2) {
		this.numprop2 = numprop2;
	}
	/**
	 * @return the plazodoc
	 */
	public BigDecimal getPlazodoc() {
		return plazodoc;
	}
	/**
	 * @param plazodoc the plazodoc to set
	 */
	public void setPlazodoc(BigDecimal plazodoc) {
		this.plazodoc = plazodoc;
	}
	/**
	 * @return the pncopers
	 */
	public BigDecimal getPncopers() {
		return pncopers;
	}
	/**
	 * @param pncopers the pncopers to set
	 */
	public void setPncopers(BigDecimal pncopers) {
		this.pncopers = pncopers;
	}
	/**
	 * @return the pnplazo
	 */
	public BigDecimal getPnplazo() {
		return pnplazo;
	}
	/**
	 * @param pnplazo the pnplazo to set
	 */
	public void setPnplazo(BigDecimal pnplazo) {
		this.pnplazo = pnplazo;
	}
	/**
	 * @return the pntipers
	 */
	public String getPntipers() {
		return pntipers;
	}
	/**
	 * @param pntipers the pntipers to set
	 */
	public void setPntipers(String pntipers) {
		this.pntipers = pntipers;
	}
	/**
	 * @return the prodante
	 */
	public String getProdante() {
		return prodante;
	}
	/**
	 * @param prodante the prodante to set
	 */
	public void setProdante(String prodante) {
		this.prodante = prodante;
	}
	/**
	 * @return the prodcona
	 */
	public BigDecimal getProdcona() {
		return prodcona;
	}
	/**
	 * @param prodcona the prodcona to set
	 */
	public void setProdcona(BigDecimal prodcona) {
		this.prodcona = prodcona;
	}
	/**
	 * @return the subgante
	 */
	public BigDecimal getSubgante() {
		return subgante;
	}
	/**
	 * @param subgante the subgante to set
	 */
	public void setSubgante(BigDecimal subgante) {
		this.subgante = subgante;
	}
	/**
	 * @return the swantece
	 */
	public String getSwantece() {
		return swantece;
	}
	/**
	 * @param swantece the swantece to set
	 */
	public void setSwantece(String swantece) {
		this.swantece = swantece;
	}
	/**
	 * @return the tanteced
	 */
	public String getTanteced() {
		return tanteced;
	}
	/**
	 * @param tanteced the tanteced to set
	 */
	public void setTanteced(String tanteced) {
		this.tanteced = tanteced;
	}
	/**
	 * @return the tconante
	 */
	public String getTconante() {
		return tconante;
	}
	/**
	 * @param tconante the tconante to set
	 */
	public void setTconante(String tconante) {
		this.tconante = tconante;
	}
	/**
	 * @return the timeprop
	 */
	public String getTimeprop() {
		return timeprop;
	}
	/**
	 * @param timeprop the timeprop to set
	 */
	public void setTimeprop(String timeprop) {
		this.timeprop = timeprop;
	}
	/**
	 * @return the tipforma
	 */
	public String getTipforma() {
		return tipforma;
	}
	/**
	 * @param tipforma the tipforma to set
	 */
	public void setTipforma(String tipforma) {
		this.tipforma = tipforma;
	}
	/**
	 * @return the tipopers
	 */
	public String getTipopers() {
		return tipopers;
	}
	/**
	 * @param tipopers the tipopers to set
	 */
	public void setTipopers(String tipopers) {
		this.tipopers = tipopers;
	}
	/**
	 * @return the tipoper2
	 */
	public String getTipoper2() {
		return tipoper2;
	}
	/**
	 * @param tipoper2 the tipoper2 to set
	 */
	public void setTipoper2(String tipoper2) {
		this.tipoper2 = tipoper2;
	}
	/**
	 * @return the tipviadm
	 */
	public String getTipviadm() {
		return tipviadm;
	}
	/**
	 * @param tipviadm the tipviadm to set
	 */
	public void setTipviadm(String tipviadm) {
		this.tipviadm = tipviadm;
	}
	/**
	 * @return the zfecha
	 */
	public Date getZfecha() {
		return zfecha;
	}
	/**
	 * @param zfecha the zfecha to set
	 */
	public void setZfecha(Date zfecha) {
		this.zfecha = zfecha;
	}
	/**
	 * @return the zfecvenc
	 */
	public Date getZfecvenc() {
		return zfecvenc;
	}
	/**
	 * @param zfecvenc the zfecvenc to set
	 */
	public void setZfecvenc(Date zfecvenc) {
		this.zfecvenc = zfecvenc;
	}
	
	
}
