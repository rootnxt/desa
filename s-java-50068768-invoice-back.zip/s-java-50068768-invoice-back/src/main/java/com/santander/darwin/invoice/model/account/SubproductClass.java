package com.santander.darwin.invoice.model.account;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;


/**
 * The Subproduct model class.
 *
 * @Autor luis.lopez
 */
@Getter
@Setter
@NoArgsConstructor
public class SubproductClass implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The entity. */
	private String entity;

    /** The product. */
    private String product;

    /** The subproduct. */
    private String subproduct;

    /**
     * Instantiates a new Subproduct object.
     *
     * @param subproduct the subproduct.
     */
    public SubproductClass (SubproductClass subproduct) {
        this.entity = subproduct.entity;
        this.product = subproduct.product;
        this.subproduct = subproduct.subproduct;
    }

}
