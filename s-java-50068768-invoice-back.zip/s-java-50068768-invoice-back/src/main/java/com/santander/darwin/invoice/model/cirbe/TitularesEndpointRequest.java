/**
 * 
 */
package com.santander.darwin.invoice.model.cirbe;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * TitularesEndpointRequest
 * 
 * @author josdon
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class TitularesEndpointRequest {

	/** The person code. */
	// Para swagger
	@Schema(example = "120", description = "Code of person")
	private BigDecimal personCode;

	/** The person type. */
	// Para swagger
	@Schema(example = "F", description = "Type of person")
	private String personType;

	/** The source type. */
	// Para swagger
	@Schema(example = "00", description = "Type of source")
	private String sourceType;

	/** The source state. */
	// Para swagger
	@Schema(example = "00", description = "State of source")
	private String sourceState;

	/** The criticality data. */
	// Para swagger
	@Schema(example = "00", description = "Criticality of data")
	private String criticalityData;

	/** The process indicator. */
	// Para swagger
	@Schema(example = "00", description = "Indicator of process")
	private String processIndicator;

}
