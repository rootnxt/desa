package com.santander.darwin.invoice.model;

import lombok.Data;

import java.util.List;

/**
 * Proposal Response.
 *
 * @author NttData
 */

/**
 * Instantiates a new response client web signatories DTO.
 */
@Data
public class ResponseClientWebSignatoriesDTO {

	/** The count. */
	private Integer count;
	
	/** The total. */
	private Integer total;
	
	/** The links. */
	private Links links;
	
	/** The embedded. */
	private List<DataRulesCustomerDTO> embedded;

}