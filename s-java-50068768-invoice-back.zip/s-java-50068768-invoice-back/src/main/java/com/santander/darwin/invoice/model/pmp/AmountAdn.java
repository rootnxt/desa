package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * AmountAdn
 * model
 * class
 */
@Getter
@Setter
public class AmountAdn {
	
	/** The amount. */
	private BigDecimal amount;
}
