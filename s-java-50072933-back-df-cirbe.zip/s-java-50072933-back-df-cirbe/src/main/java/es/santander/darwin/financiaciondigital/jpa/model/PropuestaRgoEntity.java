package es.santander.darwin.financiaciondigital.jpa.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import es.santander.darwin.financiaciondigital.constant.Constants;
import es.santander.darwin.financiaciondigital.util.converter.CustomLocalDateTimeConverter;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PropuestaRgoEntity.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data
@Entity

/**
 * Builds the.
 *
 * @return the propuesta rgo entity
 */
@Builder

/**
 * Instantiates a new propuesta rgo entity.
 */
@NoArgsConstructor

/**
 * Instantiates a new propuesta rgo entity.
 *
 * @param id the id
 * @param a1tippcc the a 1 tippcc
 * @param a1tippci the a 1 tippci
 * @param a1tippld the a 1 tippld
 * @param a1tipppr the a 1 tipppr
 * @param a6proced the a 6 proced
 * @param canalcom the canalcom
 * @param canalope the canalope
 * @param capson the capson
 * @param cdactivi the cdactivi
 * @param cdfinali the cdfinali
 * @param cdfinalo the cdfinalo
 * @param ciacapi the ciacapi
 * @param ciacapia the ciacapia
 * @param ciainte the ciainte
 * @param ciaintea the ciaintea
 * @param clfinali the clfinali
 * @param cnae the cnae
 * @param cnae93 the cnae 93
 * @param codcesta the codcesta
 * @param codmonsw the codmonsw
 * @param codprod the codprod
 * @param codproda the codproda
 * @param codseg the codseg
 * @param codsproa the codsproa
 * @param codsprod the codsprod
 * @param coestref the coestref
 * @param cotestad the cotestad
 * @param cotfinal the cotfinal
 * @param cotlocal the cotlocal
 * @param cotpropu the cotpropu
 * @param cotsicon the cotsicon
 * @param cotsiele the cotsiele
 * @param fecancel the fecancel
 * @param fecestac the fecestac
 * @param fecharat the fecharat
 * @param fechsoli the fechsoli
 * @param fechvtoc the fechvtoc
 * @param fecmod the fecmod
 * @param idanalis the idanalis
 * @param idtiporg the idtiporg
 * @param iintervi the iintervi
 * @param impaprb the impaprb
 * @param impprop the impprop
 * @param indbcorp the indbcorp
 * @param indplazo the indplazo
 * @param indproce the indproce
 * @param indverif the indverif
 * @param intccp the intccp
 * @param ipfinali the ipfinali
 * @param operarat the operarat
 * @param plazodo the plazodo
 * @param plazodoa the plazodoa
 * @param plazopro the plazopro
 * @param porcents the porcents
 * @param timeprop the timeprop
 * @param usumod the usumod
 */
@AllArgsConstructor
@Table(name = Constants.PROPUESTA_RGO)
public class PropuestaRgoEntity {

    /** The id. */
    @EmbeddedId
    private PropuestaRgoEntityPK id;

    /** The a 1 tippcc. */
    @Column(name = "PNA_A1TIPPCC")
    private String a1tippcc;

    /** The a 1 tippci. */
    @Column(name = "PNA_A1TIPPCI")
    private String a1tippci;

    /** The a 1 tippld. */
    @Column(name = "PNA_A1TIPPLD")
    private String a1tippld;

    /** The a 1 tipppr. */
    @Column(name = "PNA_A1TIPPPR")
    private String a1tipppr;

    /** The a 6 proced. */
    @Column(name = "PNA_A6PROCED")
    private String a6proced;

    /** The canalcom. */
    @Column(name = "PNA_CANALCOM")
    private String canalcom;

    /** The canalope. */
    @Column(name = "PNA_CANALOPE")
    private String canalope;

    /** The capson. */
    @Column(name = "PNA_CAPSON")
    private String capson;

    /** The cdactivi. */
    @Column(name = "PNA_CDACTIVI")
    private String cdactivi;

    /** The cdfinali. */
    @Column(name = "PNA_CDFINALI")
    private String cdfinali;

    /** The cdfinalo. */
    @Column(name = "PNA_CDFINALO")
    private String cdfinalo;

    /** The ciacapi. */
    @Column(name = "PNA_CIACAPI")
    private String ciacapi;

    /** The ciacapia. */
    @Column(name = "PNA_CIACAPIA")
    private String ciacapia;

    /** The ciainte. */
    @Column(name = "PNA_CIAINTE")
    private String ciainte;

    /** The ciaintea. */
    @Column(name = "PNA_CIAINTEA")
    private String ciaintea;

    /** The clfinali. */
    @Column(name = "PNA_CLFINALI")
    private String clfinali;

    /** The cnae. */
    @Column(name = "PNA_CNAE")
    private String cnae;

    /** The cnae 93. */
    @Column(name = "PNA_CNAE93")
    private String cnae93;

    /** The codcesta. */
    @Column(name = "PNA_CODCESTA")
    private String codcesta;

    /** The codmonsw. */
    @Column(name = "PNA_CODMONSW")
    private String codmonsw;

    /** The codprod. */
    @Column(name = "PNA_CODPROD")
    private String codprod;

    /** The codproda. */
    @Column(name = "PNA_CODPRODA")
    private String codproda;

    /** The codseg. */
    @Column(name = "PNA_CODSEG")
    private String codseg;

    /** The codsproa. */
    @Column(name = "PNA_CODSPROA")
    private String codsproa;

    /** The codsprod. */
    @Column(name = "PNA_CODSPROD")
    private String codsprod;

    /** The coestref. */
    @Column(name = "PNA_COESTREF")
    private String coestref;

    /** The cotestad. */
    @Column(name = "PNA_COTESTAD")
    private String cotestad;

    /** The cotfinal. */
    @Column(name = "PNA_COTFINAL")
    private String cotfinal;

    /** The cotlocal. */
    @Column(name = "PNA_COTLOCAL")
    private String cotlocal;

    /** The cotpropu. */
    @Column(name = "PNA_COTPROPU")
    private String cotpropu;

    /** The cotsicon. */
    @Column(name = "PNA_COTSICON")
    private String cotsicon;

    /** The cotsiele. */
    @Column(name = "PNA_COTSIELE")
    private String cotsiele;

    /** The fecancel. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECANCEL")
    private LocalDate fecancel;

    /** The fecestac. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECESTAC")
    private LocalDate fecestac;

    /** The fecharat. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECHARAT")
    private LocalDate fecharat;

    /** The fechsoli. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECHSOLI")
    private LocalDate fechsoli;

    /** The fechvtoc. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECHVTOC")
    private LocalDate fechvtoc;

    /** The fecmod. */
    @Convert(converter = LocalDateConverter.class)
    @Column(name = "PNA_FECMOD")
    private LocalDate fecmod;

    /** The idanalis. */
    @Column(name = "PNA_IDANALIS")
    private String idanalis;

    /** The idtiporg. */
    @Column(name = "PNA_IDTIPORG")
    private String idtiporg;

    /** The iintervi. */
    @Column(name = "PNA_IINTERVI")
    private String iintervi;

    /** The impaprb. */
    @Column(name = "PNA_IMPAPRB")
    private BigDecimal impaprb;

    /** The impprop. */
    @Column(name = "PNA_IMPPROP")
    private BigDecimal impprop;

    /** The indbcorp. */
    @Column(name = "PNA_INDBCORP")
    private String indbcorp;

    /** The indplazo. */
    @Column(name = "PNA_INDPLAZO")
    private String indplazo;

    /** The indproce. */
    @Column(name = "PNA_INDPROCE")
    private String indproce;

    /** The indverif. */
    @Column(name = "PNA_INDVERIF")
    private String indverif;

    /** The intccp. */
    @Column(name = "PNA_INTCCP")
    private String intccp;

    /** The ipfinali. */
    @Column(name = "PNA_IPFINALI")
    private String ipfinali;

    /** The operarat. */
    @Column(name = "PNA_OPERARAT")
    private BigDecimal operarat;

    /** The plazodo. */
    @Column(name = "PNA_PLAZODO")
    private BigDecimal plazodo;

    /** The plazodoa. */
    @Column(name = "PNA_PLAZODOA")
    private BigDecimal plazodoa;

    /** The plazopro. */
    @Column(name = "PNA_PLAZOPRO")
    private BigDecimal plazopro;

    /** The porcents. */
    @Column(name = "PNA_PORCENTS")
    private BigDecimal porcents;

    /** The timeprop. */
    @Convert(converter = CustomLocalDateTimeConverter.class)
    @Column(name = "PNA_TIMEPROP")
    private LocalDateTime timeprop;

    /** The usumod. */
    @Column(name = "PNA_USUMOD")
    private String usumod;

}
