package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the amount.
 *
 * @return the amount
 */
@Getter

/**
 * Sets the amount.
 *
 * @param amount the new amount
 */
@Setter

/**
 * Instantiates a new type finance.
 */
@NoArgsConstructor
public class TypeFinance {

    /** The name. */
    private String name;
    
    /** The amount. */
    private Integer amount;
    
    /** The amount Management. */
    private Integer amountManagement;

}
