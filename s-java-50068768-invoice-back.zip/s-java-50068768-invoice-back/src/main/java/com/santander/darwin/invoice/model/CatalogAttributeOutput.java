package com.santander.darwin.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Salida de la consulta de atributos de catálogo de productos
 * 
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CatalogAttributeOutput {

	/**
	 * atribfis
	 */
    private String atribfis;

	/**
	 * codprods
	 */
    private String codprods;

	/**
	 * codspros
	 */
    private String codspros;

	/**
	 * coestre7
	 */
    private String coestre7;

	/**
	 * desatr
	 */
    private String desatr;

	/**
	 * desc10b
	 */
    private String desc10b;

	/**
	 * desc25
	 */
    private String desc25;

	/**
	 * desc25a
	 */
    private String desc25a;

	/**
	 * fecomval
	 */
    private String fecomval;

	/**
	 * fefinval
	 */
    private String fefinval;

	/**
	 * grupos
	 */
    private String grupos;

	/**
	 * idemprd
	 */
    private String idemprd;

	/**
	 * indac
	 */
    private String indac;
    
}
