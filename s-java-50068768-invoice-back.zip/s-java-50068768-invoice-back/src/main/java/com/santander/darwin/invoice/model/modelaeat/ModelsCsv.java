/*
 * 
 */
package com.santander.darwin.invoice.model.modelaeat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.santander.darwin.invoice.model.CommonInformation;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Instantiates a new models csv.
 */
@NoArgsConstructor
@Getter
@Setter
public class ModelsCsv {

    /** The id. */
    private String id;

    /** The name. */
    @NotNull(message = "MODELCSVNAMENULL")
    private String name;

    /** The value. */
    @NotNull(message = "MODELCSVVALUENULL")
    private String value;

    /** The error. */
    private boolean error;

    /** The years. */
    private List<CommonInformation> years;

    /** The years selected */
    private CommonInformation yearSelected;
    
    @JsonIgnore
    private String idAeat;
    
    @JsonIgnore
    private String stateAeat;
}
