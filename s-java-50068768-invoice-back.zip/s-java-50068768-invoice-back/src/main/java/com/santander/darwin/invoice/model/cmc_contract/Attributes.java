package com.santander.darwin.invoice.model.cmc_contract;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Attributes
 * 
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Attributes {
	
	// comCodCentro
	private String comCodCentro;
	
	@Setter(onMethod_ = {@JsonSetter("SanCodCentroAlternativo")})
	@Getter(onMethod_ = {@JsonSetter("SanCodCentroAlternativo")})
	// SanCodCentroAlternativo
	private String sanCodCentroAlternativo;

	@Setter(onMethod_ = {@JsonSetter("SanNumeroEmpleado")})
	@Getter(onMethod_ = {@JsonSetter("SanNumeroEmpleado")})
	// SanNumeroEmpleado
	private String sanNumeroEmpleado;

	// organizationName
	private String organizationName;
	
	// mobile
	private String mobile;
	
	// mail
	private String mail;
	
	// fullName
	private String fullName;
	
	// documentCode 
	private String documentCode;
	
	// documentType
	private String documentType;
	
}
