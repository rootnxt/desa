/**
 * 
 */
package com.santander.darwin.invoice.model.pmp;

import lombok.Getter;
import lombok.Setter;

/**
 * Product.java
 * 
 *
 */
@Getter
@Setter
public class ProductClass {
	
	// Atributos de la clase
	// product
	private String product;
	// subProduct
	private String subProduct;
	//standardPrices
	private String standardPrices;
	// typeDescription
	private String typeDescription;
	// standardPricesDescription
	private String standardPricesDescription;
	// riskConsumptionIndicator
	private String riskConsumptionIndicator;
	// riskConsumptionIndicatorDescription
	private String riskConsumptionIndicatorDescription;
	 
}
