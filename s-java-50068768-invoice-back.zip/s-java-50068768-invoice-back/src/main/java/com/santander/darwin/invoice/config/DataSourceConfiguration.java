package com.santander.darwin.invoice.config;

import com.gruposantander.enablers.dualrun.DualrunDataSource;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * DataSourceConfiguration
 * 
 * @author igndom
 *
 */
@Configuration
@RequiredArgsConstructor
public class DataSourceConfiguration {

	public static final String SNETLOGON_DB = "db2.snetlogon";
	private final DualrunDataSource dataSource;

	/**
	 * jdbcSNETLOGONDB
	 * 
	 * @return JdbcTemplate
	 */
	@Bean
	public JdbcTemplate jdbcSNETLOGONDB() {
		return new JdbcTemplate(dataSource);
	}
}
