package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Document.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Document {
	// Datos de Document
	private String documentTypeCode;
	private String documentTypeNumber;
}