package es.santander.darwin.financiaciondigital.domain;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdeInfo.
 */

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the bde info
 */
@Builder

/**
 * Instantiates a new bde info.
 */
@NoArgsConstructor

/**
 * Instantiates a new bde info.
 *
 * @param bdeCode the bde code
 * @param bdeDescription the bde description
 */
@AllArgsConstructor
@Component
public class BdeInfo {

    /** The bde code. */
    private String bdeCode;

    /** The bde description. */
    private String bdeDescription;
}
