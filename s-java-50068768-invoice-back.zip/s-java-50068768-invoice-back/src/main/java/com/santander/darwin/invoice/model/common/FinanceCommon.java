package com.santander.darwin.invoice.model.common;

import java.math.BigDecimal;

/**
 * FinanceCommon.java
 *
 * @author igndom
 *
 */
public class FinanceCommon {

	private boolean selected;
	private BigDecimal finance;
	private BigDecimal preFinance;

	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}

	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	/**
	 * @return the finance
	 */
	public BigDecimal getFinance() {
		return finance;
	}

	/**
	 * @param finance the finance to set
	 */
	public void setFinance(BigDecimal finance) {
		this.finance = finance;
	}

	/**
	 * @return the preFinance
	 */
	public BigDecimal getPreFinance() {
		return preFinance;
	}

	/**
	 * @param preFinance the preFinance to set
	 */
	public void setPreFinance(BigDecimal preFinance) {
		this.preFinance = preFinance;
	}

}
