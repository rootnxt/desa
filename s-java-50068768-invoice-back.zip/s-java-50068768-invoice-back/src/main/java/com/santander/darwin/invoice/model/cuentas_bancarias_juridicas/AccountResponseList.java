package com.santander.darwin.invoice.model.cuentas_bancarias_juridicas;

import com.santander.darwin.invoice.model.AccountPtn;
import com.santander.darwin.invoice.model.Parties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * AccountResponseList
 * 
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class AccountResponseList {
	// Number Account
	private String aliasOrAccount;
	private String alias;
	// Holder
	private String holderName;
	// Balance
	private BigDecimal balance;
	// Currency
	private String currency;
	// Account 
	private Account accountNumber;
	// Name Bank Account
	private String modality;
	// Account 
	private AccountPtn accountPtn;
	// Parties 
	private List<Parties> parties;	

}
