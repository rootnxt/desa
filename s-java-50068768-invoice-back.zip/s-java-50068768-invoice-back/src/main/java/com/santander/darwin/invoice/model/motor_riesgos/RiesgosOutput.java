package com.santander.darwin.invoice.model.motor_riesgos;

/**
 * RiesgosOutput
 * 
 * @author igndom
 *
 */
public class RiesgosOutput {

	private String systemDecision;
	private String groupDecision;
	private String spidNumber;
	private String returnDesc;
	private String returnCode;
	private String routine;

	/**
	 * @return the systemDecision
	 */
	public String getSystemDecision() {
		return systemDecision;
	}

	/**
	 * @param systemDecision the systemDecision to set
	 */
	public void setSystemDecision(String systemDecision) {
		this.systemDecision = systemDecision;
	}

	/**
	 * @return the groupDecision
	 */
	public String getGroupDecision() {
		return groupDecision;
	}

	/**
	 * @param groupDecision the groupDecision to set
	 */
	public void setGroupDecision(String groupDecision) {
		this.groupDecision = groupDecision;
	}

	/**
	 * @return the spidNumber
	 */
	public String getSpidNumber() {
		return spidNumber;
	}

	/**
	 * @param spidNumber the spidNumber to set
	 */
	public void setSpidNumber(String spidNumber) {
		this.spidNumber = spidNumber;
	}

	/**
	 * @return the returnDesc
	 */
	public String getReturnDesc() {
		return returnDesc;
	}

	/**
	 * @param returnDesc the returnDesc to set
	 */
	public void setReturnDesc(String returnDesc) {
		this.returnDesc = returnDesc;
	}

	/**
	 * @return the returnCode
	 */
	public String getReturnCode() {
		return returnCode;
	}

	/**
	 * @param returnCode the returnCode to set
	 */
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	/**
	 * @return the routine
	 */
	public String getRoutine() {
		return routine;
	}

	/**
	 * @param routine the routine to set
	 */
	public void setRoutine(String routine) {
		this.routine = routine;
	}
}
