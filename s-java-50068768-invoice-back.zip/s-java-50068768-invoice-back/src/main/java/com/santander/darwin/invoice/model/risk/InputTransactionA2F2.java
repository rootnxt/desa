package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * InputTransactionA2F2.java
 *
 * @author igndom
 *
 */
public class InputTransactionA2F2 {

	// Partenon unsigned numeric (N) - Length (4, 0)
	private BigDecimal aaa;
	// Partenon unsigned numeric (N) - Length (4, 0)
	private BigDecimal ccentro;
	// Partenon unsigned numeric (N) - Length (4, 0)
	private BigDecimal cempresa;
	// Partenon unsigned numeric (N) - Length (5, 0)
	private BigDecimal cnumeric;
	// Partenon VARCHAR Value
	private String numeroEmpleado;

	/**
	 * @return the aaa
	 */
	public BigDecimal getAaa() {
		return aaa;
	}

	/**
	 * @param aaa the aaa to set
	 */
	public void setAaa(BigDecimal aaa) {
		this.aaa = aaa;
	}

	/**
	 * @return the ccentro
	 */
	public BigDecimal getCcentro() {
		return ccentro;
	}

	/**
	 * @param ccentro the ccentro to set
	 */
	public void setCcentro(BigDecimal ccentro) {
		this.ccentro = ccentro;
	}

	/**
	 * @return the cempresa
	 */
	public BigDecimal getCempresa() {
		return cempresa;
	}

	/**
	 * @param cempresa the cempresa to set
	 */
	public void setCempresa(BigDecimal cempresa) {
		this.cempresa = cempresa;
	}

	/**
	 * @return the cnumeric
	 */
	public BigDecimal getCnumeric() {
		return cnumeric;
	}

	/**
	 * @param cnumeric the cnumeric to set
	 */
	public void setCnumeric(BigDecimal cnumeric) {
		this.cnumeric = cnumeric;
	}

	/**
	 * @return the cnumeric
	 */
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	/**
	 * @param cnumeric the cnumeric to set
	 */
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

}
