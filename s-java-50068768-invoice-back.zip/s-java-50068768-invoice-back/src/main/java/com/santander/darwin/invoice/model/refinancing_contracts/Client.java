package com.santander.darwin.invoice.model.refinancing_contracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Client.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Client {

	// Variables
	private String tipoPers;
	private int codPers;

}
