package com.santander.darwin.invoice.model.lanzadera;

/**
 * OutputLanzadera.java
 *
 * @author igndom
 *
 */
public class OutputLanzadera {

	private String token;
	private String operationId;

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the operationId
	 */
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @param operationId the operationId to set
	 */
	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

}
