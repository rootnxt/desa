package com.santander.darwin.invoice.model.product_common;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Optional;

/**
 * InputTransactionBP2E
 * 
 * @author igndom
 *
 */
public class InputTransactionBP2E {

	// INPUT DATA

	// Partenon alphanumeric (A) - Length (4)
	private String codcesta;

	// Partenon alphanumeric (A) - Length (3)
	private String codprodr;

	// Partenon alphanumeric (A) - Length (3)
	private String codspror;

	// Partenon alphanumeric (A) - Length (7)
	private String coestrer;

	// Partenon date (D1) - Length (8)
	private Date fecomvar;

	// Partenon alphanumeric (A) - Length (4)
	private String idempres;

	// Partenon alphanumeric (A) - Length (4)
	private String idemprr;

	// Partenon unsigned numeric (N) - Length (3, 0)
	private BigDecimal numfilas;

	/**
	 * @return the codcesta
	 */
	public String getCodcesta() {
		return codcesta;
	}

	/**
	 * @param codcesta the codcesta to set
	 */
	public void setCodcesta(String codcesta) {
		this.codcesta = codcesta;
	}

	/**
	 * @return the codprodr
	 */
	public String getCodprodr() {
		return codprodr;
	}

	/**
	 * @param codprodr the codprodr to set
	 */
	public void setCodprodr(String codprodr) {
		this.codprodr = codprodr;
	}

	/**
	 * @return the codspror
	 */
	public String getCodspror() {
		return codspror;
	}

	/**
	 * @param codspror the codspror to set
	 */
	public void setCodspror(String codspror) {
		this.codspror = codspror;
	}

	/**
	 * @return the coestrer
	 */
	public String getCoestrer() {
		return coestrer;
	}

	/**
	 * @param coestrer the coestrer to set
	 */
	public void setCoestrer(String coestrer) {
		this.coestrer = coestrer;
	}

	/**
	 * @return the fecomvar
	 */
	public Date getFecomvar() {
		return Optional.ofNullable(fecomvar).map(Date::getTime).map(Date::new).orElse(null);
	}

	/**
	 * @param fecomvar the fecomvar to set
	 */
	public void setFecomvar(Date fecomvar) {
		this.fecomvar = Optional.ofNullable(fecomvar).map(Date::getTime).map(Date::new).orElse(null);
	}

	/**
	 * @return the idempres
	 */
	public String getIdempres() {
		return idempres;
	}

	/**
	 * @param idempres the idempres to set
	 */
	public void setIdempres(String idempres) {
		this.idempres = idempres;
	}

	/**
	 * @return the idemprr
	 */
	public String getIdemprr() {
		return idemprr;
	}

	/**
	 * @param idemprr the idemprr to set
	 */
	public void setIdemprr(String idemprr) {
		this.idemprr = idemprr;
	}

	/**
	 * @return the numfilas
	 */
	public BigDecimal getNumfilas() {
		return numfilas;
	}

	/**
	 * @param numfilas the numfilas to set
	 */
	public void setNumfilas(BigDecimal numfilas) {
		this.numfilas = numfilas;
	}
}
