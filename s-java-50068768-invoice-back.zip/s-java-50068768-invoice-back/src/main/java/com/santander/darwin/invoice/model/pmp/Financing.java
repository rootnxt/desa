package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Financing model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Financing {
    /** min */
    private BigDecimal min;
    /** max */
    private BigDecimal max;
    /** finance */
    private BigDecimal finance;
}
