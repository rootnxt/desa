package com.santander.darwin.invoice.model.financiacion_digital;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * DetailFFNN.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class DetailFFNN {
	// Nombre
    private String fileName;
    //Origen
    private String origin;
    //Importe
    private BigDecimal amount;
    //Fecha
    private String date;
    //Anotaciones
    private int numberAnnotations;
}