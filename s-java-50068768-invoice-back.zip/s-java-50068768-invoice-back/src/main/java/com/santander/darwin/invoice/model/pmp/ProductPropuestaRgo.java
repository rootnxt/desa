package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * ProductPropuestaRgo model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductPropuestaRgo {
	
	/** The product. PNA_CODPRODA. */
    private String product;
	
	/** The subType. PNA_CODSPROA. */
	private String subType;
	
	/** The standard. PNA_COESTREF. */
	private String standard;
	
	/** The limit. PNA_IMPAPRB. */
	private BigDecimal limit;
	
	/** The currency. PNA_CODMONSW. */
	private String currency;
	
	/** The term. PNA_PLAZOPRO. */
	private Integer term;
	
	/** The dateVto. PNA_FECHVTOC. */
	private Date dateVto;
}
