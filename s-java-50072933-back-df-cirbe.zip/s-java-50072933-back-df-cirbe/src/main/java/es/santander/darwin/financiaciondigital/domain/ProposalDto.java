package es.santander.darwin.financiaciondigital.domain;

import lombok.Builder;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the proposal dto
 */
@Builder

/**
 * Instantiates a new proposal dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new proposal dto.
 *
 * @param companyId the company id
 * @param centerId the center id
 * @param proposalYear the proposal year
 * @param proposalNumber the proposal number
 */
@AllArgsConstructor
public class ProposalDto{


    /** The company id. */
    private String companyId;

    /** The center id. */
    private String centerId;

    /** The proposal year. */
    private String proposalYear;

    /** The proposal number. */
    private Integer proposalNumber;



}
