package es.santander.darwin.financiaciondigital.util;

import java.lang.invoke.MethodHandles;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.santander.darwin.financiaciondigital.constant.ErrorMessagesConstants;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionServiceException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;

/**
 * The Class TimeUtil.
 *
 * @author everis
 */
public class TimeUtil {

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    /**
     * Instantiates a new time util.
     */
    private TimeUtil() {

    }

    /**
     * String to date.
     *
     * @param fecha
     *            the fecha
     * @return the date
     */
    public static Date stringToDate(String fecha) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {

            date = formatter.parse(fecha);
            LOGGER.error("stringToDate " + date);
            LOGGER.error(formatter.format(date));

        } catch (ParseException e) {
            LOGGER.error("Ha ocurrido un error en el parseo de la fecha");
        }
        return date;
    }

    /**
     * String to date.
     *
     * @param fecha
     *            the fecha
     * @return the date
     */
    public static YearMonth stringToDateYYYYMM(String fecha) throws DigitalConsumptionServiceException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMM");
        YearMonth date = null;
        try {
            date = YearMonth.parse(fecha, formatter);
            LOGGER.error("stringToDate " + date);
            // LOGGER.error(formatter.format(date));
        } catch (DateTimeParseException e) {
            LOGGER.error("Ha ocurrido un error en el parseo de la fecha");
            throw new DigitalConsumptionServiceException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
                    ErrorMessagesConstants.ERROR_DETAILS_CIRBE_CONSOLIDADO, e);
        }

        return date;
    }

    /**
     * String to timestamp.
     *
     * @param fecha
     *            the fecha
     * @return the timestamp
     */
    public static Timestamp stringToTimestamp(String fecha) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = null;
        Timestamp timestamp = null;
        try {

            date = formatter.parse(fecha);
            timestamp = new Timestamp(date.getTime());
            LOGGER.error("stringToDate " + date);
            LOGGER.error(formatter.format(timestamp));

        } catch (ParseException e) {
            LOGGER.error("Ha ocurrido un error en el parseo de la fecha");
        }
        return timestamp;
    }

}
