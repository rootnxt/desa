package com.santander.darwin.invoice.model.campaigns;

import java.math.BigDecimal;

/**
 * DetailCampaign.java
 *
 * @author igndom
 *
 */
public class DetailCampaign {

	private String campaignCode;
	private String startEffectiveDate;
	private String endEffectiveDate;
	private BigDecimal minImportCN;
	private BigDecimal maxImportCN;
	private Integer factor;
	private String triad;
	private BigDecimal maxOperationChannel;
	private BigDecimal numberOperationsChannel;
	private BigDecimal importAcu1;
	private BigDecimal limitImport;
	private BigDecimal limitTriad;
	private String currencyCode;
	

	/**
	 * @return the campaignCode
	 */
	public String getCampaignCode() {
		return campaignCode;
	}

	/**
	 * @param campaignCode the campaignCode to set
	 */
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	/**
	 * @return the startEffectiveDate
	 */
	public String getStartEffectiveDate() {
		return startEffectiveDate;
	}
	
	/**
	 * @param startEffectiveDate the startEffectiveDate to set
	 */
	public void setStartEffectiveDate(String startEffectiveDate) {
		this.startEffectiveDate = startEffectiveDate;
	}
	
	/**
	 * @param endEffectiveDate the endEffectiveDate to set
	 */
	public void setEndEffectiveDate(String endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}
	
	/**
	 * @return the endEffectiveDate
	 */
	public String getEndEffectiveDate() {
		return endEffectiveDate;
	}

	
	
	/**
	 * @return the minImportCN
	 */
	public BigDecimal getMinImportCN() {
		return minImportCN;
	}

	/**
	 * @param minImportCN the minImportCN to set
	 */
	public void setMinImportCN(BigDecimal minImportCN) {
		this.minImportCN = minImportCN;
	}

	/**
	 * @return the maxImportCN
	 */
	public BigDecimal getMaxImportCN() {
		return maxImportCN;
	}

	/**
	 * @param maxImportCN the maxImportCN to set
	 */
	public void setMaxImportCN(BigDecimal maxImportCN) {
		this.maxImportCN = maxImportCN;
	}
	
	/**
	 * @return the factor
	 */
	public Integer getFactor() {
		return factor;
	}

	/**
	 * @param factor the factor to set
	 */
	public void setFactor(Integer factor) {
		this.factor = factor;
	}

	/**
	 * @return the triad
	 */
	public String getTriad() {
		return triad;
	}

	/**
	 * @param triad the triad to set
	 */
	public void setTriad(String triad) {
		this.triad = triad;
	}
	
	/**
	 * @return the maxOperationChannel
	 */
	public BigDecimal getMaxOperationChannel() {
		return maxOperationChannel;
	}

	/**
	 * @param maxOperationChannel the maxOperationChannel to set
	 */
	public void setMaxOperationChannel(BigDecimal maxOperationChannel) {
		this.maxOperationChannel = maxOperationChannel;
	}
	
	/**
	 * @return the numberOperationsChannel
	 */
	public BigDecimal getNumberOperationsChannel() {
		return numberOperationsChannel;
	}

	/**
	 * @param numberOperationsChannel the numberOperationsChannel to set
	 */
	public void setNumberOperationsChannel(BigDecimal numberOperationsChannel) {
		this.numberOperationsChannel = numberOperationsChannel;
	}
	
	/**
	 * @return the importAcu1
	 */
	public BigDecimal getImportAcu1() {
		return importAcu1;
	}

	/**
	 * @param importAcu1 the importAcu1 to set
	 */
	public void setImportAcu1(BigDecimal importAcu1) {
		this.importAcu1 = importAcu1;
	}
	
	/**
	 * @return the limitImport
	 */
	public BigDecimal getLimitImport() {
		return limitImport;
	}

	/**
	 * @param limitImport the limitImport to set
	 */
	public void setLimitImport(BigDecimal limitImport) {
		this.limitImport = limitImport;
	}
	
	/**
	 * @return the limitTriad
	 */
	public BigDecimal getLimitTriad() {
		return limitTriad;
	}

	/**
	 * @param limitTriad the limitTriad to set
	 */
	public void setLimitTriad(BigDecimal limitTriad) {
		this.limitTriad = limitTriad;
	}
	
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
}
