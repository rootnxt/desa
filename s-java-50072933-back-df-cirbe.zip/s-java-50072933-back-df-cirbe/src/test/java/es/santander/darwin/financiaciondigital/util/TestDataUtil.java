package es.santander.darwin.financiaciondigital.util;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class TestDataUtil.
 *
 * @author everis
 */
@Slf4j
public class TestDataUtil {

    /** The Constant SERVICE_RESOURCE. */
    private static final String SERVICE_RESOURCE = "classpath:srv/";

    /** The Constant DUMMY_STRING. */
    private static final String DUMMY_STRING = "test";

    /** The Constant DUMMY_BIGDECIMAL. */
    private static final BigDecimal DUMMY_BIGDECIMAL = BigDecimal.TEN;

    /** The Constant DUMMY_DATE. */
    private static final Date DUMMY_DATE = new Date();

    /** The Constant DUMMY_LIST_BIGDECIMAL. */
    private static final List<BigDecimal> DUMMY_LIST_BIGDECIMAL = Arrays.asList(DUMMY_BIGDECIMAL, DUMMY_BIGDECIMAL,
            DUMMY_BIGDECIMAL);

    /** The Constant DUMMY_LIST_STRING. */
    private static final List<String> DUMMY_LIST_STRING = Arrays.asList(DUMMY_STRING, DUMMY_STRING, DUMMY_STRING);

    /** The Constant DUMMY_LIST_DATE. */
    private static final List<Date> DUMMY_LIST_DATE = Arrays.asList(DUMMY_DATE, DUMMY_DATE, DUMMY_DATE);

    /** The Constant SETTER_PREFIX. */
    private static final String SETTER_PREFIX = "set";

    /** The Constant DUMMY_LIST_STRING_TYPE. */
    private static final String DUMMY_LIST_STRING_TYPE = "java.util.List<java.lang.String>";

    /** The Constant DUMMY_LIST_DATE_TYPE. */
    private static final String DUMMY_LIST_DATE_TYPE = "java.util.List<java.util.Date>";

    /** The Constant DUMMY_LIST_BIGDECIMAL_TYPE. */
    private static final String DUMMY_LIST_BIGDECIMAL_TYPE = "java.util.List<java.math.BigDecimal>";

    /** The Constant DUMMY_LONG. */
    private static final Long DUMMY_LONG = new Long(1);

    /** The Constant DUMMY_SHORT. */
    private static final Short DUMMY_SHORT = new Short("1");

    /** The Constant DUMMY_BYTE. */
    private static final Byte DUMMY_BYTE = new Byte("1");

    /** The Constant DUMMY_DOUBLE. */
    private static final Double DUMMY_DOUBLE = new Double("1.1");

    /** The Constant DUMMY_FLOAT. */
    private static final Float DUMMY_FLOAT = new Float("1.1");

    /**
     * Rellena el objeto dummy object si tiene campos de tipo String, BigDecimal, Date, o List<String>, List<Date> o
     * List<BigDecimal>. Si tiene otro tipo de dato lo dejara null.
     *
     * @param <T> the generic type
     * @param dummyObject the dummy object
     * @return the dummy object con datos
     */
    public static <T> T fillDummyObject(T dummyObject) {
        Method[] methods = dummyObject.getClass().getMethods();
        Map<String, Object> dummyParameters = getDummyParametersForFill();
        for (Method method : methods) {
            String methodName = method.getName();
            if (methodName.startsWith(SETTER_PREFIX)) {
                Type[] types = method.getGenericParameterTypes();
                if (types.length == 1) {
                    Type type = types[0];
                    Object argument = dummyParameters.get(type.getTypeName());
                    try {
                        method.invoke(dummyObject, argument);
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                        log.warn("NO SE PUDO SETEAR UN VALOR MEDIANTE EL METODO [" + methodName
                                + "] con un argumento de tipo [" + type.getTypeName() + "] debido a " + e.getMessage());
                    }
                }
            }
        }
        return dummyObject;
    }

    /**
     * Gets the dummy parameters for fill.
     *
     * @return the dummy parameters for fill
     */
    private static Map<String, Object> getDummyParametersForFill() {
        Map<String, Object> objects = new HashMap<>();
        objects.put(DUMMY_LIST_BIGDECIMAL_TYPE, new ArrayList<BigDecimal>(DUMMY_LIST_BIGDECIMAL));
        objects.put(DUMMY_LIST_DATE_TYPE, new ArrayList<Date>(DUMMY_LIST_DATE));
        objects.put(DUMMY_LIST_STRING_TYPE, new ArrayList<String>(DUMMY_LIST_STRING));
        objects.put(DUMMY_BIGDECIMAL.getClass().getTypeName(), DUMMY_BIGDECIMAL);
        objects.put(DUMMY_DATE.getClass().getTypeName(), DUMMY_DATE);
        objects.put(DUMMY_STRING.getClass().getTypeName(), DUMMY_STRING);
        objects.put(Long.TYPE.getTypeName(), DUMMY_LONG);
        objects.put(Integer.TYPE.getTypeName(), DUMMY_LONG);
        objects.put(Double.TYPE.getTypeName(), DUMMY_DOUBLE);
        objects.put(Short.TYPE.getTypeName(), DUMMY_SHORT);
        objects.put(Byte.TYPE.getTypeName(), DUMMY_BYTE);
        objects.put(Float.TYPE.getTypeName(), DUMMY_FLOAT);
        objects.put(Character.TYPE.getTypeName(), DUMMY_FLOAT);
        objects.put(Boolean.TYPE.getTypeName(), Boolean.TRUE);
        objects.put(Long.class.getTypeName(), DUMMY_LONG);
        objects.put(Integer.class.getTypeName(), DUMMY_LONG);
        objects.put(Double.class.getTypeName(), DUMMY_DOUBLE);
        objects.put(Short.class.getTypeName(), DUMMY_SHORT);
        objects.put(Byte.class.getTypeName(), DUMMY_BYTE);
        objects.put(Float.class.getTypeName(), DUMMY_FLOAT);
        objects.put(Character.class.getTypeName(), DUMMY_FLOAT);
        objects.put(Boolean.class.getTypeName(), Boolean.TRUE);
        return objects;
    }

    
    public static byte[] getAdmissionSimpleDataValidation() throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + "admissionSimpleData.json");
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();

        return bytesArray;
    }

    /**
     * Object to json string.
     *
     * @param obj the obj
     * @return the string
     */
    public static String objectToJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Gets the client carterized request validation.
     *
     * @return the client carterized request validation
     * @throws Exception the exception
     */
    public static byte[] getClientCarterizedRequestValidation() throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + "ValidationManagersRequestNull.json");
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();

        return bytesArray;
    }
    
    /**
     * Gets the client carterized request.
     *
     * @return the client carterized request
     * @throws Exception the exception
     */
    public static byte[] getClientCarterizedRequest() throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + "ValidationManagersRequest.json");
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();

        return bytesArray;
    }
    
    public static byte[] getDefaultSimulationRequest() throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + "DefaultSimulationRequest.json");
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();

        return bytesArray;
    }

    public static byte[] getDefaultSimulationRequestNOK() throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + "DefaultSimulationRequestNOK.json");
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();

        return bytesArray;
    }
    
    /**
     * Gets the json request.
     *
     * @param requestFile the request file
     * @return the json request
     * @throws Exception the exception
     */
    public static byte[] getJsonRequest(String requestFile) throws Exception {
        File file = ResourceUtils.getFile(SERVICE_RESOURCE + requestFile);
        byte[] bytesArray = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytesArray);
        fis.close();
        return bytesArray;
    }
}
