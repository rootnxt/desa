package com.santander.darwin.invoice.model.pmp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OutputValidateProduct model
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OutputValidateProduct {
	
	/** The proposalProp. */
    private ProposalPropDelM proposalProp;
	
	/** The limit. */
	private ProductPropuestaRgo productRgo;
	
}
