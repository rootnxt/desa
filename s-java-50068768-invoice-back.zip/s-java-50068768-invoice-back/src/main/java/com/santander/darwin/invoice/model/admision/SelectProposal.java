/**
 *
 */
package com.santander.darwin.invoice.model.admision;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Clase de entrada para las llamadas rest
 *
 * @author josdon
 *
 */
@Getter
@Setter
public class SelectProposal extends InputSelectProposal{

    // Estado de la propuesta en admision
    private String cotestad;

    // Indicador de proceso
    private String indproce;

    // Importe
    private BigDecimal finance;

}