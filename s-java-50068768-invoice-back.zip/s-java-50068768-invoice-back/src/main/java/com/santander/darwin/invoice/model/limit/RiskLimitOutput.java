package com.santander.darwin.invoice.model.limit;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the resume.
 *
 * @return the resume
 */
@Getter

/**
 * Sets the resume.
 *
 * @param resume the new resume
 */
@Setter
public class RiskLimitOutput {

    /** The limites. */
    private RiskLimitResponse limites;
    
    /** Limites preconcedidos*/
    private RiskLimitResponse preconcedidos;
    
    /** Limites preconcedidos*/
    private RiskLimitResponse orientados;
    
    /** The resume. */
    private Resume resume;

}
