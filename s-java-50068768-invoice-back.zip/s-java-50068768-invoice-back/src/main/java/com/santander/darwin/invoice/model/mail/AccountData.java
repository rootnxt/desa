package com.santander.darwin.invoice.model.mail;

import lombok.Getter;
import lombok.Setter;


/**
 * AccountData Class
 * 
 *
 */
@Getter
@Setter
public class AccountData {
	// The account.
	private String account;
	// The description.
	private String description;
	// The international mnemo.
	private String mnemoInternational;
	// The national mnemo.
	private String mnemoNational;
	// The new row
	private boolean newRow;
	// The end row
	private boolean endRow;
}
