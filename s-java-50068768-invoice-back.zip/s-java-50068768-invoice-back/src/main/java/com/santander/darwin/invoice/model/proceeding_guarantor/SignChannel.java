package com.santander.darwin.invoice.model.proceeding_guarantor;

/**
 * SignChannel.java
 *
 * @author igndom
 *
 */
public class SignChannel {
	
    private String contactPoint;
    private String startDate;
    private String validityDate;
	private String expirationDays;

	/**
	 * @return the contactPoint
	 */
	public String getContactPoint() {
		return contactPoint;
	}

	/**
	 * @param contactPoint the contactPoint to set
	 */
	public void setContactPoint(String contactPoint) {
		this.contactPoint = contactPoint;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the validityDate
	 */
	public String getValidityDate() {
		return validityDate;
	}

	/**
	 * @param validityDate the validityDate to set
	 */
	public void setValidityDate(String validityDate) {
		this.validityDate = validityDate;
	}

	/**
	 * @return the expirationDays
	 */
	public String getExpirationDays() {
		return expirationDays;
	}

	/**
	 * @param expirationDays the expirationDays to set
	 */
	public void setExpirationDays(String expirationDays) {
		this.expirationDays = expirationDays;
	}

}
