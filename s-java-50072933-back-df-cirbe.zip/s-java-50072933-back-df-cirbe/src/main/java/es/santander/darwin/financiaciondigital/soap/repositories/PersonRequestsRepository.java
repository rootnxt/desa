package es.santander.darwin.financiaciondigital.soap.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import es.santander.darwin.financiaciondigital.constant.Queries;
import es.santander.darwin.financiaciondigital.lib.model.PersonRequests;

/**
 * The Interface InformationControlProcessRepository.
 */
@Repository
public interface PersonRequestsRepository extends MongoRepository<PersonRequests, String> {

    /**
     * Find by person request identifier company id.
     *
     * @param companyId the company id
     * @return the person requests
     */
    @Query(Queries.PERSON_REQUESTS_BY_IDENTIFIER)
    List<PersonRequests> findPersonRequestByIdentifier(String companyId, String personType, int personCode,
            String sourceType);

    /**
     * Find person request for petitions 2.
     *
     * @param companyId the company id
     * @param personType the person type
     * @param personCode the person code
     * @param sourceTyp the source typ
     * @return the person requests
     */
    @Query(Queries.PERSON_REQUESTS_FOR_PETITIONNS2)
    List<PersonRequests> findPersonRequestForPetitions2(String companyId, String personType, int personCode);

}
