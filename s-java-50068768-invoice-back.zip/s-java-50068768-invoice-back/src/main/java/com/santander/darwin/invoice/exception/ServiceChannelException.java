package com.santander.darwin.invoice.exception;

/**
 * ServiceException.java
 *
 * @author igndom
 *
 */
public class ServiceChannelException extends ServiceException {

    private static final long serialVersionUID = -7361822941285793296L;
    private final String channel;

    /**
     * Constructor
     *
     * @param code String
     * @param lang String
     * @param app  String
     * @param channel  String
     */
    public ServiceChannelException(String code, String lang, String app, String channel) {
        super(code,lang,app);
        this.channel = channel;
    }

    /**
     * @return the app
     */
    public String getChannel() {
        return channel;
    }

}
