package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the peticiones persona dto
 */
@Builder

/**
 * Instantiates a new peticiones persona dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new peticiones persona dto.
 *
 * @param nuevoAcreditado the nuevo acreditado
 * @param numeroPeticiones the numero peticiones
 * @param fechaAlta the fecha alta
 * @param fechaModif the fecha modif
 * @param codBdE the cod bd E
 * @param descBdE the desc bd E
 * @param usuario the usuario
 */
@AllArgsConstructor
public class PeticionesPersonaDto{

    /** The nuevoAcreditado. */
    private boolean nuevoAcreditado;
    
    /** The numeroPeticiones. */
    private Integer numeroPeticiones;
    
    /** The fechaAlta. */
    private boolean fechaAlta;
    
    /** The fechaModif. */
    private boolean fechaModif;
    
    /** The codBdE. */
    private String codBdE;
    
    /** The descBdE. */
    private String descBdE;
    
    /** The usuario. */
    private String usuario;
}
