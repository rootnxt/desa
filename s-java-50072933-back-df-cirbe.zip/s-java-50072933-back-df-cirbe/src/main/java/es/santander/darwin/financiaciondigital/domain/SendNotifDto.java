package es.santander.darwin.financiaciondigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the send notif dto
 */
@Builder

/**
 * Instantiates a new send notif dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new send notif dto.
 *
 * @param companyId the company id
 * @param internationalPrefix the international prefix
 * @param phoneNumber the phone number
 * @param email the email
 * @param subject the subject
 * @param message the message
 * @param indNotif the ind notif
 */
@AllArgsConstructor
public class SendNotifDto {

    /** The company id. */
    private String companyId;

    /** The international prefix. */
    private String internationalPrefix;

    /** The phone number. */
    private String phoneNumber;

    /** The email. */
    private String email;

    /** The subject. */
    private String subject;

    /** The message. */
    private String message;

    /** The indNotif. */
    private Integer indNotif;

}
