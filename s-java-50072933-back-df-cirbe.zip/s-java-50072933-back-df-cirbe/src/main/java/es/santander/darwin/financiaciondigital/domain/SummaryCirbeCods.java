package es.santander.darwin.financiaciondigital.domain;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Can equal.
 *
 * @param other the other
 * @return true, if successful
 */
@Data

/**
 * Builds the.
 *
 * @return the summary cirbe cods
 */
@Builder

/**
 * Instantiates a new summary cirbe cods.
 */
@NoArgsConstructor

/**
 * Instantiates a new summary cirbe cods.
 *
 * @param cirbeCodsList the cirbe cods list
 */
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "summary-cirbe")
public class SummaryCirbeCods {
    
    /** The Summary cirbe cods list. */
    private List<SummaryCirbe> cirbeCodsList;

}
