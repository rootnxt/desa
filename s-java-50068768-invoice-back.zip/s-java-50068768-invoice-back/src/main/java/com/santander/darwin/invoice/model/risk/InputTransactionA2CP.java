package com.santander.darwin.invoice.model.risk;

import java.math.BigDecimal;

/**
 * InputTransactionA2CP.java
 *
 * @author igndom
 *
 */
public class InputTransactionA2CP {

	// Partenon alphanumeric (A) - Length (4)
	private String anoprop;
	// Partenon alphanumeric (A) - Length (4)
	private String cenctaso;
	// Partenon alphanumeric (A) - Length (7)
	private String contra;
	// Partenon alphanumeric (A) - Length (4)
	private String empre;
	// Partenon alphanumeric (A) - Length (4)
	private String idcent;
	// Partenon alphanumeric (A) - Length (4)
	private String idempr;
	// Partenon unsigned numeric (N) - Length (5, 0)
	private BigDecimal numprop;
	// Partenon alphanumeric (A) - Length (3)
	private String producto;

	/**
	 * @return the anoprop
	 */
	public String getAnoprop() {
		return anoprop;
	}

	/**
	 * @param anoprop the anoprop to set
	 */
	public void setAnoprop(String anoprop) {
		this.anoprop = anoprop;
	}

	/**
	 * @return the cenctaso
	 */
	public String getCenctaso() {
		return cenctaso;
	}

	/**
	 * @param cenctaso the cenctaso to set
	 */
	public void setCenctaso(String cenctaso) {
		this.cenctaso = cenctaso;
	}

	/**
	 * @return the contra
	 */
	public String getContra() {
		return contra;
	}

	/**
	 * @param contra the contra to set
	 */
	public void setContra(String contra) {
		this.contra = contra;
	}

	/**
	 * @return the empre
	 */
	public String getEmpre() {
		return empre;
	}

	/**
	 * @param empre the empre to set
	 */
	public void setEmpre(String empre) {
		this.empre = empre;
	}

	/**
	 * @return the idcent
	 */
	public String getIdcent() {
		return idcent;
	}

	/**
	 * @param idcent the idcent to set
	 */
	public void setIdcent(String idcent) {
		this.idcent = idcent;
	}

	/**
	 * @return the idempr
	 */
	public String getIdempr() {
		return idempr;
	}

	/**
	 * @param idempr the idempr to set
	 */
	public void setIdempr(String idempr) {
		this.idempr = idempr;
	}

	/**
	 * @return the numprop
	 */
	public BigDecimal getNumprop() {
		return numprop;
	}

	/**
	 * @param numprop the numprop to set
	 */
	public void setNumprop(BigDecimal numprop) {
		this.numprop = numprop;
	}

	/**
	 * @return the producto
	 */
	public String getProducto() {
		return producto;
	}

	/**
	 * @param producto the producto to set
	 */
	public void setProducto(String producto) {
		this.producto = producto;
	}

}
