package com.santander.darwin.invoice.model.campaigns;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * ProdutcsCampaign.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class ProductsCampaign {

	// entries 
	private List<Product> entries;
}
