package com.santander.darwin.invoice.model.confirming;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Audit.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Audit {
	// Datos de Audit
    private String creationUser;
    private String creationDate;
}