package com.santander.darwin.invoice.model.be;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the contract number.
 *
 * @return the contract number
 */
@Getter

/**
 * Sets the contract number.
 *
 * @param contractNumber
 *            the new contract number
 */
@Setter
public class ContractBE {

    /** The bank. */
    private String bank;

    /** The branch. */
    private String branch;

    /** The product. */
    private String product;

    /** The contract number. */
    private String contractNumber;

}
