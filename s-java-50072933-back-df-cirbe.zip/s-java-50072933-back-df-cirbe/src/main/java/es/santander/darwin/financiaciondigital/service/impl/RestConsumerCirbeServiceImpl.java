package es.santander.darwin.financiaciondigital.service.impl;

import java.text.MessageFormat;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.santander.darwin.common.annotation.DarwinQualifier;
import es.santander.darwin.financiaciondigital.domain.ConsultPersonProcessResponseVO;
import es.santander.darwin.financiaciondigital.domain.OrchestratorMotorResponse;
import es.santander.darwin.financiaciondigital.domain.ProposalDto;
import es.santander.darwin.financiaciondigital.domain.RecoveryEndpointRequest;
import es.santander.darwin.financiaciondigital.domain.RecoveryPhoneAndMailResponse;
import es.santander.darwin.financiaciondigital.domain.SendNotifDto;
import es.santander.darwin.financiaciondigital.exceptions.DigitalConsumptionInternalException;
import es.santander.darwin.financiaciondigital.exceptions.constants.ExceptionsErrorConstants;
import es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest;
import es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService;
import lombok.extern.slf4j.Slf4j;

/** The Class RestConsumerServiceImpl. */

/** The Constant log. */

/** The Constant log. */
@Slf4j
@Service
public class RestConsumerCirbeServiceImpl implements RestConsumerCirbeService {

	/** The aeat noti. */
	@Value("${rest.mongo.serviceAeat}")
	private String aeatNoti;

	/** The get phone email. */
	@Value("${rest.mongo.recoveryPhoneMail}")
	private String recoveryPhoneMail;

	/** The motor url. */
	@Value("${rest.mongo.motor}")
	private String motorUrl;

	/** The sencol motor url service. */
	@Value("${cirbe.consultPerson}")
	private String sencolMotorUrlService;

	/** The rest template. */
	@Autowired
	@DarwinQualifier
	private RestTemplate restTemplate;

	/** The json mapper. */
	@Autowired
	private ObjectMapper jsonMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see es.santander.darwin.financiaciondigital.service.RestConsumerService#
	 * senNotiSmsAndEmail(java.lang.String, java.lang.Integer,
	 * es.santander.darwin.financiaciondigital.dto.SendNotifDto)
	 */
	@Override
	public SendNotifDto senNotiSmsOrEmail(String personType, Integer personCode, SendNotifDto sendNotifDto) {
		String url = MessageFormat.format(aeatNoti, personType, String.valueOf(personCode));
		return callRest(SendNotifDto.class, HttpMethod.POST, url, sendNotifDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService#
	 * recoveryPhoneMail(java.lang.String, java.lang.Integer,
	 * es.santander.darwin.financiaciondigital.lib.bean.ProposalRequest)
	 */
	@Override
	public RecoveryPhoneAndMailResponse recoveryPhoneMail(String personType, Integer personCode,
			ProposalRequest proposalRequest) {
		String url = MessageFormat.format(recoveryPhoneMail, personType, String.valueOf(personCode.intValue()));
		return callRest(RecoveryPhoneAndMailResponse.class, HttpMethod.POST, url, proposalRequest);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService#
	 * orchestratorMotor(java.lang.String, java.lang.Integer, java.lang.String,
	 * es.santander.darwin.financiaciondigital.domain.ProposalDto)
	 */
	@Override
	public OrchestratorMotorResponse orchestratorMotor(String personType, Integer personCode, String callType,
			ProposalDto body) {
		String url = MessageFormat.format(motorUrl, personType, String.valueOf(personCode), callType);
		return callRest(OrchestratorMotorResponse.class, HttpMethod.POST, url, body);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.santander.darwin.financiaciondigital.service.RestConsumerCirbeService#
	 * consultPerson(java.lang.String, java.lang.String, java.lang.Integer,
	 * java.lang.Integer)
	 */
	public ConsultPersonProcessResponseVO consultPerson(Map<String, String> bodyParamMap) {
		return (ConsultPersonProcessResponseVO) callRest2(ConsultPersonProcessResponseVO.class, HttpMethod.POST,
				sencolMotorUrlService, bodyParamMap);
	}

	public void recoveryEndpoint(String url, RecoveryEndpointRequest request) {
		callRest(Object.class, HttpMethod.POST, url, request);
	}

	/**
	 * Call rest.
	 *
	 * @param <T>          the generic type
	 * @param responseType the response type
	 * @param method       the method
	 * @param url          the url
	 * @param request      the request
	 * @return the t
	 */
	private <T> T callRest(Class<T> responseType, HttpMethod method, String url, Object request) {
		log.info("Invoking rest service [" + method + "]: " + url);
		if (null != request) {
			try {
				log.info("cuerpo de solicitud [" + method + " (" + url + ")] : "
						+ jsonMapper.writeValueAsString(request));
			} catch (JsonProcessingException e1) {
				throw new DigitalConsumptionInternalException(ExceptionsErrorConstants.ERROR_MESSAGE_GENERIC,
						ExceptionsErrorConstants.ERROR_DETAIL_UNEXPECTED, e1, e1.getMessage());
			}
		}
		HttpHeaders headersAux = new HttpHeaders();
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headersAux.setContentType(MediaType.APPLICATION_JSON);
		if (null != request) {
			headersAux.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		}
		headersAux.forEach((k, v) -> headers.put(k, v));
		HttpEntity<Object> entity;
		if (null != request) {
			entity = new HttpEntity<>(request, headers);
		} else {
			entity = new HttpEntity<>(headers);
		}

		log.info("Entity " + entity);
		try {
			ResponseEntity<T> response = restTemplate.exchange(url, method, entity, responseType);

			log.info("Response: " + response.getBody());
			return response.getBody();
		} catch (RestClientResponseException e) {
			throw new DigitalConsumptionInternalException(e, "Error restTemplate - RestClientResponseException");

		} catch (Exception ex) {
			log.info("Error conectividad desconocido en " + url);
			throw new DigitalConsumptionInternalException(ex, "Error en llamada Rest");
		}
	}

	/**
	 * Call rest 2.
	 *
	 * @param <T>          the generic type
	 * @param responseType the response type
	 * @param method       the method
	 * @param url          the url
	 * @param bodyParamMap the body param map
	 * @return the object
	 */
	private <T> Object callRest2(Class<T> responseType, HttpMethod method, String url,
			Map<String, String> bodyParamMap) {
		log.info("Invoking rest service [" + method + "]: " + url);
		try {

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
			String reqBodyData = new ObjectMapper().writeValueAsString(bodyParamMap);
			HttpEntity<String> requestEnty = new HttpEntity<>(reqBodyData, header);
			ResponseEntity<T> response = restTemplate.exchange(url, method, requestEnty, responseType);
			log.info("Response: " + response.getBody());
			return response.getBody();
		} catch (RestClientResponseException e) {
			throw new DigitalConsumptionInternalException(e, "Error restTemplate - RestClientResponseException");

		} catch (Exception ex) {
			log.info("Error conectividad desconocido en " + url);
			throw new DigitalConsumptionInternalException(ex, "Error en llamada Rest");
		}
	}
}
