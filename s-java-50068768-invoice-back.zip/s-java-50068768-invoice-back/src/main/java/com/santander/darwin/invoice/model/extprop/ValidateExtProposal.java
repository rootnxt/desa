package com.santander.darwin.invoice.model.extprop;

import com.santander.darwin.invoice.model.InvoiceAppFinality;
import com.santander.darwin.invoice.model.limit.RiskLimitOutput;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * InputConsultProposal.
 *
 * @author seresc
 */

@Getter
@Setter
public class ValidateExtProposal {
	
	/** PNA_CODSEG. */
	@Schema(example = "PQ", description = "The PNA_CODSEG")
	private String codSeg;
	
	/** PNA_CODPRODA. */
	@Schema(example = "100", description = "The PNA_CODPRODA")
	private String productCode;
	
	/** PNA_CODSPROA. */
	@Schema(example = "201", description = "The PNA_CODSPROA")
	private String productSubType;
	
	/** PNA_COESTREF. */
	@Schema(example = "0000001", description = "The PNA_COESTREF")
	private String referenceStandard;

    /** PNE_TIPOPERS. */
	@Schema(example = "F", description = "The PNE_TIPOPERS")
    private String tipoPers;
	
	/** PNE_CODPERS. */
	@Schema(example = "F", description = "The PNE_CODPERS")
	private String codPers;
	
	/** PNA_IMPAPRB. */
	@Schema(example = "1000.00", description = "The PNA_IMPAPRB")
	private String ammount;

	/** PNA_PLAZODOC. */
	@Schema(example = "3", description = "The PNA_PLAZODOC")
	private int term;
	
	private RiskLimitOutput limitOutput;
	
	private InputCreatePilot createPilot;
	
	private InvoiceAppFinality invoiceAppf;
	
	private BigDecimal maxLimit;
	
	private boolean isMaxLimitLimit;
}