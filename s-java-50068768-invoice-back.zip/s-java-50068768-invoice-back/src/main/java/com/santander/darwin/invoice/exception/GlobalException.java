package com.santander.darwin.invoice.exception;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.UUID;

/**
 * GlobalException.java
 *
 * @author igndom
 *
 */
public class GlobalException extends RuntimeException {

	private static final long serialVersionUID = 8889113249840650980L;

	private final UUID uuid;
	private final long timestamp;
	private final String status;
	private final String lang;
	private final String code;
	private final String message;
	private final String errorAppType;
	private final String pathTarget;

	/**
	 * Constructor
	 *
	 * @param lang String
	 */
	public GlobalException(String lang) {
		super();
		this.uuid = UUID.randomUUID();
		this.timestamp = System.currentTimeMillis();
		this.status = null;
		this.lang = lang;
		this.code = null;
		this.message = null;
		this.errorAppType = null;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param uuid      UUID
	 * @param timestamp long
	 * @param lang      String
	 */
	public GlobalException(UUID uuid, long timestamp, String lang) {
		super();
		this.uuid = uuid;
		this.timestamp = timestamp;
		this.status = null;
		this.lang = lang;
		this.code = null;
		this.message = null;
		this.errorAppType = null;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param uuid      UUID
	 * @param timestamp long
	 * @param code      String
	 * @param lang      String
	 */
	public GlobalException(UUID uuid, long timestamp, String code, String lang) {
		super();
		this.uuid = uuid;
		this.timestamp = timestamp;
		this.status = null;
		this.lang = lang;
		this.code = code;
		this.message = null;
		this.errorAppType = null;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param uuid      UUID
	 * @param timestamp long
	 * @param status    String
	 * @param code      String
	 * @param lang      String
	 */
	public GlobalException(UUID uuid, long timestamp, String status, String code, String lang) {
		super();
		this.uuid = uuid;
		this.timestamp = timestamp;
		this.status = status;
		this.lang = lang;
		this.code = code;
		this.message = null;
		this.errorAppType = null;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param uuid      UUID
	 * @param timestamp long
	 * @param status    String
	 * @param code      String
	 * @param message   String
	 * @param lang      String
	 */
	public GlobalException(UUID uuid, long timestamp, String status, String code, String message, String lang) {
		super();
		this.uuid = uuid;
		this.timestamp = timestamp;
		this.status = status;
		this.lang = lang;
		this.code = code;
		this.message = message;
		this.errorAppType = null;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param code         String
	 * @param lang         String
	 * @param errorAppType String
	 */
	public GlobalException(String code, String lang, String errorAppType) {
		super();
		this.uuid = UUID.randomUUID();
		this.timestamp = System.currentTimeMillis();
		this.status = null;
		this.lang = lang;
		this.code = code;
		this.message = null;
		this.errorAppType = errorAppType;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param code         String
	 * @param lang         String
	 * @param message      String
	 * @param errorAppType String
	 */
	public GlobalException(String code, String lang, String message, String errorAppType) {
		super();
		this.uuid = UUID.randomUUID();
		this.timestamp = System.currentTimeMillis();
		this.status = null;
		this.lang = lang;
		this.code = code;
		this.message = message;
		this.errorAppType = errorAppType;
		this.pathTarget = null;
	}

	/**
	 * Constructor
	 *
	 * @param code         String
	 * @param lang         String
	 * @param message      String
	 * @param errorAppType String
	 * @param pathTarget   String
	 */
	public GlobalException(String code, String lang, String message, String errorAppType, String pathTarget) {
		super();
		this.uuid = UUID.randomUUID();
		this.timestamp = System.currentTimeMillis();
		this.status = null;
		this.lang = lang;
		this.code = code;
		this.message = message;
		this.errorAppType = errorAppType;
		this.pathTarget = pathTarget;
	}

	/**
	 * @return the uuid
	 */
	public UUID getUuid() {
		return uuid;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * @return the message
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * @return the errorAppType
	 */
	public String getErrorAppType() {
		return errorAppType;
	}

	/**
	 * @return the pathTarget
	 */
	public String getPathTarget() {
		return pathTarget;
	}

	@JsonIgnore
	@Override
	public StackTraceElement[] getStackTrace() {
		return super.getStackTrace();
	}

	@Override
	public String toString() {
		return "GlobalException [uuid=" + uuid + ", timestamp=" + timestamp + "]";
	}

}
