package com.santander.darwin.invoice.model.model200;

import com.santander.darwin.invoice.model.CommonModel200;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * TaxSummary.java
 *
 * @author igndom
 *
 */
@Getter
@Setter
public class TaxSummary {

	// idSociety
	private CommonModel200 idSociety;
	
	// management
	private List<CommonModel200> management;
	
	// shareHolding
	private List<ShareHolding> shareHolding;
	
	// financialStatement
	private FinancialStatement financialStatement;

}
