package com.santander.darwin.invoice.model.consult_kpis;

/**
 * The Class ScoreKpis.
 */
public class ScoreKpis {

    /** The score name. */
    private String scoreName;
    
    /** The score value. */
    private Double scoreValue;
    
    /** The delphi score. */
    private String delphiScore;
	
	/**
	 * Gets the score name.
	 *
	 * @return the score name
	 */
	public String getScoreName() {
		return scoreName;
	}
	
	/**
	 * Sets the score name.
	 *
	 * @param scoreName the new score name
	 */
	public void setScoreName(String scoreName) {
		this.scoreName = scoreName;
	}
	
	/**
	 * Gets the score value.
	 *
	 * @return the score value
	 */
	public Double getScoreValue() {
		return scoreValue;
	}
	
	/**
	 * Sets the score value.
	 *
	 * @param scoreValue the new score value
	 */
	public void setScoreValue(Double scoreValue) {
		this.scoreValue = scoreValue;
	}
	
	/**
	 * Gets the delphi score.
	 *
	 * @return the delphi score
	 */
	public String getDelphiScore() {
		return delphiScore;
	}
	
	/**
	 * Sets the delphi score.
	 *
	 * @param delphiScore the new delphi score
	 */
	public void setDelphiScore(String delphiScore) {
		this.delphiScore = delphiScore;
	}
	

}
