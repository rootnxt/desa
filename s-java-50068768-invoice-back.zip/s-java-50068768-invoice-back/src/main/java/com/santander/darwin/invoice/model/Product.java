package com.santander.darwin.invoice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Product.java
 *
 * @author igndom
 *
 */
@NoArgsConstructor
@Getter
@Setter
public class Product {

	// Variables de producto
	private String type;
	private String subType;
	private String reference;

}
